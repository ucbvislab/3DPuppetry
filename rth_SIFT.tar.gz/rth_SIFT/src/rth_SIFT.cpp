/*
 * rth_SIFT.cpp
 *
 *  Created on: 2011-06-15
 *  	Author: Robin Held
 *  	See LICENSE.txt for copyright info.
 */

#include "SIFTPose.h"
#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <SiftGPU.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <image_transport/subscriber_filter.h>
#include <boost/filesystem/path.hpp>
#include <ros/ros.h>
#include <ros/node_handle.h>
#include <ros/package.h>
#include <std_msgs/Int32.h>
#include <std_msgs/Float32MultiArray.h>
#include <sensor_msgs/Image.h>
#include <cv_bridge/CvBridge.h>
#include <image_transport/image_transport.h>
#include <Eigen/Core>
#include "pcl_ros/point_cloud.h"

#include <cstdio>
#include <deque>

using boost::lexical_cast;

namespace fs = boost::filesystem;
using namespace std;
using namespace sensor_msgs;
using namespace message_filters;

const float min_pose_distance = 0.1;			// Minimum distance between two poses to be published
vector<SIFTPoseCollection>	pose_collections;	// Holds all the stored pose collections.

/*
 *  Main class that maintains loaded pose templates, matches them to the incoming Kinect feed,
 *  and publishes the estimated poses.
 */
class SIFTHandler {
public:

	SIFTHandler(const ros::NodeHandle& node_handle,const ros::NodeHandle& load_node_handle);
	virtual ~SIFTHandler();
	void load_ros_params(ros::NodeHandle nh_load);
	void start();

private:
	////////////////////////////
	// ROS-message variables
	ros::NodeHandle m_node;
	ros::NodeHandle load_node;
	image_transport::ImageTransport it;
	typedef image_transport::SubscriberFilter ImageSubscriber;
	ImageSubscriber color_sub;
	ImageSubscriber depth_sub;
	typedef message_filters::sync_policies::ApproximateTime<sensor_msgs::Image, sensor_msgs::Image> MySyncPolicy;
	message_filters::Synchronizer< MySyncPolicy > sync;
	ros::Publisher match_pub;
	ros::Publisher cloud_pub;
	sensor_msgs::CvBridge m_cvBridge;


	////////////////////////////
	// SIFT extraction and matching
	SiftGPU			sift_extractor;
	SiftMatchGPU 	sift_matcher;
	struct siftOptions
	{
		/*
		 * the defaults listed here should match the SiftGPU defaults
		 */
		siftOptions() : firstOctave(0), numOctaves(5),dogThreshold(.0067), edgeThreshold(10), filterWidthFactor(4) {}
		siftOptions(const int o) : firstOctave(o), numOctaves(5), dogThreshold(.0067), edgeThreshold(10), filterWidthFactor(4) {}

		int firstOctave;
		int	numOctaves;
		double dogThreshold;
		double edgeThreshold;
		double filterWidthFactor;
		int	numOrientations;
	};
	siftOptions sift_opts;

	////////////////////////////
	// Storage for SIFT points
	vector<float> descs_source;
	vector<float> descs_target;
	vector<SiftGPU::SiftKeypoint> keys_source;
	vector<SiftGPU::SiftKeypoint> keys_target;
	int 	num_keys_target;
	int	 	num_keys_source;
	int 	nmatch;
	float 	max_match_distance;
	float 	max_match_ratio;

	int 	bin_cutoff;			// The minimum number of points in a bin to consider a pose a match to the input image
	double 	RANSAC_threshold;
	int 	manual_match;

	////////////////////////////
	// SIFT pose collectors
	SIFTPose* 			source;
	SIFTPose* 			target;
	bool 				match_to_loaded_poses;
	int 				matched_pose;
	vector<int> 		old_matches;		// Used for debugging RANSAC algorithm
	vector<float> 		all_poses;

	////////////////////////////
	// Kinect-data variables
	float	focal_length;
	int 	frames;
	int		refresh_rate;	// Frequency in Hz of refreshes


	////////////////////////////
	// Image handling
	std::string m_windowName;

	// The following data structures are used to capture, manipulate, and/or display images
	// from the stored templates or the Kinect
	IplImage*	loaded_img;
	IplImage* 	rgb_img;
	IplImage* 	mono8Img;
	IplImage* 	raw_capturedImg;
	IplImage* 	flipped_image;
	IplImage* 	combined_image;
	IplImage* 	combined_image_BW;
	IplImage* 	database_image;
	IplImage*	to_screen;

	// Names and locations of files
	std::string input_image;
	std::string files_path;
	std::string pose_file_path;
	std::string captured_image;
	vector<std::string> pose_load_names_vector;
	int 		num_collections;

	////////////////////////////
	// User-set parameters
	bool 		show_feed_points;		// Just take in the rgb image feed and label SIFT points?
	// Debug / test parameters:
	bool 		test_template_transform;//
	bool 		use_homography;			// False = use affine transform
	bool 		use_RANSAC;				// False = use Hough transform
	bool 		keyboard_input;
	bool 		show_windows;
	bool 		pose_feed_only;
	bool 		freeze_depth;


	////////////////////////////
	// Other

	// Debugging data structures
	bool freeze_rgb;
	IplImage* frozen_rgb;
	bool captured_rgb;
	float * frozen_depth;
	bool captured_depth;

	// For timing functions
	timeval tracker_time;

	////////////////////////////
	// Private functions
	void publishPose();
	void imageUpdate(const sensor_msgs::ImageConstPtr& rgb_msg, const sensor_msgs::ImageConstPtr& depth_msg);
	void saveImage(std::string im_name,IplImage *img_i); // Used for debugging
};


/**
 * SIFTHandler Constructor
 *
 * \param node_handle 		ROS node handle for communications
 * \param load_node_handle 	ROS node for loading parameters
 */
SIFTHandler::SIFTHandler(const ros::NodeHandle& node_handle, const ros::NodeHandle& load_node_handle):
		m_node(node_handle), load_node(load_node_handle),it(m_node), color_sub( it, "rgb_feed", 1 ),
		depth_sub( it, "depth_feed", 1 ), sync( MySyncPolicy( 10 ), color_sub, depth_sub) {

	manual_match = 0;
	// Load parameters
	load_ros_params(load_node);

	// Setup SIFT extractor
	const string sift_first_octave_string = boost::lexical_cast<string>(sift_opts.firstOctave),
		sift_num_octaves_string = lexical_cast<string>(sift_opts.numOctaves),
		dogThreshStr = lexical_cast<string>(sift_opts.dogThreshold),
		edgeThreshStr = lexical_cast<string>(sift_opts.edgeThreshold),
		filterWidthFactorStr = lexical_cast<string>(sift_opts.filterWidthFactor),
		numFeatureOrientationsStr = lexical_cast<string>(sift_opts.numOrientations);
	boost::array<char*, 19> argv =
	{{
		(char*)"-fo", (char*)sift_first_octave_string.c_str(),
		(char*)"-no", (char*)sift_num_octaves_string.c_str(),
		(char*)"-t", (char*)dogThreshStr.c_str(),
		(char*)"-e", (char*)edgeThreshStr.c_str(),
		(char*)"-f", (char*)filterWidthFactorStr.c_str(),
		(char*)"-v", (char*)"0",
////		(char*)"-p ", (char*)"640x480",
////		(char*)"-dw", (char*)"1.5",
////		(char*)"-s", (char*)"1",
		(char*)"-m –mo", (char*)numFeatureOrientationsStr.c_str(),
////		(char*)"-tc2",
		(char*)"-pack ",
		(char*)"-cuda", (char*)"0",
		(char*)"-di ",
//		(char*)"-nogl "
	}};

	sift_extractor.ParseParam(argv.size(), argv.data());
	int support = sift_extractor.CreateContextGL();
	assert(support == SiftGPU::SIFTGPU_FULL_SUPPORTED);
	sift_extractor.AllocatePyramid(640, 480);

	// Setup SIFT matcher
	sift_matcher.SetMaxSift(4096);
	// Verify current OpenGL Context and do initialization
	if(sift_matcher.VerifyContextGL() == 0) return;
	// Default parameters for match metrics
	max_match_distance 	= 0.8;
	max_match_ratio 	= 0.8;

	focal_length 		= 525; // Set to 1100 for 1280x960 (default is 640x480)

	// Opencv Variables
	frames = 0;
	RANSAC_threshold = 1;


	if (show_windows && !pose_feed_only){
	m_node.param("window_name", m_windowName, m_node.resolveName("image"));
		cvNamedWindow(m_windowName.c_str(), 1);
		cvNamedWindow("RGB_Feed", 1);
		cvNamedWindow("Matches", 1);
		cvNamedWindow("Overlay", 1);
		cvNamedWindow("Segmentation",1);

		cvStartWindowThread();
	}

	old_matches.push_back(0);
	old_matches.push_back(0);
	old_matches.push_back(0);
	old_matches.push_back(0);

	mono8Img 			= cvCreateImage( cvSize(640,480), IPL_DEPTH_8U, 1);
	rgb_img				= cvCreateImage( cvSize(640,480), IPL_DEPTH_8U, 3);
	raw_capturedImg 	= cvCreateImage( cvSize(640,480), IPL_DEPTH_8U, 3);
	to_screen			= cvCreateImage( cvSize(640,480), IPL_DEPTH_8U, 3);
	combined_image 		= cvCreateImage( cvSize(640*2,480), IPL_DEPTH_8U, 3);
	combined_image_BW 	= cvCreateImage( cvSize(640*2,480), IPL_DEPTH_8U, 1);
	database_image 		= cvCreateImage( cvSize(640,480), IPL_DEPTH_8U, 3 );
	flipped_image		= cvCreateImage( cvSize(640,480), IPL_DEPTH_8U, 3 );
	if (freeze_rgb)
	{
		frozen_rgb	= cvCreateImage( cvSize(640,480), IPL_DEPTH_8U, 3 );
		captured_rgb = false;
	}

	if (freeze_depth)
	{
		frozen_depth 	= new float[640*480];
		captured_depth 	= false;
	}

	num_collections = 0;

	// Load poses
	for (uint p=0;p<pose_load_names_vector.size();p++)
	{
		ROS_INFO_STREAM("Loading pose collection " << p+1 << " of " << pose_load_names_vector.size());
		SIFTPoseCollection temp;
		temp.loadPoses(files_path, pose_load_names_vector[p], &sift_extractor);
		temp.bin_cutoff = bin_cutoff;
		pose_collections.push_back(temp);
		num_collections++;
	}

	// Subscribe to kinect RGB and depth feeds
	// Setup synchronizing message filter for the RGB and depth images
	sync.registerCallback( boost::bind( &SIFTHandler::imageUpdate, this, _1, _2) );
	// Setup publisher that will broadcast the matched pose(s)
	match_pub = m_node.advertise<std_msgs::Float32MultiArray>("pose_feed", 3);
}


/**
 * SIFTHandler Destructor
 */
SIFTHandler::~SIFTHandler() {
    cvDestroyWindow(m_windowName.c_str());
}

/*
 * Publish 4x4 matrices representing the rough poses of puppets detecte in the image feed.
 * Used by kinect_tracker to initialize tracking of each puppet.
 */
void SIFTHandler::publishPose()
{
		std_msgs::Float32MultiArray match_msg;
		match_msg.data = all_poses;
		match_pub.publish(match_msg);
}


/*
 * Primary function. Takes images from Kinect and finds matches to the stored templates.
 *
 * \param rgb_msg	RGB image from the Kinect
 * \param depth_msg Corresponding depth map from the Kinect
 */
void
SIFTHandler::imageUpdate(const sensor_msgs::ImageConstPtr& rgb_msg, const sensor_msgs::ImageConstPtr& depth_msg)
{
//	double start_update;
//	double intermediate_update;
//	double finish_update;
//	double before_image;
//	double start_detection;
//	double finish_detection;
//	gettimeofday(&tracker_time, NULL);
//	start_update 	= tracker_time.tv_sec+(tracker_time.tv_usec/1000000.0);
	frames++;

	// Used to test effect of image noise on template matches and transform estimates
	if (!freeze_rgb || (freeze_rgb && !captured_rgb))
	{
		raw_capturedImg = m_cvBridge.imgMsgToCv(rgb_msg,"bgr8");
		if (freeze_rgb && frames > 3)
		{
			cvCopy(raw_capturedImg,frozen_rgb);
			captured_rgb = true;
		}
	} else {
		cvCopy(frozen_rgb,raw_capturedImg);
	}
	const float* depth_data;
	if (!freeze_depth || (freeze_depth && !captured_depth))
	{
		depth_data = reinterpret_cast<const float*>(&depth_msg->data[0]);
		if (freeze_depth && frames > 3)
		{
			memcpy(frozen_depth,depth_data,640*480*sizeof(float));
			captured_depth = true;
		}
	} else {
		depth_data = (const float*) frozen_depth;
	}

	rgb_img = raw_capturedImg;

//	gettimeofday(&tracker_time, NULL);
//	before_image = tracker_time.tv_sec+(tracker_time.tv_usec/1000000.0);

	// Convert incoming image to B&W for use by SIFT extractor
	cvCvtColor( rgb_img, mono8Img, CV_RGB2GRAY );
	int width 	= mono8Img->width;
	int height 	= mono8Img->height;
	char *data 	= mono8Img->imageData;

//	gettimeofday(&tracker_time, NULL);
//	start_detection 	= tracker_time.tv_sec+(tracker_time.tv_usec/1000000.0);

	// Extract SIFT keys from incoming image
	sift_extractor.RunSIFT (width, height, data, GL_LUMINANCE, GL_UNSIGNED_BYTE);
	num_keys_target = sift_extractor.GetFeatureNum();//get feature count
	descs_target.clear();
	descs_target.resize(128*num_keys_target);
	keys_target.clear();
	keys_target.resize(num_keys_target);
	sift_extractor.GetFeatureVector(&keys_target[0], &descs_target[0]);

//	gettimeofday(&tracker_time, NULL);
//	finish_detection 	= tracker_time.tv_sec+(tracker_time.tv_usec/1000000.0);
//	cout << "Detection step: " << (finish_detection - start_detection) << " sec" << endl;

	// Case where we want to just publish the transform estimates for use by kinect_tracker
    if (pose_feed_only){
		if (match_pub.getNumSubscribers() > 0){
			Transform3f eigen_transform;
			vector<Vector3f> xformed_pts;
			vector<Vector3f> translations;
			vector<Transform3f> transforms;
			vector<int> matched_collections;
			vector<int> max_bin_sizes;

			all_poses.clear();
			for (int p=0;p<num_collections;p++)
			{
				int match_index = -1;
				// Find the best-matched image template within this collection
				int bin_result = pose_collections[p].findBestMatchBinOnly(keys_target, descs_target, &sift_matcher,max_match_distance,max_match_ratio, match_index);

				if (match_index > -1)
				{
					// If the best template's number of matches passes the threshold, recover the transform
					SIFTPose match = pose_collections[p].poses[match_index];
					int found_transform = pose_collections[p].getTranslation(keys_target, match_index,eigen_transform,depth_data,
												xformed_pts);
					// (Check that there were enough valid points to calculate the translation)
					if (found_transform)
					{
						Transform3f output_pose = eigen_transform*pose_collections[p].poses[match_index].transform_matrix;
						Vector3f translation 	= output_pose.translation();
						bool add_to_output = true;

						// Check whether this translation is very close to a
						for (uint t=0;t<translations.size();t++)
						{
							if ((translation-translations[t]).norm() < min_pose_distance)
							{
								// This pose is very close to a previously found pose.
								// If its associated match bin has more entries than the existing pose, replace the latter.
								if (bin_result > max_bin_sizes[t])
								{
//									ROS_INFO_STREAM("Replaced pose " << translation-translations[t]).norm());
									max_bin_sizes[t] 		= bin_result;
									translations[t]  		= translation;
									transforms[t]	 		= output_pose;
									matched_collections[t] 	= p;
									add_to_output 			= false;
								}
							}
						}

						if (add_to_output)
						{
							// No previously found poses were near the current one
							matched_collections.push_back(p);
							translations.push_back(translation);
							max_bin_sizes.push_back(bin_result);
							transforms.push_back(output_pose);
						}
					}
				}
			}

			// Concatenate poses with collection ID's for publishing in a single a ROS message.
			for (uint p=0; p<transforms.size(); p++)
			{
				all_poses.push_back(matched_collections[p]);
				for (uint i=0;i<4; i++)
				{
					for (uint j=0; j<4; j++)
					{
						all_poses.push_back(transforms[p].matrix()(j,i));
					}
				}
			}

			// If no poses were estimated, just published "-1"
			if (all_poses.size() == 0)
				all_poses.push_back(-1);

			// Publish the message
			publishPose();
		}
	} else {
		// NOTE: The rest of this code was used for testing purposes.
		// It may not be complete or work as advertised.

		// Initialize affine-transform array
		Mat affine_transform = Mat::zeros(2,3,CV_32F);
		Mat homography		 = Mat::zeros(3,3,CV_32F);
		vector<int> transform_indices (4,0);
		if (test_template_transform)
		{
			// Used to visually assess matches between incoming image feed and store template poses

			// For example videos:
			int small_width = 293;
			int small_height = 220;

			combined_image = cvCreateImage( cvSize( 640+312, 480 ), IPL_DEPTH_8U, 3 );
			cvZero(combined_image);
			cvSetImageROI(combined_image, cvRect(0, 0, 640, 480));
			cvCopy(raw_capturedImg,combined_image);
			for (int p=0;p<2;p++)
			{
				Transform3f eigen_transform;
				int 		match_index = -1;
				vector<Vector3f> xformed_pts;

				pose_collections[p].findBestMatchBinOnly(keys_target, descs_target, &sift_matcher,max_match_distance,max_match_ratio, match_index);
				if (match_index > -1)
				{
					SIFTPose match  = pose_collections[p].poses[match_index];

					IplImage* img_downsized = cvCreateImage( cvSize( small_width, small_height ), IPL_DEPTH_8U, 3 );

//					if (p == 0)
//					{
//						cvSetImageROI(combined_image, cvRect(0, 0, 640, 480));
//						cvCopy(raw_capturedImg,combined_image);
//					}
					cvSetImageROI(combined_image, cvRect(640+10, small_height*p+(p+1)*10+p*10, small_width, small_height));
					cvResize(match.image, img_downsized);
					cvCopy(img_downsized,combined_image);
					cvResetImageROI(combined_image);

					sift_matcher.SetDescriptors(0, match.num_keys, &match.descs[0]);
					sift_matcher.SetDescriptors(1, num_keys_target, &descs_target[0]);
					int match_buf[4096][2];
					nmatch = sift_matcher.GetSiftMatch(4096, match_buf, max_match_distance,max_match_ratio,1);

					// Draw lines between matches
					for(uint i=0; i< match.largest_bin_indices.size(); i++){
						SiftGPU::SiftKeypoint pt = keys_target[match.matches[match.largest_bin_indices[i]][1]];;
						SiftGPU::SiftKeypoint pt2 = match.keys[match.matches[match.largest_bin_indices[i]][0]];
						CvPoint center = cvPoint((int)round(pt.x),(int)round(pt.y));
						CvPoint center2 = cvPoint((int)round(pt2.x*0.46)+640+10,(int)round(pt2.y*0.46)+small_height*p+(p+1)*10+p*10);
						if (p == 0)
						{
							cvCircle(combined_image,center,3, CV_RGB(255,100,100),-1);
							cvCircle(combined_image,center,3, CV_RGB(255,0,0));
							cvCircle(combined_image,center2,2, CV_RGB(255,100,100),-1);
							cvCircle(combined_image,center2,2, CV_RGB(255,0,0));
						} else {
							cvCircle(combined_image,center,3, CV_RGB(155,255,155),-1);
							cvCircle(combined_image,center,3, CV_RGB(0,175,0));
							cvCircle(combined_image,center2,2, CV_RGB(155,255,155),-1);
							cvCircle(combined_image,center2,2, CV_RGB(0,175,0));
						}

					}
				}
			}
			if (show_windows) {
				cvShowImage("Matches",combined_image);
			}

		} else if (match_to_loaded_poses){

//					gettimeofday(&tracker_time, NULL);
//					double start_search 	= tracker_time.tv_sec+(tracker_time.tv_usec/1000000.0);

				int 		match_index = -1;
				SIFTPose 	match;
				uint			largest_bin_collection = 0;
				for (int i = 0; i<num_collections;i++){
					int temp_match_index;
					pose_collections[i].findBestMatchBinOnly(keys_target, descs_target, &sift_matcher,max_match_distance,max_match_ratio, temp_match_index);

					if (match_index != -1)
					{
						SIFTPose temp_match = pose_collections[i].poses[match_index];
						if (temp_match.largest_bin_indices.size() > largest_bin_collection){
							largest_bin_collection = temp_match.largest_bin_indices.size();
							match = temp_match;
							match_index = temp_match_index;
						}
					}
				}

//					gettimeofday(&tracker_time, NULL);
//					double finish_search = tracker_time.tv_sec+(tracker_time.tv_usec/1000000.0);

//					cout << "Search step: " << (finish_search - start_search) << " sec" << endl;
//					cout << "Found match" << endl;
//					cout << "Bin size: " << match.largest_bin_indices.size() << endl;

				cvCopyImage(rgb_img,to_screen);

				if (largest_bin_collection > 0)
				{
					cvCopyImage(match.image,flipped_image);
					cvFlip(flipped_image,NULL,-1);
					if (show_windows)
						cvShowImage("Overlay",flipped_image);

					// Mark up image with matches
					for(unsigned int i=0; i < match.largest_bin_indices.size(); i++){
						SiftGPU::SiftKeypoint pt = keys_target[match.matches[match.largest_bin_indices[i]][1]];
						//draw a circle on the image to be displayed
						CvPoint center = cvPoint((int)round(pt.x),(int)round(pt.y));
						cvCircle(to_screen,center,1,CV_RGB(0,0,255));
					}
					cvFlip(to_screen,NULL,-1);


					std_msgs::Int32 match_msg;
					match_msg.data = match_index;

					match_pub.publish(match_msg);

					if (show_windows){
						if (match_index >= 0){
							// Create combined image displaying matches.
							cvSetImageROI(combined_image, cvRect(0, 0, 640, 480));
							cvCopy(rgb_img,combined_image);
							cvSetImageROI(combined_image, cvRect(640, 0, 640, 480));
							cvCopy(match.image,combined_image);
							cvResetImageROI(combined_image);


							// Draw lines between matches
							for(uint i=0; i< match.largest_bin_indices.size(); i++){
								SiftGPU::SiftKeypoint pt = keys_target[match.matches[match.largest_bin_indices[i]][1]];
								SiftGPU::SiftKeypoint pt2 = match.keys[match.matches[match.largest_bin_indices[i]][0]];
								CvPoint center = cvPoint((int)round(pt.x),(int)round(pt.y));
								CvPoint center2 = cvPoint((int)round(pt2.x)+640,(int)round(pt2.y));
								cvLine(combined_image,center,center2,CV_RGB(255,255,255),1);
							}
							cvCvtColor( combined_image, combined_image_BW, CV_RGB2GRAY );

							cvShowImage("Matches",combined_image_BW);

						}
					}
				}

		} else if (show_feed_points){
			// Used to just display the detected SIFT keys in the incoming feed.

			cvCvtColor( rgb_img, mono8Img, CV_RGB2GRAY );

			int width 	= mono8Img->width;
			int height 	= mono8Img->height;
			char *data 	= mono8Img->imageData;

			sift_extractor.RunSIFT (width, height, data, GL_LUMINANCE, GL_UNSIGNED_BYTE);

			int num = sift_extractor.GetFeatureNum();
			descs_target.clear();
			descs_target.resize(128*num);
			keys_target.clear();
			keys_target.resize(num);
			sift_extractor.GetFeatureVector(&keys_target[0], &descs_target[0]);

			to_screen = rgb_img;
			// Display keys in target image
			for(uint i=0; i < keys_target.size(); i++){
				SiftGPU::SiftKeypoint pt = keys_target[i];
				CvPoint center = cvPoint((int)round(pt.x),(int)round(pt.y));
				cvCircle(to_screen,center,1,CV_RGB(0,0,255));
			}
		}
	}

	// Show input feed
	if (show_windows)
		cvShowImage("RGB_Feed", raw_capturedImg);

	// Only used during debugging
	if (keyboard_input) {
		int key;
		key=cvWaitKey(50);	// Add 1048576 to smaller numbers
		switch(key){
			/* Esc */
			case 27:
			case 1048603:
				ROS_INFO ("EXIT");
				exit(0);
				break;

			/* Page up */
			case 65365:
			case 1113941:
				if (manual_match < 35)
				{
					manual_match++;
				} else {
					manual_match = 0;

				}
//					max_match_ratio += 0.02;
//					cout << "Max match ratio: " << max_match_ratio << endl;
				break;

			/* Page down */
			case 65366:
			case 1113942:
//					max_match_ratio -= 0.02;
//					cout << "Max match ratio: " << max_match_ratio << endl;
				if (manual_match > 0)
				{
					manual_match--;
				} else {
					manual_match = 35;

				}
				break;

			/* Up arrow */
			case 65362:
			case 1113938:
				max_match_distance += 0.02;
				cout << "Max match distance: " << max_match_distance << endl;
				break;

			/* Down arrow*/
			case 65364:
			case 1113940:
				max_match_distance -= 0.02;
				cout << "Max match distance: " << max_match_distance << endl;
				break;

			/* R */
			case 82:
			case 1048658:
				RANSAC_threshold += 0.1;
				cout << "RANSAC threshold: " << RANSAC_threshold << endl;
				break;

			/* r */
			case 114:
			case 1048690:
				RANSAC_threshold -= 0.1;
				cout << "RANSAC threshold: " << RANSAC_threshold << endl;
				break;

			/* c */
			case 99:
			case 1048675:
				break;

			/* s */
			case 115:
			case 1048691:
				break;

		}
	}
//	double start_pc;
//	double finish_pc;


//	cout << "Image capture: " << (before_image - start_update) << " sec" << endl;
//	cout << "Image conversion: " << (start_detection - before_image) << " sec" << endl;
//	cout << "Detection step: " << (finish_detection - start_detection) << " sec" << endl;
//	cout << "Filler: " << (start_pc - finish_detection) << " sec" << endl;
//	cout << "Point cloud creation: " << (finish_pc - start_pc) << " sec" << endl;
//	gettimeofday(&tracker_time, NULL);
//	finish_update 	= tracker_time.tv_sec+(tracker_time.tv_usec/1000000.0);
//	cout << "Update duration " << (finish_update - start_update) << " sec" << endl;
}


/*
 * Start running the ROS node
 */
void SIFTHandler::start()
{
	loaded_img = cvLoadImage(input_image.c_str(), CV_LOAD_IMAGE_UNCHANGED );
	ros::Rate loop_rate(refresh_rate);
	while (ros::ok()) {
		ros::spinOnce();
		loop_rate.sleep();
	}
}


/*
 *  Load user-set parameters
 *
 *  \param nh_load 	ROS node handle for loading parameters
 */
void SIFTHandler::load_ros_params(ros::NodeHandle nh_load) {
	show_feed_points = false;

	std::string short_pose_load_names;

	nh_load.param("files_path", files_path, std::string(""));
	nh_load.param("pose_load_names", short_pose_load_names, std::string(""));

	// These parameters determine what features are extracted
	nh_load.param("sift_first_octave",sift_opts.firstOctave,-1);
	nh_load.param("sift_num_octaves",sift_opts.numOctaves,5);
	nh_load.param("sift_dog_threshold",sift_opts.dogThreshold ,0.0067);
	nh_load.param("sift_edge_threshold",sift_opts.edgeThreshold ,10.0);
	nh_load.param("sift_filter_width_factor",sift_opts.filterWidthFactor ,4.0);
	nh_load.param("sift_num_feature_orientations",sift_opts.numOrientations ,2);
	// Minimum number of matched features in a bin in order to consider a pose correctly
	// matchd to the incoming rgb feed:
	nh_load.param("bin_cutoff",bin_cutoff,10);

	// For debugging
	nh_load.param("freeze_rgb",freeze_rgb,false);
	nh_load.param("freeze_depth",freeze_depth,false);

	// Old / deprecated
	nh_load.param("refresh_rate",refresh_rate,60);
	nh_load.param("input_image", input_image, std::string(""));
	nh_load.param("keyboard_input", keyboard_input, false);
	nh_load.param("windows_on", show_windows, false);
	nh_load.param("pose_feed_only", pose_feed_only, true);
	nh_load.param("show_feed_points", show_feed_points, false);
	nh_load.param("match_to_loaded_poses",match_to_loaded_poses,false);
	nh_load.param("test_template_transform",test_template_transform,false);
	nh_load.param("use_homography",use_homography,false);
	nh_load.param("use_RANSAC",use_RANSAC,true);

	int poses = 0;

	// Load ply file names
	if (short_pose_load_names.empty())
	{
		ROS_WARN("Pose files incorrectly set.");
	}else{
		std::stringstream ss(short_pose_load_names);
		char str[200];
		std::string temp_name;
		while (ss.getline(str,50,','))
		{
			temp_name.append(str);
			pose_load_names_vector.push_back(temp_name);
			// A new ply file indicates a new model to be tracked
			poses++;
			temp_name = "";
		}
	}

}

/*
 * Main function that loads parameters and starts the ROS node
 */
int main(int argc, char** argv)
{

	ros::init (argc, argv,"rth_SIFT",ros::init_options::AnonymousName);
	ros::NodeHandle ros_node;
	ros::NodeHandle nh_load("~");

	ROS_INFO ("Starting SIFT pose estimator...");

	// Wait for kinect to start publishing
	*ros::topic::waitForMessage<sensor_msgs::PointCloud2>("/camera/rgb/points_seg");

	SIFTHandler node(ros_node,nh_load);

	node.start();
	return 0;
}

///////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////

/*
 *  Used previously for testing
 */
void SIFTHandler::saveImage(std::string im_name,IplImage *img_in){
	captured_image = files_path;
	captured_image.append(im_name);
	captured_image.append(".jpg");
	cvSaveImage(captured_image.c_str(), img_in);
}
