/*
 * rth_SIFT.cpp
 *
 *  Created on: 2011-06-15
 *  	Author: Robin Held
 *  	See LICENSE.txt for copyright info.
 *
 */

#include "SIFTPose.h"

/////////////////////////////////////////
/////////////////////////////////////////
/***
 * SIFTPose Class Functions
 ***/
/////////////////////////////////////////
/////////////////////////////////////////

SIFTPose::~SIFTPose(){};

SIFTPose::SIFTPose(){};

/**
 * SIFTPose Constructor
 *
 * \param path 		Folder containing the new pose's data
 * \param name 		The base name for the pose's image and depth map
 * \param extractor The SIFT extractor to be used to recover the image's SIFT keys
 */
SIFTPose::SIFTPose(std::string path, std::string name, int num,	SiftGPU* extractor) {
	// Loads an image, depth map, and pose estimate

//	timeval tracker_time;
//	double start;
//	double finish;
//	gettimeofday(&tracker_time, NULL);
//	start 	= tracker_time.tv_sec+(tracker_time.tv_usec/1000000.0);

	// Setup folder
	std::string new_folder = path;
	new_folder.append("/");
	new_folder.append(name);
	new_folder.append("/");
	fs::path p(new_folder);
	if (!fs::exists(p)) {
		ROS_WARN("POSE FOLDER DOES NOT EXIST");
		return;
	}

	// Name base
	std::string file_name = new_folder;
	file_name.append(name);
	char number[50];
	sprintf(number, "%d", num);
	file_name.append(number);

	// Load image
	std::string image_name = file_name;
	image_name.append(".png");
	if (!fs::exists(image_name)) {
		ROS_INFO_STREAM(image_name << " DOES NOT EXIST");
	} else {
		image = cvLoadImage(image_name.c_str(), CV_LOAD_IMAGE_COLOR);
	}

	// Load focal length, if available, for interpreting depth map:
	float focal_length;
	std::string settings_name = file_name;
	settings_name.append("settings.yml");
	if (!fs::exists(settings_name)) {
		if (image->width == 640) {
			focal_length = 525;
		} else {
			focal_length = 1050;
		}
	} else {
		FileStorage fs(settings_name.c_str(), FileStorage::READ);
		fs["focal_length"] >> focal_length;
		fs.release();
	}
	pose_depth_constant = 1.0f / focal_length;
	image_depth_constant = 1.0f/525.0f;

//	gettimeofday(&tracker_time, NULL);
//	double image_load 	= tracker_time.tv_sec+(tracker_time.tv_usec/1000000.0);
//	ROS_INFO_STREAM("Time to load image: " << image_load - start);

	// Run SIFT extractor on image and save the keys & descriptors
	IplImage *mono8Img = cvCreateImage(cvSize(image->width, image->height),
			image->depth, 1);
	cvCvtColor(image, mono8Img, CV_BGR2GRAY);
	int width 	= mono8Img->width;
	int height 	= mono8Img->height;
	char *data 	= mono8Img->imageData;
	extractor->RunSIFT(width, height, data, GL_LUMINANCE, GL_UNSIGNED_BYTE);
	num_keys = extractor->GetFeatureNum();//get feature count
	descs.clear();
	descs.resize(128 * num_keys);
	keys.clear();
	keys.resize(num_keys);
	extractor->GetFeatureVector(&keys[0], &descs[0]);

//	gettimeofday(&tracker_time, NULL);
//	double keys_time 	= tracker_time.tv_sec+(tracker_time.tv_usec/1000000.0);
//	ROS_INFO_STREAM("Time to generate keys: " << keys_time - image_load);

	// Load depth map
	std::string depths_file = file_name;
	depths_file.append(".yml");
	if (!fs::exists(depths_file)) {
		ROS_WARN("DEPTH FILE DOES NOT EXIST");
	} else {
		FileStorage fs(depths_file.c_str(), FileStorage::READ);
		fs["depths"] >> depths;
		fs.release();

//		gettimeofday(&tracker_time, NULL);
//		double depths_time 	= tracker_time.tv_sec+(tracker_time.tv_usec/1000000.0);
//		ROS_INFO_STREAM("Time to process depths: " << depths_time - keys_time);

		// Alternate loading method (incomplete):
//		depths.resize(480*480);
//		float* depths2 = new float[640*480];
//		CvFileStorage * fileStorage = cvOpenFileStorage(depths_file.c_str(),0,CV_STORAGE_READ);
//		CvFileNode* depthsNode = cvGetFileNodeByName(fileStorage, NULL, "depths");
//		CvSeq* depthsSeq = depthsNode->data.seq;
//		CvSeqReader DepthsReader;
//		cvStartReadRawData(fileStorage, depthsNode, &DepthsReader);
//		cvReadRawData(fileStorage,depthsNode,&depths2[0],"f");

		// Find the 3D points associated with each SIFT key
		float centerX = (width >> 1) - 0.5f;
		float centerY = (width >> 1) - 0.5f;
		for (int i = 0; i < num_keys; i++) {
			SiftGPU::SiftKeypoint pt = keys[i];
			int x_coord = (int) round(pt.x);
			int y_coord = (int) round(pt.y);
			if (!((x_coord >= 0) && (x_coord < width) && (y_coord >= 0) && (y_coord
					< height)))
			{
				ROS_WARN("Pose-image pixel out of bounds");
			}
			float d = depths[y_coord * width + x_coord];
			float x = (x_coord - centerX) * d * pose_depth_constant;
			float y = (y_coord - centerY) * d * pose_depth_constant;
			points.push_back(cvPoint3D32f(x, y, d));
		}
	}

	// Load the pose of the puppet in the image
	std::string pose_file = file_name;
	pose_file.append("_pose.yml");
	if (!fs::exists(depths_file)) {
		ROS_WARN("NO POSE FILE");
	} else {
		FileStorage fs_pose(pose_file.c_str(), FileStorage::READ);
		fs_pose["pose"] >> transform_vector;
		fs_pose.release();
		// Convert vector to matrix
		for (int i=0;i<4;i++)
		{
			for (int j=0;j<4;j++){
				transform_matrix(i,j) = transform_vector[i+j*4];
			}
		}
	}
}

//////////
// Old / deprecated (not recently tested) functions
/////////

SIFTPose::SIFTPose(SiftGPU* extractor, IplImage* image_in) {
	image = cvCloneImage(image_in);
	IplImage *mono8Img = cvCreateImage(cvSize(image->width, image->height),
			image->depth, 1);
	cvCvtColor(image, mono8Img, CV_BGR2GRAY);
	int width = mono8Img->width;
	int height = mono8Img->height;
	char *data = mono8Img->imageData;
	extractor->RunSIFT(width, height, data, GL_LUMINANCE, GL_UNSIGNED_BYTE);
	cvShowImage("/image", mono8Img);
	//	int key=cvWaitKey(0);
	num_keys = extractor->GetFeatureNum();//get feature count
	descs.clear();
	descs.resize(128 * num_keys);
	keys.clear();
	keys.resize(num_keys);
	extractor->GetFeatureVector(&keys[0], &descs[0]);

	// Enter dummy values for 3D points
	for (int i = 0; i < num_keys; i++) {
		points.push_back(cvPoint3D32f(0.0f, 0.0f, 0.0f));
	}
}

SIFTPose::SIFTPose(SiftGPU* extractor, IplImage* image_in, const float* depth_in) {

	for (int i=0; i<image_in->width*image_in->height;i++){
		raw_depths.push_back(depth_in[i]);
	}
//	raw_depths = depth_in;
	image = cvCloneImage(image_in);
	float focal_length;
	if (image->width == 640) {
		focal_length = 525;
	} else {
		focal_length = 1100;
	}
	pose_depth_constant = 1.0f / focal_length;

	IplImage *mono8Img = cvCreateImage(cvSize(image->width, image->height),
			image->depth, 1);
	cvCvtColor(image, mono8Img, CV_BGR2GRAY);
	int width = mono8Img->width;
	int height = mono8Img->height;
	char *data = mono8Img->imageData;
	extractor->RunSIFT(width, height, data, GL_LUMINANCE, GL_UNSIGNED_BYTE);
	cvShowImage("/image", mono8Img);
	//	int key=cvWaitKey(0);
	num_keys = extractor->GetFeatureNum();//get feature count
	descs.clear();
	descs.resize(128 * num_keys);
	keys.clear();
	keys.resize(num_keys);
	extractor->GetFeatureVector(&keys[0], &descs[0]);
	// Enter dummy values for 3D points
	float centerX = (width >> 1) - 0.5f;
	float centerY = (width >> 1) - 0.5f;

	for (int i = 0; i < num_keys; i++) {
		SiftGPU::SiftKeypoint pt = keys[i];
		int x_coord = (int) round(pt.x);
		int y_coord = (int) round(pt.y);
		int x_switch = 1;
		if ((x_coord >= 0) && (x_coord < width) && (y_coord >= 0) && (y_coord
				< height)) {
			//			cout << x_coord << " " << y_coord << endl;
			CvScalar s = cvGet2D(mono8Img, y_coord, x_coord);
			int x_offset = 0;
			int x_offset_direction = 1;
			if (s.val[0] == 0) {
				// If this point has no valid depth, search horizontally and vertically for the nearest valid depth
				int step = 1;
				while (s.val[0] == 0) {
					int checked = 0;
					if ((x_coord + x_offset - step) >= 0) {
						checked++;
						s = cvGet2D(mono8Img, y_coord, x_coord + x_offset
								- step);
						if (s.val[0] > 0) {
							x_coord = x_coord + x_offset - step;
							break;
						}
					}
					if ((x_coord + x_offset + step) < width) {
						checked++;
						s = cvGet2D(mono8Img, y_coord, x_coord + x_offset
								+ step);
						if (s.val[0] > 0) {
							x_coord = x_coord + x_offset + step;
							break;
						}
					}
					if ((y_coord - step) >= 0) {
						checked++;
						s = cvGet2D(mono8Img, y_coord - step, x_coord
								+ x_offset);
						if (s.val[0] > 0) {
							x_coord = x_coord + x_offset;
							y_coord = y_coord - step;
							break;
						}
					}
					if ((y_coord + step) < height) {
						checked++;
						s = cvGet2D(mono8Img, y_coord + step, x_coord
								+ x_offset);
						if (s.val[0] > 0) {
							x_coord = x_coord + x_offset;
							y_coord = y_coord + step;
							break;
						}
					}
					if (checked == 0) {
						step = 0;
						x_offset += x_offset_direction * x_switch;

						if ((x_coord + x_offset >= width - 1) || (x_coord
								+ x_offset <= 1)) {
							x_offset *= -1;
						}
						if (x_coord + x_offset <= 1) {
							x_offset = 0;
							x_offset_direction *= -1;
						}
					}
					step++;
				}
			}
			float d = raw_depths[y_coord * width + x_coord];
			float x = (x_coord - centerX) * d * pose_depth_constant;
			float y = (y_coord - centerY) * d * pose_depth_constant;
			points.push_back(cvPoint3D32f(x, y, d));
		} else {
			points.push_back(cvPoint3D32f(-5000, -5000, -5000));
		}
	}
}

SIFTPose::SIFTPose(vector<float> descs_in, vector<SiftGPU::SiftKeypoint> keys_in, IplImage* image_in, vector<CvPoint3D32f> points_in) :
	descs(descs_in), keys(keys_in), image(image_in), points(points_in) {
	num_keys = keys.size();
}

/////////////////////////////////////////
/////////////////////////////////////////
/***
 * SIFTPoseCollection Class Functions
 ***/
/////////////////////////////////////////
/////////////////////////////////////////

SIFTPoseCollection::~SIFTPoseCollection() {
}

/**
 * Default constructor for the class
 */
SIFTPoseCollection::SIFTPoseCollection() {
	// We use a Hough transform (based on binning) to find sets of SIFT matches that are
	// geometrically consist with each other. Here we set up the number of rotation, scale,
	// and position bins, along with their sizes

	rotation_bins = 4;
	rotation_bin_size = 2 * PI / rotation_bins;
	scale_bins = 1;
	min_scale_bin = -2;
	pos_bins = 96;
	pos_bin_size = 15;
	min_pos_diff = 1;
	min_scale_diff = sqrt(2);
	min_orientation_diff = 15.0 * PI / 180.0;
	int max_bin_size = 256;

	// Create table for binning positions and orientations
	pos_rot_table.resize(rotation_bins*pos_bins*pos_bins);
	for (int i=0;i<rotation_bins*pos_bins*pos_bins;i++)
	{
		pos_rot_table[i].resize(max_bin_size);
	}
}


/**
 * Add a pose to this collection
 *
 * \param pose_to_add 	The pose to be added
 */
void SIFTPoseCollection::addPose(SIFTPose pose_to_add) {
	poses.push_back(pose_to_add);
}

/**
 * Get a pose from this collection
 *
 * \param index 	Index of the pose
 */
SIFTPose SIFTPoseCollection::getPose(int index) {
	return poses[index];
}

/**
 * Load a new SIFTPose into this collection
 *
 * \param path 		Folder containing the new pose's data
 * \param name 		The base name for the pose's image and depth map
 * \param extractor The SIFT extractor to be used to recover the image's SIFT keys
 *
 * NOTE: This function is not used with the kinect_tracker software.
 */
void SIFTPoseCollection::loadPoses(std::string path, std::string name,
		SiftGPU* extractor) {
	// Setup folder
	std::string new_folder = path;
	new_folder.append("/");
	new_folder.append(name);
	new_folder.append("/");
	fs::path p(new_folder);
	if (!fs::exists(p)) {
		ROS_WARN("Folder doesn't exit. Check pose load name");
		return;
	}
	// Get image name to make sure it exists
	int num = 0;
	std::string file_name = new_folder;
	file_name.append(name);
	char number[50];
	sprintf(number, "%d", num);
	file_name.append(number);
	std::string image_name = file_name;
	image_name.append(".png");

	while (fs::exists(image_name)) {
		addPose(SIFTPose(path, name, num, extractor));
		num++;
		file_name = new_folder;
		file_name.append(name);
		char new_number[50];
		sprintf(new_number, "%d", num);
		file_name.append(new_number);
		image_name = file_name;
		image_name.append(".png");
	}
	if (num == 0)
		ROS_WARN("Error loading poses: No poses found.");
}


/**
 * Bin the matches between two sets of SIFT keys/descriptors.
 * Return the size of the largest bin and the match indices using bin_contents.
 *
 * \param 	pose_keys 		SIFT keys belonging to a template pose.
 * \param 	image_keys		SIFT keys belonging ton incoming RGB image
 * \param 	nmatch			Number of SIFT matches
 * \param 	matches			Indices of the matching pairs
 * \return 	bin_contents	Indices of the matching pairs in the largest bin
 * \return	largest_bin		Size of the largest bin of matching pairs
 */
int SIFTPoseCollection::binKeysOrientationPosition(vector<SiftGPU::SiftKeypoint> pose_keys,
		vector<SiftGPU::SiftKeypoint> image_keys, int nmatch, int matches[][2],
		vector<int> &bin_contents) {
	// Create the hash table for binning similar matches
	vector<int> added(rotation_bins*pos_bins*pos_bins,0);

	vector<vector<int> > indices;
	vector<int> binned_indices;
	int largest_bin = 0;

	// Find transformations between each key match
	for (int i = 0; i < nmatch; i++) {
		int im_coord = matches[i][1];
		int pose_coord = matches[i][0];

		// Get transforms from pose to input image
		float x_diff = pose_keys[pose_coord].x - image_keys[im_coord].x;
		float y_diff = pose_keys[pose_coord].y - image_keys[im_coord].y;
		float rot_diff = pose_keys[pose_coord].o - image_keys[im_coord].o;

		// Place in bins
		// X position
		int x_bin1;
		int x_bin2;
		x_bin1 = floor(x_diff / pos_bin_size) + pos_bins / 2 - 1;
		if (abs(x_diff - (x_bin1+1 - pos_bins / 2) * pos_bin_size)
				<= pos_bin_size / 2) {
			// Match in middle of bin
			x_bin2 = x_bin1 - 1;
			if (x_bin2 < 0)
				x_bin2 = x_bin1 + 1;
		} else {
			x_bin2 = x_bin1 + 1;
			if (x_bin2 >= pos_bins)
				x_bin2 = x_bin1 - 1;
		}

		// Y position
		int y_bin1;
		int y_bin2;
		y_bin1 = floor(y_diff / pos_bin_size) + pos_bins / 2 - 1;
		if (abs(y_diff - (y_bin1+1 - pos_bins / 2) * pos_bin_size)
				<= pos_bin_size / 2) {
			// Match in middle of bin
			y_bin2 = y_bin1 - 1;
			if (y_bin2 < 0)
				y_bin2 = y_bin1 + 1;
		} else {
			y_bin2 = y_bin1 + 1;
			if (y_bin2 >= pos_bins)
				y_bin2 = y_bin1 - 1;
		}

		// Orientation
		rot_diff = fmod(rot_diff, 2 * PI);
		if (rot_diff < 0)
			rot_diff += 2 * PI;
		int rot_bin1;
		int rot_bin2;
		rot_bin1 = int(rot_diff / rotation_bin_size);
		if (rot_bin1 < 0) {
			rot_bin1 = 0;
			rot_bin2 = 1;
		} else if (rot_bin1 > rotation_bins - 1) {
			rot_bin1 = rotation_bins - 2;
			rot_bin2 = rotation_bins - 1;
		} else {
			if (abs(rot_diff - rot_bin1 * rotation_bin_size)
					== rotation_bin_size / 2) {
				// Match in middle of bin
				rot_bin2 = rot_bin1 - 1;
				if (rot_bin2 < 0)
					rot_bin2 = rotation_bins-1;
			} else {
				rot_bin2 = rot_bin1 + 1;
				if (rot_bin2 >= rotation_bins)
					rot_bin2 = 0;
			}
		}

		pos_rot_table[rot_bin1 * pos_bins*pos_bins + x_bin1 * pos_bins + y_bin1][added[rot_bin1 * pos_bins*pos_bins + x_bin1 * pos_bins + y_bin1]] = i;
		pos_rot_table[rot_bin1 * pos_bins*pos_bins + x_bin1 * pos_bins + y_bin2][added[rot_bin1 * pos_bins*pos_bins + x_bin1 * pos_bins + y_bin2]] = i;
		pos_rot_table[rot_bin1 * pos_bins*pos_bins + x_bin2 * pos_bins + y_bin1][added[rot_bin1 * pos_bins*pos_bins + x_bin2 * pos_bins + y_bin1]] = i;
		pos_rot_table[rot_bin1 * pos_bins*pos_bins + x_bin2 * pos_bins + y_bin2][added[rot_bin1 * pos_bins*pos_bins + x_bin2 * pos_bins + y_bin2]] = i;
		pos_rot_table[rot_bin2 * pos_bins*pos_bins + x_bin1 * pos_bins + y_bin1][added[rot_bin2 * pos_bins*pos_bins + x_bin1 * pos_bins + y_bin1]] = i;
		pos_rot_table[rot_bin2 * pos_bins*pos_bins + x_bin1 * pos_bins + y_bin2][added[rot_bin2 * pos_bins*pos_bins + x_bin1 * pos_bins + y_bin2]] = i;
		pos_rot_table[rot_bin2 * pos_bins*pos_bins + x_bin2 * pos_bins + y_bin1][added[rot_bin2 * pos_bins*pos_bins + x_bin2 * pos_bins + y_bin1]] = i;
		pos_rot_table[rot_bin2 * pos_bins*pos_bins + x_bin2 * pos_bins + y_bin2][added[rot_bin2 * pos_bins*pos_bins + x_bin2 * pos_bins + y_bin2]] = i;

		added[rot_bin1 * pos_bins*pos_bins + x_bin1 * pos_bins + y_bin1]++;
		added[rot_bin1 * pos_bins*pos_bins + x_bin1 * pos_bins + y_bin2]++;
		added[rot_bin1 * pos_bins*pos_bins + x_bin2 * pos_bins + y_bin1]++;
		added[rot_bin1 * pos_bins*pos_bins + x_bin2 * pos_bins + y_bin2]++;
		added[rot_bin2 * pos_bins*pos_bins + x_bin1 * pos_bins + y_bin1]++;
		added[rot_bin2 * pos_bins*pos_bins + x_bin1 * pos_bins + y_bin2]++;
		added[rot_bin2 * pos_bins*pos_bins + x_bin2 * pos_bins + y_bin1]++;
		added[rot_bin2 * pos_bins*pos_bins + x_bin2 * pos_bins + y_bin2]++;

	}
	// First find the largest bin
	int li, ls, lt;
	li = 0; ls = 0; lt = 0;
	for (int i = 0; i < rotation_bins; i++) {
		for (int s = 0; s < pos_bins; s++) {
			for (int t = 0; t < pos_bins; t++) {
				if (added[i * pos_bins*pos_bins + s*pos_bins + t] > largest_bin)
				{
					largest_bin = added[i * pos_bins*pos_bins + s*pos_bins + t];
					li = i;
					ls = s;
					lt = t;
				}
			}
		}
	}

	bin_contents.clear();
	for (int i=0; i<largest_bin; i++){
		bin_contents.push_back(pos_rot_table[li * pos_bins*pos_bins + ls*pos_bins + lt][i]);
	}

	return largest_bin;
}


/**
 * Go through each of the poses in this collection and find the best match to a set of designated
 * SIFT keys/descriptors. Evalulate the goodness of the overall pose matches by the largest bins of matched SIFT keys
 *
 * \param 	keys_in 			SIFT keys to be matched
 * \param 	descs_in			Descriptors for the SIFT keys to be matched
 * \param 	sift_matcher		The SiftGPU matcher instance used to compare SIFT descriptors
 * \param 	max_match_distance	Maximum euclidian distance between two matched SIFT descriptors
 * \param  	max_match_ratio		Maximum ratio between the euclidean distances to a key's second-best and best matches
 * \return 	match_index			Index of the overall best-matched SiftPose
 * \return	largest_bin			Size of the largest bin in the best-matched SiftPose
 */
int SIFTPoseCollection::findBestMatchBinOnly(
		vector<SiftGPU::SiftKeypoint> keys_in, vector<float> descs_in,
		SiftMatchGPU* sift_matcher, float max_match_distance,
		float max_match_ratio, int& match_index) {
	int best_pose = -1;
	uint largest_bin = 0;
	global_largest_bin_indices.clear();

	// Prep matcher by loading keys to be matched.
	vector<SiftGPU::SiftKeypoint> image_keys = keys_in;
	sift_matcher->SetDescriptors(1, keys_in.size(), &descs_in[0]);

	// Go through each stored SIFTPose and determine its largest SIFT-match bin
	for (uint i = 0; i < poses.size(); i++) {
//		double start;
//		double finish;
//		gettimeofday(&tracker_time, NULL);
//		start 	= tracker_time.tv_sec+(tracker_time.tv_usec/1000000.0);

		// Verify there are sufficient matches to proceed
		vector<SiftGPU::SiftKeypoint> pose_keys = poses[i].keys;
		sift_matcher->SetDescriptors(0, poses[i].num_keys, &poses[i].descs[0]);
		uint point_count = sift_matcher->GetSiftMatch(4096, poses[i].matches,
				max_match_distance, max_match_ratio, 0);


//		gettimeofday(&tracker_time, NULL);
//		finish 	= tracker_time.tv_sec+(tracker_time.tv_usec/1000000.0);
//		cout << "Time to find matches: " << (finish - start) << " sec" << endl;

		vector<int> bin_indices;

		// Check whether this pose has provided the best match so far
		if (point_count >= bin_cutoff) {
			uint temp_bin_size = binKeysOrientationPosition(poses[i].keys, keys_in, point_count,
							poses[i].matches, bin_indices);
			poses[i].largest_bin_indices = bin_indices;
			if ((temp_bin_size >= largest_bin) && (temp_bin_size >= bin_cutoff)) {
				best_pose = i;
				largest_bin = temp_bin_size;
			}
		}
	}

	match_index = best_pose;

	// Store the matches from the largest bin for use when computing the translation between the puppet in the
	// matched pose and the puppet in the incoming RGB image
	if (largest_bin >= bin_cutoff) {
		// Add to global collection of bin_indices. These should be the indices within the input image key vectors
		for (uint b=0; b<poses[best_pose].largest_bin_indices.size();b++){
			global_largest_bin_indices.push_back(poses[best_pose].matches[poses[best_pose].largest_bin_indices[b]][0]);
		}
	}

	return largest_bin;
}

/**
 * Calculate the translation between two sets of SIFT keys, based on their 3D positions
 *
 * \param 	keys_in 			SIFT keys in the incoming RGB image
 * \param 	pose_match			Pose that has been matched to the RGB image
 * \param 	eigen_transform		The translation-only transform to be computed
 * \param 	depth_buffer		The depths associated with the incoming RGB image
 * \return  transformed_points	The SIFT points from the Pose, after they have been translated
 * \return 	found_transform		Whether or not any pose sufficiently matched the incoming image (based on bin_cutoff)
 */
int SIFTPoseCollection::getTranslation(vector<SiftGPU::SiftKeypoint> keys_in, int pose_match, Transform3f &eigen_transform, const float* depth_buffer,
										vector<Vector3f> &transformed_points)
{
	int width = 640;
	float centerX = (width >> 1) - 0.5f;
	float centerY = (width >> 1) - 0.5f;
	eigen_transform.setIdentity();
	float image_depth_constant = poses[pose_match].image_depth_constant;

	int found_transform = 1;

	if ((poses[pose_match].largest_bin_indices.size() >= bin_cutoff) && (pose_match >= 0)){

		vector<Vector3f> 		src_KLT_3D_points;
		vector<Vector3f> 		dst_KLT_3D_points;;

		uint numPoints = poses[pose_match].largest_bin_indices.size();

		CvPoint3D32f pose_pt;
		SiftGPU::SiftKeypoint image_keypt;
		CvPoint3D32f image_pt;

		// Fill two matrices with the matched SIFT keys' coordinates
		int num_refined_pts = 0;
		for (uint i=0; i<numPoints; i++)
		{
			image_keypt = keys_in[poses[pose_match].matches[poses[pose_match].largest_bin_indices[i]][1]];
			float d = depth_buffer[int(image_keypt.y) * width + int(image_keypt.x)];

			if (d!=d)
			{
				continue;
			}
			pose_pt = poses[pose_match].points[poses[pose_match].matches[poses[pose_match].largest_bin_indices[i]][0]];

			if (pose_pt.z == 0)
				continue;

			image_pt.x 	= (image_keypt.x - centerX) * d * image_depth_constant;
			image_pt.y	= (image_keypt.y - centerY) * d * image_depth_constant;
			image_pt.z 	= d;

			src_KLT_3D_points.push_back(Vector3f(pose_pt.x, pose_pt.y,pose_pt.z));
			dst_KLT_3D_points.push_back(Vector3f(image_pt.x, image_pt.y,image_pt.z));
			num_refined_pts++;
		}

		// Use the matrices to calculate the optimal translation between the two
		if (num_refined_pts >= 4)
		{
			// Find the means
			Vector3f src_mean = Vector3f::Zero();
			Vector3f dst_mean = Vector3f::Zero();
			for(unsigned int i=0; i<src_KLT_3D_points.size(); i++){
				src_mean += src_KLT_3D_points[i];
				dst_mean += dst_KLT_3D_points[i];
			}
			src_mean = src_mean / src_KLT_3D_points.size();
			dst_mean = dst_mean / dst_KLT_3D_points.size();

			// Create the translation component
			Vector3f translation =  dst_mean - src_mean;
			eigen_transform.pretranslate(translation);

			transformed_points.clear();
			for (int p=0; p<num_refined_pts; p++){
				Vector3f transformed 	= eigen_transform * src_KLT_3D_points[p];
				Vector3f transformed2D;
				transformed2D[0] = transformed[0]/(transformed[2]*image_depth_constant)+centerX;
				transformed2D[1] = transformed[1]/(transformed[2]*image_depth_constant)+centerY;
				transformed_points.push_back(transformed2D);
			}
		} else {
			found_transform = 0;
		}
	} else {
		found_transform = 0;
	}
	poses[pose_match].best_transform = eigen_transform;
	return found_transform;
}

//////////
// Old / deprecated (not recently tested) functions
/////////

SIFTPoseCollection::SIFTPoseCollection(SIFTPose init_pose) {
	poses.push_back(init_pose);
}

int SIFTPoseCollection::binKeys(vector<SiftGPU::SiftKeypoint> pose_keys,
		vector<SiftGPU::SiftKeypoint> image_keys, int nmatch, int matches[][2],
		vector<int> &bin_contents) {

	// Bin the matches based on position, scale, and orientation. Return the size of the largest bin. Also return the match indices using bin_contents.

	// Create the hash table for binning similar matches
	vector_4d<vector<int> >
			table(rotation_bins, scale_bins, pos_bins, pos_bins);
	vector_4d<int> added(rotation_bins, scale_bins, pos_bins, pos_bins);
	vector<vector<int> > indices;
	vector<int> binned_indices;
	uint largest_bin = 0;

	// Find transformations between each key match
	for (int i = 0; i < nmatch; i++) {
		int im_coord = matches[i][1];
		int pose_coord = matches[i][0];

		//		cout << "Loading differences" << endl;

		// Get transforms from pose to input image
		float x_diff = pose_keys[pose_coord].x - image_keys[im_coord].x;
		float y_diff = pose_keys[pose_coord].y - image_keys[im_coord].y;
		float scale_diff = pose_keys[pose_coord].s - image_keys[im_coord].s;
		float rot_diff = pose_keys[pose_coord].o - image_keys[im_coord].o;

		//		cout << "Loaded differences" << endl;

		// Place in bins
		// X position
		int x_bin1;
		int x_bin2;
		x_bin1 = floor(x_diff / pos_bin_size) + pos_bins / 2 - 1;
		if (abs(x_diff - (x_bin1 - pos_bins / 2) * pos_bin_size)
				== pos_bin_size / 2) {
			// Match in middle of bin
			x_bin2 = x_bin1 - 1;
			if (x_bin2 < 0)
				x_bin2 = x_bin1 + 1;
		} else {
			x_bin2 = x_bin1 + 1;
			if (x_bin2 >= pos_bins)
				x_bin2 = x_bin1 - 1;
		}

		// Y position
		int y_bin1;
		int y_bin2;
		y_bin1 = floor(y_diff / pos_bin_size) + pos_bins / 2 - 1;
		if (abs(y_diff - (y_bin1 - pos_bins / 2) * pos_bin_size)
				== pos_bin_size / 2) {
			// Match in middle of bin
			y_bin2 = y_bin1 - 1;
			if (y_bin2 < 0)
				y_bin2 = y_bin1 + 1;
		} else {
			y_bin2 = y_bin1 + 1;
			if (y_bin2 >= pos_bins)
				y_bin2 = y_bin1 - 1;
		}

		// Scale
		int scale_bin1;
		int scale_bin2;
		scale_bin1 = floor(scale_diff / 2) - min_scale_bin / 2;
		if (scale_bin1 < 0) {
			scale_bin1 = 0;
			scale_bin2 = 1;
		} else if (scale_bin1 > scale_bins - 1) {
			scale_bin1 = scale_bins - 2;
			scale_bin2 = scale_bins - 1;
		} else {
			if (abs(scale_diff - (scale_bin1 + min_scale_bin / 2) * 2) == 1) {
				// Match in middle of bin
				scale_bin2 = scale_bin1 - 1;
				if (scale_bin2 < 0)
					scale_bin2 = scale_bin1 + 1;
			} else {
				scale_bin2 = scale_bin1 + 1;
				if (scale_bin2 >= scale_bins)
					scale_bin2 = scale_bin1 - 1;
			}
		}

		// Orientation
		rot_diff = fmod(rot_diff, 2 * PI);
		if (rot_diff < 0)
			rot_diff += 2 * PI;
		int rot_bin1;
		int rot_bin2;
		rot_bin1 = int(rot_diff / rotation_bin_size);
		if (rot_bin1 < 0) {
			rot_bin1 = 0;
			rot_bin2 = 1;
		} else if (rot_bin1 > rotation_bins - 1) {
			rot_bin1 = rotation_bins - 2;
			rot_bin2 = rotation_bins - 1;
		} else {
			if (abs(rot_diff - rot_bin1 * rotation_bin_size)
					== rotation_bin_size / 2) {
				// Match in middle of bin
				rot_bin2 = rot_bin1 - 1;
				if (rot_bin2 < 0)
					rot_bin2 += rotation_bins;
			} else {
				rot_bin2 = rot_bin1 + 1;
				if (rot_bin2 >= rotation_bins)
					rot_bin2 -= rotation_bins;
			}
		}
		// Add to bins
		table(rot_bin1, scale_bin1, x_bin1, y_bin1).push_back(i);
		table(rot_bin1, scale_bin1, x_bin1, y_bin2).push_back(i);
		table(rot_bin1, scale_bin1, x_bin2, y_bin1).push_back(i);
		table(rot_bin1, scale_bin1, x_bin2, y_bin2).push_back(i);
		table(rot_bin1, scale_bin2, x_bin1, y_bin1).push_back(i);
		table(rot_bin1, scale_bin2, x_bin1, y_bin2).push_back(i);
		table(rot_bin1, scale_bin2, x_bin2, y_bin1).push_back(i);
		table(rot_bin1, scale_bin2, x_bin2, y_bin2).push_back(i);
		table(rot_bin2, scale_bin1, x_bin1, y_bin1).push_back(i);
		table(rot_bin2, scale_bin1, x_bin1, y_bin2).push_back(i);
		table(rot_bin2, scale_bin1, x_bin2, y_bin1).push_back(i);
		table(rot_bin2, scale_bin1, x_bin2, y_bin2).push_back(i);
		table(rot_bin2, scale_bin2, x_bin1, y_bin1).push_back(i);
		table(rot_bin2, scale_bin2, x_bin1, y_bin2).push_back(i);
		table(rot_bin2, scale_bin2, x_bin2, y_bin1).push_back(i);
		table(rot_bin2, scale_bin2, x_bin2, y_bin2).push_back(i);
	}

	//	cout << "Bins processed." << endl;

	// Initialize vectors storing whether a bin has been used for matching
	for (int i = 0; i < rotation_bins; i++) {
		for (int j = 0; j < scale_bins; j++) {
			for (int s = 0; s < pos_bins; s++) {
				for (int t = 0; t < pos_bins; t++) {
					added(i, j, s, t) = 0;
				}
			}
		}
	}

	// First find the largest bin
	int li, lj, ls, lt;
	li = 0; lj = 0; ls = 0; lt = 0;
	for (int i = 0; i < rotation_bins; i++) {
		for (int j = 0; j < scale_bins; j++) {
			for (int s = 0; s < pos_bins; s++) {
				for (int t = 0; t < pos_bins; t++) {
					if (table(i, j, s, t).size() > largest_bin) {
						largest_bin = table(i, j, s, t).size();
						li = i;
						lj = j;
						ls = s;
						lt = t;
					}
				}
			}
		}
	}
	bin_contents = table(li, lj, ls, lt);
	return largest_bin;
}

void SIFTPoseCollection::getAverageTranslation(vector<SiftGPU::SiftKeypoint> keys_in, int pose_match, Mat &transform){
	// Finds average translation between two sets of SIFT keys
	// Note: This function needs the largest bins to be calculated first.
	transform = Mat::zeros(2,3,CV_32F);
	transform.at<float>(0,0) = 1.0;
	transform.at<float>(1,1) = 1.0;
	if ((global_largest_bin_indices.size() >= 4) && (pose_match >= 0)){
		float 	ave_x 	= 0;
		float 	ave_y 	= 0;
		// Only uses SIFT matches from best-matched pose
		vector<SiftGPU::SiftKeypoint> pose_keys 	= poses[pose_match].keys;
		for(unsigned int m=0; m < global_largest_bin_indices.size(); m++){
			SiftGPU::SiftKeypoint pose_pt = poses[pose_match].keys[poses[pose_match].matches[poses[pose_match].largest_bin_indices[m]][0]];
			SiftGPU::SiftKeypoint image_pt = keys_in[global_largest_bin_indices[m]];
			ave_x += image_pt.x - pose_pt.x;
			ave_y += image_pt.y - pose_pt.y;
		}
		ave_x = ave_x/(float)global_largest_bin_indices.size();
		ave_y = ave_y/(float)global_largest_bin_indices.size();
//		cout <<ave_x << " " << ave_y << endl;
		transform.at<float>(0,2) = ave_x;
		transform.at<float>(1,2) = ave_y;
	}
}

void SIFTPoseCollection::getHornTransform3D(vector<SiftGPU::SiftKeypoint> keys_in, int pose_match,Transform3f &eigen_transform, const float* depth_buffer,
											float &error_out, vector<Vector3f> &transformed_points)
{
	int width = 640;
	float centerX = (width >> 1) - 0.5f;
	float centerY = (width >> 1) - 0.5f;
	float	lowest_error 	= 1000;
	Transform3f best_transform;
	best_transform.setIdentity();
	Vector3f 	best_translation;
	Quaternionf best_rotation;
	srand(230);
	float image_depth_constant = poses[pose_match].image_depth_constant;
	if ((poses[pose_match].largest_bin_indices.size() >= bin_cutoff) && (pose_match >= 0)){
		int 	num_iterations  = 100;
		Matrix3f m = Matrix3f::Zero();
		Vector4f evals;
		Matrix4f evecs;
		Vector4f largestEvec;
		vector<Vector3f> 		src_KLT_3D_points;
		vector<Vector3f> 		dst_KLT_3D_points;
		vector<SiftGPU::SiftKeypoint>	dst_2D_points;

		uint numPoints = poses[pose_match].largest_bin_indices.size();

		CvPoint3D32f pose_pt;
		SiftGPU::SiftKeypoint image_keypt;
		CvPoint3D32f image_pt;

		int num_refined_pts = 0;
		for (uint i=0; i<numPoints; i++)
		{
			image_keypt = keys_in[poses[pose_match].matches[poses[pose_match].largest_bin_indices[i]][1]];
			float d = depth_buffer[int(image_keypt.y) * width + int(image_keypt.x)];

			if (d!=d)
			{
				continue;	// NaN value; skip it
			}

			pose_pt = poses[pose_match].points[poses[pose_match].matches[poses[pose_match].largest_bin_indices[i]][0]];

			if (pose_pt.z == 0)
			{
				continue;
			}

			image_pt.x 	= (image_keypt.x - centerX) * d * image_depth_constant;
			image_pt.y	= (image_keypt.y - centerY) * d * image_depth_constant;
			image_pt.z 	= d;
			dst_2D_points.push_back(image_keypt);
			src_KLT_3D_points.push_back(Vector3f(pose_pt.x, pose_pt.y,pose_pt.z));
			dst_KLT_3D_points.push_back(Vector3f(image_pt.x, image_pt.y,image_pt.z));
			num_refined_pts++;
		}

		uint 	num_in_subset 	= max(num_refined_pts*1/2,4);

		vector<int> indices;
		for (int i=0;i<num_refined_pts;i++)
			indices.push_back(i);

		if (num_refined_pts >= 4)
		{

			for (int i=0; i<num_iterations; i++)
			{
				// Select subset of four points from sources
				vector<Vector3f> 	src_subset;
				vector<Vector3f> 	dst_subset;
				vector<int>			added_indices;
				vector<int> temp_indices = indices;

				int new_index = rand() % num_refined_pts;
				for (uint n = 0; n<num_in_subset;n++)
				{
					new_index = rand() % temp_indices.size();
					src_subset.push_back(src_KLT_3D_points[temp_indices[new_index]]);
					dst_subset.push_back(dst_KLT_3D_points[temp_indices[new_index]]);
					temp_indices.erase(temp_indices.begin()+new_index);
				}

				// Translate source and target points to the origin

				// Find the means
				Vector3f src_mean = Vector3f::Zero();
				Vector3f dst_mean = Vector3f::Zero();
				for(unsigned int i=0; i<src_subset.size(); i++){
					src_mean += src_subset[i];
					dst_mean += dst_subset[i];
				}
				src_mean = src_mean / src_subset.size();
				dst_mean = dst_mean / src_subset.size();

				// Translate the points so their centroids align
				std::vector<Vector3f> shifted_src(src_subset.size());
				std::vector<Vector3f> shifted_dst(dst_subset.size());

				for(unsigned int i=0; i<src_subset.size(); i++){
					shifted_src[i] = src_subset[i] - src_mean;
					shifted_dst[i] = dst_subset[i] - dst_mean;
				}

				// Find rotation between points
				// Get the M-matrix described in the Henry paper
				// This is the sum of outer products of the vector pairs
				m = Matrix3f::Zero();
				for(unsigned int i=0; i<src_subset.size(); i++)
					m += shifted_src[i] * shifted_dst[i].transpose();

				// Get the N-matrix
				// This is constructed from elements of the M-matrix
				// Our goal is to find a quaternion q which maximizes q^t*N*q
				// when the quaternion is interpreted as a 4 element vector
				// note that the N-matrix is symmetric
				Matrix4f n = Matrix4f::Zero();
				// Diagonal
				n(0,0) = m(0,0) + m(1,1) + m(2,2);
				n(1,1) = m(0,0) - m(1,1) - m(2,2);
				n(2,2) = -m(0,0) + m(1,1) - m(2,2);
				n(3,3) = -m(0,0) - m(1,1) + m(2,2);
				// Non-diagonal
				n(1,0) = n(0,1) = m(1,2) - m(2,1);
				n(2,0) = n(0,2) = m(2,0) - m(0,2);
				n(3,0) = n(0,3) = m(0,1) - m(1,0);
				n(2,1) = n(1,2) = m(0,1) + m(1,0);
				n(3,1) = n(1,3) = m(2,0) + m(0,2);
				n(3,2) = n(2,3) = m(1,2) + m(2,1);

				// Get the eigenvalues and eigenvectors
				SelfAdjointEigenSolver<Matrix4f> eig(n);
				evals = eig.eigenvalues();
				evecs = eig.eigenvectors();

				// Get the eigenvector for the largest eigenvalue (yes, last is largest)
				largestEvec = evecs.col(3);

				// Interpret the eigenvector as a rotation
				Quaternionf rotation = Quaternionf(largestEvec(0),largestEvec(1),largestEvec(2),largestEvec(3));
				rotation.normalize();

				// Create the translation component
				Vector3f translation =  dst_mean - src_mean;

				Transform3f temp_transform;
				temp_transform.setIdentity();
				temp_transform.rotate(rotation);
				temp_transform.pretranslate(translation);

				// Test new transform
				// Least-squared-error metric (3D)
				float error = 0;
				for (int p=0; p<num_refined_pts; p++){
					Vector3f transformed = temp_transform * src_KLT_3D_points[p];
					error += sqrt(pow(transformed[0]-dst_KLT_3D_points[p][0],2) + pow(transformed[1]-dst_KLT_3D_points[p][1],2)
							+ pow(transformed[2]-dst_KLT_3D_points[p][2],2));
				}
				error /= num_refined_pts;
				if (error <= lowest_error){
					best_translation 	= translation;
					best_rotation		= rotation;
					best_transform 		= temp_transform;
					lowest_error 		= error;
					transformed_points.clear();
					for (int p=0; p<num_refined_pts; p++){
						Vector3f transformed 	= temp_transform * src_KLT_3D_points[p];
						Vector3f transformed2D;
						transformed2D[0] = transformed[0]/(transformed[2]*image_depth_constant)+centerX;
						transformed2D[1] = transformed[1]/(transformed[2]*image_depth_constant)+centerY;
						transformed_points.push_back(transformed2D);
					}
				}
			}
		}
	}
//	cout << "match: " << pose_match << " error: " << lowest_error << endl;
	poses[pose_match].best_transform = best_transform;
	eigen_transform = best_transform;
	error_out = lowest_error;
}

void SIFTPoseCollection::findBestMatchUsingError(vector<SiftGPU::SiftKeypoint> keys_in, vector<float> descs_in,SiftMatchGPU* sift_matcher,
				 float max_match_distance, float max_match_ratio, int& match_index,
				 Transform3f &eigen_transform, const float* depth_buffer,
				 float &error, vector<Vector3f> &transformed_points)
{
	int 	best_pose 		= -1;
	float 	smallest_error	= 1000;
	global_largest_bin_indices.clear();

	vector<SiftGPU::SiftKeypoint> image_keys = keys_in;
	sift_matcher->SetDescriptors(1, keys_in.size(), &descs_in[0]);

	for (uint i = 0; i < poses.size(); i++) {
//		double start;
//		double finish;
//		gettimeofday(&tracker_time, NULL);
//		start 	= tracker_time.tv_sec+(tracker_time.tv_usec/1000000.0);

		// Verify there are sufficient matches to proceed
		vector<SiftGPU::SiftKeypoint> pose_keys = poses[i].keys;
		sift_matcher->SetDescriptors(0, poses[i].num_keys, &poses[i].descs[0]);
		uint point_count = sift_matcher->GetSiftMatch(4096, poses[i].matches,max_match_distance, max_match_ratio, 0);

//		gettimeofday(&tracker_time, NULL);
//		finish 	= tracker_time.tv_sec+(tracker_time.tv_usec/1000000.0);
//		cout << "Time to find matches: " << (finish - start) << " sec" << endl;

		vector<int> bin_indices;
		float 		temp_error;
		Transform3f temp_eigen_transform;
		vector<Vector3f> temp_transformed_pts;
		if (point_count > bin_cutoff) {
			// Bin matches
			uint temp_bin_size = binKeysOrientationPosition(poses[i].keys, keys_in, point_count,	poses[i].matches, bin_indices);
			poses[i].largest_bin_indices = bin_indices;

			if (temp_bin_size >= bin_cutoff)
			{
				// Find best transform and the root mean-square error
				getHornTransform3D(keys_in,i,temp_eigen_transform,depth_buffer, temp_error, temp_transformed_pts);
				if (temp_error < smallest_error) {
					eigen_transform = temp_eigen_transform;
					transformed_points = temp_transformed_pts;
					best_pose = i;
					smallest_error = temp_error;
				}
			}
		}
	}
	cout << smallest_error << endl;
	if (smallest_error < 1000) {
		// Add to global collection of bin_indices. These should be the indices within the input image key vectors
		for (uint b=0; b<poses[best_pose].largest_bin_indices.size();b++){
			global_largest_bin_indices.push_back(poses[best_pose].matches[poses[best_pose].largest_bin_indices[b]][0]); // TODO: this may be incorrect
		}
	}

	if (smallest_error < 1000)
		match_index = best_pose;

	error		= smallest_error;
}
