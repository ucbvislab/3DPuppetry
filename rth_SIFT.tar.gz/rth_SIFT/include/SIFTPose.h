/*
 * rth_SIFT.cpp
 *
 *  Created on: 2011-06-15
 *  	Author: Robin Held
 *  	See LICENSE.txt for copyright info.
 *
 *  	The classes in this file are used by rth_SIFT to load image templates and compute SIFT matches to incoming
 *  	images. They are specifically designed for use with the kinect_tracker 3D animation software.
 */


#ifndef SIFTPOSE_H_
#define SIFTPOSE_H_

#include <cstdio>
#include <cstddef>
 #include <iostream>
#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <GL/gl.h>
#include <boost/filesystem.hpp>
#include <cstdio>
#include <deque>
#include <math.h>
#include "rgbd_util/ros_utility.h"
#include <Eigen/Core>
#include <Eigen/Eigenvalues>
#include <Eigen/Geometry>

#include <SiftGPU.h>

namespace fs = boost::filesystem;

using namespace fs;
using namespace std;
using namespace cv;
using namespace Eigen;

#define PI 3.14159265

// The following vector_4d class was copied from http://forums.codeguru.com/archive/index.php/t-515385.html :
template <typename T>
class vector_4d {
public:
  typedef typename std::vector<T>::size_type size_type;
  typedef typename std::vector<T>::iterator iterator;
  typedef typename std::vector<T>::const_iterator const_iterator;

  vector_4d(size_type x, size_type y, size_type z, size_type w)
    :x_(x)
    ,y_(y)
    ,z_(z)
    ,w_(w)
    ,data_(x_*y_*z_*w_)
  {}

  const T& operator()(size_type x_pos, size_type y_pos, size_type z_pos, size_type w_pos) const
  {
    size_type pos_in_4d_plane = x_ * y_ * z_ * w_pos;
    size_type pos_in_3d_plane = x_ * y_ * z_pos;
    size_type pos_in_2d_plane = x_ * y_pos;
    size_type pos_in_1d_plane = x_pos;
    return data_[pos_in_4d_plane + pos_in_3d_plane + pos_in_2d_plane + pos_in_1d_plane];
  }

  T& operator()(size_type x_pos, size_type y_pos, size_type z_pos, size_type w_pos)
  {
    size_type pos_in_4d_plane = x_ * y_ * z_ * w_pos;
    size_type pos_in_3d_plane = x_ * y_ * z_pos;
    size_type pos_in_2d_plane = x_ * y_pos;
    size_type pos_in_1d_plane = x_pos;
    return data_[pos_in_4d_plane + pos_in_3d_plane + pos_in_2d_plane + pos_in_1d_plane];
  }

  iterator begin() { return data_.begin(); }
  iterator end()   { return data_.end(); }

  const_iterator begin() const { return data_.begin(); }
  const_iterator end()   const { return data_.end(); }

private:
  size_type x_;
  size_type y_;
  size_type z_;
  size_type w_;

  std::vector<T> data_;
};



/*
 *  One template pose. Includes an image, a depth map, and pose representing the position of the puppet within the image.
 *  The functions have been separated to clarify which are crucial to the kinect_tracker software.
 */
class SIFTPose {
public:
	SIFTPose();
	virtual ~SIFTPose();
	SIFTPose(std::string path, std::string name, int num, SiftGPU* extractor);

	// Old / deprecated (not recently tested) functions:
	SIFTPose(SiftGPU* extractor, IplImage* image_in);
	SIFTPose(SiftGPU* extractor, IplImage* image_in, const float* depth_in);
	SIFTPose(vector<float> descs_in, vector<SiftGPU::SiftKeypoint> keys_in, IplImage* image_in, vector<CvPoint3D32f> points_in);

	vector<float> 					descs;					// The descriptors associated with each SIFT key
	vector<float>					transform_vector;		// For publishing estimated puppet poses
	Transform3f						transform_matrix;
	vector<SiftGPU::SiftKeypoint> 	keys;					// The SIFT keys found in the image
	int								num_keys;
	IplImage*						image;
	vector<float>					raw_depths;
	float							pose_depth_constant;
	float							image_depth_constant;
	vector<float>					depths;
	vector<CvPoint3D32f> 			points;
	vector<int>						largest_bin_indices;
	int								num_matches;
	int								matches[4096][2];
	Transform3f 					best_transform;
};


/*
 *  Each SIFTPoseCollection represents one puppet to be tracked by kinect_tracker. It consists of several representative SIFTPose instances,
 *  which show the puppet in different positions and orientations throughout the Kinect's field of view. In addition to storage, this class
 *  also includes functions for determining which SIFTPose best matches the incoming images from the Kinect's RGB feed, and the optimal translation
 *  to align the puppet in that SIFTPose to the puppet's position in the incoming image.
 */
class SIFTPoseCollection {
public:
	~SIFTPoseCollection();
	SIFTPoseCollection();
	void addPose(SIFTPose pose_to_add);
	SIFTPose getPose(int index);
	int findBestMatchBinOnly(vector<SiftGPU::SiftKeypoint> keys_in, vector<float> descs_in, SiftMatchGPU* sift_matcher, float max_match_distance,
									float max_match_ratio, int& match_index);
	int binKeysOrientationPosition(vector<SiftGPU::SiftKeypoint> pose_keys,	vector<SiftGPU::SiftKeypoint> image_keys, int nmatch, int matches[][2],
									vector<int> &bin_contents);
	void loadPoses(std::string path, std::string name, SiftGPU* extractor);
	int getTranslation(vector<SiftGPU::SiftKeypoint> keys_in, int pose_match,Transform3f &eigen_transform, const float* depth_buffer,
			vector<Vector3f> &transformed_points);

	// Old / deprecated (not recently tested) functions:
	SIFTPoseCollection(SIFTPose init_pose);
	int binKeys(vector<SiftGPU::SiftKeypoint>  pose_keys, vector<SiftGPU::SiftKeypoint> image_keys, int nmatch, int matches[][2], vector<int> &bin_contents);
	void getAverageTranslation(vector<SiftGPU::SiftKeypoint> keys_in, int pose_match, Mat &transform);
	void getHornTransform3D(vector<SiftGPU::SiftKeypoint> keys_in, int pose_match, Transform3f &eigen_transform, const float* depth_buffer,
							float &error, vector<Vector3f> &transformed_points);
	void findBestMatchUsingError(vector<SiftGPU::SiftKeypoint> keys_in, vector<float> descs_in,SiftMatchGPU* sift_matcher,
			 float max_match_distance, float max_match_ratio, int& match_index,
			 Transform3f &eigen_transform, const float* depth_buffer,
			 float &error, vector<Vector3f> &transformed_points);


	vector<SIFTPose> poses;
	vector<int>		 global_largest_bin_indices;
	int				 current_match;

	// Hough-transform variables
	vector<vector<int> > pos_rot_table;		// For binning positions and orientations
	int				rotation_bins;
	float			rotation_bin_size;
	int				scale_bins;
	int 			min_scale_bin;
	int			    pos_bins;
	float			pos_bin_size;
	float 			min_pos_diff;
	float			min_scale_diff;
	float			min_orientation_diff;
	uint			bin_cutoff;				// Minimum size of a bin to consider a pose matched to the incoming RGB feed

	// Keys and descriptors derived from all of the collection's poses. Needs to be created by pruneKeys()
	vector<float> 					collection_descs;
	vector<SiftGPU::SiftKeypoint> 	collection_keys;

	// For timing functions
	timeval tracker_time;

};

#endif
