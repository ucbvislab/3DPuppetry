/*
 * depthIO: read/write depth maps
 *
 * Evan Herbst
 * 8 / 2 / 10
 */

#ifndef EX_RGBD_DEPTH_IO_H
#define EX_RGBD_DEPTH_IO_H

#include <boost/filesystem/path.hpp>
#include <opencv2/core/core.hpp>
#include "rgbd_msgs/DepthMap.h"

namespace rgbd
{
namespace fs = boost::filesystem;

/*
 * don't change the header
 */
void readDepthMap(const fs::path& filepath, rgbd_msgs::DepthMap& depth);

void writeDepthMap(const rgbd_msgs::DepthMap& depth, const fs::path& filepath);

/*
 * write a color image to be viewed by people
 *
 * img will be allocated
 *
 * pre: depth is uncompressed
 */
void writeDepthMapColorsImg(const rgbd_msgs::DepthMap& depth, cv::Mat& img, const float maxDepth = 10, const cv::Scalar minDepthCol = cvScalar(255, 255, 0), const cv::Scalar maxDepthCol = cvScalar(0, 0, 0));

/*
 * write a single-channel image to be read by a machine, giving depth values in integral mm
 *
 * if you cv::imwrite() the result and it's 16-bit, the resulting file will contain 16-bit values
 *
 * img will be allocated
 *
 * pre: depth is uncompressed
 */
void writeDepthMapValuesImg(const rgbd_msgs::DepthMap& depth, cv::Mat& img, const bool write16bit = true);

/*
 * read 8- or 16-bit png
 *
 * don't change the header
 */
void readDepthMapValuesImg(const cv::Mat& img, rgbd_msgs::DepthMap& depth);

} //namespace

#endif //header
