/*
 * cleanUpDepthMap: deal with pixels being assigned to the wrong side of depth discontinuities
 *
 * Evan Herbst
 * 8 / 20 / 10
 */

#ifndef EX_CLEAN_DEPTH_MAP_H
#define EX_CLEAN_DEPTH_MAP_H

#include "rgbd_msgs/DepthMap.h"

namespace rgbd
{

/*
 * "clean up" a depth map to deal with pixels being assigned to the wrong side of depth discontinuities: simply mark suspicious pixels invalid
 *
 * outDepth is inDepth with some extra points marked invalid
 *
 * outDepth will be allocated
 *
 * maxDistToRemove: we'll mark invalid all points less than this manhattan distance from a depth boundary
 */
void cleanUpDepthMap(const rgbd_msgs::DepthMap& inDepth, rgbd_msgs::DepthMap& outDepth, const unsigned int maxDistToRemove);

} //namespace

#endif //header
