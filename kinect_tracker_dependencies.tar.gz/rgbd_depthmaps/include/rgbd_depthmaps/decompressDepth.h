/*
 * decompressDepth
 *
 * Evan Herbst
 * 4 / 28 / 10
 */

#ifndef EX_DECOMPRESS_DEPTH_MAP_H
#define EX_DECOMPRESS_DEPTH_MAP_H

#include <boost/filesystem/path.hpp>
#include <zlib.h>
#include "rgbd_msgs/DepthMap.h"
namespace fs = boost::filesystem;

namespace rgbd
{

/*
 * pre: src.format == format_zlib
 * post: dest.format == format_raw
 */
void decompressDepthMap(const rgbd_msgs::DepthMap& src, rgbd_msgs::DepthMap& dest);

/*
 * pre: src.format == format_raw
 * post: dest.format == format_zlib
 */
void compressDepthMap(const rgbd_msgs::DepthMap& src, rgbd_msgs::DepthMap& dest, const int compressionMode = Z_DEFAULT_COMPRESSION);

/*
 * don't change the header
 *
 * post: depth.format == format_raw
 */
void readUncompressedDepthMap(const fs::path& filepath, rgbd_msgs::DepthMap& depth);

/*******************************************************************************************************
 * expert access to the memory of an uncompressed depth map
 */

/*
 * provide a pointer to the data of a depth map possibly owned by us
 */
class depthmapPtrs
{
	public:

		depthmapPtrs() {}

		void setOwning(const rgbd_msgs::DepthMapPtr& m)
		{
			msg = m;
			dm = &msg->float_data[0];
		}
		void setNonOwning(const rgbd_msgs::DepthMap& m)
		{
			msg.reset();
			dm = &m.float_data[0];
		}

		const float* dm; //our client interface; similar to msg->float_data

	private:

		rgbd_msgs::DepthMapPtr msg; //empty if we're non-owning
};

/*
 * return a structure giving us access to an uncompressed depth map, whether the one we're given is compressed or not
 *
 * throw on any error
 */
void getUncompressedDepthMapPtrs(const rgbd_msgs::DepthMap& depth_msg, depthmapPtrs& ptrs);

} //namespace

#endif //header
