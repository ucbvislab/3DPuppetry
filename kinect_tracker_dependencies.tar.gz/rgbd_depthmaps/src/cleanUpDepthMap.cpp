/*
 * cleanUpDepthMap: deal with pixels being assigned to the wrong side of depth discontinuities
 *
 * Evan Herbst
 * 8 / 20 / 10
 */

#include <cassert>
#include <cmath> //floor(), fabs(), pow()
#include <algorithm> //fill()
#include <boost/multi_array.hpp>
#include "rgbd_depthmaps/cleanUpDepthMap.h"

namespace rgbd
{

bool ptNextToDepthDiscontinuity(const rgbd_msgs::DepthMap& depth, const unsigned int y0, const unsigned int x0, const int dy, const int dx, const float minDiff)
{
	for(int y1 = y0 + dy, x1 = x0 + dx, n = 0; y1 >= 0 && x1 >= 0 && y1 < depth.height && x1 < depth.width && n < 8/* max no-sample run size to skip */; y1 += dy, x1 += dx, n++)
		if(depth.float_data[y1 * depth.width + x1] > 0)
		{
			if(fabs(depth.float_data[y1 * depth.width + x1] - depth.float_data[y0 * depth.width + x0]) > minDiff) return true;
			return false;
		}
	return false;
}

/*
 * "clean up" a depth map to deal with pixels being assigned to the wrong side of depth discontinuities: simply mark suspicious pixels invalid
 *
 * outDepth is inDepth with some extra points marked invalid
 *
 * outDepth will be allocated
 *
 * maxDistToRemove: we'll mark invalid all points less than this manhattan distance from a depth boundary
 */
void cleanUpDepthMap(const rgbd_msgs::DepthMap& inDepth, rgbd_msgs::DepthMap& outDepth, const unsigned int maxDistToRemove)
{
	assert(inDepth.format == rgbd_msgs::DepthMap::format_raw);
	outDepth = inDepth;

	boost::multi_array<int, 2> discontinuityDist(boost::extents[inDepth.height][inDepth.width]);
	std::fill(discontinuityDist.data(), discontinuityDist.data() + discontinuityDist.num_elements(), -1);
	/*
	 * mark edge points of cloud as bad
	 */
	for(unsigned int i = 0; i < inDepth.height; i++)
	{
		discontinuityDist[i][0] = 0;
		discontinuityDist[i][inDepth.width - 1] = 0;
	}
	for(unsigned int j = 0; j < inDepth.width; j++)
	{
		discontinuityDist[0][j] = 0;
		discontinuityDist[inDepth.height - 1][j] = 0;
	}
	/*
	 * mark pixels "next to" depth boundaries with 0
	 */
	for(unsigned int i = 0; i < inDepth.height; i++)
		for(unsigned int j = 0; j < inDepth.width; j++)
			if(inDepth.float_data[i * inDepth.width + j] > 0)
			{
				const float minDepthDiff = .02 * pow(inDepth.float_data[i * inDepth.width + j], 1.398/* a guess */);
				if(ptNextToDepthDiscontinuity(inDepth, i, j, -1, 0, minDepthDiff)
					|| ptNextToDepthDiscontinuity(inDepth, i, j, 1, 0, minDepthDiff)
					|| ptNextToDepthDiscontinuity(inDepth, i, j, 0, -1, minDepthDiff)
					|| ptNextToDepthDiscontinuity(inDepth, i, j, 0, 1, minDepthDiff))
					discontinuityDist[i][j] = 0;
			}

	/*
	 * compute manhattan dist for all points up to a max dist
	 */
	const unsigned int maxDist = maxDistToRemove; //max boundary distance we care about
	for(unsigned int d = 1; d < maxDist; d++)
		for(unsigned int i = 1; i < inDepth.height - 1; i++)
			for(unsigned int j = 1; j < inDepth.width - 1; j++)
				if(inDepth.float_data[i * inDepth.width + j] > 0 && discontinuityDist[i][j] == -1)
					if(discontinuityDist[i - 1][j] == d - 1
						|| discontinuityDist[i + 1][j] == d - 1
						|| discontinuityDist[i][j - 1] == d - 1
						|| discontinuityDist[i][j + 1] == d - 1)
						discontinuityDist[i][j] = d;

	/*
	 * mark each point as invalid if it's within a (possibly depth-dependent) distance of a boundary
	 */
	for(unsigned int i = 0; i < inDepth.height; i++)
		for(unsigned int j = 0; j < inDepth.width; j++)
			if(inDepth.float_data[i * inDepth.width + j] > 0)
				if(discontinuityDist[i][j] >= 0 && discontinuityDist[i][j] < maxDistToRemove/*7 - .5 * std::max(0.0f, inDepth.float_data[i * inDepth.width + j] - 1))*/)
					outDepth.float_data[i * outDepth.width + j] = inDepth.no_sample_value; //mark invalid
}

} //namespace
