/*
 * compressDepthMapFile: read a depth-map file, compress if not compressed, and rewrite
 *
 * Evan Herbst
 * 10 / 8 / 10
 */

#include <cassert>
#include <boost/filesystem/path.hpp>
#include "rgbd_depthmaps/depthIO.h"
#include "rgbd_depthmaps/decompressDepth.h"
namespace fs = boost::filesystem;

/*
 * arguments: infilepath, outfilepath
 */
int main(int argc, char* argv[])
{
	assert(argc == 3);
	const fs::path infilepath(argv[1]), outfilepath(argv[2]);

	rgbd_msgs::DepthMap rawDepth;
	rgbd::readDepthMap(infilepath, rawDepth);
	switch(rawDepth.format)
	{
		case rgbd_msgs::DepthMap::format_raw:
		{
			rgbd_msgs::DepthMap compressedDepth;
			rgbd::compressDepthMap(rawDepth, compressedDepth);
			rgbd::writeDepthMap(compressedDepth, outfilepath);
			break;
		}
		case rgbd_msgs::DepthMap::format_zlib:
		{
			rgbd::writeDepthMap(rawDepth, outfilepath);
			break;
		}
		default: assert(false);
	}

	return 0;
}
