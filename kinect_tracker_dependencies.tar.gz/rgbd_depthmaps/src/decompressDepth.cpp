/*
 * decompressDepth
 *
 * Evan Herbst
 * 4 / 28 / 10
 */

#include <cassert>
#include <stdexcept>
#include <boost/lexical_cast.hpp>
#include "rgbd_depthmaps/depthIO.h"
#include "rgbd_depthmaps/decompressDepth.h"
using std::string;
using boost::lexical_cast;

namespace rgbd
{

/*
 * pre: src.format == format_zlib
 * post: dest.format == format_raw
 */
void decompressDepthMap(const rgbd_msgs::DepthMap& src, rgbd_msgs::DepthMap& dest)
{
	if(src.format != rgbd_msgs::DepthMap::format_zlib) throw std::invalid_argument("src depth map isn't compressed");

	dest.header = src.header;
	dest.width = src.width;
	dest.height = src.height;
	dest.focal_distance = src.focal_distance;
	dest.no_sample_value = src.no_sample_value;
	dest.shadow_value = src.shadow_value;
	dest.format = rgbd_msgs::DepthMap::format_raw;

	uLongf destLen = dest.width * dest.height * sizeof(float);
	dest.float_data.resize(dest.width * dest.height);
	dest.binary_data.clear();
	const int ret = uncompress((Bytef*)&dest.float_data[0], &destLen, (const Bytef*)&src.binary_data[0], src.binary_data.size());
	assert(destLen == dest.width * dest.height * sizeof(float));
	if(ret != Z_OK) throw std::runtime_error("Depth decompression failed: zlib status " + lexical_cast<string>(ret));
}

/*
 * pre: src.format == format_raw
 * post: dest.format == format_zlib
 */
void compressDepthMap(const rgbd_msgs::DepthMap& src, rgbd_msgs::DepthMap& dest, const int compressionMode)
{
	if(src.format != rgbd_msgs::DepthMap::format_raw) throw std::invalid_argument("src depth map isn't raw");

	dest.header = src.header;
	dest.width = src.width;
	dest.height = src.height;
	dest.focal_distance = src.focal_distance;
	dest.no_sample_value = src.no_sample_value;
	dest.shadow_value = src.shadow_value;
	dest.format = rgbd_msgs::DepthMap::format_zlib;

	const uLongf rawLen = src.float_data.size() * sizeof(float);
	uLongf destLen = compressBound(rawLen);
	dest.binary_data.resize(destLen);
	dest.float_data.clear();
	const int ret = compress2((Bytef*)&dest.binary_data[0], &destLen, (const Bytef*)&src.float_data[0], rawLen, compressionMode);
	if(ret != Z_OK) throw std::runtime_error("Depth compression failed: zlib status " + lexical_cast<string>(ret));
	dest.binary_data.resize(destLen); //deallocate the part of the buffer we aren't using
}

/*
 * don't change the header
 *
 * post: depth.format == format_raw
 */
void readUncompressedDepthMap(const fs::path& filepath, rgbd_msgs::DepthMap& depth)
{
	rgbd::readDepthMap(filepath, depth);
	if(depth.format == rgbd_msgs::DepthMap::format_zlib)
	{
		rgbd_msgs::DepthMap rawDepth;
		rgbd::decompressDepthMap(depth, rawDepth);
		depth = rawDepth;
	}
}

/*
 * return a structure giving us access to an uncompressed depth map, whether the one we're given is compressed or not
 *
 * throw on any error
 */
void getUncompressedDepthMapPtrs(const rgbd_msgs::DepthMap& depth_msg, depthmapPtrs& ptrs)
{
	if(depth_msg.format == rgbd_msgs::DepthMap::format_raw)
	{
		ptrs.setNonOwning(depth_msg);
	}
	else if(depth_msg.format == rgbd_msgs::DepthMap::format_zlib)
	{
		rgbd_msgs::DepthMapPtr depth(new rgbd_msgs::DepthMap);
		rgbd::decompressDepthMap(depth_msg, *depth);
		ptrs.setOwning(depth);
	}
	else
	{
		throw std::runtime_error("Unsupported format for depth map");
	}
}

} //namespace
