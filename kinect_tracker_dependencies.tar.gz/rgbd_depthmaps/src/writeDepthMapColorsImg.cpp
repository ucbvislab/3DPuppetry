/*
 * writeDepthMapColorsImg: take a file written by rgbd::writeDepthMap() and create an image akin to those of Brian's depth_visualizer package
 *
 * Evan Herbst
 * 8 / 17 / 10
 */

#include <cassert>
#include <boost/lexical_cast.hpp>
#include <boost/filesystem/path.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "rgbd_depthmaps/depthIO.h"
#include "rgbd_depthmaps/decompressDepth.h"
using boost::lexical_cast;
namespace fs = boost::filesystem;

/*
 * arguments: infilepath, outfilepath, max depth (default 10)
 */
int main(int argc, char* argv[])
{
	assert(argc == 3 || argc == 4);
	const fs::path inpath(argv[1]), outpath(argv[2]);
	const float maxDepth = (argc == 4) ? lexical_cast<float>(argv[3]) : 10;

	rgbd_msgs::DepthMap dm;
	rgbd::readDepthMap(inpath, dm);
	cv::Mat img;
	if(dm.format == rgbd_msgs::DepthMap::format_raw)
	{
		rgbd::writeDepthMapColorsImg(dm, img, maxDepth);
	}
	else
	{
		rgbd_msgs::DepthMap uncompressedDM;
		rgbd::decompressDepthMap(dm, uncompressedDM);
		rgbd::writeDepthMapColorsImg(uncompressedDM, img, maxDepth);
	}
	cv::imwrite(outpath.string(), img);

	return 0;
}
