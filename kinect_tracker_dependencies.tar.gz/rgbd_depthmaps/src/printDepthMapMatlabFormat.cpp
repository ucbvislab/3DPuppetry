/*
 * printDepthMapMatlabFormat: read a depth-map file and print it as a matlab matrix
 *
 * Evan Herbst
 * 8 / 2 / 10
 */

#include <cassert>
#include <iostream>
#include <boost/lexical_cast.hpp>
#include <boost/filesystem.hpp>
#include "rgbd_msgs/DepthMap.h"
#include "rgbd_util/ros_utility.h"
#include "rgbd_depthmaps/depthIO.h"
#include "rgbd_depthmaps/decompressDepth.h"
//#include "rgbd_bag_utils/contents.h"
//#include "rgbd_bag_utils/rgbdBagReader.h"
using std::string;
using std::cout;
using std::endl;
using boost::lexical_cast;
namespace fs = boost::filesystem;

void printDepthMap(const rgbd_msgs::DepthMap& depth, std::ostream& out)
{
	for(unsigned int i = 0, k = 0; i < depth.height; i++)
	{
		for(unsigned int j = 0; j < depth.width; j++, k++) out << depth.float_data[k] << ' ';
		out << endl;
	}
}

//#define DO_WHOLE_BAG
#ifdef DO_WHOLE_BAG

/*
 * arguments: bag infilepath, start frame index, end frame index (use -1 for no limit)
 *
 * write to stdout (every 480 lines is a new frame)
 */
int main(int argc, char* argv[])
{
	assert(argc == 4);
	const fs::path bagFilepath(argv[1]);
	const unsigned int startFrameIndex = lexical_cast<unsigned int>(argv[2]), endFrameIndex = lexical_cast<unsigned int>(argv[3]);

	string depthTopic, imgTopic;
	bool depthCompressed, imgCompressed;
	rgbd::determineRGBDBagSchema(bagFilepath, depthTopic, imgTopic, depthCompressed, imgCompressed);
	rgbd::rgbdBagReader<> frameReader(bagFilepath, depthTopic, imgTopic, startFrameIndex, endFrameIndex, 0/* frameskip */, 1/* num prev frames to keep */);
	unsigned int frameIndex = startFrameIndex;
	while(frameReader.readOne())
	{
		const rgbd_msgs::DepthMap& depth = frameReader.getLastDepthMap();
		if(depth.format == rgbd_msgs::DepthMap::format_zlib)
		{
			rgbd_msgs::DepthMap rawDepth;
			rgbd::decompressDepthMap(depth, rawDepth);
			printDepthMap(rawDepth, cout);
		}
		else printDepthMap(depth, cout);
	}

	return 0;
}

#else

/*
 * arguments: depth-map infilepath
 *
 * write to stdout
 */
int main(int argc, char* argv[])
{
	assert(argc == 2);
	rgbd_msgs::DepthMap depth;
	rgbd::readDepthMap(argv[1], depth);
	if(depth.format == rgbd_msgs::DepthMap::format_zlib)
	{
		rgbd_msgs::DepthMap rawDepth;
		rgbd::decompressDepthMap(depth, rawDepth);
		printDepthMap(rawDepth, cout);
	}
	else printDepthMap(depth, cout);

	return 0;
}

#endif
