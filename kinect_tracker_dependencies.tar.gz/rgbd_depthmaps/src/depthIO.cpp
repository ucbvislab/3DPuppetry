/*
 * depthIO: read/write depth maps
 *
 * Evan Herbst
 * 8 / 2 / 10
 */

#include <cassert>
#include <fstream>
#include <stdexcept>
#include <boost/lexical_cast.hpp>
#include "rgbd_util/ioUtils.h"
#include "rgbd_util/mathUtils.h" //clamp()
#include "rgbd_depthmaps/depthIO.h"
using std::string;
using std::ifstream;
using std::ofstream;
using boost::lexical_cast;

namespace rgbd
{

/*
 * don't change the header
 */
void readDepthMap(const fs::path& filepath, rgbd_msgs::DepthMap& depth)
{
	ifstream infile(filepath.string().c_str(), ifstream::binary);
	assert(infile);
	readBinary(infile, depth.width);
	readBinary(infile, depth.height);
	readBinary(infile, depth.focal_distance);
	readBinary(infile, depth.no_sample_value);
	readBinary(infile, depth.shadow_value);
	readBinary(infile, depth.format);
	switch(depth.format)
	{
		case rgbd_msgs::DepthMap::format_raw:
			depth.float_data.resize(depth.width * depth.height);
			readBinaryArray(infile, depth.float_data.data(), depth.float_data.size());
			break;
		case rgbd_msgs::DepthMap::format_zlib:
		{
			uint64_t len;
			readBinary(infile, len);
			depth.binary_data.resize(len);
			readBinaryArray(infile, depth.binary_data.data(), depth.binary_data.size());
			break;
		}
		default: throw std::runtime_error("unhandled depth-map format" + lexical_cast<string>(depth.format));
	}
}

void writeDepthMap(const rgbd_msgs::DepthMap& depth, const fs::path& filepath)
{
	ofstream outfile(filepath.string().c_str(), ofstream::binary);
	assert(outfile);
	writeBinary(outfile, depth.width);
	writeBinary(outfile, depth.height);
	writeBinary(outfile, depth.focal_distance);
	writeBinary(outfile, depth.no_sample_value);
	writeBinary(outfile, depth.shadow_value);
	writeBinary(outfile, depth.format);
	switch(depth.format)
	{
		case rgbd_msgs::DepthMap::format_raw:
			writeBinaryArray(outfile, depth.float_data.data(), depth.float_data.size());
			break;
		case rgbd_msgs::DepthMap::format_zlib:
			writeBinary(outfile, (uint64_t)depth.binary_data.size());
			writeBinaryArray(outfile, depth.binary_data.data(), depth.binary_data.size());
			break;
		default: throw std::runtime_error("unhandled depth-map format" + lexical_cast<string>(depth.format));
	}
}

/*
 * write an image to be viewed by people
 *
 * img will be allocated
 *
 * pre: depth is uncompressed
 */
void writeDepthMapColorsImg(const rgbd_msgs::DepthMap& depth, cv::Mat& img, const float maxDepth, const cv::Scalar minDepthCol, const cv::Scalar maxDepthCol)
{
	assert(depth.format == rgbd_msgs::DepthMap::format_raw);
	img.create(depth.height, depth.width, CV_8UC3);

	const float minDepth = 0;
	for(uint32_t i = 0; i < depth.height; i++)
		for(uint32_t j = 0; j < depth.width; j++)
		{
			const float d = depth.float_data[i * depth.width + j];
			unsigned char* pixel = img.ptr(i) + 3 * j;

			if(d < 0)
			{
				pixel[0] = 0;
				pixel[1] = 0;
				pixel[2] = 255;
			}
			else
			{
				const double normalized_depth = clamp((double)(d - minDepth) / (maxDepth - minDepth), 0.0, 1.0);
				for(unsigned int k = 0; k < 3; k++) pixel[k] = normalized_depth * maxDepthCol[2 - k] + (1 - normalized_depth) * minDepthCol[2 - k]; //2 - k because opencv stores bgr
			}
		}
}

/*
 * write a single-channel image to be read by a machine, giving depth values in integral mm
 *
 * if you cv::imwrite() the result and it's 16-bit, the resulting file will contain 16-bit values
 *
 * img will be allocated
 *
 * pre: depth is uncompressed
 */
void writeDepthMapValuesImg(const rgbd_msgs::DepthMap& depth, cv::Mat& img, const bool write16bit)
{
	assert(depth.format == rgbd_msgs::DepthMap::format_raw);
	img.create(depth.height, depth.width, write16bit ? CV_16UC1 : CV_8UC1);

	const float minDepth = 0;
	for(uint32_t i = 0; i < depth.height; i++)
		for(uint32_t j = 0; j < depth.width; j++)
		{
			float d = depth.float_data[i * depth.width + j];
			if(d < 0) d = 0;
			const unsigned short ud = rint(1000 * d); //m -> mm
			if(write16bit) img.at<unsigned short>(i, j) = ud;
			else img.at<unsigned char>(i, j) = ud;
		}
}

/*
 * read 8- or 16-bit png
 *
 * don't change the header
 */
void readDepthMapValuesImg(const cv::Mat& img, rgbd_msgs::DepthMap& depth)
{
	assert(img.type() == CV_8UC1 || img.type() == CV_16UC1);
	const bool read16bit = (img.type() == CV_16UC1);
	depth.height = img.rows;
	depth.width = img.cols;
	depth.format = rgbd_msgs::DepthMap::format_raw;
	depth.float_data.resize(depth.height * depth.width);
	for(uint32_t i = 0, k = 0; i < img.rows; i++)
		for(uint32_t j = 0; j < img.cols; j++, k++)
		{
			if(read16bit) depth.float_data[k] = img.at<unsigned short>(i, j) * .001; //mm -> m
			else depth.float_data[k] = img.at<unsigned char>(i, j) * .001; //mm -> m
		}
}

} //namespace
