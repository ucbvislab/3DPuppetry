/*
 * writeDepthMapValuesImg: take a .dm-format depth-map file and write a single-channel 16-bit image
 *
 * Evan Herbst
 * 11 / 17 / 10
 */

#include <cassert>
#include <boost/filesystem/path.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "rgbd_depthmaps/depthIO.h"
#include "rgbd_depthmaps/decompressDepth.h"
namespace fs = boost::filesystem;

/*
 * arguments: infilepath, outfilepath
 */
int main(int argc, char* argv[])
{
	assert(argc == 3);
	const fs::path inpath(argv[1]), outpath(argv[2]);
	rgbd_msgs::DepthMap depth;
	rgbd::readDepthMap(inpath, depth);
	rgbd_msgs::DepthMap rawDepth;
	if(depth.format == rgbd_msgs::DepthMap::format_zlib) rgbd::decompressDepthMap(depth, rawDepth);
	else rawDepth = depth;
	cv::Mat outImg;
	rgbd::writeDepthMapValuesImg(rawDepth, outImg, true/* 16-bit */);
	cv::imwrite(outpath.string(), outImg);
	return 0;
}
