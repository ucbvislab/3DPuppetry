#include <fstream>
#include <iostream>
#include <string>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>
#include <math.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <cmath>
#include <vector>
#include <opencv/cv.h>
#include <opencv/highgui.h>

#include <ros/ros.h>
#include <ros/subscriber.h>
#include <rgbd_util/ros_utility.h>
#include <sensor_msgs/Image.h>
#include <rgbd_msgs/DepthMap.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include <std_msgs/Float32MultiArray.h>

#include "pcl_rgbd/pointTypes.h"
#include "pcl_rgbd/depth_to_cloud_lib.h"
#include "pcl_rgbd/cloudUtils.h"
#include "pcl_rgbd/cloudTofroPLY.h"
#include "pcl_rgbd/cloudGeometry.h"


#include <pcl/ros/conversions.h>
#include <pcl_ros/publisher.h>

using namespace std;

#define ADD		0
#define	REMOVE	1
#define	CONFIRM	2

#define	RED		0
#define	GREEN	1
#define	BLUE	2
#define	YELLOW	3
#define	SPEC	4

typedef rgbd::pt PointT;

float background_depth[640][480];

float findcolor(PointT pt)
{
	boost::array<float, 3> fcolor = rgbd::unpackRGB<float>(pt.rgb);

	if(fcolor[0]>1.5*fcolor[1] && fcolor[0]>1.5*fcolor[2])
		return RED;
	else if(fcolor[1]>1.01*fcolor[0] && fcolor[1]>1.01*fcolor[2])
		return GREEN;
	else if(fcolor[2]>1.01*fcolor[0] && fcolor[2]>1.01*fcolor[1])
		return BLUE;
	else if(fcolor[0]>1.3*fcolor[2] && fcolor[1]>1.3*fcolor[2])
		return YELLOW;
	else
		return YELLOW;
}

class BlockTracker {
public:
	BlockTracker();
	~BlockTracker();

	void start();
	void cloudCallback(sensor_msgs::PointCloud2ConstPtr cloud_ptr);
	void findBackgroundPlane(pcl::PointCloud<pcl::PointXYZRGB> kcloud);

protected:
	// functions
	void load_ros_params();

	// members
	ros::NodeHandle nh_global;
	ros::NodeHandle nh_local;

	int processed_frame;
	int subscription_buffer_size;
	bool use_backsub_segmenter;
	bool use_volume_segmenter;
	bool use_color_segmenter;
	bool use_ui;
	bool publish_background;
	std::string color_model_name;
	std::string volume_model_name;
	std::string button_volume_name;
	vector<bool> colormodel;
	float depthvolume[4][9];
	float button1[4][9];
	float button2[4][9];
	float button3[4][9];
	int decision[4][4];
	int numr, numg, numb;
	double depth_focal_length;

	static const int 			max_out_of_order = 100;
	ros::Subscriber 			cloud_subscription;
	pcl_ros::Publisher<PointT> 	cloud_pub;
	ros::Publisher 				background_pub;
	vector<float> 				publish_background_plane;
	int	cloud_skip;

};

BlockTracker::BlockTracker()
: nh_global(),
  nh_local("~")
{
	processed_frame = 0;

	load_ros_params();

	if(use_color_segmenter)
	{
		// load color model
		char str[100];
		std::fstream file;
		file.open(color_model_name.c_str(), ios::in);
		if(!file.is_open())
			use_color_segmenter = false;
		else
		{
			file>>str;	numr = atoi(str);
			file>>str;	numg = atoi(str);
			file>>str;	numb = atoi(str);
			colormodel.clear();
			for(int i=0;i<numr*numg*numb;i++)
			{
				file>>str;
				int label = atoi(str);
				if(label==1)
					colormodel.push_back(true);
				else
					colormodel.push_back(false);
			}
			file.close();
		}
	}
	if(use_volume_segmenter)
	{
		ROS_INFO_STREAM("Loading the volume model");
		// load volume model
		char str[100];
		std::fstream file;
		file.open(volume_model_name.c_str(), ios::in);
		if(!file.is_open())
		{
			ROS_INFO_STREAM("Not able to open volume model file so setting it to false");
			use_volume_segmenter = false;
		}
		else
		{
			if(use_ui)
			{
				for(int i=0;i<16;i++)
					for(int j=0;j<9;j++)
					{
						file>>str;
						float val = atof(str);
						if(i<4)
							depthvolume[i][j] = val;
						else if(i<8)
							button1[i-4][j] = val;
						else if(i<12)
							button2[i-8][j] = val;
						else if(i<16)
							button3[i-12][j] = val;
					}
			}
			else
			{
				for(int i=0;i<4;i++)
					for(int j=0;j<9;j++)
					{
						file>>str;
						float val = atof(str);
						depthvolume[i][j] = val;
					}
			}
//			for(int i=0;i<4;i++)
//				for(int j=0;j<9;j++)
//					ROS_INFO_STREAM(button1[i][j]<<"\t"<<button2[i][j]);

		}
		file.close();
	}
	cloud_pub.advertise(nh_global, "outcloud", 1);

	if (publish_background)
		background_pub = nh_global.advertise<std_msgs::Float32MultiArray>("camera/background_plane", 1);

}

BlockTracker::~BlockTracker()
{
}

void
BlockTracker::load_ros_params()
{
    nh_local.param("subscription_buffer_size", subscription_buffer_size, 1);
    nh_local.param("color_model_name", color_model_name, std::string(""));
    nh_local.param("volume_model_name", volume_model_name, std::string(""));
    nh_local.param("use_color_segmenter", use_color_segmenter, false);
    nh_local.param("use_volume_segmenter", use_volume_segmenter, false);
    nh_local.param("use_ui", use_ui, false);
    nh_local.param("use_backsub_segmenter", use_backsub_segmenter, false);
    nh_local.param("cloud_skip",cloud_skip,1);
    nh_local.param("publish_background", publish_background, false);
    nh_local.param("depth_focal_length", depth_focal_length, 525.00);
}

void
BlockTracker::cloudCallback(sensor_msgs::PointCloud2ConstPtr cloud_ptr)
{
	ros::Time current_frame_timestamp = cloud_ptr->header.stamp;
	pcl::PointCloud<pcl::PointXYZRGB> kcloud;
	pcl::PointCloud<PointT> incloud, outcloud;
	pcl::fromROSMsg(*cloud_ptr, kcloud);
	outcloud.header = kcloud.header;

	int width = 640, height = 480;
	float f=(float)depth_focal_length; // Ankit used 570.342, 525 works best for Robin
	if(processed_frame<10)
	{
		// learn depth buffer
		// project the cloud onto a depth buffer
		for(int i=0;i<640;i++)
			for(int j=0;j<480;j++)
				background_depth[i][j] = 9999;

		int numpts = (int)kcloud.points.size();
		for(int i=0;i<numpts;i++)
		{
			// project the point and keep the lowest depth at a frame
			pcl::PointXYZRGB point = kcloud.points[i];
			int px, py;
			// splat the point into 3X3 window
			px = (int)(point.x*f/point.z + width/2);
			py = (int)(point.y*f/point.z + height/2);
			float d = point.z;
			int w = 1;
			for(int j=px-w;j<=px+w;j++)
				for(int k=py-w;k<=py+w;k++)
					if(j>=0 && k>=0 && j<640 && k<480 && d==d)
						background_depth[j][k] = min(background_depth[j][k], d);
		}

		if (processed_frame<5 && publish_background)
			findBackgroundPlane(kcloud);
	}
	else
	{
		for(int i=0;i<4;i++)
			for(int j=0;j<4;j++)
				decision[i][j] = 0;

		for (int i=0;i<(int)kcloud.points.size();i++)
		{

			pcl::PointXYZRGB point = kcloud.points[i];
			PointT pt;
			pt.x = point.x;
			pt.y = point.y;
			pt.z = point.z;
			pt.rgb = point.rgb;

			// project point into the depth buffer and check
			int x=0, y=0;
			x = (int)max(0.0f, min(639.0f, (point.x*f/point.z + width/2)));
			y = (int)max(0.0f, min(479.0f, (point.y*f/point.z + height/2)));

			if (((x%cloud_skip)!= 0) || ((y%cloud_skip)!= 0))
				continue;

//			ROS_INFO_STREAM("x coord: " << (point.x*f/point.z + width/2));

			float d_back = background_depth[x][y];
			float d = point.z;

			if(use_backsub_segmenter)
				if((d!=d) || (d_back>999) || (d > 0.985*d_back && d_back<999))
					continue;

			const uint32_t rgbi = *reinterpret_cast<const uint32_t*>(&(point.rgb));
			const boost::array<float, 3> fcolor =
			{{(float)((rgbi >> 16) & 0xff) / 255,
					(float)((rgbi >> 8) & 0xff) / 255,
					(float)(rgbi & 0xff) / 255}};

			bool color_ok = true;
			if(use_color_segmenter)
			{
				if((int)colormodel.size()>0 && (int)colormodel.size()==numr*numg*numb)
				{
					int rbin = (int)(fcolor[0]*numr);
					int gbin = (int)(fcolor[1]*numg);
					int bbin = (int)(fcolor[2]*numb);
					if(colormodel[rbin*numg*numb + gbin*numr + bbin])
						color_ok = false;
				}
			}

			if(use_volume_segmenter)
			{
				bool flag0 = true;
				bool flag1 = true;
				bool flag2 = true;
				bool flag3 = true;
				for(int j=0;j<4;j++)
				{
					// check with the plane
					if((point.x - depthvolume[j][0])*depthvolume[j][6] +
							(point.y - depthvolume[j][1])*depthvolume[j][7] +
							(point.z - depthvolume[j][2])*depthvolume[j][8] < 0)
						flag0 = false;
				}
				if(use_ui)
				{
					for(int j=0;j<4;j++)
					{
						// check with the plane
						if((point.x - button1[j][0])*button1[j][6] +
								(point.y - button1[j][1])*button1[j][7] +
								(point.z - button1[j][2])*button1[j][8] < 0)
							flag1 = false;
					}
					for(int j=0;j<4;j++)
					{
						// check with the plane
						if((point.x - button2[j][0])*button2[j][6] +
								(point.y - button2[j][1])*button2[j][7] +
								(point.z - button2[j][2])*button2[j][8] < 0)
							flag2 = false;
					}
					for(int j=0;j<4;j++)
					{
						// check with the plane
						if((point.x - button3[j][0])*button3[j][6] +
								(point.y - button3[j][1])*button3[j][7] +
								(point.z - button3[j][2])*button3[j][8] < 0)
							flag3 = false;
					}

					if(flag1 && color_ok)
					{
						// find color of point
						int col = (int)findcolor(pt);
						// add to corresponding decision[ADD][i]
						if(col!=SPEC)
							decision[ADD][col]++;
					}
					if(flag2 && color_ok)
					{
						// find color of point
						int col = (int)findcolor(pt);
						// add to corresponding decision[REM][i]
						if(col!=SPEC)
							decision[REMOVE][col]++;
					}
					if(flag3)
						decision[CONFIRM][0]++;
				}
				//if(!flag0 && !flag1 && !flag2 && !flag3 && !flag4)
				if(!flag0)
					continue;

			}

			if(!color_ok)
				continue;

			outcloud.push_back(pt);
		}

		// check the decision
		if(use_ui)
		{
			PointT pt;
			pt.rgb = -1;
			// pick maxima
			int maxvotes = 200;
			int besti=-1, bestj=-1;

			// find best of add or remove, if they are fine declare that to be decision
			// else look at check or confirm

			if(decision[CONFIRM][0]>maxvotes)
			{
				besti = CONFIRM;
				bestj = -1;
			}
			else
			{
				for(int i=0;i<2;i++)
					for(int j=0;j<4;j++)
						if(decision[i][j]>maxvotes)
						{
							maxvotes = decision[i][j];
							besti = i;
							bestj = j;
						}
			}

			pt.imgX = besti;
			pt.imgY = bestj;

			outcloud.push_back(pt);
/*
			if(besti==ADD)
				ROS_INFO_STREAM("Block added "<<besti<<" of color "<<bestj);
			else if(besti==REMOVE)
				ROS_INFO_STREAM("Block removed "<<besti<<" of color "<<bestj);
			else if(besti==CONFIRM)
				ROS_INFO_STREAM("Rechecking");
			else
				ROS_INFO_STREAM("No update");
*/
		}

		outcloud.height = 1;
		outcloud.width = outcloud.points.size();
		cloud_pub.publish(outcloud);

	}

	if (publish_background && processed_frame > 5)
	{
		std_msgs::Float32MultiArray background_msg;
		background_msg.data = publish_background_plane;
		background_pub.publish(background_msg);
	}
	processed_frame++;
}

// Used for background estimation
bool orderfunc(float x, float y)
{
	return (x<y);
}

void
BlockTracker::findBackgroundPlane(pcl::PointCloud<pcl::PointXYZRGB> kcloud)
{
	// Characterize background
	Eigen::Vector3f bnormal;
	Eigen::Vector3f bnormal_base;
	int best_inliers = 0;
//	float bdepth;
//	vector<float> depths;
	vector<Eigen::Vector3f> valid_points;
	int invalid_depths = 0;
	int num_pts;

	float med_depth = -1;
	for(int i=0; i<(int)kcloud.points.size(); i++)
	{
		const float depth = kcloud.points[i].z;
		if(depth>0 && depth==depth /* to check for NaN */)
		{
			if ((fabs(kcloud.points[i].x) < 0.40) && (fabs(kcloud.points[i].y) < 0.4))
			{
				Eigen::Vector3f pt;
				pt.x() = kcloud.points[i].x;
				pt.y() = kcloud.points[i].y;
				pt.z() = kcloud.points[i].z;
				valid_points.push_back(pt);
			}
		}
		else
		{
			invalid_depths++;
		}
	}

	num_pts = valid_points.size();

	if(invalid_depths>60000)
	{
		ROS_INFO_STREAM("Invalid depths: " << invalid_depths);
		return;
	}

	// Adapted from http://mariotapilouw.blogspot.com/2011/05/plane-fitting-using-opencv.html
	CvMat *res  = cvCreateMat(3, 1, CV_32FC1);
	CvMat *matX = cvCreateMat(num_pts, 3, CV_32FC1);
	CvMat *matZ = cvCreateMat(num_pts, 1, CV_32FC1);

	for(uint idx=0;idx<num_pts;idx++)
	{
		cvmSet(matX, idx, 0, valid_points[idx].x());
		cvmSet(matX, idx, 1, valid_points[idx].y());
		cvmSet(matX, idx, 2, 1);
		cvmSet(matZ, idx, 0, valid_points[idx].z());
	}

	float A,B,C;

	cvSolve(matX, matZ, res, CV_SVD);
	A = cvmGet(res, 0, 0);
	B = cvmGet(res, 1, 0);
	C = cvmGet(res, 2, 0);

	// Find normal
	// Assume x=1, y=1:
	Eigen::Vector3f vec1(0,0,C);
	Eigen::Vector3f vec2(1,1,A + B + C);
	Eigen::Vector3f vec3(-1,2,-A + 2*B + C);

	bnormal = (vec3-vec1).cross(vec2-vec1);
	bnormal = bnormal.normalized();

	bnormal_base[0] = 0;
	bnormal_base[1] = 0;
	bnormal_base[2] = C;


//		// OLD WAY:
//		// Characterize background
//			Eigen::Vector3f bnormal;
//			Eigen::Vector3f bnormal_base;
//			int best_inliers = 0;
//		//	float bdepth;
//			vector<float> depths;
//			int invalid_depths = 0;
//			int num_pts = (int)kcloud.points.size();
//
//			float med_depth = -1;
//			for(int i=0; i<num_pts; i++)
//			{
//				const float depth = kcloud.points[i].z;
//				if(depth>0 && depth==depth /* to check for NaN */)
//				{
//					depths.push_back(depth);
//				}
//				else
//				{
//					invalid_depths++;
//				}
//			}
//
//			if(invalid_depths>60000)
//			{
//				ROS_INFO_STREAM("Invalid depths: " << invalid_depths);
//				return;
//			}
//
//			sort (depths.begin(), depths.end(), orderfunc);
//		//	ROS_INFO_STREAM("Min depth: " << depths[0]);
//		//	ROS_INFO_STREAM("Max depth: %f", depths[depths.size()-1]);
//
//			med_depth = depths[(int)depths.size()/2];
//		//	ROS_INFO_STREAM("Median depth: " << depths[(int)depths.size()/2]);
//		// Pick 3 random points
//		Eigen::Vector3f pts[3];
//		int count = 0;
//		int index = 0;
//		while(count<3)
//		{
//			index = (index+rand())%num_pts;
//			pcl::PointXYZRGB point = kcloud.points[index];
//			float d = point.z;
//			if(d!=d /* check for NanN */ || d>=1.2*med_depth || d<0.8*med_depth)
//				continue;
//
//			pts[count].x() = point.x;
//			pts[count].y() = point.y;
//			pts[count].z() = point.z;
//			count = count+1;
//		}
//
//		Eigen::Vector3f tnormal = (pts[2]-pts[0]).cross(pts[1]-pts[0]);
//		tnormal.normalize();
//		if(tnormal.z()>0)
//			tnormal = tnormal * -1;
//
//		float tdepth = pts[0].dot(tnormal);
//
//		// go through all the points to get inliers
//		int inliers = 0;
//		for(int i=0; i<num_pts; i++) {
//			Eigen::Vector3f pt;
//			pt.x() = kcloud.points[i].x;
//			pt.y() = kcloud.points[i].y;
//			pt.z() = kcloud.points[i].z;
//			if(abs(tnormal.dot(pt) - tdepth)<0.01)
//				inliers++;
//		}
//
////		ROS_INFO_STREAM("inliers: " << inliers);
//
//		if(inliers>best_inliers)
//		{
//			bnormal = tnormal;
//			bnormal_base = pts[0];
////			bdepth = tdepth;
//			best_inliers = inliers;
//		}
//	}
	publish_background_plane.clear();
	publish_background_plane.push_back(bnormal.x());
	publish_background_plane.push_back(bnormal.y());
	publish_background_plane.push_back(bnormal.z());
	publish_background_plane.push_back(bnormal_base.x());
	publish_background_plane.push_back(bnormal_base.y());
	publish_background_plane.push_back(bnormal_base.z());

//	ROS_INFO_STREAM("background center: " << bnormal.x() << " " << bnormal.y() << " " << bnormal.z());
//	ROS_INFO_STREAM("background normal: " << bnormal_base.x() << " " << bnormal_base.y() << " " << bnormal_base.z());
}


void
BlockTracker::start()
{
	int queue_size = 3; // 0 means unlimited queue...
	cloud_subscription = nh_global.subscribe<sensor_msgs::PointCloud2>("incloud", queue_size, boost::bind(&BlockTracker::cloudCallback, this, _1));

	ros::spin();
}

void *NodeThread(void*)
{
	BlockTracker node;
	node.start();
}

int main (int argc, char** argv)
{
	ros::init (argc, argv, "ColorVolumeSegmenter");

	int rc1;
	pthread_t thread1;

	/* Create independent threads each of which will execute functionC */

	if( (rc1=pthread_create( &thread1, NULL, &NodeThread, NULL)) )
	{
		printf("Thread creation failed: %d\n", rc1);
	}

	pthread_join( thread1, NULL);

	return 0;
}
