/*
 * imageCompression: a customized copy of compressed_image_transport that, unlike the original, will have a reliable API
 *
 * Evan Herbst
 * 10 / 19 / 10
 */

#ifndef EX_RGBD_IMAGE_COMPRESSION_H
#define EX_RGBD_IMAGE_COMPRESSION_H

#include <sensor_msgs/Image.h>
#include <sensor_msgs/CompressedImage.h>

namespace rgbd
{

struct imgCompressionOptions
{
	imgCompressionOptions() : format(FMT_PNG), pngCompressionLevel(9)
	{}

	enum {FMT_JPG, FMT_PNG} format;
	unsigned int jpgQuality, //in [1, 100]
		pngCompressionLevel; //in [1, 9]
};

void compressImg(const sensor_msgs::Image& img, sensor_msgs::CompressedImage& cimg, const imgCompressionOptions& opts = imgCompressionOptions());
void decompressImg(const sensor_msgs::CompressedImage& cimg, sensor_msgs::Image& img);

} //namespace

#endif //header
