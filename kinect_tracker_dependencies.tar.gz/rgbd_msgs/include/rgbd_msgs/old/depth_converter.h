#include <ros/ros.h>
#include <rgbd_msgs/DepthMap.h>
#include <rgbd_msgs/DepthMapArray.h>

#include <stdint.h>
#include <string.h>
#include <png.h>
#include <zlib.h>

#ifndef LIBRGBD_MSGS
#warning BIG WARNING: YOU ARE USING CODE THAT IS STILL UNDER DEVELOPMENT \
AND COMPLETELY UNTESTED!!!  PROCEED AT YOUR OWN RISK!
#endif

typedef struct {
    uint8_t *data;
    size_t offset;
} img_read_state;

namespace rgbd_msgs {

class DepthConverter {
    
    public:
    DepthConverter();
    ~DepthConverter();
    float *convert(rgbd_msgs::DepthMap &dm);
    float *convert(rgbd_msgs::DepthMapArray &dm);

    protected:
    float *depth_map;
    size_t dm_alloc_size;

    void check_alloc(size_t required_size);
    void setup_image(unsigned int width, unsigned int height);
    void decompress(float *out, size_t out_size, uint8_t *in, size_t in_size,
        uint8_t format);
    void decompress_zlib(float *out, size_t out_size, uint8_t *in, size_t in_size);
    void decompress_png(float *out, uint8_t *in);

    // PNG decompression stuff
    uint16_t *int_map;
    size_t im_alloc_size;
    png_bytep *im_row_pointers;

};

}

