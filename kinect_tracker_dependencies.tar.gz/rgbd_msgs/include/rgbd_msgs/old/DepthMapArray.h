#ifndef RGBD_MSGS_DEPTHMAPARRAY_H
#define RGBD_MSGS_DEPTHMAPARRAY_H

#include <string>
#include <vector>
#include "ros/message.h"
#include "ros/debug.h"
#include "ros/assert.h"
#include "ros/time.h"

#include "roslib/Header.h"

namespace rgbd_msgs
{

//! \htmlinclude DepthMap.msg.html

class DepthMapArray : public ros::Message
{
public:
  typedef boost::shared_ptr<DepthMapArray> Ptr;
  typedef boost::shared_ptr<DepthMapArray const> ConstPtr;

  typedef roslib::Header _header_type;
  typedef std::string _sensor_type_type;
  typedef uint16_t _width_type;
  typedef uint16_t _height_type;
  typedef float _focal_distance_type;
  typedef float _no_sample_value_type;
  typedef float _shadow_value_type;
  typedef int8_t _format_type;
  typedef uint8_t* _binary_data_type;
  typedef float* _float_data_type;

  roslib::Header header;
  std::string sensor_type;
  uint16_t width;
  uint16_t height;
  float focal_distance;
  float no_sample_value;
  float shadow_value;
  int8_t format;
  const static int8_t format_raw = 0;
  const static int8_t format_packed = 1;
  const static int8_t format_zlib = 2;
  const static int8_t format_png = 3;
  uint8_t *binary_data;
  unsigned int binary_data_length;
  float *float_data;
  unsigned int float_data_length;

  DepthMapArray() : ros::Message(),
    width(0),
    height(0),
    focal_distance(0),
    no_sample_value(0),
    shadow_value(0),
    format(0),
    binary_data(NULL),
    binary_data_length(NULL),
    float_data(NULL),
    float_data_length(0)
  {
  }
  DepthMapArray(const DepthMapArray &copy) : ros::Message(),
    header(copy.header),
    sensor_type(copy.sensor_type),
    width(copy.width),
    height(copy.height),
    focal_distance(copy.focal_distance),
    no_sample_value(copy.no_sample_value),
    shadow_value(copy.shadow_value),
    format(copy.format)
  {
    (void)copy;
    if(copy.binary_data) {
        binary_data = (uint8_t *)malloc( copy.binary_data_length);
        binary_data_length = copy.binary_data_length;
    } else {
        binary_data = NULL;
        binary_data_length = 0;
    }
    if(copy.float_data) {
        float_data = (float *)malloc(sizeof(float) * copy.float_data_length);
        float_data_length = copy.float_data_length;
    } else {
        float_data = NULL;
        float_data_length = 0;
    }
  }

  DepthMapArray &operator =(const DepthMapArray &copy)
  {
    if (this == &copy)
      return *this;
    header = copy.header;
    sensor_type = copy.sensor_type;
    width = copy.width;
    height = copy.height;
    focal_distance = copy.focal_distance;
    no_sample_value = copy.no_sample_value;
    shadow_value = copy.shadow_value;
    format = copy.format;
    if(copy.float_data) {
        float_data = (float *)malloc(sizeof(float) * copy.float_data_length);
        float_data_length = copy.float_data_length;
    } else {
        float_data = NULL;
        float_data_length = 0;
    }
    if(copy.binary_data) {
        binary_data = (uint8_t *)malloc(copy.binary_data_length);
        binary_data_length = copy.binary_data_length;
    } else {
        binary_data = NULL;
        binary_data_length = 0;
    }
    return *this;
  }

  virtual ~DepthMapArray() 
  {
    if(binary_data) {
        free(binary_data);
        binary_data = NULL;
    }
    if(float_data) {
        free(float_data);
        float_data = NULL;
    }
  }
  inline static std::string __s_getDataType() { return std::string("rgbd_msgs/DepthMap"); }
  inline static std::string __s_getMD5Sum() { return std::string("332809c46e540d2f25081e8ac3d4a68f"); }
  inline static std::string __s_getMessageDefinition()
  {
    return std::string(
    "Header header\n"
    "\n"
    "string sensor_type\n"
    "\n"
    "# Dimensions of the depth map\n"
    "uint16 width\n"
    "uint16 height\n"
    "\n"
    "# focal distance in pixels\n"
    "float32 focal_distance\n"
    "\n"
    "# 3D parameters\n"
    "float32 no_sample_value\n"
    "float32 shadow_value\n"
    "\n"
    "# encoding\n"
    "int8 format\n"
    "int8 format_raw = 0\n"
    "int8 format_packed = 1\n"
    "int8 format_zlib = 2\n"
    "int8 format_png = 3\n"
    "\n"
    "# data: only one of the following (determined by the encoding type)\n"
    "# should be filled in; raw uses float_data, zlib uses binary_data\n"
    "uint8[] binary_data\n"
    "float32[] float_data\n"
    "\n"
    "\n"
    "================================================================================\n"
    "MSG: roslib/Header\n"
    "#Standard metadata for higher-level flow data types\n"
    "#sequence ID: consecutively increasing ID \n"
    "uint32 seq\n"
    "#Two-integer timestamp that is expressed as:\n"
    "# * stamp.secs: seconds (stamp_secs) since epoch\n"
    "# * stamp.nsecs: nanoseconds since stamp_secs\n"
    "# time-handling sugar is provided by the client library\n"
    "time stamp\n"
    "#Frame this data is associated with\n"
    "# 0: no frame\n"
    "# 1: global frame\n"
    "string frame_id\n"
    "\n"
    "\n"
    );
  }
  inline virtual const std::string __getDataType() const { return __s_getDataType(); }
  inline virtual const std::string __getMD5Sum() const { return __s_getMD5Sum(); }
  inline virtual const std::string __getMessageDefinition() const { return __s_getMessageDefinition(); }
  void set_binary_data_size(uint32_t __ros_new_size)
  {
    if(binary_data) {
        free(binary_data);
    }
    binary_data_length = __ros_new_size;
    binary_data = (uint8_t*)malloc(binary_data_length);
  }
  inline uint32_t get_binary_data_size() const { return binary_data_length; }
  
  void set_float_data_size(uint32_t __ros_new_size)
  {
    if(float_data) {
        free(float_data);
    }
    float_data_length = __ros_new_size;
    float_data = (float *)malloc(sizeof(float) * float_data_length);
  }

  inline uint32_t get_float_data_size() const { return float_data_length; }
  
  /*
  inline void get_float_data_vec (std::vector<float> &__ros_vec) const
  {
    __ros_vec = this->float_data;
  }
  inline void set_float_data_vec(const std::vector<float> &__ros_vec)
  {
    this->float_data = __ros_vec;
  }
  */
  inline uint32_t serializationLength() const
  {
    unsigned __l = 0;
    __l += header.serializationLength(); // header
    __l += 4 + sensor_type.length(); // sensor_type
    __l += 2; // width
    __l += 2; // height
    __l += 4; // focal_distance
    __l += 4; // no_sample_value
    __l += 4; // shadow_value
    __l += 1; // format
    __l += 0; // format_raw
    __l += 0; // format_packed
    __l += 0; // format_zlib
    __l += 0; // format_png
    __l += 4 + (binary_data_length ? binary_data_length * 1 : 0); // binary_data
    __l += 4 + (float_data ? float_data_length * 4 : 0); // float_data
    return __l;
  }
  virtual uint8_t *serialize(uint8_t *write_ptr,
                             uint32_t seq) const
  {
    roslib::Header _ser_header = header;
    bool __reset_seq = (header.seq == 0);
    if (__reset_seq) _ser_header.seq = seq;
    write_ptr = _ser_header.serialize(write_ptr, seq);
    unsigned __ros_sensor_type_len = sensor_type.length();
    SROS_SERIALIZE_PRIMITIVE(write_ptr, __ros_sensor_type_len);
    SROS_SERIALIZE_BUFFER(write_ptr, sensor_type.c_str(), __ros_sensor_type_len);
    SROS_SERIALIZE_PRIMITIVE(write_ptr, width);
    SROS_SERIALIZE_PRIMITIVE(write_ptr, height);
    SROS_SERIALIZE_PRIMITIVE(write_ptr, focal_distance);
    SROS_SERIALIZE_PRIMITIVE(write_ptr, no_sample_value);
    SROS_SERIALIZE_PRIMITIVE(write_ptr, shadow_value);
    SROS_SERIALIZE_PRIMITIVE(write_ptr, format);
    uint32_t __binary_data_size = binary_data_length;
    SROS_SERIALIZE_PRIMITIVE(write_ptr, __binary_data_size);
    memcpy(write_ptr, &binary_data[0], sizeof(uint8_t) * __binary_data_size);
    write_ptr += sizeof(uint8_t) * __binary_data_size;
    uint32_t __float_data_size = float_data_length;
    SROS_SERIALIZE_PRIMITIVE(write_ptr, __float_data_size);
    memcpy(write_ptr, &float_data[0], sizeof(float) * __float_data_size);
    write_ptr += sizeof(float) * __float_data_size;
    return write_ptr;
  }
  virtual uint8_t *deserialize(uint8_t *read_ptr)
  {
    read_ptr = header.deserialize(read_ptr);
    unsigned __ros_sensor_type_len;
    SROS_DESERIALIZE_PRIMITIVE(read_ptr, __ros_sensor_type_len);
    sensor_type = std::string((const char *)read_ptr, __ros_sensor_type_len);
    read_ptr += __ros_sensor_type_len;
    SROS_DESERIALIZE_PRIMITIVE(read_ptr, width);
    SROS_DESERIALIZE_PRIMITIVE(read_ptr, height);
    SROS_DESERIALIZE_PRIMITIVE(read_ptr, focal_distance);
    SROS_DESERIALIZE_PRIMITIVE(read_ptr, no_sample_value);
    SROS_DESERIALIZE_PRIMITIVE(read_ptr, shadow_value);
    SROS_DESERIALIZE_PRIMITIVE(read_ptr, format);
    uint32_t __binary_data_size;
    SROS_DESERIALIZE_PRIMITIVE(read_ptr, __binary_data_size);
    set_binary_data_size(__binary_data_size);
    memcpy(&binary_data[0], read_ptr, sizeof(uint8_t) * __binary_data_size);
    read_ptr += sizeof(uint8_t) * __binary_data_size;
    uint32_t __float_data_size;
    SROS_DESERIALIZE_PRIMITIVE(read_ptr, __float_data_size);
    set_float_data_size(__float_data_size);
    memcpy(&float_data[0], read_ptr, sizeof(float) * __float_data_size);
    read_ptr += sizeof(float) * __float_data_size;
    return read_ptr;
  }
};

typedef boost::shared_ptr<DepthMapArray> DepthMapArrayPtr;
typedef boost::shared_ptr<DepthMapArray const> DepthMapArrayConstPtr;


}

#endif
