/*
 * imageCompression: a customized copy of compressed_image_transport that, unlike the original, will have a reliable API
 *
 * Evan Herbst
 * 10 / 19 / 10
 */

#include <sensor_msgs/image_encodings.h>
#include <cv_bridge/CvBridge.h>
#include <opencv/cvwimage.h>
#include <opencv/highgui.h>
#include "rgbd_msgs/imageCompression.h"
#include <ros/console.h>

namespace rgbd
{

void compressImg(const sensor_msgs::Image& img, sensor_msgs::CompressedImage& cimg, const imgCompressionOptions& opts)
{
	// View/convert as mono or RGB
	sensor_msgs::CvBridge bridge;
	/// @todo This probably misses some cases
	/// @todo What about bayer??
	/// @todo Try to avoid deprecated fromImage
	if (bridge.encoding_as_fmt(img.encoding) == "GRAY") {
		if (!bridge.fromImage(img, sensor_msgs::image_encodings::MONO8)) {
			ROS_ERROR("Could not convert image from %s to mono8", img.encoding.c_str());
			return;
		}
	}
	else if (!bridge.fromImage(img, sensor_msgs::image_encodings::BGR8)) {
		ROS_ERROR("Could not convert image from %s to bgr8", img.encoding.c_str());
		return;
	}

	const std::string formatStr = (opts.format == imgCompressionOptions::FMT_JPG) ? "jpeg" : "png";
	const int params[3] =
	{
		(opts.format == imgCompressionOptions::FMT_JPG) ? CV_IMWRITE_JPEG_QUALITY : CV_IMWRITE_PNG_COMPRESSION,
		(opts.format == imgCompressionOptions::FMT_JPG) ? opts.jpgQuality : opts.pngCompressionLevel,
		0
	};
	const std::string extension = (opts.format == imgCompressionOptions::FMT_JPG) ? ".jpg" : ".png";

	// Compress image
	const IplImage* image = bridge.toIpl();
	/// @todo Use cv::imencode, can write directly to compressed.data
	CvMat* buf = cvEncodeImage(extension.c_str(), image, params);

	// Set up message and publish
	cimg.header = img.header;
	cimg.format = formatStr;
	cimg.data.resize(buf->width);
	memcpy(&cimg.data[0], buf->data.ptr, buf->width);
	cvReleaseMat(&buf);
}

void decompressImg(const sensor_msgs::CompressedImage& cimg, sensor_msgs::Image& img)
{
	/// @todo Use cv::Mat, cv::imdecode
	// Decompress
	const CvMat compressed = cvMat(1, cimg.data.size(), CV_8UC1, const_cast<unsigned char*>(&cimg.data[0]));
	cv::WImageBuffer_b decompressed( cvDecodeImage(&compressed, CV_LOAD_IMAGE_ANYCOLOR) );

	// Copy into ROS image message
	if ( !sensor_msgs::CvBridge::fromIpltoRosImage(decompressed.Ipl(), img) ) {
		ROS_ERROR("Unable to create image message");
		return;
	}
	img.header = cimg.header;
	img.__connection_header = cimg.__connection_header;
	/// @todo Don't assume 8-bit channels
	if (decompressed.Channels() == 1) {
		img.encoding = sensor_msgs::image_encodings::MONO8;
	}
	else if (decompressed.Channels() == 3) {
		img.encoding = sensor_msgs::image_encodings::BGR8;
	}
	else {
		ROS_ERROR("Unsupported number of channels: %i", decompressed.Channels());
	}
}

} //namespace
