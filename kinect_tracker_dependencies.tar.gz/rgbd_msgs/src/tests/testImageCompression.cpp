#include <cassert>
#include <iostream>
#include <opencv/highgui.h>
#include <cv_bridge/CvBridge.h>
#include "rgbd_msgs/imageCompression.h"
using std::cout;
using std::endl;

/*
 * arguments: image filename
 */
int main(int argc, char* argv[])
{
	assert(argc == 2);
	cv::Mat cvImg = cv::imread(argv[1]);
	sensor_msgs::CvBridge bridge;
	IplImage ipl = cvImg;
	sensor_msgs::Image::Ptr img = bridge.cvToImgMsg(&ipl);
	cout << "orig data size " << img->data.size() << endl;
	sensor_msgs::CompressedImage cimg;
	rgbd::imgCompressionOptions opts;
	rgbd::compressImg(*img, cimg, opts);
	cout << "compressed data size " << cimg.data.size() << endl;
	sensor_msgs::Image img2;
	rgbd::decompressImg(cimg, img2);
	cout << "decompressed data size " << img2.data.size() << endl;
	assert(img->data == img2.data);
	cout << "decompressed data match" << endl;
	return 0;
}
