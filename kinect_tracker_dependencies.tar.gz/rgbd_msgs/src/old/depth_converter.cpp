#include <rgbd_msgs/depth_converter.h>

/**
 * Read function for libpng... 
 */
static void user_read_png_data(png_structp png_ptr, png_bytep data, png_size_t length) {
    img_read_state *state = (img_read_state*)png_get_io_ptr(png_ptr);
    memcpy(data, state->data + state->offset, length);
    state->offset += length;
}

namespace rgbd_msgs {

/**
 * Constructs a new DepthConverter object.
 */
DepthConverter::DepthConverter() {
    depth_map = NULL;
    dm_alloc_size = 0;
    int_map = NULL;
    im_alloc_size = 0;
    im_row_pointers = NULL;
}

/**
 * Default destructor
 */
DepthConverter::~DepthConverter() {
    if(depth_map) free(depth_map);
    depth_map = NULL;
}

/**
 * Converts the payload of a depth map to raw format (an array of float values, in meters.)
 *
 * @param dm the input depth map
 * @return a float array containing the raw depth data.  If the input depth data is already
 *         in raw format, then the pointer to the data in the original message is returned;
 *         this is obviously valid as long as the original DepthMap message.  If conversion
 *         or decompression is required, memory is allocated inside of the DepthConverter
 *         object to store the raw data.  The pointer to this data will be valid until the
 *         next call to convert().
 */
float *DepthConverter::convert(rgbd_msgs::DepthMap &dm) {
    // Check if map is already raw and just return the pointer if it is
    if(dm.format == rgbd_msgs::DepthMap::format_raw)
        return &dm.float_data[0];

    // Decompression will be required; make sure we have memory
    check_alloc(dm.width * dm.height);

    // Decompress.
    decompress(depth_map, dm_alloc_size * sizeof(float), &dm.binary_data[0],
        dm.binary_data.size(), dm.format);

    return depth_map;
}

float *DepthConverter::convert(rgbd_msgs::DepthMapArray &dm) {
    // Check if map is already raw and just return the pointer if it is
    if(dm.format == rgbd_msgs::DepthMap::format_raw)
        return &dm.float_data[0];

    // Decompression will be required; make sure we have memory
    check_alloc(dm.width * dm.height);

    // Decompress.
    decompress(depth_map, dm_alloc_size * sizeof(float), &dm.binary_data[0],
        dm.binary_data.size(), dm.format);

    return depth_map;
}

/**
 * Checks to see that memory has been allocated for at least the requested number of floats.
 * If no memory, or not enough memory, has been allocated, then any existing memory is freed
 * and a new array is allocated.  Exceptions thrown if out of memory.
 *
 * @param required_size the number of floats for which memory is required
 */ 
void DepthConverter::check_alloc(size_t required_size) {
    if(!depth_map) {
        depth_map = (float*)malloc(sizeof(float) * required_size);
        if(!depth_map) {
            ROS_ERROR("Unable to allocate memory for depth map!");
            throw "Unable to allocate memory for depth map!";
        }
        dm_alloc_size = required_size;
    } else if(dm_alloc_size < required_size) {
        free(depth_map);
        depth_map = (float*)malloc(sizeof(float) * required_size);
        if(!depth_map) {
            ROS_ERROR("Unable to allocate memory for depth map!");
            throw "Unable to allocate memory for depth map!";
        }
        dm_alloc_size = required_size;
    }
}

/**
 * Sets up memory for decompression of PNG images, including the required array of row
 * pointers.  Used when decompressing PNG depth maps; this memory is required for the
 * intermediate integer-mm depth maps.
 *
 * @param width required image width
 * @param height required image height
 */
void DepthConverter::setup_image(unsigned int width, unsigned int height) {
    if(int_map && im_alloc_size >= width * height) 
        return;

    if(int_map) free(int_map);
    int_map = (uint16_t*)malloc(sizeof(uint16_t) * width * height);
    if(!int_map) {
        ROS_ERROR("Unable to allocate memory for integer depth map!");
        throw "Unable to allocate memory for integer depth map!";
    }
    im_alloc_size = width * height; 

    if(im_row_pointers) free(im_row_pointers);
    im_row_pointers = (png_bytep*)malloc(sizeof(png_bytep) * height);
    for(unsigned int i=0; i<height; i++) {
        im_row_pointers[i] = (png_bytep)(&int_map[i*width]);
    }   
}

/**
 * Decompresses data (nominally depth map payloads.)
 *
 * @param out where the output data will be written
 * @param out_size size (in bytes) of the output array
 * @param in the input data
 * @param in_size size (in bytes) of the input data
 * @param format compressed data type; constants defined in DepthMap message
 */
void DepthConverter::decompress(float *out, size_t out_size, uint8_t *in, size_t in_size,
                                uint8_t format) {
    if(format == rgbd_msgs::DepthMap::format_zlib) {
        decompress_zlib(out, out_size, in, in_size);
    } else if(format == rgbd_msgs::DepthMap::format_png) {
        decompress_png(out, in);
    } else {
        ROS_ERROR("Unsupported depth map compression type, no decompression done!");
    }
}

/**
 * Decompresses zlib depth data.
 *
 * @param out output array of floats
 * @param out_size size of output array in bytes
 * @param in input binary zlib data
 * @param in_size input data size in bytes
 */
void DepthConverter::decompress_zlib(float *out, size_t out_size, uint8_t *in, 
                                     size_t in_size) {
    uLongf ul_out_size = out_size;
    int ret = uncompress((Bytef*)out, &ul_out_size, (Bytef*)in, (uLongf)in_size);
    if(ret != Z_OK) {
        ROS_ERROR("zlib decompression of depth map failed with status: %d", ret);
    }
}

/**
 * Decompresses PNG depth data and converts to float-meters from integer-mm.
 *
 * @param out output array of floats
 * @param in input binary png data
 */
void DepthConverter::decompress_png(float *out, uint8_t *in) {
    static img_read_state png_state;

    png_state.data = in;
    png_state.offset = 0;

    png_structp png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING,
        NULL, NULL, NULL);

    if(!png_ptr) {
        ROS_ERROR("png_create_read_struct failed");
        return;
    }

    if(setjmp(png_jmpbuf(png_ptr))) {
        ROS_ERROR("Error occurred during PNG decompression");
        return;
    }

    png_infop info_ptr = png_create_info_struct(png_ptr);
    png_set_read_fn(png_ptr, (void*)&png_state, &user_read_png_data);

    if(png_get_bit_depth(png_ptr, info_ptr) != 16 || 
        png_get_color_type(png_ptr, info_ptr) != PNG_COLOR_TYPE_GRAY) {
        ROS_ERROR("Invalid color type for PNG depth map");
        png_destroy_read_struct(&png_ptr, &info_ptr, NULL);
        return;
    }

    unsigned int width = png_get_image_width(png_ptr, info_ptr);
    unsigned int height = png_get_image_height(png_ptr, info_ptr);
    setup_image(width, height);

    png_read_image(png_ptr, im_row_pointers);
    png_destroy_read_struct(&png_ptr, &info_ptr, NULL);

    for(unsigned int i=0; i< width * height; i++) {
        if(int_map[i] == 65535)
            out[i] = -1.0;
        else
            out[i] = (float)int_map[i] / 1000.0;
    }
}


}

