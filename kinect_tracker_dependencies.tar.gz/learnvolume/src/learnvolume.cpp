#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>
#include <math.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <cmath>
#include <queue>

#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <cv_bridge/CvBridge.h>
#include <image_transport/image_transport.h>

#include <ros/ros.h>
#include <ros/subscriber.h>
#include <rgbd_util/ros_utility.h>
#include <sensor_msgs/Image.h>
#include <rgbd_msgs/DepthMap.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>

#include <pcl/point_cloud.h>
#include <pcl/features/integral_image_normal.h>
#include <pcl/features/normal_3d.h>
#include <pcl/io/pcd_io.h>
#include <pcl/ros/conversions.h>
#include <pcl_ros/publisher.h>

#include "pcl_rgbd/depth_to_cloud_lib.h"
#include "pcl_rgbd/cloudUtils.h"
#include "pcl_rgbd/cloudTofroPLY.h"
#include "pcl_rgbd/cloudGeometry.h"
#include "pcl_rgbd/pointTypes.h"

#include <GL/glut.h>    // Header File For The GLUT Library
#include <GL/gl.h>	// Header File For The OpenGL32 Library
#include <GL/glu.h>	// Header File For The GLu32 Library
#include <GL/glext.h>

#define GLH_EXT_SINGLE_FILE
#include <glh/glh_extensions.h>
#include <glh/glh_obs.h>
#include <glh/glh_glut.h>
#include <glh/glh_glut_text.h>
#include <glh/glh_genext.h>
#include <glh/glh_convenience.h>
#include <glh/glh_text.h>
#include <glh/glh_linear.h>

#define PI 3.14159265

using namespace std;
using namespace glh;

#define ESCAPE 27

#define	SKIN	0
#define	NOTSKIN	1
#define	CLEAR	2
#define	LEARN	3
#define	NOP		4
#define	SET_RGB	5
#define	SET_HSV	6
#define	WRITE	7

#define NUMREGIONS	4

int window;
int               rc;
struct timespec   ts;
struct timeval    tp;

pthread_mutex_t mutex;
typedef rgbd::pt PointT;

int mode;
int featuretype;
int _width, _height;

float volume[4*NUMREGIONS][9];
float points[4*NUMREGIONS][3];
vector<int> points2d;
bool learnedmodel;
pthread_mutex_t mutexQ;
GLubyte image[480][640][4];
static GLuint texName[1];

pcl::PointCloud<PointT> kcloud;

void clearModel()
{
	for(int i=0;i<4*NUMREGIONS;i++)
		for(int j=0;j<9;j++)
			volume[i][j] = -1;
}

void fillVolume(int index)
{
	int ind0 = 4*index;
	int ind1 = ind0+1;
	int ind2 = ind0+2;
	int ind3 = ind0+3;

	float normval, dotval;
	float n12[3], n23[3], n34[3], n41[3];
	dotval = (points[ind3][0] - points[ind0][0])*(points[ind1][0] - points[ind0][0]) +
					(points[ind3][1] - points[ind0][1])*(points[ind1][1] - points[ind0][1]) +
					(points[ind3][2] - points[ind0][2])*(points[ind1][2] - points[ind0][2]);
	n12[0] = (points[ind3][0] - points[ind0][0]) - dotval*(points[ind1][0] - points[ind0][0]);
	n12[1] = (points[ind3][1] - points[ind0][1]) - dotval*(points[ind1][1] - points[ind0][1]);
	n12[2] = (points[ind3][2] - points[ind0][2]) - dotval*(points[ind1][2] - points[ind0][2]);
	normval = sqrt(n12[0]*n12[0] + n12[1]*n12[1] + n12[2]*n12[2]);
	n12[0] /= normval;
	n12[1] /= normval;
	n12[2] /= normval;

	dotval = (points[ind0][0] - points[ind1][0])*(points[ind2][0] - points[ind1][0]) +
					(points[ind0][1] - points[ind1][1])*(points[ind2][1] - points[ind1][1]) +
					(points[ind0][2] - points[ind1][2])*(points[ind2][2] - points[ind1][2]);
	n23[0] = (points[ind0][0] - points[ind1][0]) - dotval*(points[ind2][0] - points[ind1][0]);
	n23[1] = (points[ind0][1] - points[ind1][1]) - dotval*(points[ind2][1] - points[ind1][1]);
	n23[2] = (points[ind0][2] - points[ind1][2]) - dotval*(points[ind2][2] - points[ind1][2]);
	normval = sqrt(n23[0]*n23[0] + n23[1]*n23[1] + n23[2]*n23[2]);
	n23[0] /= normval;
	n23[1] /= normval;
	n23[2] /= normval;

	dotval = (points[ind1][0] - points[ind2][0])*(points[ind3][0] - points[ind2][0]) +
					(points[ind1][1] - points[ind2][1])*(points[ind3][1] - points[ind2][1]) +
					(points[ind1][2] - points[ind2][2])*(points[ind3][2] - points[ind2][2]);
	n34[0] = (points[ind1][0] - points[ind2][0]) - dotval*(points[ind3][0] - points[ind2][0]);
	n34[1] = (points[ind1][1] - points[ind2][1]) - dotval*(points[ind3][1] - points[ind2][1]);
	n34[2] = (points[ind1][2] - points[ind2][2]) - dotval*(points[ind3][2] - points[ind2][2]);
	normval = sqrt(n34[0]*n34[0] + n34[1]*n34[1] + n34[2]*n34[2]);
	n34[0] /= normval;
	n34[1] /= normval;
	n34[2] /= normval;

	dotval = (points[ind2][0] - points[ind3][0])*(points[ind0][0] - points[ind3][0]) +
					(points[ind2][1] - points[ind3][1])*(points[ind0][1] - points[ind3][1]) +
					(points[ind2][2] - points[ind3][2])*(points[ind0][2] - points[ind3][2]);
	n41[0] = (points[ind2][0] - points[ind3][0]) - dotval*(points[ind0][0] - points[ind3][0]);
	n41[1] = (points[ind2][1] - points[ind3][1]) - dotval*(points[ind0][1] - points[ind3][1]);
	n41[2] = (points[ind2][2] - points[ind3][2]) - dotval*(points[ind0][2] - points[ind3][2]);
	normval = sqrt(n41[0]*n41[0] + n41[1]*n41[1] + n41[2]*n41[2]);
	n41[0] /= normval;
	n41[1] /= normval;
	n41[2] /= normval;

	volume[ind0][0] = points[ind0][0];	volume[ind0][1] = points[ind0][1]; 	volume[ind0][2] = points[ind0][2];
	volume[ind0][3] = points[ind1][0];	volume[ind0][4] = points[ind1][1];	volume[ind0][5] = points[ind1][2];
	volume[ind0][6] = n12[0]; 		 	volume[ind0][7] = n12[1]; 			volume[ind0][8] = n12[2];
	volume[ind1][0] = points[ind1][0]; 	volume[ind1][1] = points[ind1][1]; 	volume[ind1][2] = points[ind1][2];
	volume[ind1][3] = points[ind2][0]; 	volume[ind1][4] = points[ind2][1]; 	volume[ind1][5] = points[ind2][2];
	volume[ind1][6] = n23[0]; 		 	volume[ind1][7] = n23[1]; 	  		volume[ind1][8] = n23[2];
	volume[ind2][0] = points[ind2][0]; 	volume[ind2][1] = points[ind2][1]; 	volume[ind2][2] = points[ind2][2];
	volume[ind2][3] = points[ind3][0]; 	volume[ind2][4] = points[ind3][1]; 	volume[ind2][5] = points[ind3][2];
	volume[ind2][6] = n34[0]; 		 	volume[ind2][7] = n34[1]; 	  		volume[ind2][8] = n34[2];
	volume[ind3][0] = points[ind3][0]; 	volume[ind3][1] = points[ind3][1]; 	volume[ind3][2] = points[ind3][2];
	volume[ind3][3] = points[ind0][0]; 	volume[ind3][4] = points[ind0][1]; 	volume[ind3][5] = points[ind0][2];
	volume[ind3][6] = n41[0]; 		 	volume[ind3][7] = n41[1]; 	  		volume[ind3][8] = n41[2];
}

void learnVolumeModel()
{
	// project the cloud
	int width = 640, height = 480;
	float f=570.342;
	int proj[640][480];
	for(int i=0;i<640;i++)
		for(int j=0;j<480;j++)
			proj[i][j] = -1;

	int numpts = kcloud.points.size();
	for(int i=0;i<numpts;i++)
	{
		PointT pt = kcloud.points[i];
		if(pt.z!=pt.z)
			continue;

		int x = (int)(pt.x*f/pt.z + width/2);
		int y = (int)(pt.y*f/pt.z + height/2);
		// find color of point
		for(int j=x-1;j<=x+1;j++)
			for(int k=y-1;k<=y+1;k++)
				if(j>=0 && j<640 && k>=0 && k<480)
					if(proj[j][k]<0 || kcloud.points[proj[j][k]].z>pt.z)
						proj[j][k] = i;
	}

	// using points2d, fill the 3d points
	int num2d = points2d.size()/2;
	if(num2d==4*NUMREGIONS)
	{
		for(int i=0;i<4*NUMREGIONS;i++)
		{
			int x = points2d[2*i];
			int y = points2d[2*i+1];
			if(proj[x][y]<0)
				ROS_INFO_STREAM("Data not available properly");
			else
			{
				PointT pt = kcloud.points[proj[x][y]];
				points[i][0] = pt.x;
				points[i][1] = pt.y;
				points[i][2] = pt.z;
			}
		}

		/* testing with canonical points
		points[0][0] = 0;	points[0][1] = 0;	points[0][2] = 1;
		points[1][0] = 0;	points[1][1] = -5;	points[1][2] = 1;
		points[2][0] = 5;	points[2][1] = -5;	points[2][2] = 1;
		points[3][0] = 5;	points[3][1] = 0;	points[3][2] = 1;
		*/

		// fill volume based on 3D points

		for(int i=0;i<NUMREGIONS;i++)
			fillVolume(i);

		learnedmodel = true;
		ROS_INFO_STREAM("Learned the model");
	}
	else
	{
		ROS_INFO_STREAM("Insufficient number of points to learn the volume");
	}
}

class GLManager
{
public:
	static void InitGL(int Width, int Height);
	static void ReSizeGLScene(int Width, int Height);
	static void keyPressed(unsigned char key,int x,int y);
	static void mouseClicked(int button,int state,int x,int y);
	static void DrawGLScene();
	void cleanup();
	void start();
	static void removeOccludedPoints();
	static void empty()
	{
		glutPostRedisplay();
	}
};

void GLManager::InitGL(int Width, int Height)	        // We call this right after our OpenGL window is created.
{
	glClearDepth(1.0);				// Enables Clearing Of The Depth Buffer
	glDepthFunc(GL_LESS);			        // The Type Of Depth Test To Do
	glEnable(GL_BLEND);
	glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	for(int y=0;y<480;y++)
		for(int x=0;x<640;x++)
			for(int k=0;k<4;k++)
				image[y][x][k] = 255;
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	glGenTextures(1, &texName[0]);
}

void GLManager::mouseClicked(int button, int state,int x,int y)
{
	if((button==GLUT_LEFT_BUTTON)&&(state==GLUT_DOWN))
	{
		points2d.push_back(x);
		points2d.push_back(y);
	}

}

void GLManager::keyPressed(unsigned char key,int x,int y)
{
	ROS_INFO_STREAM("Key pressed: "<<key<<", x: "<<x<<", y: "<<y);
	switch(key){
	case 'c':
		pthread_mutex_lock(&mutex);
		mode = CLEAR;
		pthread_mutex_unlock(&mutex);
		break;
	case 'l':
		pthread_mutex_lock(&mutex);
		mode = LEARN;
		pthread_mutex_unlock(&mutex);
		break;
	case 'w':
		pthread_mutex_lock(&mutex);
		mode = WRITE;
		pthread_mutex_unlock(&mutex);
		break;
	default:
		pthread_mutex_lock(&mutex);
		mode = NOP;
		pthread_mutex_unlock(&mutex);
		break;
	}
}

void GLManager::ReSizeGLScene(int Width, int Height)
{
	if (Height==0)				// Prevent A Divide By Zero If The Window Is Too Small
		Height=1;

	_width = Width;
	_height = Height;
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();				// Reset The Projection Matrix
	glOrtho (0, Width, Height, 0, 0, 1);
	glMatrixMode (GL_MODELVIEW);
}

void GLManager::DrawGLScene()
{
	int width = 640, height = 480;
	pcl::PointCloud<PointT> cloud;
	cloud.points.clear();

	glBindTexture(GL_TEXTURE_2D, texName[0]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	pthread_mutex_lock(&mutexQ);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 640, 480, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
	pthread_mutex_unlock(&mutexQ);

	glMatrixMode (GL_PROJECTION);
	glLoadIdentity ();
	glOrtho (0, width, height, 0, 0, 1);
	glMatrixMode (GL_MODELVIEW);
	glDisable(GL_DEPTH_TEST);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glEnable(GL_TEXTURE_2D);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
	glBindTexture(GL_TEXTURE_2D, texName[0]);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0, 0.0); glVertex3f(0.0, 0.0, 0.0);
	glTexCoord2f(1.0, 0.0); glVertex3f(width, 0.0, 0.0);
	glTexCoord2f(1.0, 1.0); glVertex3f(width, height, 0.0);
	glTexCoord2f(0.0, 1.0); glVertex3f(0.0, height, 0.0);
	glEnd();
	glDisable(GL_TEXTURE_2D);

	// draw the four points2d
	int num2d = points2d.size()/2;
	int x, y;
	for(int i=0;i<num2d;i++)
	{
		x = points2d[2*i];
		y = points2d[2*i+1];
		glColor3f(0.0f, 1.0f, 0.0f);
		glBegin(GL_QUADS);
		glVertex2f(x-5, y-5);
		glVertex2f(x+5, y-5);
		glVertex2f(x+5, y+5);
		glVertex2f(x-5, y+5);
		glEnd();
	}

	glFlush();

	// swap the buffers to display, since double buffering is used.
	glutSwapBuffers();
}

void GLManager::cleanup()
{
}

void GLManager::start()
{
	_width = 640;
	_height = 480;

	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_ALPHA | GLUT_DEPTH);

	glutInitWindowSize(_width, _height);

	glutInitWindowPosition(0, 0);

	window = glutCreateWindow("Volume Learner");

	glutDisplayFunc(&DrawGLScene);

	glutIdleFunc(empty);

	glutReshapeFunc(&ReSizeGLScene);

	glutKeyboardFunc(&keyPressed);

	glutMouseFunc(&mouseClicked);

	InitGL(_width, _height);

	glutMainLoop();

	cleanup();
}

class LearnVolume {
public:
	LearnVolume();
	~LearnVolume();

	void start();
	void cloudCallback(sensor_msgs::PointCloud2ConstPtr cloud_ptr);

protected:
	// functions
	void load_ros_params();


	// members
	ros::NodeHandle nh_global;
	ros::NodeHandle nh_local;

	int processed_frame;
	int subscription_buffer_size;
	std::string model_name;
	std::string files_path;

	static const int max_out_of_order = 100;
	ros::Subscriber cloud_subscription;
	pcl_ros::Publisher<PointT> cloud_pub;
};

LearnVolume::LearnVolume()
: nh_global(),
  nh_local("~")
{
	processed_frame = 0;

	load_ros_params();

	cloud_pub.advertise(nh_global, "outcloud", 1);
}

LearnVolume::~LearnVolume()
{
}

void
LearnVolume::load_ros_params()
{
    nh_local.param("subscription_buffer_size", subscription_buffer_size, 1);
    nh_local.param("model_name", model_name, std::string(""));
    nh_local.param("files_path", files_path, std::string(""));
}

void writeVolumeModel()
{
	fstream f;
	f.open("/home/ankit/data/volumemodel.txt", ios::out);
	for(int i=0;i<4*NUMREGIONS;i++)
	{
		for(int j=0;j<9;j++)
			f<<volume[i][j]<<"\t";
		f<<"\n";
	}
	f.close();
}

void LearnVolume::cloudCallback(sensor_msgs::PointCloud2ConstPtr cloud_ptr)
{
	ros::Time current_frame_timestamp = cloud_ptr->header.stamp;
	pcl::fromROSMsg(*cloud_ptr, kcloud);
	int num_points = kcloud.points.size();

	int width = 640, height = 480;
	float f=570.342;
	int numpts = kcloud.points.size();
	pthread_mutex_lock(&mutexQ);
	for(int i=0;i<numpts;i++)
	{
		PointT pt = kcloud.points[i];
		int x = (int)(pt.x*f/pt.z + width/2);
		int y = (int)(pt.y*f/pt.z + height/2);
		// find color of point
		boost::array<float, 3> fcolor = rgbd::unpackRGB<float>(pt.rgb);
		for(int j=x-1;j<=x+1;j++)
			for(int k=y-1;k<=y+1;k++)
				if(j>=0 && j<640 && k>=0 && k<480)
				{
					image[k][j][0] = (GLubyte) 255*fcolor[0];
					image[k][j][1] = (GLubyte) 255*fcolor[1];
					image[k][j][2] = (GLubyte) 255*fcolor[2];
					image[k][j][3] = (GLubyte) 255;
				}
	}
    pthread_mutex_unlock(&mutexQ);

	pthread_mutex_lock(&mutex);
	switch(mode){
	case CLEAR:
		ROS_INFO_STREAM("Cleared the learning data");
		clearModel();
		points2d.clear();
		mode = NOP;
		break;
	case LEARN:
		ROS_INFO_STREAM("Learning model");
		learnVolumeModel();
		writeVolumeModel();
		mode = NOP;
		break;
	case WRITE:
		ROS_INFO_STREAM("Saving model");
		writeVolumeModel();
		mode = NOP;
		break;
	default:
		break;
	};
	pthread_mutex_unlock(&mutex);

	if(num_points>50)
	{
		// Convert the kcloud into the cloud as required by point_cloud_icp

		pcl::PointCloud<PointT> pubcloud = kcloud;
		pubcloud.points.clear();
		for(int i=0;i<(int)kcloud.points.size();i++)
		{
			PointT point = kcloud.points[i];

			// filter the point using volume
			if(learnedmodel)
			{
				bool flag1=true, flag2=true, flag3=true, flag4 = true, flag5 = true;
				for(int j=0;j<4;j++)
				{
					// check with the plane
					if((point.x - volume[j][0])*volume[j][6] +
							(point.y - volume[j][1])*volume[j][7] +
							(point.z - volume[j][2])*volume[j][8] < 0)
						flag1 = false;
				}
				for(int j=4;j<8;j++)
				{
					// check with the plane
					if((point.x - volume[j][0])*volume[j][6] +
							(point.y - volume[j][1])*volume[j][7] +
							(point.z - volume[j][2])*volume[j][8] < 0)
						flag2 = false;
				}
				for(int j=8;j<12;j++)
				{
					// check with the plane
					if((point.x - volume[j][0])*volume[j][6] +
							(point.y - volume[j][1])*volume[j][7] +
							(point.z - volume[j][2])*volume[j][8] < 0)
						flag3 = false;
				}
				for(int j=12;j<16;j++)
				{
					// check with the plane
					if((point.x - volume[j][0])*volume[j][6] +
							(point.y - volume[j][1])*volume[j][7] +
							(point.z - volume[j][2])*volume[j][8] < 0)
						flag4 = false;
				}
				if(flag1 || flag2 || flag3 || flag4)
					pubcloud.push_back(point);
			}
			else
				pubcloud.push_back(point);
		}
		pubcloud.height = 1;
		pubcloud.width = pubcloud.points.size();
		cloud_pub.publish(pubcloud);
	}
	processed_frame++;
}

void
LearnVolume::start()
{
	int queue_size = 3; // 0 means unlimited queue...
	cloud_subscription = nh_global.subscribe<sensor_msgs::PointCloud2>("incloud", queue_size, boost::bind(&LearnVolume::cloudCallback, this, _1));

	ros::spin();
}

void *NodeThread(void*)
{
	LearnVolume node;
	node.start();
}

void *RenderThread(void*)
{
	GLManager render;
	render.start();
}

int main (int argc, char** argv)
{
	pthread_mutex_init(&mutex, NULL);
	mode = NOP;
	clearModel();
	learnedmodel = false;

	ros::init (argc, argv, "SkinLearner");
	glutInit(&argc, argv);

	int rc1, rc2;
	pthread_t thread1, thread2;

	/* Create independent threads each of which will execute functionC */

	if( (rc1=pthread_create( &thread1, NULL, &NodeThread, NULL)) )
	{
		printf("Thread creation failed: %d\n", rc1);
	}

	if( (rc2=pthread_create( &thread2, NULL, &RenderThread, NULL)) )
	{
		printf("Thread creation failed: %d\n", rc2);
	}

	/* Wait till threads are complete before main continues. Unless we  */
	/* wait we run the risk of executing an exit which will terminate   */
	/* the process and all threads before the threads have completed.   */

	pthread_join( thread1, NULL);
	pthread_join( thread2, NULL);
	return 0;
}
