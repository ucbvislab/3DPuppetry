/*
 * cloudSearchTrees: search trees over point clouds (using 3-d position and possibly other things)
 *
 * Evan Herbst
 * 3 / 24 / 10
 */

#ifndef EX_PCL_POINTCLOUD_SEARCHTREES_H
#define EX_PCL_POINTCLOUD_SEARCHTREES_H

#include <tuple>
#include <boost/shared_ptr.hpp>
#include <pcl/point_cloud.h>
#include <pcl/kdtree/kdtree.h>
#include "rgbd_util/eigen/Geometry"
#include "kdtree2/kdtree2.hpp"
#include "rgbd_util/kdtree2utils.h"

namespace rgbd
{

/*
 * efficient alternative to libANN
 */
template <typename PointT>
boost::shared_ptr<kdtree2> createKDTree2(const pcl::PointCloud<PointT>& cloud);
/*
 * apply xform to all points in cloud
 */
template <typename PointT>
boost::shared_ptr<kdtree2> createKDTree2(const pcl::PointCloud<PointT>& cloud, const rgbd::eigen::Affine3f& xform);

template <typename PointT>
typename pcl::KdTree<PointT>::Ptr createKDTree(const typename pcl::PointCloud<PointT>::Ptr& cloudPtr);

template <typename PointT>
std::tuple<std::vector<int>, std::vector<float>> searchKDTree(pcl::KdTree<PointT>& tree, const kdtreeNbrhoodSpec& nspec, const PointT& qpt);

} //namespace

#include "cloudSearchTrees.ipp"

#endif //header
