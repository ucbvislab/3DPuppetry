/*
 * normalsIO: I/O for point-cloud normals
 *
 * Evan Herbst
 * 12 / 20 / 10
 */

#ifndef EX_CLOUD_NORMALS_IO_H
#define EX_CLOUD_NORMALS_IO_H

namespace rgbd
{

template <typename PointT>
void writeNormals(const pcl::PointCloud<PointT>& cloud, const fs::path& filepath);

/*
 * cloud will be resized if nec
 *
 * only the normals fields of cloud will be set
 */
template <typename PointT>
void readNormals(const fs::path& filepath, pcl::PointCloud<PointT>& cloud);

} //namespace

#include "normalsIO.ipp"

#endif //header
