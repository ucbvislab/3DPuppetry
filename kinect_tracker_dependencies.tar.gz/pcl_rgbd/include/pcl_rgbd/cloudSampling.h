/*
 * cloudSampling: selecting points to throw away
 *
 * Evan Herbst
 * 6 / 22 / 10
 */

#ifndef EX_CLOUD_SAMPLING_H
#define EX_CLOUD_SAMPLING_H

#include <vector>
#include <pcl/point_cloud.h>
#include "rgbd_util/eigen/Geometry"

namespace rgbd
{

/*
 * remove points too far from the camera in 3-d
 *
 * radiusIsMax: if false, remove points *closer* than radius
 */
template <typename PointT>
std::vector<unsigned int> getRadiusDownsamplingIndices(const pcl::PointCloud<PointT>& cloud, rgbd::eigen::Vector3f center,float radius,bool radiusIsMax);

std::vector<unsigned int> getRandomDownsamplingIndices(const unsigned int numPts, float downsampleRate, unsigned int minPts = 0);

/*
 * remove points in the corners of the depth image, which seem to be moved too far toward the camera
 */
template <typename PointT>
std::vector<unsigned int> getImageRadiusDownsamplingIndices(const pcl::PointCloud<PointT>& cloud, int source_width, int source_height, float radius_ratio);

/*
 * take points with {imgX and imgY} % downsampleFactor == 0
 */
template <typename PointT>
std::vector<unsigned int> getPixelSpaceDownsamplingIndices(const pcl::PointCloud<PointT>& cloud, const unsigned int downsampleFactor);
template <typename PointT>
std::vector<unsigned int> getPixelSpaceDownsamplingIndices(const pcl::PointCloud<PointT>& cloud, std::vector<unsigned int> indices, const unsigned int downsampleFactor);

/*
 * each sampled point must be far enough (>= minDist) from all others in 3-d
 *
 * stop when we can't find an acceptable next pt after maxSamplesOnePt tries
 *
 * use rand() to sample
 */
template <typename PointT>
std::vector<unsigned int> getWellSeparatedPointsIndices(const pcl::PointCloud<PointT>& cloud, const float minDist, const unsigned int maxSamplesOnePt = 100);
/*
 * select points with probability proportional to their weights
 */
template <typename PointT>
std::vector<unsigned int> getWellSeparatedPointsIndices(const pcl::PointCloud<PointT>& cloud, const std::vector<double>& ptWeights, const float minDist, const unsigned int maxSamplesOnePt = 100);

template <typename PointT, typename PointT2, typename IndexRangeT>
void downsampleFromIndices(const pcl::PointCloud<PointT>& cloud, pcl::PointCloud<PointT2>& downsampledCloud, const IndexRangeT& acceptedIndices);

void downsampleFromIndices(
		const std::vector<rgbd::eigen::Vector3f> & sourcePoints,
		std::vector<rgbd::eigen::Vector3f> & targetPoints,
		const std::vector<unsigned int> & acceptedIndices);

void boolVectorToIndices(const std::vector<bool> & acceptedPositions, std::vector<unsigned int> & acceptedIndices);

std::vector<unsigned int> getRandomSubsetOfIndices(const std::vector<unsigned int> & indices, unsigned int num_indices);

} //namespace

#include "cloudSampling.ipp"

#endif //header
