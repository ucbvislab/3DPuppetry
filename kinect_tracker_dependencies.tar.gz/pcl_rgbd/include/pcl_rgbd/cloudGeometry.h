/*
 * cloudGeometry
 *
 * Evan Herbst
 * 6 / 23 / 10
 */

#ifndef EX_CLOUD_GEOMETRY_H
#define EX_CLOUD_GEOMETRY_H

#include <vector>
#include <tuple>
#include <pcl/point_cloud.h>
#include "rgbd_util/eigen/Geometry"

namespace rgbd
{

rgbd::eigen::Vector3f centroid(const std::vector<rgbd::eigen::Vector3f>& pts);
template <typename PointT>
rgbd::eigen::Vector3f centroid(const pcl::PointCloud<PointT>& cloud);

rgbd::eigen::Matrix3f covariance(const std::vector<rgbd::eigen::Vector3f>& pts);
template <typename PointT>
rgbd::eigen::Vector3f covariance(const pcl::PointCloud<PointT>& cloud);

/*
 * bounding box: min (x y z), max (x y z)
 */
template <typename PointT>
std::tuple<rgbd::eigen::Vector3f, rgbd::eigen::Vector3f> bbox(const pcl::PointCloud<PointT>& cloud);

/*
 * return all eigenvectors of the covariance mtx, one per row
 */
rgbd::eigen::Matrix3f eigenvectors(const std::vector<rgbd::eigen::Vector3f>& pts);
template <typename PointT>
rgbd::eigen::Matrix3f eigenvectors(const pcl::PointCloud<PointT>& cloud);

} //namespace

#include "cloudGeometry.ipp"

#endif //header
