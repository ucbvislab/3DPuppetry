/*
 * cloudTofroPLY: write PointClouds to and read them from PLY files
 *
 * Evan Herbst
 * 2 / 18 / 10
 */

#ifndef EX_PCL_CLOUD_TOFRO_PLY_H
#define EX_PCL_CLOUD_TOFRO_PLY_H

#include <boost/filesystem/path.hpp>
#include <pcl/point_cloud.h>
#include <sensor_msgs/PointCloud2.h>
#include "pcl_rgbd/pointTypes.h"

namespace rgbd
{
namespace fs = boost::filesystem;

/**
 * throw on any error
 */
template <typename PointT>
void write_ply_file(pcl::PointCloud<PointT> const& cloud, const fs::path& filepath);
void write_ply_file(const sensor_msgs::PointCloud2& cloud, const fs::path& filepath);

/*
 * edit the data of cloud but not the header
 *
 * throw on any format error
 */
template <typename PointT>
void read_ply_file(pcl::PointCloud<PointT> & cloud, const fs::path& filepath);
void read_ply_file(sensor_msgs::PointCloud2& cloud, const fs::path& filepath);

/*
 * deal with format conversion of PLYs written by write_ply_file()
 *
 * PointT should be rgbd::pt or rgbd::surfelPt or similar
 */
template <typename PointT>
typename pcl::PointCloud<PointT>::Ptr readRGBDPLY(const fs::path& filepath);

}

#include "cloudTofroPLY.ipp"

#endif //header
