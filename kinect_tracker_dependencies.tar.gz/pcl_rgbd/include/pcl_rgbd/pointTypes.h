/*
 * pointTypes: point structs for use with pcl
 *
 * Evan Herbst
 * 6 / 15 / 10
 */

#ifndef EX_PCL_POINT_TYPES_H
#define EX_PCL_POINT_TYPES_H

#include <boost/array.hpp>
#include <boost/mpl/bool.hpp>
#include <pcl/point_types.h>
#include <pcl/ros/register_point_struct.h>
#include "rgbd_util/eigen/Core"
#include "rgbd_util/eigen/Geometry"

namespace rgbd
{

/*
 * ***** CAVEAT: pcl uses the c++ offsetof() macro on these point types, so they must be POD -- EVH 20100615
 */

/*
 * most of the fields we use
 */
struct EIGEN_ALIGN16 pt
{
  PCL_ADD_POINT4D;    // This adds the members x,y,z which can also be accessed using the point (which is float[4])
  float rgb; //packed
  PCL_ADD_NORMAL4D;   // This adds the member normal[3] which can also be accessed using the point (which is float[4])
  float curvature;
  uint32_t imgX, imgY;
  EIGEN_MAKE_ALIGNED_OPERATOR_NEW
  bool visibility;
};
inline std::ostream& operator << (std::ostream& os, const pt& p)
{
  os << "(" << p.x << "," << p.y << "," << p.z << " - " << p.rgb << " - " << p.normal[0] << "," << p.normal[1] << "," << p.normal[2] << " - " << p.curvature << " (" << p.imgX << "," << p.imgY << ") " << ")";
  return (os);
}

struct EIGEN_ALIGN16 surfelPt
{
	PCL_ADD_POINT4D;    // This adds the members x,y,z which can also be accessed using the point (which is float[4])
	float rgb; //packed
	PCL_ADD_NORMAL4D;   // This adds the member normal[3] which can also be accessed using the point (which is float[4])
	float curvature;
	float radius;
	float confidence;
	EIGEN_MAKE_ALIGNED_OPERATOR_NEW
};
inline std::ostream& operator << (std::ostream& os, const surfelPt& p)
{
  os << "(" << p.x << "," << p.y << "," << p.z << " - " << p.rgb << " - " << p.normal[0] << "," << p.normal[1] << "," << p.normal[2] << " - " << p.curvature << " - " << p.radius << " - " << p.confidence << ")";
  return (os);
}

struct EIGEN_ALIGN16 sbaPt
{
	PCL_ADD_POINT4D;    // This adds the members x,y,z which can also be accessed using the point (which is float[4])
	float rgb; //packed
	int valid_projections;
	int invalid_projections;
	int has_enough_valid_projections;
	int sba_track_index;
	float error_total;
	float error_mean;
	float error_max;
	float e_x_abs_mean;
	float e_x_abs_max;
	float e_x_mean;
	float e_y_abs_mean;
	float e_y_abs_max;
	float e_y_mean;
	float e_z_abs_mean;
	float e_z_abs_max;
	float e_z_mean;
	EIGEN_MAKE_ALIGNED_OPERATOR_NEW
};
inline std::ostream& operator << (std::ostream& os, const sbaPt& p)
{
  os << "(" << p.x << "," << p.y << "," << p.z << " - " << p.rgb << " - " << p.valid_projections << "," << p.invalid_projections << ")";
  return (os);
}

} //namespace

/*
 * must register structs in the global namespace so the macros can use other namespace names
 */

POINT_CLOUD_REGISTER_POINT_STRUCT(
	rgbd::pt,
	(float, x, x)
	(float, y, y)
	(float, z, z)
	(float, rgb, rgb)
	(float, normal[0], nx)
	(float, normal[1], ny)
	(float, normal[2], nz)
	(float, curvature, curvature)
	(uint32_t, imgX, imgX)
	(uint32_t, imgY, imgY)
);

POINT_CLOUD_REGISTER_POINT_STRUCT(
	rgbd::surfelPt,
	(float, x, x)
	(float, y, y)
	(float, z, z)
	(float, rgb, rgb)
	(float, normal[0], nx)
	(float, normal[1], ny)
	(float, normal[2], nz)
	(float, curvature, curvature)
	(float, radius, radius)
	(float, confidence, confidence)
);

POINT_CLOUD_REGISTER_POINT_STRUCT(
	rgbd::sbaPt,
	(float, x, x)
	(float, y, y)
	(float, z, z)
	(float, rgb, rgb)
	(int, valid_projections, valid_projections)
	(int, invalid_projections, invalid_projections)
	(int, has_enough_valid_projections, has_enough_valid_projections)
	(int, sba_track_index, sba_track_index)
	(float, error_total, error_total)
	(float, error_mean, error_mean)
	(float, error_max, error_max)
	(float, e_x_abs_mean, e_x_abs_mean)
	(float, e_x_abs_max, e_x_abs_max)
	(float, e_x_mean, e_x_mean)
	(float, e_y_abs_mean, e_y_abs_mean)
	(float, e_y_abs_max, e_y_abs_max)
	(float, e_y_mean, e_y_mean)
	(float, e_z_abs_mean, e_z_abs_mean)
	(float, e_z_abs_max, e_z_abs_max)
	(float, e_z_mean, e_z_mean)
);

namespace rgbd
{

/**********************************************************************************************
 * type traits for points
 */

template <typename PointT> struct pointHasImgXY {typedef boost::mpl::bool_<false> type;};
template <> struct pointHasImgXY<rgbd::pt> {typedef boost::mpl::bool_<true> type;};

/**********************************************************************************************
 * convenience functions for dealing with the ridiculously inconvenient types above
 */

float packRGB(const unsigned char r, const unsigned char g, const unsigned char b);
float packRGB(const boost::array<unsigned char, 3> rgb);
float packRGB(const boost::array<float, 3> rgb); //args should be in [0, 1)
float packRGB(const rgbd::eigen::Vector3f& rgb); //args should be in [0, 1)

template <typename T>
boost::array<T, 3> unpackRGB(const float rgb);
template <>
boost::array<unsigned char, 3> unpackRGB(const float rgb);
template <>
boost::array<float, 3> unpackRGB(const float rgb); //outputs will be in [0, 1)
rgbd::eigen::Vector3f unpackRGB2eigen(const float rgb); //outputs will be in [0, 1)

template <typename PointT>
void setImgCoords(PointT& p, const int x, const int y) {} //by default assume the point type doesn't have img{X,Y}
template <>
inline void setImgCoords<rgbd::pt>(rgbd::pt& p, const int x, const int y) {p.imgX = x; p.imgY = y;}

//p.xyz = q
template <typename PointT>
void eigen2ptX(PointT& p, const rgbd::eigen::Vector3f& q)
{
	p.x = q.x();
	p.y = q.y();
	p.z = q.z();
}
template <typename PointT>
void eigen2ptX(PointT& p, const rgbd::eigen::Vector4f& q)
{
	p.x = q.x();
	p.y = q.y();
	p.z = q.z();
}

//p.n{xyz} = q
template <typename PointT>
void eigen2ptNormal(PointT& p, const rgbd::eigen::Vector3f& q)
{
	p.normal[0] = q.x();
	p.normal[1] = q.y();
	p.normal[2] = q.z();
}
template <typename PointT>
void eigen2ptNormal(PointT& p, const rgbd::eigen::Vector4f& q)
{
	p.normal[0] = q.x();
	p.normal[1] = q.y();
	p.normal[2] = q.z();
}

/*
 * EigenPointT should be Vector3f or Vector4f
 */
template <typename EigenPointT, typename PointT>
EigenPointT ptX2eigen(const PointT& p);
template <typename EigenPointT, typename PointT>
EigenPointT ptNormal2eigen(const PointT& p);

/*
 * p.x = T * q.x, assuming T(3, 3) == 1
 *
 * pre: p != q
 */
template <typename PointT>
void xformPtPosSafe(PointT& p, const rgbd::eigen::Affine3f& xform, const PointT& q)
{
	p.x = xform(0, 0) * q.x + xform(0, 1) * q.y + xform(0, 2) * q.z + xform(0, 3);
	p.y = xform(1, 0) * q.x + xform(1, 1) * q.y + xform(1, 2) * q.z + xform(1, 3);
	p.z = xform(2, 0) * q.x + xform(2, 1) * q.y + xform(2, 2) * q.z + xform(2, 3);
}

/*
 * p.x = T * q.x, assuming T(3, 3) == 1
 */
template <typename PointT>
void xformPtPos(PointT& p, const rgbd::eigen::Affine3f& xform, const PointT q)
{
	p.x = xform(0, 0) * q.x + xform(0, 1) * q.y + xform(0, 2) * q.z + xform(0, 3);
	p.y = xform(1, 0) * q.x + xform(1, 1) * q.y + xform(1, 2) * q.z + xform(1, 3);
	p.z = xform(2, 0) * q.x + xform(2, 1) * q.y + xform(2, 2) * q.z + xform(2, 3);
}

/*
 * p.normal = T * q.normal
 *
 * pre: p != q
 */
template <typename PointT>
void xformPtNormalSafe(PointT& p, const rgbd::eigen::Affine3f& xform, const PointT& q)
{
	p.normal[0] = xform(0, 0) * q.normal[0] + xform(0, 1) * q.normal[1] + xform(0, 2) * q.normal[2];
	p.normal[1] = xform(1, 0) * q.normal[0] + xform(1, 1) * q.normal[1] + xform(1, 2) * q.normal[2];
	p.normal[2] = xform(2, 0) * q.normal[0] + xform(2, 1) * q.normal[1] + xform(2, 2) * q.normal[2];
}

/*
 * p.normal = T * q.normal
 */
template <typename PointT>
void xformPtNormal(PointT& p, const rgbd::eigen::Affine3f& xform, const PointT q)
{
	p.normal[0] = xform(0, 0) * q.normal[0] + xform(0, 1) * q.normal[1] + xform(0, 2) * q.normal[2];
	p.normal[1] = xform(1, 0) * q.normal[0] + xform(1, 1) * q.normal[1] + xform(1, 2) * q.normal[2];
	p.normal[2] = xform(2, 0) * q.normal[0] + xform(2, 1) * q.normal[1] + xform(2, 2) * q.normal[2];
}

} //namespace

#include "pointTypes.ipp"

#endif //header
