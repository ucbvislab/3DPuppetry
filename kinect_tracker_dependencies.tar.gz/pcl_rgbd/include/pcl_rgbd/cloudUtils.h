/*
 * cloudUtils: general-purpose functions on PointClouds
 *
 * Evan Herbst
 * 2 / 18 / 10
 */

#ifndef EX_PCL_CLOUD_UTILS_H
#define EX_PCL_CLOUD_UTILS_H

#include <vector>
#include <string>
#include <iostream>
#include <boost/array.hpp>
#include <boost/function.hpp>
#include "rgbd_util/eigen/Geometry"
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <visualization_msgs/Marker.h>
#include <ros/publisher.h>
#include <geometry_msgs/Point32.h>
#include <sensor_msgs/PointCloud2.h>
#include "pcl_rgbd/pointTypes.h"
#include <rgbd_msgs/DepthMap.h>
#include <sensor_msgs/Image.h>
#include <cv_bridge/cv_bridge.h>
#include <rgbd_util/CameraParams.h>

namespace rgbd
{

/*
 * PointVectorT must be vector<Vector3f> or vector<Vector4f, aligned_allocator>
 */
template <typename PointT, typename PointVectorT>
void convertPointCloudToVector (const pcl::PointCloud<PointT>& point_cloud, PointVectorT& point_vector);
template <typename PointT, typename PointVectorT>
void convertVectorToPointCloud (const PointVectorT& point_vector, pcl::PointCloud<PointT>& point_cloud);

/*
 * Convert an Eigen vector3f (3d point) to a ROS Point32
 */
void convertVector3fToPoint32 (const rgbd::eigen::Vector3f & vector3f, geometry_msgs::Point32 & point32);

/*
 * Convert a ROS Point32 to an Eigen vector3f (3d point)
 */
void convertPoint32ToVector3f (const geometry_msgs::Point32 & point32, rgbd::eigen::Vector3f & vector3f);

void convertVector4fToROSPoint (const rgbd::eigen::Vector4f & vector4f, geometry_msgs::Point & ros_point);
void convertROSPointToVector4f (const geometry_msgs::Point & ros_point, rgbd::eigen::Vector4f & vector4f);
void convertVector4fToROSVector3 (const rgbd::eigen::Vector4f & vector4f, geometry_msgs::Vector3 & ros_vector);
void convertROSVector3ToVector4f (const geometry_msgs::Vector3 & ros_vector, rgbd::eigen::Vector4f & vector4f);

/*
 * pre: point_cloud != result
 */
template <typename PointT>
void transform_point_cloud(rgbd::eigen::Affine3f t, const pcl::PointCloud<PointT>& point_cloud, pcl::PointCloud<PointT>& result, const bool transformNormals);

// a version of the above that doesn't require PointT to have "normal" field
template <typename PointT>
void transform_point_cloud(rgbd::eigen::Affine3f t, const pcl::PointCloud<PointT>& point_cloud, pcl::PointCloud<PointT>& result);

template <typename PointT>
void transform_point_cloud_in_place(rgbd::eigen::Affine3f t, pcl::PointCloud<PointT>& point_cloud, const bool transformNormals);

// a version of the above that doesn't require PointT to have "normal" field
template <typename PointT>
void transform_point_cloud_in_place(rgbd::eigen::Affine3f t, pcl::PointCloud<PointT>& point_cloud);

/*
 * append all points in src onto dest
 */
template <typename PointT>
void mergeInPlace(pcl::PointCloud<PointT> const& src, pcl::PointCloud<PointT>& dest);

/*
 * Get the bit size by PointCloud2 field type code
 */
unsigned int datatypeByteCount(const int pointFieldTypeCode);

bool cloudHasField(const sensor_msgs::PointCloud2 &cloud2, std::string const& fieldName);

/*
 * Convert 3 separate color channels into a single packed "rgb" channel
 *
 * Copies the other channels
 */
void packColorChannels(
		const std::string& r_name,
		const std::string& g_name,
		const std::string& b_name,
		const sensor_msgs::PointCloud2& src,
		sensor_msgs::PointCloud2& dest);

template <typename SrcT, typename DestT>
void convertFieldType(const std::string& fieldName, const sensor_msgs::PointCloud2& src, sensor_msgs::PointCloud2& dest);

/*
 * Rename fields in cloud_msg according to map
 */
void renameFields(sensor_msgs::PointCloud2& cloud_msg, std::map<std::string, std::string> const& rename_map);

pcl::PointCloud<rgbd::pt> surfelsToPts(const pcl::PointCloud<rgbd::surfelPt>& surfels);

template <typename PointT>
rgbd_msgs::DepthMapPtr convertKinectCloudToDepthMap(const pcl::PointCloud<PointT> & cloud, float focal_distance = 525.0);

template <typename PointT>
sensor_msgs::ImagePtr convertKinectCloudToImage(const pcl::PointCloud<PointT> & cloud);

template <typename PointT>
sensor_msgs::ImagePtr convertKinectCloudToDepthImage(const pcl::PointCloud<PointT> & cloud);

rgbd_msgs::DepthMapPtr convertKinectDepthImageToDepthMap(const sensor_msgs::Image & depth_image, float focal_distance = 525.0);

sensor_msgs::ImagePtr convertDepthMapToKinectDepthImage(const rgbd_msgs::DepthMap & depth_map);

pcl::PointCloud<pcl::PointXYZRGB>::Ptr convertKinectImageAndDepthImageToCloud(
		const sensor_msgs::Image & rgb_image,
		const sensor_msgs::Image & depth_image,
		rgbd::CameraParams & camera_params);

template <typename PointT>
typename pcl::PointCloud<PointT>::Ptr convertKinectCloudType(
		const sensor_msgs::PointCloud2 & kinect_cloud);

template <typename PointT>
typename pcl::PointCloud<PointT>::Ptr convertKinectCloudType(
		const pcl::PointCloud<pcl::PointXYZRGB> & kinect_cloud);

/*
 * Checks if a cloud is organized (height > 1)
 */
template <typename PointT>
bool isOrganizedCloud(const pcl::PointCloud<PointT> & cloud);

template <typename PointT>
void getValidIndicesForOrganizedCloud(
		const pcl::PointCloud<PointT> &organized_cloud,
		float max_depth,
		std::vector<unsigned int> &valid_indices);

template <typename PointT>
void getValidIndicesXYForOrganizedCloud(
		const pcl::PointCloud<PointT> &organized_cloud,
		float max_depth,
		std::vector<std::pair<unsigned int, unsigned int> > &valid_indices);

/*
 * set all points to the given color
 */
template <typename PointT>
void recolor(pcl::PointCloud<PointT>& cloud, const rgbd::eigen::Vector3f& rgb);

/*
 * Get a mesh structure over an organized cloud (ie Kinect frame)
 * triangles are indices into organized_cloud.points (each successive 3 indices are a triangle)
 */
template <typename PointT>
void getMeshForOrganizedCloud(
		const pcl::PointCloud<PointT> &organized_cloud,
		float max_edge_length,
		std::vector<unsigned int> &triangles);

} // ns

#include "cloudUtils.ipp"

#endif //header
