/*
 * cloudNormals: computing and retrieving normals
 *
 * Evan Herbst
 * 3 / 24 / 10
 */

#ifndef EX_PCL_POINT_CLOUD_NORMALS_H
#define EX_PCL_POINT_CLOUD_NORMALS_H

#include <vector>
#include <string>
#include <boost/multi_array.hpp>
#include <ros/publisher.h>
#include <pcl/point_cloud.h>
#include <geometry_msgs/Point32.h>
#include <geometry_msgs/PointStamped.h>
#include <visualization_msgs/Marker.h>
#include "rgbd_util/eigen/Geometry"

#if ENABLE_OPENCL
#include <oclUtils.h>
#include <CL/cl_platform.h>
#endif

namespace rgbd
{

	/*
	 * WARNING: the numbers coming from here don't match those from pcl; they're generally larger -- ??
	 * -- as of 20120501 they do seem to match
	 *
	 * first and second principal curvatures, computed in parallel (unlike pcl as of 20110131)
	 *
	 * pc1, pc2 will be allocated
	 *
	 * pre: cloud has normals
	 */
	template <typename PointT>
	void computePrincipalCurvatures(const pcl::PointCloud<PointT>& cloud, const float nbrhoodRadius, std::vector<float>& pc1, std::vector<float>& pc2, const bool parallelize = true);

	/*
	 * set a normal to all zeros as the closest thing we have to setting a flag to say it's invalid -- TODO replace this with a non-hack
	 */
	template <typename PointT>
	bool hasValidNormal(const PointT& pt);
	template <typename PointT>
	void markNormalInvalid(PointT& pt);

	/*
	 * common params for all functions calculating normals using 2-d neighborhoods
	 */
	struct normals2dParams
	{
		unsigned int windowHalfwidth;
		unsigned int downsampleFactor; //2 means calculate for each 2nd pixel in x and y
		float maxZDiff; //ignore pts farther than this (scaled by stereo error ratio wrt 1m) from the center pt
	};

	/** \brief Estimate (in place) the point normals and surface curvatures for a given point cloud dataset (points)
	 *
	 * EVH copied from point_cloud_mapping/src/cloud_geometry/nearest.cpp and edited
	 * (differences: mainly that we do it in parallel)
	 *
	 * \param points the input point cloud (on output, 4 extra channels will be added: \a nx, \a ny, \a nz, and \a curvatures)
	 * \param k use a fixed number of k-nearest neighbors for the least-squares fit
	 * \param viewpoint the viewpoint the cloud was acquired from (used for normal flip)
	 */
	template <typename PointT>
	void computePointCloudNormals (pcl::PointCloud<PointT> &points, unsigned int k, const geometry_msgs::Point32 &viewpoint);

#ifdef UNUSED
	/** \brief Estimate point normals for a given organized point cloud
	 *
	 * Like computeOrganizedPointCloudNormals() except:
	 * - compute for all points
	 * - use the same cloud for plane estimation
	 * - no depth threshold used to define neighbors (instead we have different heuristics for neighborhood "planarity")
	 * - parallelize
	 * - for each point select the neighborhood size for which the neighborhood is most planar
	 *
	 * \param organizedCloud: on output, 4 extra channels will be added: \a nx, \a ny, \a nz, and \a curvatures
	 */
	template <typename PointT>
	void compute2DNormalsAdaptively(pcl::PointCloud<PointT>& organizedCloud, const boost::multi_array<bool, 2>& validityMap);
#endif

    /** \brief Estimate the point normals and surface curvatures for a given organized point cloud dataset (points)
      * using the data from a different point cloud (surface) for least-squares planar estimation.
      *
      * Copied from point_cloud_mapping/cloud_geometry/nearest.cpp to facilitate making changes
      *
      *
      * Key Differences:
      * 1) Ignore points with z <= 0
      * 2) no pragma omp parallel (causes segfaults)
      * 3) added missing j++ to if(nn_indices.size () < 4) --
      * 	still need to move on to next destination point
      *
      * \param points result is put here. note that the ONLY channels will be normals and curvature
      * also, this WILL HAVE THE DOWNSAMPLED SIZE
      * \param surface the point cloud data to use for least-squares planar estimation
      * \param k the windowing factor (i.e., how many pixels in the depth image in all directions should the neighborhood of a point contain)
      * \param downsample_factor factor for downsampling the input data, i.e., take every Nth row and column in the depth image
      * \param max_z maximum distance threshold (on Z) between the query point and its neighbors (set to -1 to ignore the check)
      * \param viewpoint the viewpoint where the cloud was acquired from (used for normal flip)
      */
	template <typename PointT>
	void computeOrganizedPointCloudNormals (
		pcl::PointCloud<PointT> &points, const pcl::PointCloud<PointT> &surface,
		boost::multi_array<bool, 2>& surfaceValidity,
		unsigned int k, unsigned int downsample_factor, double max_z,
		const geometry_msgs::Point32 &viewpoint, const bool multithread = true);

	/*
	 * like computeOrganizedPointCloudNormals(), but also return uncertainty of each normal (see computeNormals2dWithStdevs() for details)
	 */
	template <typename PointT>
	void computeOrganizedPointCloudNormalsWithStdevs(
	    pcl::PointCloud<PointT> &points, std::vector<rgbd::eigen::Matrix3f>& stdevs, const pcl::PointCloud<PointT> &surface, boost::multi_array<bool, 2>& surfaceValidity, const normals2dParams& params);

	  /**
		 * Sets the normals in an organized point cloud by calling computeOrganizedPointCloudNormals
		 * and then upsampling using interpolateNormals
		 *
		 * @param organizedCloud should have height, width set
		 * @param targetValidityGrid should be sized for organizedCloud and should have been filled
		 * @param normals_window_size
		 * @param normals_downsample
		 * @param normals_max_z_diff
		 * @param use_GPU_for_normals
		 */
	template <typename PointT>
	void setOrganizedNormals(
			pcl::PointCloud<PointT> &organizedCloud,
			boost::multi_array<bool, 2>& targetValidityGrid,
			unsigned int normals_window_size,
			unsigned int normals_downsample,
			float normals_max_z_diff,
			bool use_GPU_for_normals = false,
			const bool multithread = true);

	/*
	 * compute normals in a disorganized cloud by converting it to and from an organized cloud
	 */
	template <typename PointT>
	  void computeNormals2d(pcl::PointCloud<PointT>& cloud, const unsigned int windowSize, const unsigned int downsampleFactor, const double maxDepthDifference, const unsigned int width, const unsigned int height, bool use_GPU_for_normals = false);
	
	/*
	 * compute normals and their uncertainty in a disorganized cloud by converting it to and from an organized cloud
	 *
	 * returned stdevs are covariance matrices of n_x, n_y, offset params of a Bayesian linear regression of the form z = n_x x + n_y y + offset
	 *
	 * post: stdevs has one entry per point in cloud; for points with invalid normals set, stdevs[.] is undefined
	 */
	template <typename PointT>
	void computeNormals2dWithStdevs(pcl::PointCloud<PointT>& cloud, std::vector<rgbd::eigen::Matrix3f>& stdevs, const normals2dParams& params);

	template <typename PointT>
    rgbd::eigen::Vector3f getNormal(pcl::PointCloud<PointT> &organizedCloud, unsigned int x, unsigned int y);
	template <typename PointT>
    float getCurvature(pcl::PointCloud<PointT> &organizedCloud, unsigned int x, unsigned int y);

	/*
	 * PointVectorT must be vector<Vector3f> or vector<Vector4f, aligned_allocator>
	 */
	template <typename PointT, typename PointVectorT>
    void pointCloudNormalsToEigenNormals(const pcl::PointCloud<PointT>& point_cloud, PointVectorT& normals);

	/**
	 * Use the img{X,Y} fields in the unorganized cloud to copy all fields of points in cloud to organizedCloud.
	 *
	 * The ordering is such that if you want the point at position (x,y), you
	 * use organizedCloud.point[x + y*xRes]
	 *
	 * @param cloud
	 * @param organizedCloud should have height, width set; points will be allocated
	 * @param validity will be allocated; to be indexed by (x, y)
	 */
	template <typename PointT>
	void computeOrganizedPointCloud(const pcl::PointCloud<PointT>& cloud, pcl::PointCloud<PointT>& organizedCloud, boost::multi_array<bool, 2>&validity);

	/*
	 * unorganizedCloud will be allocated; if it has img{X,Y} fields they'll be set
	 *
	 * all fields will be copied
	 */
	template <typename PointT>
	void organized2unorganizedCloud(const pcl::PointCloud<PointT>& organizedCloud, const boost::multi_array<bool, 2>&validity, pcl::PointCloud<PointT>& unorganizedCloud);

	/*
	 * Extract the valid indices into an organizedCloud from its validity grid.
	 * These indices can be used to extract the corresponding "unorganized cloud" containing only valid points.
	 */
	void getValidIndices(const boost::multi_array<bool, 2> &validity, std::vector<unsigned int> & indices);

	/*
	 * Extract the validity grid from an organized point cloud (use z > 0 to determine validity)
	 *
	 * validity_grid will be allocated (to be indexed with (x, y))
	 */
	template <typename PointT>
	void getValidityGrid(const pcl::PointCloud<PointT> & organized_cloud, boost::multi_array<bool, 2>& validity_grid );

	/*
	 * use pointcloud_normal_marker()
	template <typename PointT>
    void publishNormalLines (pcl::PointCloud<PointT> &points, ros::Publisher &publisher,
        		std::string frameID, double length, double width);

        		See newer alternative in cloudMarkers.h
    */

	template <typename PointT>
	void pointcloud_normal_marker(pcl::PointCloud<PointT> const& cloud, visualization_msgs::Marker& marker, const std::string& marker_namespace,
		float line_length, float line_width, float red, float green, float blue);

	/*
	 * An refactoring that allows for a normal at a particular index in an organized cloud
	 * Returns true if the normal was set in the cloud, false if either the point or enough neighbors were invalid
	 * As opposed to a validity grid, point[index].z must be > 0
	 */
	template <typename PointT>
	bool computeOrganizedNormalForIndex(
			pcl::PointCloud<PointT> & organized_cloud,
			unsigned int index,
			int k,
			int min_neighbors,
			double max_z,
			const geometry_msgs::Point32 & viewpoint);

	/*
	 * Calls computeOrganizedNormalForIndex storing valid normals in the cloud and validity in index_has_valid_normal, which is resized internally
	 */
	template <typename PointT>
	void computeOrganizedNormalsForIndices(
			pcl::PointCloud<PointT> & organized_cloud,
			const std::vector<unsigned int> & indices,
			std::vector<bool> & index_has_valid_normal,
			int k,
			int min_neighbors,
			double max_z,
			const geometry_msgs::Point32 & viewpoint);


#if ENABLE_OPENCL
	template <typename PointT>
	bool GPUcomputeOrganizedPointCloudNormals ( pcl::PointCloud<PointT> &points, const pcl::PointCloud<PointT> &surface, int k, int downsample_factor, int width, int height, double max_z, const geometry_msgs::Point32 &viewpoint);
#endif

} //namespace

#include "cloudNormals.ipp"

#endif //header
