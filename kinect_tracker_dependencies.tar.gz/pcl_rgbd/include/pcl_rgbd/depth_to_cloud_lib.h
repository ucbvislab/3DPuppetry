/*
 * depth_to_cloud_lib.h
 *
 *  Created on: Jan 15, 2010
 *      Author: peter
 */

#ifndef EX_PCL_DEPTH_TO_CLOUD_LIB_H_
#define EX_PCL_DEPTH_TO_CLOUD_LIB_H_

#include <opencv2/core/core.hpp>
#include <sensor_msgs/Image.h>
#include <pcl/point_cloud.h>
#include "rgbd_msgs/DepthMap.h"
#include "rgbd_util/CameraParams.h"
#include "rgbd_util/eigen/Geometry"

/**
 * cloud holds the result
 *
 * When matching depth maps and images are received, the conversion from projective
 * coordinates to real-world coordinates is performed, RGB information
 * is looked up in the image map and associated with the points, and the
 * resulting PointCloud is returned.
 *
 * depth_msg can be compressed or not.
 *
 * @param include_xy_channels whether to include image_{x,y} channels in the cloud (you want to do this if you're
 * creating an unorganized cloud but will convert it to an organized later)
 * @param publish_all_points whether to include in the cloud points with negative depth (if yes, the cloud is "organized";
 * if not, it's "unorganized")
 *
 * if the cloud is organized, points will appear in row-major order
 *
 * @return true
 *
 * throw on any error
 */
template <typename PointT>
bool depth_to_cloud(
		const rgbd_msgs::DepthMap& depth_msg,
		bool include_xy_channels,
		bool publish_all_points,
		pcl::PointCloud<PointT>& cloud,
		const rgbd::CameraParams& depthCamParams);
/*
 * sample colors from image using depth2imgXform and camParams to transform depth pts
 * (so image and depth don't need to be related by, eg, having the same size and having been preregistered)
 */
template <typename PointT>
bool image_and_depth_to_cloud(
		const sensor_msgs::Image& image_msg,
		const rgbd_msgs::DepthMap& depth_msg,
		const rgbd::eigen::Affine3f& depth2imgXform,
		const rgbd::CameraParams& camParams,
		bool include_xy_channels,
		bool publish_all_points,
		pcl::PointCloud<PointT>& cloud,
		const rgbd::CameraParams& depthCamParams);
/*
 * version of the above where we take depth2imgXform to be the identity and camParams to be the same as depthCamParams
 *
 * image and depth must be the same size
 */
template <typename PointT>
bool image_and_depth_to_cloud(
		const sensor_msgs::Image& image_msg,
		const rgbd_msgs::DepthMap& depth_msg,
		bool include_xy_channels,
		bool publish_all_points,
		pcl::PointCloud<PointT>& cloud,
		const rgbd::CameraParams& depthCamParams);
template <typename PointT>
bool image_and_depth_to_cloud(
		const cv::Mat& image,
		const rgbd_msgs::DepthMap& depth_msg,
		bool include_xy_channels,
		bool publish_all_points,
		pcl::PointCloud<PointT>& cloud,
		const rgbd::CameraParams& depthCamParams);

#include "depth_to_cloud_lib.ipp"

#endif //header
