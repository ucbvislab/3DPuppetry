/*
 * cloudMarkers.h
 *
 *  Created on: 2010-08-18
 *      Author: phenry
 */

#ifndef CLOUDMARKERS_H_
#define CLOUDMARKERS_H_

#include <pcl/point_cloud.h>
#include <visualization_msgs/Marker.h>
#include <visualization_msgs/MarkerArray.h>
#include <rgbd_msgs/Transform.h>
#include <vector>
#include <rgbd_util/eigen/Core>

namespace rgbd {

template <typename PointT1, typename PointT2>
visualization_msgs::Marker cloud_correspondence_marker(
		pcl::PointCloud<PointT1> const& cloud0,
		pcl::PointCloud<PointT2> const& cloud1,
		const std::vector<std::pair<unsigned int, unsigned int> >& index_pairs,
		float line_width, float red, float green, float blue);

template <typename PointT1, typename PointT2>
visualization_msgs::Marker cloud_correspondence_marker_with_colors(
		pcl::PointCloud<PointT1> const& cloud0,
		pcl::PointCloud<PointT2> const& cloud1,
		const std::vector<std::pair<unsigned int, unsigned int> >& index_pairs,
		const std::vector<rgbd::eigen::Vector3f> & color_vector,
		float line_width);

/*
 * If indices is empty, publish normals for all points in cloud
 */
template <typename PointT>
visualization_msgs::Marker cloud_normal_marker(
		pcl::PointCloud<PointT> const& cloud,
		const std::vector<unsigned int>& indices,
		float line_length, float line_width, float red, float green, float blue);

template <typename PointT>
visualization_msgs::Marker cloud_marker(
		pcl::PointCloud<PointT> const& cloud,
		const std::vector<unsigned int>& indices,
		float red, float green, float blue);


void add_pose_to_marker_array(
		visualization_msgs::MarkerArray & all_poses_marker_array,
		const rgbd_msgs::Transform& transform_msg,
		int id,
		const std_msgs::ColorRGBA& sphere_color,
		float sphere_radius,
		float direction_line_width = 0.01,
		float direction_line_length_x = 0.05,
		float direction_line_length_y = 0.05,
		float direction_line_length_z = 0.2);

visualization_msgs::Marker prepare_pose_edge_marker(
		const roslib::Header & header,
		float edge_width = 0.02);

void add_pose_edge_to_marker(
		visualization_msgs::Marker & all_edges_marker,
		const geometry_msgs::Transform& transform_msg_1,
		const geometry_msgs::Transform& transform_msg_2,
		const std_msgs::ColorRGBA& color);


} // namespace

#include "cloudMarkers.ipp"


#endif /* CLOUDMARKERS_H_ */
