/*
 * cloudUncertainty: uncertainty modeling of single clouds
 *
 * Evan Herbst
 * 1 / 9 / 11
 */

#ifndef EX_POINT_CLOUD_UNCERTAINTY_H
#define EX_POINT_CLOUD_UNCERTAINTY_H

#include <vector>
#include <pcl/point_cloud.h>
#include "rgbd_util/eigen/Geometry"

namespace rgbd
{

/*
 * return a covariance matrix for the position of each point in the cloud independently
 *
 * dthetaX, dthetaY: angle differences (in rad) between adjacent pixels in x and y
 * xySigmaInPixels: covariance in x and y directions is this multiplier x the distance between pixels
 * zSigmaInDepthBins: covariance in depth direction is this multipler x the size of the depth bin containing the point
 *
 * points with z <= 0 will have invalid entries
 */
template <typename PointT>
std::vector<rgbd::eigen::Matrix3d> getIndependentPointCovariances(const pcl::PointCloud<PointT>& cloud, const double dthetaX, const double dthetaY, const double xySigmaInPixels = 1, const double zSigmaInDepthBins = 1);

} //namespace

#include "cloudUncertainty.ipp"

#endif //header
