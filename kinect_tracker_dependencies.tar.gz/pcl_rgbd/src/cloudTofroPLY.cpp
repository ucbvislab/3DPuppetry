/*
 * cloudTofroPLY: write PointClouds to and read them from PLY files (including all the clouds' channels)
 *
 * Evan Herbst
 * 2 / 18 / 10
 */

#include <string>
#include <fstream>
#include <stdexcept>
#include <boost/array.hpp>
#include <pcl/io/io.h> //getFieldIndex()
#include <pcl/ros/conversions.h>
#include "ply/ply.h"
#include "pcl_rgbd/cloudUtils.h"
#include "pcl_rgbd/cloudTofroPLY.h"
using std::string;
using std::ifstream;
using std::ofstream;
using std::invalid_argument;
using std::runtime_error;

namespace rgbd
{
typedef unsigned char uchar;

int plyTypeStr2rosmsgTypeCode(const string& plyType)
{
	if(plyType == "float") return sensor_msgs::PointField::FLOAT32;
	else if(plyType == "uint") return sensor_msgs::PointField::UINT32;
	else if(plyType == "int") return sensor_msgs::PointField::INT32;
	else if(plyType == "uchar") return sensor_msgs::PointField::UINT8;
	else throw invalid_argument("unknown datatype string");
}

string rosmsgTypeCode2plyTypeStr(const int type)
{
	switch(type)
	{
		case sensor_msgs::PointField::UINT8: return "uchar";
		case sensor_msgs::PointField::UINT32: return "uint";
		case sensor_msgs::PointField::INT32: return "int";
		case sensor_msgs::PointField::FLOAT32: return "float";
		default: throw invalid_argument("unknown type code");
	}
}

/**
 * throw on any error
 */
void write_ply_file(sensor_msgs::PointCloud2 const& cloud, const fs::path& filepath)
{
	const int rgb_channel = pcl::getFieldIndex(cloud, "rgb");
//	assert(rgb_channel > -1);
	const int xFieldIndex = pcl::getFieldIndex(cloud, "x"), yFieldIndex = pcl::getFieldIndex(cloud, "y"), zFieldIndex = pcl::getFieldIndex(cloud, "z");
	assert(xFieldIndex > -1 && yFieldIndex > -1 && zFieldIndex > -1);

	ofstream ofs(filepath.string().c_str(), ofstream::binary);
	if (!ofs.is_open()) throw runtime_error("Failed to open file " + filepath.string());

	const unsigned int point_count = cloud.height * cloud.width;

	// create ply header
	ofs << "ply\n";
	ofs << "format binary_little_endian 1.0\n";
	ofs << "element vertex " << point_count << "\n";
	ofs << "property float x\n";
	ofs << "property float y\n";
	ofs << "property float z\n";

	if(rgb_channel > -1){
		ofs << "property uchar diffuse_red\n";
		ofs << "property uchar diffuse_green\n";
		ofs << "property uchar diffuse_blue\n";
	}

	for (int c = 0; c < (int) cloud.fields.size(); c++)
		if (c != xFieldIndex && c != yFieldIndex && c != zFieldIndex && c != rgb_channel)
			ofs << "property " << rosmsgTypeCode2plyTypeStr(cloud.fields[c].datatype) << " " << cloud.fields[c].name << "\n";
	ofs << "end_header\n";

	const unsigned int xOffset = cloud.fields[xFieldIndex].offset, yOffset = cloud.fields[yFieldIndex].offset, zOffset = cloud.fields[zFieldIndex].offset;
	const unsigned int rgbOffset = cloud.fields[rgb_channel].offset;
	for(unsigned int i = 0; i < cloud.height; i++)
	{
		const unsigned char* rowptr = (unsigned char*)(&cloud.data[0]) + i * cloud.row_step;
		for(unsigned int j = 0; j < cloud.width; j++)
		{
			const unsigned char* ptptr = rowptr + j * cloud.point_step;
			ofs.write((char*) (ptptr + xOffset), sizeof(float));
			ofs.write((char*) (ptptr + yOffset), sizeof(float));
			ofs.write((char*) (ptptr + zOffset), sizeof(float));

			/*
			 * next the uchars for the color
			 *
			 * a major reason for this function is viewing in meshlab, which requires that its rgb channels have type uchar (as opposed to, say, float),
			 * so write uchars even if the PointCloud stores floats for rgb
			 */
			if(rgb_channel > -1){
#if 0
				// This looks right but may be wrong -a frustrated Peter
				uint byte_mask = 0xFF;
				const uint* rgb_uint_ptr = reinterpret_cast<const uint*>(ptptr + rgbOffset);
				uchar r = (uchar) ((*rgb_uint_ptr) >> 16) & byte_mask;
				uchar g = (uchar) ((*rgb_uint_ptr) >> 8) & byte_mask;
				uchar b = (uchar) ((*rgb_uint_ptr)) & byte_mask;
				ofs.write((char*) (&r), sizeof(uchar));
				ofs.write((char*) (&g), sizeof(uchar));
				ofs.write((char*) (&b), sizeof(uchar));
#endif
				// alternative:
				boost::array<uchar, 3> rgb_array = rgbd::unpackRGB<uchar>(*reinterpret_cast<const float*>(ptptr + rgbOffset));
				ofs.write((char*) (&rgb_array[0]), sizeof(uchar));
				ofs.write((char*) (&rgb_array[1]), sizeof(uchar));
				ofs.write((char*) (&rgb_array[2]), sizeof(uchar));
			}

			// finally floats for all remaining channels
			for (unsigned int c = 0; c < cloud.fields.size(); c++)
				if (c != xFieldIndex && c != yFieldIndex && c != zFieldIndex && c != rgb_channel)
					ofs.write((char*)(ptptr + cloud.fields[c].offset), datatypeByteCount(cloud.fields[c].datatype));
		}
	}
}

/*
 * edit the data of cloud but not the header
 *
 * throw on any format error
 */
void read_ply_file(sensor_msgs::PointCloud2& cloud, const fs::path& filepath)
{
	 ifstream infile(filepath.string().c_str(), ifstream::binary); //as long as the file was written using \n and not \n\r or some such, reading in binary mode is fine
	 if(!infile) throw runtime_error("can't open file '" + filepath.string() + "' for read");

	 const ply::schema s = ply::readHeader(infile);
	 const ply::element& e = s.elements[0];
	 if(e.name != "vertex") throw runtime_error("can't find vertex element");
	 if(e.props.size() < 6) throw runtime_error("vertex element has bad schema");
	 const boost::array<std::string, 6> propnames = {{"x", "y", "z", "diffuse_red", "diffuse_green", "diffuse_blue"}}; //expected channels
	 for(unsigned int i = 0; i < propnames.size(); i++)
		 if(e.props[i].name != propnames[i])
			 throw runtime_error("vertex element has bad property name(s)");
	 const unsigned int numPts = e.count;
	 ply::istreamReader read(s.fmt, infile);
	 cloud.fields.resize(e.props.size());
	 unsigned int offsetSum = 0;
	for(unsigned int i = 0; i < cloud.fields.size(); i++)
	{
		cloud.fields[i].name = e.props[i].name;
		cloud.fields[i].datatype = plyTypeStr2rosmsgTypeCode(e.props[i].type);
		if(offsetSum % 4 != 0 && datatypeByteCount(cloud.fields[i].datatype) > 1) offsetSum += (4 - offsetSum % 4); //pad after uchars if nec so later floats will be word-aligned
		cloud.fields[i].offset = offsetSum;
		cloud.fields[i].count = 1;
		offsetSum += datatypeByteCount(cloud.fields[i].datatype);
	}

	/*
	 * switch on type of color fields
	 */
	if(e.props[3].type == "float")
	{
		cloud.data.resize(numPts * cloud.fields.size() * sizeof(float));
		float* dataptr = (float*)(&cloud.data[0]);
		for(unsigned int i = 0; i < numPts; i++)
			for(unsigned int j = 0; j < cloud.fields.size(); j++)
			{
				read(*dataptr);
				dataptr++;
			}
	}
	else if(e.props[3].type == "uchar")
	{
		cloud.data.resize(numPts * (cloud.fields.size() - 2) * sizeof(float));
		unsigned char* dataptr = (unsigned char*)(&cloud.data[0]);
		for(unsigned int i = 0; i < numPts; i++)
		{
			//xyz
			for(unsigned int j = 0; j < 3; j++)
			{
				read(*(float*)dataptr);
				dataptr += sizeof(float);
			}

			// rgb
			uchar r, g, b;
			read(r);
			read(g);
			read(b);
			*dataptr++ = r;
			*dataptr++ = g;
			*dataptr++ = b;
			dataptr++; // keep 4-byte aligned (and move past the float we just wrote)

			//rest of fields
			for(unsigned int j = 6; j < cloud.fields.size(); j++)
			{
				read(*(float*)dataptr);
				dataptr += sizeof(float);
			}
		}
	}
	else throw runtime_error("rgb channels have bad type");

	// need to set width, height, row_step, point_step
	// assume unorganized
	cloud.width = numPts;
	cloud.height = 1;

	// if the last field was a uchar, need to word-align
	if (offsetSum % 4 != 0) offsetSum += (4 - offsetSum % 4);
	cloud.point_step = offsetSum;
	cloud.row_step = cloud.width * cloud.point_step;
}

}
