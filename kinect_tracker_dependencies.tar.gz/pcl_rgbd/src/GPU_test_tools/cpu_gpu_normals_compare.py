# a script to compare the output of the cpu normals computation against the gpu version.
# polly powledge

import array
import re
import sys


def parse_cline(cline):

	#print "enter cline"
	d = {}
	#p = re.compile( r'^[\W*\w*]+ cpu: i=(\d+) j=(\d+) x,y,z=(\d+),(\d+),([-.0-9]+) pp=([-.0-9]+),([-.0-9]+),([-.0-9]+),([-.0-9]+)[\^]+[\W*\w*]*$')
	p = re.compile( r'^[\W*\w*]+ cpu: i=(\d+) j=(\d+) x,y,z=(\d+),(\d+),([-.0-9]+) pp=([-.0-9]+),([-.0-9]+),([-.0-9]+),([-.0-9]+)[\W*\w*]*$')
	m = p.match ( cline )

	#print "cline: m = " + str(m)
	if m:
		d['i'] = m.group(1)
		d['j'] = m.group(2)
		d['x'] = m.group(3)
		d['y'] = m.group(4)
		# make sure these are really floating pt numbers
		d['z'] = float ( m.group(5) ) 
		d['pp0'] = float ( m.group(6) ) 
		d['pp1'] = float ( m.group(7) ) 
		d['pp2'] = float ( m.group(8) ) 
		d['pp3'] = float ( m.group(9) ) 
		d['raw'] = cline
	else:
		print "cannot parse " + cline
		return None
	return d

def parse_gline(gline):
	#print "enter gline"
	d = {}
	#p = re.compile( r'^[\W*\w*]+ gpu: i=(\d+) x,y,z=(\d+),(\d+),([-.0-9]+) pp=([-.0-9]+),([-.0-9]+),([-.0-9]+),([-.0-9]+)[\^]+[\W*\w*]*$')
	p = re.compile( r'^[\W*\w*]+ gpu: i=(\d+) x,y,z=(\d+),(\d+),([-.0-9]+) pp=([-.0-9]+),([-.0-9]+),([-.0-9]+),([-.0-9]+)[\W*\w*]*$')
	m = p.match ( gline )

	#print "gline: m = " + str(m)
	if m:
		d['i'] = m.group(1)
		d['x'] = m.group(2)
		d['y'] = m.group(3)
		# make sure these are really floating pt numbers
		d['z'] = float ( m.group(4) ) 
		d['pp0'] = float ( m.group(5) ) 
		d['pp1'] = float ( m.group(6) ) 
		d['pp2'] = float ( m.group(7) ) 
		d['pp3'] = float ( m.group(8) ) 
		d['raw'] = gline
	else:
		#print "could not parse, looking for drops"
		d = gline_is_dropped(gline)
		if d == None:
			print "cannot parse " + gline
	return d

def gline_is_dropped(gline):
#[ INFO] 1273693167.224154000: gpu-dropped: i=307198 x,y,z=638,479,-1.000000 pp=9999.000000
	d = {}
	p = re.compile( r'^[\W*\w*]+ gpu-dropped: i=(\d+) x,y,z=(\d+),(\d+),([-.0-9]+) pp=([-.0-9]+)[\W*\w*]*$')
	m = p.match ( gline )
	if m:
		d['i'] = m.group(1)
		d['x'] = m.group(2)
		d['y'] = m.group(3)
		d['z'] = float ( m.group(4) ) 
		d['pp0'] = float ( m.group(5) ) 
		d['raw'] = gline
		return d
	return None

def indexes_do_match( cdict, gdict ):
	#print "indexs do match"
	if cdict['i'] == gdict['i']:
		#print "indexes_do_match: yesmatched " + str(cdict) + " " + str(gdict)
		return 1
	#print "indexes_do_match: dont match " + str(cdict) + " " + str(gdict)
	return 0

def do_analyze( cdict, gdict ):
	failflag = 0

	#print "do_analyze: trying to match " + str(cdict) + " " + str(gdict)

	if cdict['x'] != gdict['x']:
		failflag = 1
	if cdict['y'] != gdict['y']:
		failflag = 1
	if cdict['z'] != gdict['z']:
		failflag = 1
	if failflag == 1:
		print "failed to match on xyz values, even though indices match: i=" + str( cdict['i'] )	
		dump_dict("cpu",cdict) 
		dump_dict("gpu",gdict) 
		return

	if gdict['pp0'] == 9999:
		print "got a xyz match, but gpu thinks the z value is invalid: i=" + str( cdict['i'] )
		dump_dict("cpu",cdict) 
		dump_dict("gpu",gdict) 
		return

	if gdict['pp0'] == 8888:
		print "got a xyz match, but gpu thinks there arent enough nns: i=" + str( cdict['i'] )
		dump_dict("cpu",cdict) 
		dump_dict("gpu",gdict) 
		return

	if cdict['pp0'] != gdict['pp0']:
		failflag = 1
	if cdict['pp1'] != gdict['pp1']:
		failflag = 1
	if cdict['pp2'] != gdict['pp2']:
		failflag = 1

	if failflag == 1:
		print "failed to match on pp values, even though indices/xyz match: i=" + str( cdict['i'] )	
		do_more_analysis( cdict, gdict )
		dump_dict("cpu",cdict) 
		dump_dict("gpu",gdict) 
		return

	print "goodmatch: i=" + str( cdict['i'] )	
	return

def do_more_analysis( cdict, gdict ):
	pp0diff = abs( gdict['pp0'] ) - abs ( cdict['pp0'] )
	pp1diff = abs( gdict['pp1'] ) - abs ( cdict['pp1'] )
	pp2diff = abs( gdict['pp2'] ) - abs( cdict['pp2'] )
	if cdict['pp0'] != 0:
		pp0pct = float( pp0diff / abs(cdict['pp0']) )
		pp1pct = float( pp1diff / abs(cdict['pp1']) )
		pp2pct = float( pp2diff / abs(cdict['pp2']) )
		print "badmatch: 0=" + str(pp0diff) + " 1=" + str(pp1diff) + " 2=" + str(pp2diff) + " (" + str(pp0pct) + "," + str(pp1pct) + "," + str(pp2pct) + ") pctgs"
	else:
		print "badmatch: 0=" + str(pp0diff) + " 1=" + str(pp1diff) + " 2=" + str(pp2diff)  

def dump_dict( label, mydict ):
	print "dumping dict for " + label
	for k in mydict.keys():
		print "\tkey = " + k + " value = " + str( mydict[k] )


cpu_file = "cpu_frame1_normals"
gpu_file = "gpu_frame1_normals"
#cpu_file = "cpu.test"
#gpu_file = "gpu.test"

cfile = open(cpu_file)

while 1:
	cline = cfile.readline()

	if not cline:
		break

	cdict = parse_cline(cline)
	if not cdict: continue;

	no_match_found = 1
	gfile = open(gpu_file)
	while 1:
		gline = gfile.readline()

		if not gline:
			break

		gdict = parse_gline(gline)
		if not gdict: 
			continue

		# if inidces,y,z match do compare and report
		if indexes_do_match(cdict,gdict) == 1:
			do_analyze(cdict,gdict)
			no_match_found = 0
			break

	if no_match_found == 1:
		# if match never found report it
		dump_dict("==> never found match!", cdict)
		
	gfile.close()

	


