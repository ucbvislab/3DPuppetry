/*
 * cloudNormals: computing and retrieving normals
 *
 * Evan Herbst
 * 3 / 24 / 10
 */

#include <cmath> //max()
#include "pcl_rgbd/cloudNormals.h"
using std::vector;

namespace rgbd
{

void checkFloat(const float f)
{
	assert(!isnan(f));
	assert(!isinf(f));
}

/*
 * auxiliary to compute2DNormalsAdaptively()
 */
namespace aux
{

vector<int> getNeighborIndices(const unsigned int x, const unsigned int y, const unsigned int radius, const boost::multi_array<bool, 2>& validityMap)
{
	const unsigned int xSize = validityMap.size(), ySize = validityMap[0].size();

	vector<int> nbrs;
	for(unsigned int i = std::max(0, (signed)y - (signed)radius); i <= std::min(ySize - 1, y + radius); i++)
		for(unsigned int j = std::max(0, (signed)x - (signed)radius); j <= std::min(xSize - 1, x + radius); j++)
			if(validityMap[j][i])
				nbrs.push_back(i * xSize + j);
	return nbrs;
}

} //namespace

	void getValidIndices(const boost::multi_array<bool, 2>&validity, std::vector<unsigned int> & indices)
	{
		unsigned int xRes = validity.shape()[0];
		unsigned int yRes = validity.shape()[1];
		indices.clear();
		indices.reserve(xRes * yRes); // assume mostly valid points
		for (unsigned int y = 0; y < yRes; y++) {
			for (unsigned int x = 0; x < xRes; x++) {
				if (validity[x][y]) {
					unsigned int index = x + y * xRes;
					indices.push_back(index);
				}
			}
		}
	}

#if ENABLE_OPENCL
/*
 * Execute the normals kernel on the GPU
 */
int exec_kernel( float input_points_data[640][640], const geometry_msgs::Point32 &viewpoint, cl_float4 *output_data, char *fname, char *kname, int k, double max_z )
{

#define USE_DEBUG_BUFFER	0
	static cl_context context = NULL;
	static cl_kernel kernel = NULL;
	static cl_command_queue cmd_queue = NULL;
	static cl_device_id devices = NULL;
	static cl_program program = NULL;
	static cl_mem output_mem = NULL;
	cl_event event;
	cl_int err;
	size_t output_data_buffer_size = sizeof(cl_float4) * 640 * 640;

	// if the startup GPU work hasn't been done yet, do it
	if ( context == NULL )
	{
		if ( setup_GPU( fname, kname, devices, program, context, cmd_queue, kernel, output_mem, output_data, output_data_buffer_size, k, max_z ) < 0 )
		{
			ROS_INFO("cloudNormals: exec_kernel: setup_GPU fails\n");
			return 1;
		}
	}

	// keep track of how long it takes to create the memory buffers
	//ros::Time ts_transfer = ros::Time::now();

	// allocate global memory, init it with input data, and queue it to be written to the device
	cl_image_format format;
	format.image_channel_order = CL_R;
	format.image_channel_data_type = CL_FLOAT;
	cl_mem input_points_mem = clCreateImage2D( context, CL_MEM_READ_ONLY, &format, 640, 640, 0, NULL, &err);
	if ( err != CL_SUCCESS )
	{
		ROS_INFO("clCreateImage2D returns error %d\n", err );
		return 1;
	}

	size_t origin[3] = { 0, 0, 0 };
	size_t region[3] = { 640, 640, 1 };

	err = clEnqueueWriteImage(cmd_queue, input_points_mem, CL_TRUE, origin, region, 640*sizeof(float), 0, (void*)input_points_data, 0, NULL, NULL);
	if ( err != CL_SUCCESS )
	{
		ROS_INFO("clCreateBuffer returns error %d\n", err );
		return 1;
	}

#if USE_DEBUG_BUFFER
	//Allocate global memory for debugging (comment out for real runs, since it kills performance)
	size_t debug_buffer_size = sizeof(float) * 640 * 640;
	float *debug_val = (float*)calloc(640 * 640, sizeof(float));
	cl_mem debug_mem = clCreateBuffer(context, CL_MEM_WRITE_ONLY, debug_buffer_size, NULL, NULL);
#endif

	// push the data out to device
	err = clFinish(cmd_queue);
	if ( err != CL_SUCCESS )
	{
		ROS_INFO("data push returns %d\n", err );
		return 1;
	}

	// finished timing host-to-device data transfers
	//ROS_INFO("execNNKernel: %f seconds to transfer data to GPU", (ros::Time::now () - ts_transfer).toSec () );

	float viewpoint_x = viewpoint.x;
	float viewpoint_y = viewpoint.y;
	float viewpoint_z = viewpoint.z;

			// set kernel arguments
#if USE_DEBUG_BUFFER
	err  = clSetKernelArg(kernel, 0, sizeof(cl_mem), &input_points_mem);
	err |= clSetKernelArg(kernel, 1, sizeof(cl_float), &viewpoint_x);
	err |= clSetKernelArg(kernel, 2, sizeof(cl_float), &viewpoint_y);
	err |= clSetKernelArg(kernel, 3, sizeof(cl_float), &viewpoint_z);
	err |= clSetKernelArg(kernel, 4, sizeof(cl_mem), &output_mem);
	err |= clSetKernelArg(kernel, 5, sizeof(cl_mem), &debug_mem);
#else
	err  = clSetKernelArg(kernel, 0, sizeof(cl_mem), &input_points_mem);
	err |= clSetKernelArg(kernel, 1, sizeof(cl_float), &viewpoint_x);
	err |= clSetKernelArg(kernel, 2, sizeof(cl_float), &viewpoint_y);
	err |= clSetKernelArg(kernel, 3, sizeof(cl_float), &viewpoint_z);
	err |= clSetKernelArg(kernel, 4, sizeof(cl_mem), &output_mem);
#endif

#if USE_DEBUG_BUFFER
	// print out system recommendations
	size_t thread_size;
	clGetKernelWorkGroupInfo(kernel,devices,CL_KERNEL_WORK_GROUP_SIZE, sizeof(size_t),&thread_size,NULL);
	ROS_INFO("recommended work group size: %lu\n",( unsigned long)thread_size);
#endif

	// set grid and block sizes
	size_t globalWorkSize[] = { 640 , 640  };
	size_t localWorkSize[] = { 1, 32 };

	// start tracking execution and device-to-host data transfer time (use openclprof for more detailed information)
	//ros::Time ts_exec = ros::Time::now();

	// execute the kernel and wait until it's done
	err = clEnqueueNDRangeKernel(cmd_queue, kernel, 2, NULL, globalWorkSize, localWorkSize, 0, NULL, &event);
	if ( err != CL_SUCCESS )
	{
		ROS_INFO("ndrangekernel returns %d\n", err );
		return 1;
	}

	err = clWaitForEvents(1, &event);
	if ( err != CL_SUCCESS )
	{
		ROS_INFO("wait4events returns %d\n", err );
		return 1;
	}

	// read output
	//ROS_INFO("kicked off kernel");
	err = clEnqueueReadBuffer(cmd_queue, output_mem, CL_TRUE, 0, output_data_buffer_size, output_data, 0, NULL, NULL);
	err |= clFinish(cmd_queue);
	if ( err != CL_SUCCESS )
	{
		ROS_INFO("enqueueread for output returns %d\n", err );
		return 1;
	}

	// finished timing execution and data transfer of result
	//ROS_INFO("execNNKernel: %f seconds to exec GPU kernel", (ros::Time::now () - ts_exec).toSec () );

	// if using openclprof, comment out these printfs, since it sometimes causes the
	// profiler to hang. and it does that often enough as it is. :^)
#if USE_DEBUG_BUFFER
#if 0
	err = clEnqueueReadBuffer(cmd_queue, debug_mem, CL_TRUE, 0, debug_buffer_size, debug_val, 0, NULL, NULL);
	err |= clFinish(cmd_queue);
	if ( err != CL_SUCCESS )
	{
		ROS_INFO("enqueueread for debug returns %d\n", err );
		return 1;
	}

	ROS_INFO("dump of debug data");
	cl_float d;
	for ( int i =0; i < 30 ; i++ )
	{
		d = *(debug_val +i);
		printf("i =%d %f \n", i, d);
	}
	ROS_INFO("finished dump of debug data");
#endif
#endif

#if 0
	ROS_INFO("dump of output data");
	cl_float4 x;
	for ( int i =0; i < 50 ; i++ )
	//for ( int i =0; i < 302700 ; i++ )
	{
		x[0] = (*(output_data + i))[0];
		x[1] = (*(output_data + i))[1];
		x[2] = (*(output_data + i))[2];
		x[3] = (*(output_data + i))[3];
		ROS_INFO("i =%d (%d,%d) %f %f %f %f", i, (int)(i % 640), (i / 640), x[0], x[1], x[2], x[3] );
	}
	ROS_INFO("finished dump of output data");
#endif

	//ROS_INFO("exec_kernel: about to release event and mem objects");
	clReleaseEvent(event);
	clReleaseMemObject(input_points_mem);
	//ROS_INFO("exited exec_kernel");

	return CL_SUCCESS;
}

/*
 * Load the GPU kernel source into a malloc'ed char array
 */
char * load_program_source(const char *filename)
{
	struct stat statbuf;
	FILE *fh;
	char *source;

	fh = fopen(filename, "r");
	if (fh == 0) return 0;
	stat(filename, &statbuf);
	source = (char *) malloc(statbuf.st_size + 1);
	fread(source, statbuf.st_size, 1, fh);
	source[statbuf.st_size] = '\0';

	return source;
}

	/*
	 * Do all the one-time-only GPU setup, e.g., compile the kernel source
	 */
	int setup_GPU( char *fname, char *kname, cl_device_id &devices, cl_program &program, cl_context &context, cl_command_queue &cmd_queue, cl_kernel &kernel, cl_mem &output_mem, cl_float4 *output_data, size_t output_data_buffer_size, int k, double max_z  )
	{

		cl_int err;
#if 0
		// hack - fixme
#define MAX_BINARIES	20
		static size_t binaries_size[MAX_BINARIES] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		static char **program_binaries;
#endif

		cl_platform_id clSelectedPlatformID = NULL;
		cl_uint numPlatforms;
    		err = clGetPlatformIDs ( 0, NULL, &numPlatforms );
		if ( err != CL_SUCCESS )
		{
			ROS_INFO("getplatformid returns %d\n", err );
			return -1;
		}
		if ( numPlatforms <= 0 )
		{
			ROS_INFO("getplatformid returns 0 platforms\n" );
			return -1;
		}
		ROS_INFO("we have %d platform(s)\n", numPlatforms );

		cl_platform_id *platforms = new cl_platform_id[numPlatforms];
		err = clGetPlatformIDs( numPlatforms, platforms, NULL );
		if ( err != CL_SUCCESS )
		{
			ROS_INFO("2nd getplatformid returns %d\n", err );
			return -1;
		}

		for ( int i = 0 ; i < numPlatforms ; i++ )
		{
			char platform_vendor[1024];
			char platform_profile[1024];
			char platform_version[1024];
			err = clGetPlatformInfo(platforms[i], CL_PLATFORM_VENDOR, sizeof(platform_vendor), platform_vendor, NULL );
			err |= clGetPlatformInfo(platforms[i], CL_PLATFORM_PROFILE, sizeof(platform_profile), platform_profile, NULL );
			err |= clGetPlatformInfo(platforms[i], CL_PLATFORM_VERSION, sizeof(platform_version), platform_version, NULL );
			if ( err != CL_SUCCESS )
			{
				ROS_INFO("getplatforminfo returns %d\n", err );
				return -1;
			}

			ROS_INFO("platform id: %i vendor:%s profile: %s version:%s", i, platform_vendor, platform_profile, platform_version );
			// if this platform is opencl and full profile, use it 
			if ( ( strncmp(platform_profile,"FULL_PROFILE",12) == 0 ) &&
				( strncmp(platform_version,"OpenCL",6) == 0 ) ) 
			{
				clSelectedPlatformID = platforms[i];
				break;
			}
		}
		delete platforms;

		if ( clSelectedPlatformID == NULL )
		{
			ROS_INFO("Never found an OpenCL platform with full profile");
			return -1;
		}

		// now look for an associated gpu device for this platform
    		err = clGetDeviceIDs (clSelectedPlatformID, CL_DEVICE_TYPE_GPU, 1, &devices, NULL);
		if ( err != CL_SUCCESS )
		{
			ROS_INFO("getdeviceid returns %d\n", err );
			return -1;
		}

		cl_char vendor_name[1024] = {0};
		cl_char device_name[1024] = {0}; 
		cl_char device_type[1024] = {0}; 
		size_t returned_size = 0;

		err = clGetDeviceInfo(devices, CL_DEVICE_VENDOR, sizeof(vendor_name), vendor_name, &returned_size);
		err|= clGetDeviceInfo(devices, CL_DEVICE_NAME, sizeof(device_name), device_name, &returned_size);
		err|= clGetDeviceInfo(devices, CL_DEVICE_TYPE, sizeof(device_type), device_type, &returned_size);
		if ( err != CL_SUCCESS )
		{
			ROS_INFO("getdeviceinfo returns %d\n", err );
			return -1;
		}
		ROS_INFO("Connecting to %s %s...\n", vendor_name, device_name);

		// create the context and command queue
		context = clCreateContext(0, 1, &devices, NULL, NULL, &err);
		if ( err != CL_SUCCESS )
		{
			ROS_INFO("createcontext returns %d\n", err );
			return -1;
		}

		cmd_queue = clCreateCommandQueue(context, devices, 0, &err);
		if ( err != CL_SUCCESS )
		{
			ROS_INFO("createcmdqueue returns %d\n", err );
			return -1;
		}

		// form some strange reason, releasing the output buffer takes 11ms!?!! so, allocate it once at startup and
		// don't release the object until application shutdown.
		output_mem = clCreateBuffer(context, CL_MEM_WRITE_ONLY|CL_MEM_ALLOC_HOST_PTR, output_data_buffer_size, output_data, &err);
		if ( err != CL_SUCCESS )
		{
			ROS_INFO("clcreatebuffer returns %d\n", err );
			return -1;
		}

		// read the program
		//string kernel_source_path = ros::package::getPath("icp_mapping") + "/../rgbd/point_clouds/src/" + fname;
		string kernel_source_path = ros::package::getPath("icp_mapping") + "/../pcl_rgbd/src/" + fname;
		ROS_INFO("Loading program '%s'\n", fname);
		//char *program_source = load_program_source( (const char *)fname);
		ROS_INFO("Loading program '%s'\n", kernel_source_path.c_str() );
		char *program_source = load_program_source( (const char *)kernel_source_path.c_str() );

		// create program from .cl file
		char wdir[1024];
		getcwd( wdir, 1024 );
		ROS_INFO("working directory = %s", wdir );
		program = clCreateProgramWithSource(context,1, (const char**)&program_source, NULL, &err);
		if ( err != CL_SUCCESS )
		{
			ROS_INFO("createpgmwsource returns %d\n", err );
			return -1;
		}

		// FIXME - free source buffer

		// construct preprocessor flag values for kernel code
		char build_options[1024];
#if USE_DEBUG_BUFFER
		strcpy(build_options,"-D USE_DEBUG_BUFFER=1");
#else
		strcpy(build_options,"-D USE_DEBUG_BUFFER=0");
#endif
		char k_def_buf[1024];
		sprintf(k_def_buf," -D NEIGHBORS_OFFSET=%d -D MAX_Z=%f", k, (float)max_z );
		strcat( build_options, (char *)k_def_buf);

		// compile the program
		ROS_INFO("about to compile %s\n", kname );
		err = clBuildProgram(program, 0, NULL, build_options, NULL, NULL);
		if ( err != CL_SUCCESS )
		{
			ROS_INFO("buildprogram returns %d\n", err );
			char build[2048];
			clGetProgramBuildInfo(program, devices, CL_PROGRAM_BUILD_LOG, 2048, build, NULL);
			ROS_INFO("Build Log:\n%s\n",build);
			return -1;
		}

		cl_uint program_num_devices;
		err = clGetProgramInfo(program,CL_PROGRAM_NUM_DEVICES,sizeof(cl_uint),&program_num_devices,NULL);
		if ( err != CL_SUCCESS )
		{
			ROS_INFO("clgetprograminfo: program num devices: returns %d\n", err );
			return -1;
		}

		// create the kernel
		kernel = clCreateKernel(program, kname, &err);
		if ( err != CL_SUCCESS )
		{
			ROS_INFO("createKernel returns %d for kernel %s\n", err, kname );
			return -1;
		}

		ROS_INFO("created kernel for %s\n", kname );
		return 0;
}

/*
 * Release GPU memory object cleanup at shutdown. Note: not currently hooked up to any desctructors! FIXME!
 */
void shutdown_GPU( cl_device_id devices, cl_program program, cl_context context, cl_command_queue cmd_queue, cl_kernel kernel, cl_mem output_mem )
{

	// release kernel, program, and memory objects. if you get lazy
	// about this you will get inscrutable errors from the opencl profiler

	clReleaseMemObject(output_mem);

	clReleaseKernel(kernel);
	clReleaseProgram(program);
	clReleaseCommandQueue(cmd_queue);
	clReleaseContext(context);
}

#endif

} //namespace
