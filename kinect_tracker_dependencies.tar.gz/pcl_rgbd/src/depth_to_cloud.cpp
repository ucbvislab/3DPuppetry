/*
 * depth_to_cloud: subscribe to Image and DepthMap channels and publish PointClouds created from them
 *
 * Evan Herbst
 * 6 / 15 / 10
 */

#include <ros/ros.h>
#include <ros/publisher.h>
#include <rgbd_msgs/DepthMap.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/CameraInfo.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl/point_cloud.h>
#include <pcl/ros/conversions.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include "pcl_rgbd/pointTypes.h"
#include "pcl_rgbd/depth_to_cloud_lib.h"
#include "pcl_rgbd/PauseDepthToCloud.h"
#include "pcl_rgbd/UnpauseDepthToCloud.h"
#include <boost/bind.hpp>
#include <ros/advertise_service_options.h>
#include "rgbd_util/primesensorUtils.h"

ros::NodeHandle *nh;
ros::Publisher cloud_pub;
ros::Publisher info_pub;
message_filters::Subscriber<sensor_msgs::Image> *image_sub;
message_filters::Subscriber<rgbd_msgs::DepthMap> *depth_sub;
bool include_xy_channels;
bool publish_all_points;
int subscription_buffer_size;
boost::shared_ptr<rgbd::CameraParams> rgbd_camera_params_ptr;

sensor_msgs::CameraInfo
get_camera_info(const rgbd_msgs::DepthMap &depth_map)
{
	sensor_msgs::CameraInfo info;
	info.header = depth_map.header;
	info.width = depth_map.width;
	info.height = depth_map.height;
	std::fill(info.D.begin(),info.D.end(),0);
	std::fill(info.K.begin(),info.K.end(),0);
	std::fill(info.R.begin(),info.R.end(),0);
	std::fill(info.P.begin(),info.P.end(),0);
	info.K[0] = info.K[4] = info.P[0] = info.P[5] = depth_map.focal_distance;
	info.K[2] = info.P[2] = depth_map.width/2.0;
	info.K[5] = info.P[6] = depth_map.height/2.0;
	info.K[8] = info.R[0] = info.R[4] = info.R[8] = info.P[10] = 1.0;
	return info;
}

void callback(const sensor_msgs::ImageConstPtr& image_msg, const rgbd_msgs::DepthMapConstPtr& depth_msg) {
	typedef rgbd::pt PointT;
	pcl::PointCloud<PointT> result;
	const bool ok = image_and_depth_to_cloud<PointT>(*image_msg, *depth_msg, include_xy_channels, publish_all_points, result, *rgbd_camera_params_ptr);
	if(!ok) ROS_WARN_STREAM("depth_to_cloud failed");
	else
	{
		sensor_msgs::PointCloud2 result2;
		pcl::toROSMsg(result, result2);
		cloud_pub.publish(result2);

		sensor_msgs::CameraInfo info = get_camera_info(*depth_msg);
		info_pub.publish(info);
	}
}

bool pause_srv(pcl_rgbd::PauseDepthToCloud::Request &req,
    pcl_rgbd::PauseDepthToCloud::Response &resp)
{
  ROS_INFO("depth to cloud service paused");
  image_sub->unsubscribe();
  depth_sub->unsubscribe();
  return true;
}

bool unpause_srv(pcl_rgbd::UnpauseDepthToCloud::Request &req,
    pcl_rgbd::UnpauseDepthToCloud::Response &resp)
{
  ROS_INFO("depth to cloud service unpaused");
  image_sub->subscribe(*nh, "image", subscription_buffer_size);
  depth_sub->subscribe(*nh, "depth", subscription_buffer_size);
  return true;
}


/**
 * Main function sets up the subscriptions to depth and image topics
 * with a time synchronizer, and registers the callback function.
 *
 * Input depth maps can be compressed or not.
 *
 * input channels: image, depth
 * output channels: cloud
 */
int main(int argc, char **argv) {
    ros::init(argc, argv, "depth_to_cloud");

    nh = new ros::NodeHandle();
    ros::NodeHandle nh_local("~");

    nh_local.param("publish_all_points", publish_all_points, false);
    nh_local.param("include_xy_channels", include_xy_channels, false);
    nh_local.param("subscription_buffer_size", subscription_buffer_size, 1);

    rgbd_camera_params_ptr = rgbd::getCameraParamsPtrFromROSParamSearch(nh_local, "rgbd_camera_id");

    image_sub = new message_filters::Subscriber<sensor_msgs::Image>(*nh, "image", subscription_buffer_size);
    depth_sub = new message_filters::Subscriber<rgbd_msgs::DepthMap>(*nh, "depth", subscription_buffer_size);
    cloud_pub = nh->advertise<sensor_msgs::PointCloud2>("cloud", 1);
    info_pub = nh->advertise<sensor_msgs::CameraInfo>("camera_info", 1);
    message_filters::TimeSynchronizer<sensor_msgs::Image, rgbd_msgs::DepthMap> sync(*image_sub, *depth_sub, 100);

    ros::ServiceServer pause_svr = nh_local.advertiseService(
        "pause_depth_to_cloud", &pause_srv);
    ros::ServiceServer unpause_svr = nh_local.advertiseService(
        "unpause_depth_to_cloud", &unpause_srv);

    sync.registerCallback(boost::bind(&callback, _1, _2));

    ros::spin();

    pause_svr.shutdown();
    unpause_svr.shutdown();

//    delete depth_sub;
//    delete image_sub;
//    delete nh;

    return 0;
}

