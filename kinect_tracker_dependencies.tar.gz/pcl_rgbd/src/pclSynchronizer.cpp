#include <ros/ros.h>
#include <iostream>
#include "pcl_rgbd/cloudUtils.h"
#include <pcl/io/pcd_io.h>
#include <message_filters/subscriber.h>
#include <message_filters/synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <sensor_msgs/CompressedImage.h>
#include <sensor_msgs/Image.h>
#include <image_transport/image_transport.h>
#include <image_transport/subscriber_filter.h>
#include <rgbd_util/runningStatistics.h>

using std::cout;
using std::endl;

class PclSynchronizer {

public:
  image_transport::Publisher out_image_pub;
  image_transport::Publisher out_depth_pub;
  ros::Publisher out_pcl_pub;
  sensor_msgs::PointCloud2 out_pcl_msg;
  int subscription_buffer_size;
    
protected:
  message_filters::Subscriber<sensor_msgs::PointCloud2> *pcl_sub_sync;
  image_transport::SubscriberFilter *image_sub_sync;
  image_transport::SubscriberFilter *depth_sub_sync;
  typedef message_filters::sync_policies::ApproximateTime<sensor_msgs::PointCloud2, sensor_msgs::Image> SyncPolicyPCL;
  message_filters::Synchronizer<SyncPolicyPCL> *synchronizer_pcl;
  typedef message_filters::sync_policies::ApproximateTime<sensor_msgs::Image, sensor_msgs::Image> SyncPolicyDepth;
  message_filters::Synchronizer<SyncPolicyDepth> *synchronizer_depth;
  
  ros::NodeHandle nh;
  ros::NodeHandle nh_local;
  image_transport::ImageTransport it;

  double max_stamp_difference;
  double publish_rate;
  ros::Time last_published_time_stamp;

  bool verbose;

public:
  PclSynchronizer()
  :
	  nh_local("~"),
	  it(nh)
  {
    nh_local.param("max_stamp_difference", max_stamp_difference, -1.0); // negative is off
    nh_local.param("publish_rate", publish_rate, -1.0); //fps; negative is off
    nh_local.param("subscription_buffer_size", subscription_buffer_size, 0);

    nh_local.param("verbose", verbose, false);

    pcl_sub_sync   = new message_filters::Subscriber<sensor_msgs::PointCloud2>(nh, "in_pcl", subscription_buffer_size);
    image_sub_sync = new image_transport::SubscriberFilter(it, "in_image", subscription_buffer_size);
    depth_sub_sync = new image_transport::SubscriberFilter(it, "in_depth", subscription_buffer_size);

    // image + pcl cloud
    synchronizer_pcl = new message_filters::Synchronizer<SyncPolicyPCL>(SyncPolicyPCL(10), *pcl_sub_sync, *image_sub_sync);
    synchronizer_pcl->registerCallback(boost::bind(&PclSynchronizer::callback_pcl_image, this, _1, _2));
    
    // image + depth
    synchronizer_depth = new message_filters::Synchronizer<SyncPolicyDepth>(SyncPolicyDepth(10), *depth_sub_sync, *image_sub_sync);
    synchronizer_depth->registerCallback(boost::bind(&PclSynchronizer::callback_depth_image, this, _1, _2));

    out_image_pub = it.advertise("out_image", 1);
    out_depth_pub = it.advertise("out_depth", 1);
    out_pcl_pub   = nh.advertise<sensor_msgs::PointCloud2>("out_pcl", 1);

    //last_published_time_stamp;
    
  }

  ~PclSynchronizer()
  {
	  delete pcl_sub_sync;
	  delete image_sub_sync;
	  delete depth_sub_sync;
	  delete synchronizer_pcl;
	  delete synchronizer_depth;
  }
  
  void callback_pcl_image(const sensor_msgs::PointCloud2ConstPtr& pcl_msg,
			  const sensor_msgs::ImageConstPtr& image_msg)
  {
    float stamp_diff_from_last_publish = (image_msg->header.stamp - last_published_time_stamp).toSec();
   
    if( (publish_rate != 0) && (stamp_diff_from_last_publish >= 1/(publish_rate*0.95)) ) {
      last_published_time_stamp = image_msg->header.stamp;
      
      if(pcl_msg->header.stamp != image_msg->header.stamp) {
	
	sensor_msgs::PointCloud2 pcl_msg_copy(*pcl_msg);
    	pcl_msg_copy.header.stamp = image_msg->header.stamp;
    	out_pcl_pub.publish(pcl_msg_copy);
	
      }
      else {
	out_pcl_pub.publish(pcl_msg);
      }
      out_image_pub.publish(image_msg);
    }
  }

  void callback_depth_image(const sensor_msgs::ImageConstPtr& depth_msg,
			    const sensor_msgs::ImageConstPtr& image_msg)
  {
    float stamp_diff_from_last_publish = (image_msg->header.stamp - last_published_time_stamp).toSec();
   
    if( (publish_rate != 0) && (stamp_diff_from_last_publish >= (1/publish_rate*0.95) ) ) {
      last_published_time_stamp = image_msg->header.stamp;
          
      // removed small optimization of avoiding copy on exactly matching stamps
      // if you're stamps match, don't use this
      float stamp_difference = (image_msg->header.stamp - depth_msg->header.stamp).toSec();
      float abs_stamp_difference = fabs(stamp_difference);
      static int total_skipped = 0;
      static int total_frames = 0;
      total_frames++;
      static rgbd::RunningStatistics running_stats;
      running_stats.push(stamp_difference);
      if(verbose)
      {
      ROS_INFO_STREAM("Stamp difference " << running_stats.summary());
      }
      
      if (max_stamp_difference > 0 && abs_stamp_difference > max_stamp_difference) {
	total_skipped++;
	if(verbose)
	{
	ROS_WARN_STREAM("Skipping sync because abs_stamp_difference: " << abs_stamp_difference);
	ROS_WARN_STREAM("Skipped: " << total_skipped << "/" << total_frames);
	}
      }
      else {
	sensor_msgs::Image depth_msg_copy(*depth_msg);
	depth_msg_copy.header.stamp = image_msg->header.stamp;
	out_depth_pub.publish(depth_msg_copy);
	out_image_pub.publish(image_msg);
      }
    }
  }
  

};

int main(int argc, char **argv) {
  ros::init(argc, argv, "pclSynchronizer");
  PclSynchronizer pcl_synchronizer;
  
  ros::spin();
  
  return 0;
}
