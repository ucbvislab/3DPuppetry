/*
 * cloudSampling: selecting points to throw away
 *
 * Evan Herbst
 * 6 / 22 / 10
 */

#include <boost/iterator/counting_iterator.hpp>
#include "rgbd_util/mathUtils.h" //randomSample()
#include "pcl_rgbd/cloudSampling.h"

namespace rgbd
{

std::vector<unsigned int> getRandomDownsamplingIndices(const unsigned int numPts, float downsampleRate, unsigned int minPts)
{
	const unsigned int finalNumPts = std::min(numPts, std::max(minPts, (unsigned int)rint(downsampleRate*numPts)));
	std::vector<unsigned int> acceptedIndices(finalNumPts);
	randomSample(boost::make_counting_iterator(0u), boost::make_counting_iterator(numPts), finalNumPts, acceptedIndices.begin());

	return acceptedIndices;
}

void downsampleFromIndices(
		const std::vector<rgbd::eigen::Vector3f> & sourcePoints,
		std::vector<rgbd::eigen::Vector3f> & targetPoints,
		const std::vector<unsigned int> & acceptedIndices)
{
	targetPoints.clear();
	for (unsigned int i = 0; i < acceptedIndices.size(); i++) {
		targetPoints.push_back(sourcePoints[acceptedIndices[i]]);
	}
}

void boolVectorToIndices(const std::vector<bool> & acceptedPositions, std::vector<unsigned int> & acceptedIndices)
{
	acceptedIndices.clear();
	for (unsigned int i = 0; i < acceptedPositions.size(); i++) {
		if (acceptedPositions[i]) {
			acceptedIndices.push_back(i);
		}
	}
}

std::vector<unsigned int> getRandomSubsetOfIndices(const std::vector<unsigned int> & indices, unsigned int num_indices)
{
	std::vector<unsigned int> selected_indices = getRandomDownsamplingIndices(indices.size(), 0, num_indices);
	std::vector<unsigned int> result_indices(selected_indices.size());
	for (unsigned int i = 0; i < selected_indices.size(); i++) result_indices[i] = indices[selected_indices[i]];
	return result_indices;
}

} //namespace
