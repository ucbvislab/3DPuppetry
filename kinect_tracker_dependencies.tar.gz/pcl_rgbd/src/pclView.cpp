/* Test node for simple point cloud opengl visualisation */

#include <ros/ros.h>
#include <iostream>
#include <rgbd_msgs/DepthMap.h>
#include "pcl_rgbd/cloudUtils.h"
#include <zlib.h>
#include <pcl/io/pcd_io.h>
#include "pcl/point_types.h"
#include "rgbd_depthmaps/decompressDepth.h"


#include <GL/gl.h>		// Header File For The OpenGL32 Library
#include <GL/glu.h>		// Header File For The GLu32 Library
#include <GL/glx.h>
#include <GL/freeglut.h>		// Header File For The GLut Library
#include <GL/freeglut_ext.h>		// Header File For The GLut Library
#include <X11/extensions/xf86vmode.h>
#include <X11/keysym.h>
// #include "pcl_visualization/cloud_viewer.h"
using std::cout;
using std::endl;

pcl::PointCloud<pcl::PointXYZRGB> cloud;
void DrawGLScene (void);

/* stuff about our window grouped together */
typedef struct {
  Display *dpy;
  int screen;
  Window win;
  GLXContext ctx;
  XSetWindowAttributes attr;
  bool fs;
  bool doubleBuffered;
  XF86VidModeModeInfo deskMode;
  int x, y;
  unsigned int width, height;
  unsigned int depth;    
} GLWindow;

/* attributes for a single buffered visual in RGBA format with at least
 * 4 bits per color and a 16 bit depth buffer */
static int attrListSgl[] = {GLX_RGBA, GLX_RED_SIZE, 4, 
			    GLX_GREEN_SIZE, 4, 
			    GLX_BLUE_SIZE, 4, 
			    GLX_DEPTH_SIZE, 16,
			    None};

/* attributes for a double buffered visual in RGBA format with at least
 * 4 bits per color and a 16 bit depth buffer */
static int attrListDbl[] = { GLX_RGBA, GLX_DOUBLEBUFFER, 
			     GLX_RED_SIZE, 4, 
			     GLX_GREEN_SIZE, 4, 
			     GLX_BLUE_SIZE, 4, 
			     GLX_DEPTH_SIZE, 16,
			     None };

GLWindow GLWin;

class PclViewer {
  
public:
  
  ros::Subscriber in_sub;
  sensor_msgs::PointCloud2 pcl;
  
  PclViewer(int argc, char **argv)
  {
    ros::NodeHandle nh;
    ros::NodeHandle local_nh("~");
    
    std::string in_topic = nh.resolveName("in");
    
    in_sub  = nh.subscribe(in_topic, 1, &PclViewer::callback, this);
    
  }
  
  void callback(const sensor_msgs::PointCloud2::ConstPtr& in_msg)
  {
    pcl = *in_msg;
    pcl::fromROSMsg (pcl, cloud);
    
    DrawGLScene();
  }

  void DrawGLScene (void)
  {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity(); 
    glTranslatef(0.0f, 0.0f, -10.0f);
  
    glBegin(GL_POINTS);

    for(unsigned int i=0; i<cloud.points.size(); i++) {
       unsigned char* rgb_ptr = (unsigned char*)&cloud.points[i].rgb;
       glColor3b( (*rgb_ptr), *(rgb_ptr+1), *(rgb_ptr+2) );
      glVertex3f(-cloud.points[i].x, -cloud.points[i].y, cloud.points[i].z);
    }
    // glColor3f(0.2, 0.2, 0.2);
    glEnd();
  
    if(GLWin.doubleBuffered) 
      glXSwapBuffers(GLWin.dpy, GLWin.win);    
  }

  /* function called when our window is resized (should only happen in window mode) */
  void resizeGLScene(unsigned int width, unsigned int height)
  {
    if (height == 0)    /* Prevent A Divide By Zero If The Window Is Too Small */
      height = 1;
    glViewport(0, 0, width, height);    /* Reset The Current Viewport And Perspective Transformation */
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0f, (GLfloat)width / (GLfloat)height, 0.1f, 100.0f);
    glMatrixMode(GL_MODELVIEW);
  }

  /* general OpenGL initialization function */
  int initGL(void)
  {
    glShadeModel(GL_SMOOTH);
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glClearDepth(1.0f);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
    /* we use resizeGLScene once to set up our initial perspective */
    resizeGLScene(GLWin.width, GLWin.height);
    glFlush();
    return True;
  }

  /* this function creates our window and sets it up properly */
  /* FIXME: bits is currently unused */
  bool createGLWindow(char* title, int width, int height, int bits, bool fullscreenflag)
  {
    XVisualInfo *vi;
    Colormap cmap;
    int dpyWidth, dpyHeight;
    int i;
    int glxMajorVersion, glxMinorVersion;
    int vidModeMajorVersion, vidModeMinorVersion;
    XF86VidModeModeInfo **modes;
    int modeNum;
    int bestMode;
    Atom wmDelete;
    Window winDummy;
    unsigned int borderDummy;
    
    GLWin.fs = fullscreenflag;
    /* set best mode to current */
    bestMode = 0;
    /* get a connection */
    GLWin.dpy = XOpenDisplay(0);
    GLWin.screen = DefaultScreen(GLWin.dpy);
    XF86VidModeQueryVersion(GLWin.dpy, &vidModeMajorVersion,
			    &vidModeMinorVersion);
    printf("XF86VidModeExtension-Version %d.%d\n", vidModeMajorVersion,
	   vidModeMinorVersion);
    XF86VidModeGetAllModeLines(GLWin.dpy, GLWin.screen, &modeNum, &modes);
    /* save desktop-resolution before switching modes */
    GLWin.deskMode = *modes[0];
    /* look for mode with requested resolution */
    for (i = 0; i < modeNum; i++) {
      if ((modes[i]->hdisplay == width) && (modes[i]->vdisplay == height))
	bestMode = i;
    }
    /* get an appropriate visual */
    vi = glXChooseVisual(GLWin.dpy, GLWin.screen, attrListDbl);
    if (vi == NULL) {
      vi = glXChooseVisual(GLWin.dpy, GLWin.screen, attrListSgl);
      GLWin.doubleBuffered = False;
      printf("Only Singlebuffered Visual!\n");
    }
    else {
      GLWin.doubleBuffered = True;
      printf("Got Doublebuffered Visual!\n");
    }
    glXQueryVersion(GLWin.dpy, &glxMajorVersion, &glxMinorVersion);
    printf("glX-Version %d.%d\n", glxMajorVersion, glxMinorVersion);
    /* create a GLX context */
    GLWin.ctx = glXCreateContext(GLWin.dpy, vi, 0, GL_TRUE);
    /* create a color map */
    cmap = XCreateColormap(GLWin.dpy, RootWindow(GLWin.dpy, vi->screen),
			   vi->visual, AllocNone);
    GLWin.attr.colormap = cmap;
    GLWin.attr.border_pixel = 0;
    
    if (GLWin.fs) {
      XF86VidModeSwitchToMode(GLWin.dpy, GLWin.screen, modes[bestMode]);
      XF86VidModeSetViewPort(GLWin.dpy, GLWin.screen, 0, 0);
      dpyWidth = modes[bestMode]->hdisplay;
      dpyHeight = modes[bestMode]->vdisplay;
      printf("Resolution %dx%d\n", dpyWidth, dpyHeight);
      XFree(modes);
      
      /* create a fullscreen window */
      GLWin.attr.override_redirect = True;
      GLWin.attr.event_mask = ExposureMask | KeyPressMask | ButtonPressMask |
	StructureNotifyMask;
      GLWin.win = XCreateWindow(GLWin.dpy, RootWindow(GLWin.dpy, vi->screen),
				0, 0, dpyWidth, dpyHeight, 0, vi->depth, InputOutput, vi->visual,
				CWBorderPixel | CWColormap | CWEventMask | CWOverrideRedirect,
				&GLWin.attr);
      XWarpPointer(GLWin.dpy, None, GLWin.win, 0, 0, 0, 0, 0, 0);
      XMapRaised(GLWin.dpy, GLWin.win);
      XGrabKeyboard(GLWin.dpy, GLWin.win, True, GrabModeAsync,
		    GrabModeAsync, CurrentTime);
      XGrabPointer(GLWin.dpy, GLWin.win, True, ButtonPressMask,
		   GrabModeAsync, GrabModeAsync, GLWin.win, None, CurrentTime);
    }
    else {
      /* create a window in window mode*/
      GLWin.attr.event_mask = ExposureMask | KeyPressMask | ButtonPressMask |
	StructureNotifyMask;
      GLWin.win = XCreateWindow(GLWin.dpy, RootWindow(GLWin.dpy, vi->screen),
				0, 0, width, height, 0, vi->depth, InputOutput, vi->visual,
				CWBorderPixel | CWColormap | CWEventMask, &GLWin.attr);
      /* only set window title and handle wm_delete_events if in windowed mode */
      wmDelete = XInternAtom(GLWin.dpy, "WM_DELETE_WINDOW", True);
      XSetWMProtocols(GLWin.dpy, GLWin.win, &wmDelete, 1);
      XSetStandardProperties(GLWin.dpy, GLWin.win, title,
			     title, None, NULL, 0, NULL);
      XMapRaised(GLWin.dpy, GLWin.win);
    }       
    /* connect the glx-context to the window */
    glXMakeCurrent(GLWin.dpy, GLWin.win, GLWin.ctx);
    XGetGeometry(GLWin.dpy, GLWin.win, &winDummy, &GLWin.x, &GLWin.y,
		 &GLWin.width, &GLWin.height, &borderDummy, &GLWin.depth);
    printf("Depth %d\n", GLWin.depth);
    if (glXIsDirect(GLWin.dpy, GLWin.ctx)) 
      printf("Direct Rendering enabled!\n");
    else
      printf("Direct Rendering not possible!\n");
    initGL();
    return True;    
  }

};

int main(int argc, char **argv) 
{
  ros::init(argc, argv, "pclViewer");
  PclViewer viewer(argc, argv);
  
  ros::Rate r(10); // 10 hz
  
  GLWin.fs = False; // Fulscreen Flag
  viewer.createGLWindow("Viewer", 640, 480, 24, GLWin.fs);
  
  //  pcl_visualization::CloudViewer pclviewer("Simple Cloud Viewer");
  while(1) {
    //    pclviewer.showCloud(cloud);
    ros::spinOnce();
    r.sleep();
  }
  return 0;
}
