/*
 * cloudGeometry
 *
 * Evan Herbst
 * 6 / 23 / 10
 */

#include "rgbd_util/eigen/QR" //eigensolving
#include "pcl_rgbd/cloudGeometry.h"
using std::vector;

namespace rgbd
{

rgbd::eigen::Vector3f centroid(const std::vector<rgbd::eigen::Vector3f>& pts)
{
	rgbd::eigen::Vector3f mean(0, 0, 0);
	for(unsigned int i = 0; i < pts.size(); i++) mean += pts[i];
	return mean / pts.size();
}

rgbd::eigen::Matrix3f covariance(const std::vector<rgbd::eigen::Vector3f>& pts)
{
	const rgbd::eigen::Vector3f mean = centroid(pts);

	rgbd::eigen::Matrix3f cov; //covariance
	cov.fill(0);

	/*
	 * compute below-diagonal entries
	 */
	for(unsigned int k = 0; k < pts.size(); k++)
	{
		for(unsigned int i = 0; i < 3; i++)
			for(unsigned int j = 0; j <= i; j++)
				cov(i, j) += pts[k][i] * pts[k][j];
	}
	for(unsigned int i = 0; i < 3; i++)
		for(unsigned int j = 0; j <= i; j++)
			cov(i, j) = cov(i, j) / pts.size() - mean[i] * mean[j];

	for(unsigned int i = 0; i < 3; i++) //copy to above-diagonal entries
		for(unsigned int j = i + 1; j < 3; j++)
			cov(i, j) = cov(j, i);

	return cov;
}

/*
 * return all eigenvectors of the covariance mtx, one per row
 */
template <typename PointT>
rgbd::eigen::Matrix3f eigenvectors(const vector<rgbd::eigen::Vector3f>& pts)
{
	const rgbd::eigen::Matrix3f cov = covariance(pts);
	rgbd::eigen::SelfAdjointEigenSolver<rgbd::eigen::Matrix3f> eigsolver(cov);
	const rgbd::eigen::Matrix3f eigvecs = eigsolver.eigenvectors(); //one per column
	return eigvecs.transpose();
}

} //namespace
