/*
 * cloudMarkers.cpp
 *
 *  Created on: Dec 9, 2010
 *      Author: peter
 */

#include <pcl_rgbd/cloudMarkers.h>

#include <rgbd_util/eigen/Geometry>
#include <xforms/xforms.h>

namespace rgbd {

void add_pose_to_marker_array(
		visualization_msgs::MarkerArray & all_poses_marker_array,
		const rgbd_msgs::Transform& transform_msg,
		int id,
		const std_msgs::ColorRGBA& sphere_color,
		float sphere_radius,
		float direction_line_width,
		float direction_line_length_x,
		float direction_line_length_y,
		float direction_line_length_z)
{
	// a sphere for the pose
	visualization_msgs::Marker pose_sphere_marker;
	pose_sphere_marker.ns = "camera_pose_sphere";
	pose_sphere_marker.id = id;
	pose_sphere_marker.header = transform_msg.header;
	pose_sphere_marker.type = visualization_msgs::Marker::SPHERE;
	pose_sphere_marker.color = sphere_color;
	// sphere
	pose_sphere_marker.scale.x = sphere_radius;
	pose_sphere_marker.scale.y = sphere_radius;
	pose_sphere_marker.scale.z = sphere_radius;
	// position
	pose_sphere_marker.pose.position.x = transform_msg.transform.translation.x;
	pose_sphere_marker.pose.position.y = transform_msg.transform.translation.y;
	pose_sphere_marker.pose.position.z = transform_msg.transform.translation.z;

	//visualization_marker_publisher.publish(pose_sphere_marker);
	all_poses_marker_array.markers.push_back(pose_sphere_marker);

	// a line for the direction
	visualization_msgs::Marker pose_direction_marker;
	pose_direction_marker.ns = "camera_pose_direction_line";
	pose_direction_marker.id = id;
	pose_direction_marker.header = transform_msg.header;
	pose_direction_marker.type = visualization_msgs::Marker::LINE_LIST;
	// color white
	pose_direction_marker.color.r = 1.0;
	pose_direction_marker.color.g = 1.0;
	pose_direction_marker.color.b = 1.0;
	pose_direction_marker.color.a = sphere_color.a;
	// line width
	pose_direction_marker.scale.x = direction_line_width;
	//pose_direction_marker.scale.y = 0.10; // ignored for LINE_LIST
	//pose_direction_marker.scale.z = 0.10; // ignored for LINE_LIST

	// use Eigen to manipulate pose direction
	rgbd::eigen::Affine3f eigen_transform;
	xf::convert_geometry_msg_to_eigen_transform(transform_msg.transform, eigen_transform);
	rgbd::eigen::Vector3f position_v = eigen_transform.translation();
	rgbd::eigen::Vector3f direction_x(1,0,0);
	rgbd::eigen::Vector3f direction_y(0,1,0);
	rgbd::eigen::Vector3f direction_z(0,0,1);

	pose_direction_marker.points.resize (6);

	rgbd::eigen::Vector3f direction_v;
	rgbd::eigen::Vector3f endpoint;

	direction_v = eigen_transform.linear() * direction_z;
	endpoint = position_v + direction_v * direction_line_length_z;
	pose_direction_marker.points[0].x = position_v.x();
	pose_direction_marker.points[0].y = position_v.y();
	pose_direction_marker.points[0].z = position_v.z();
	pose_direction_marker.points[1].x = endpoint.x();
	pose_direction_marker.points[1].y = endpoint.y();
	pose_direction_marker.points[1].z = endpoint.z();

	direction_v = eigen_transform.linear() * direction_x;
	endpoint = position_v + direction_v * direction_line_length_x;
	pose_direction_marker.points[2].x = position_v.x();
	pose_direction_marker.points[2].y = position_v.y();
	pose_direction_marker.points[2].z = position_v.z();
	pose_direction_marker.points[3].x = endpoint.x();
	pose_direction_marker.points[3].y = endpoint.y();
	pose_direction_marker.points[3].z = endpoint.z();

	direction_v = eigen_transform.linear() * direction_y;
	endpoint = position_v + direction_v * direction_line_length_y;
	pose_direction_marker.points[4].x = position_v.x();
	pose_direction_marker.points[4].y = position_v.y();
	pose_direction_marker.points[4].z = position_v.z();
	pose_direction_marker.points[5].x = endpoint.x();
	pose_direction_marker.points[5].y = endpoint.y();
	pose_direction_marker.points[5].z = endpoint.z();

	all_poses_marker_array.markers.push_back(pose_direction_marker);
}

visualization_msgs::Marker prepare_pose_edge_marker(
		const roslib::Header & header,
		float edge_width)
{
	visualization_msgs::Marker all_edges_marker;
	all_edges_marker.header = header;
	all_edges_marker.type = visualization_msgs::Marker::LINE_LIST;
	all_edges_marker.ns = "camera_edge";
	all_edges_marker.id = 0;
	all_edges_marker.scale.x = edge_width;
	all_edges_marker.color.a = 1.0; // ?
	return all_edges_marker;
}

void add_pose_edge_to_marker(
		visualization_msgs::Marker & all_edges_marker,
		const geometry_msgs::Transform& transform_msg_1,
		const geometry_msgs::Transform& transform_msg_2,
		const std_msgs::ColorRGBA& color)
{
	geometry_msgs::Point p;

	p.x = transform_msg_1.translation.x;
	p.y = transform_msg_1.translation.y;
	p.z = transform_msg_1.translation.z;

	all_edges_marker.points.push_back(p);
	all_edges_marker.colors.push_back(color);

	p.x = transform_msg_2.translation.x;
	p.y = transform_msg_2.translation.y;
	p.z = transform_msg_2.translation.z;

	all_edges_marker.points.push_back(p);
	all_edges_marker.colors.push_back(color);
}

} // ns
