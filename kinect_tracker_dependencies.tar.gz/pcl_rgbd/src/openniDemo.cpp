// Depth+Image Subscriber
// Author: Robert Chu (allegrormc@gmail.com)
//
// This code provides a simple demo of subscribing to the depth
// and image topics provided by the openni driver for primesense.
// This demo also demonstrates converting the recieved images to
// opencv2 images and displaying them.

#include <ros/ros.h>
#include <opencv2/core/core.hpp>
#include <opencv/highgui.h>
#include <cv_bridge/CvBridge.h>
#include <sensor_msgs/Image.h>
#include <message_filters/subscriber.h>

#define IMAGE "image"
#define DEPTH "depth"

// Globals
message_filters::Subscriber<sensor_msgs::Image> *image_sub;
message_filters::Subscriber<sensor_msgs::Image> *depth_sub;
sensor_msgs::CvBridge bridge;

// Image handler
void image_callback(const sensor_msgs::ImageConstPtr &image) {
    ROS_INFO_THROTTLE(1, "Recieved image");
    // Convert the image to a cvimage and display it
    IplImage* im = bridge.imgMsgToCv(image, "bgr8");
    cvShowImage(IMAGE, im);
}

// Depth handler
void depth_callback(const sensor_msgs::ImageConstPtr &depth) {
    ROS_INFO_THROTTLE(1, "Recieved depth");
    // Convert the depthmap to a cvimage and display it
    IplImage* de = bridge.imgMsgToCv(depth, "passthrough");
    cvShowImage(DEPTH, de);
}

int main(int argc, char **argv) {
    // Start the ROS system
    ros::init(argc, argv, "openniDemo");

    // Subscribe to the openni depth and image topics
    ros::NodeHandle nh;
    ros::Subscriber imageSub = nh.subscribe("/camera/rgb/image_color", 1, image_callback);
    ros::Subscriber depthSub = nh.subscribe("/camera/depth/image", 1, depth_callback);

    // Setup openCV and create two windows
    cvStartWindowThread();
    cvNamedWindow(IMAGE, 0);
    cvNamedWindow(DEPTH, 0);

    // Run the node
    ROS_INFO("Starting openniDemo");
    ros::spin();
    ROS_INFO("Stopping openniDemo");
}
