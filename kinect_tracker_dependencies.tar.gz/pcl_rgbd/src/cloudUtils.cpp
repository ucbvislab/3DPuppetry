/*
 * cloudUtils.cpp
 *
 *  Created on: 2010-06-22
 *      Author: phenry
 */

#include <iostream>
#include <iomanip>
#include <stdexcept>
#include <limits>
#include <sensor_msgs/point_cloud_conversion.h>
#include "pcl_rgbd/cloudUtils.h"
#include <cv_bridge/cv_bridge.h>

namespace rgbd
{
using std::cout;
using std::endl;

void convertVector3fToPoint32 (const rgbd::eigen::Vector3f & vector3f, geometry_msgs::Point32 & point32)
{
	point32.x = vector3f[0];
	point32.y = vector3f[1];
	point32.z = vector3f[2];
}

void convertPoint32ToVector3f (const geometry_msgs::Point32 & point32, rgbd::eigen::Vector3f & vector3f)
{
	vector3f[0] = point32.x;
	vector3f[1] = point32.y;
	vector3f[2] = point32.z;
}

void convertVector4fToROSPoint (const rgbd::eigen::Vector4f & vector4f, geometry_msgs::Point & ros_point)
{
	ros_point.x = vector4f[0];
	ros_point.y = vector4f[1];
	ros_point.z = vector4f[2];
}

void convertROSPointToVector4f (const geometry_msgs::Point & ros_point, rgbd::eigen::Vector4f & vector4f)
{
	vector4f[0] = ros_point.x;
	vector4f[1] = ros_point.y;
	vector4f[2] = ros_point.z;
	vector4f[3] = 1.0;
}

void convertVector4fToROSVector3 (const rgbd::eigen::Vector4f & vector4f, geometry_msgs::Vector3 & ros_vector)
{
	ros_vector.x = vector4f[0];
	ros_vector.y = vector4f[1];
	ros_vector.z = vector4f[2];
}

void convertROSVector3ToVector4f (const geometry_msgs::Vector3 & ros_vector, rgbd::eigen::Vector4f & vector4f)
{
	vector4f[0] = ros_vector.x;
	vector4f[1] = ros_vector.y;
	vector4f[2] = ros_vector.z;
	vector4f[3] = 0.0;
}


unsigned int datatypeByteCount(const int pointFieldTypeCode)
{
	switch(pointFieldTypeCode)
	{
		case sensor_msgs::PointField::INT8: return 1;
		case sensor_msgs::PointField::UINT8: return 1;
		case sensor_msgs::PointField::INT16: return 2;
		case sensor_msgs::PointField::UINT16: return 2;
		case sensor_msgs::PointField::INT32: return 4;
		case sensor_msgs::PointField::UINT32: return 4;
		case sensor_msgs::PointField::FLOAT32: return 4;
		case sensor_msgs::PointField::FLOAT64: return 8;
		default: throw std::invalid_argument("unknown datatype string");
	}
}

bool cloudHasField(const sensor_msgs::PointCloud2 &cloud2, std::string const& fieldName)
{
	for(unsigned int i=0; i<cloud2.fields.size(); i++)
		if(cloud2.fields[i].name == fieldName)
			return true;
	return false;
}

void packColorChannels(
		const std::string& r_name,
		const std::string& g_name,
		const std::string& b_name,
		const sensor_msgs::PointCloud2& src,
		sensor_msgs::PointCloud2& dest)
{
	dest.header = src.header;
	dest.width = src.width;
	dest.height = src.height;
	dest.is_bigendian = src.is_bigendian;
	dest.is_dense = src.is_dense;

    int r_idx = sensor_msgs::getPointCloud2FieldIndex (src, r_name);
    int g_idx = sensor_msgs::getPointCloud2FieldIndex (src, g_name);
    int b_idx = sensor_msgs::getPointCloud2FieldIndex (src, b_name);
    assert(r_idx >= 0 && g_idx >= 0 && b_idx >= 0);
    // Either all floats or all uchars
    uint8_t color_datatype;
    if (src.fields[r_idx].datatype == sensor_msgs::PointField::FLOAT32 &&
    		src.fields[g_idx].datatype == sensor_msgs::PointField::FLOAT32 &&
    		src.fields[b_idx].datatype == sensor_msgs::PointField::FLOAT32) {
    	color_datatype = sensor_msgs::PointField::FLOAT32;
    }
    else if (src.fields[r_idx].datatype == sensor_msgs::PointField::UINT8 &&
    		src.fields[g_idx].datatype == sensor_msgs::PointField::UINT8 &&
    		src.fields[b_idx].datatype == sensor_msgs::PointField::UINT8) {
    	color_datatype = sensor_msgs::PointField::UINT8;
    }
    else {
    	ROS_ERROR("Color types not recognized");
    	assert(false);
    }

    // copy all existing fields
    dest.fields = src.fields;

    // create a new field "rgb"
    sensor_msgs::PointField rgb_field;
    rgb_field.count = 1;
    rgb_field.datatype = sensor_msgs::PointField::FLOAT32;
    rgb_field.name = "rgb";
    rgb_field.offset = src.point_step;
	dest.fields.push_back(rgb_field);

	dest.point_step = src.point_step + sizeof(float);
	dest.row_step = dest.width * dest.point_step;
	dest.data.resize(dest.row_step * dest.height);

	const uint8_t *src_row_data, *src_point;
	uint8_t *dest_row_data, *dest_point;
	for (uint32_t row = 0; row < src.height; ++row) {
		src_row_data = &src.data[row * src.row_step];
		dest_row_data = &dest.data[row * dest.row_step];
		for (uint32_t col = 0; col < src.width; ++col) {
			src_point = src_row_data + col * src.point_step;
			dest_point = dest_row_data + col * dest.point_step;

			// copy the entire src point
			memcpy(dest_point, src_point, src.point_step);

			// and tack on the packed float
			float color_packed;
			if (color_datatype == sensor_msgs::PointField::FLOAT32) {
				// get the color
				float r = *reinterpret_cast<const float*>(src_point + src.fields[r_idx].offset);
				float g = *reinterpret_cast<const float*>(src_point + src.fields[g_idx].offset);
				float b = *reinterpret_cast<const float*>(src_point + src.fields[b_idx].offset);

				boost::array<float,3> color_array = {{r, g, b}};
				color_packed = packRGB(color_array);
			}
			else if (color_datatype == sensor_msgs::PointField::UINT8) {
				uint8_t r = *reinterpret_cast<const uint8_t*>(src_point + src.fields[r_idx].offset);
				uint8_t g = *reinterpret_cast<const uint8_t*>(src_point + src.fields[g_idx].offset);
				uint8_t b = *reinterpret_cast<const uint8_t*>(src_point + src.fields[b_idx].offset);

				boost::array<uint8_t, 3> color_array = {{r, g, b}};
				color_packed = packRGB(color_array);
			}
			else {
				assert(false && "Shouldn't get here");
			}

			memcpy(dest_point + rgb_field.offset, &color_packed, sizeof(float));
		}
	}
}

void renameFields(sensor_msgs::PointCloud2& cloud_msg, std::map<std::string, std::string> const& rename_map)
{
	for (size_t f = 0; f < cloud_msg.fields.size(); f++) {
		std::map<std::string, std::string>::const_iterator found_iter = rename_map.find(cloud_msg.fields[f].name);
		if (found_iter != rename_map.end()) {
			cloud_msg.fields[f].name = (*found_iter).second;
		}
	}
}

pcl::PointCloud<rgbd::pt> surfelsToPts(const pcl::PointCloud<rgbd::surfelPt>& surfels)
{
	pcl::PointCloud<rgbd::pt> outcloud;
	outcloud.points.resize(surfels.points.size());
	outcloud.width = outcloud.points.size();
	outcloud.height = 1;
	for(unsigned int i = 0; i < surfels.points.size(); i++)
	{
#define COPY(field) outcloud.points[i].field = surfels.points[i].field;
		COPY(x)
		COPY(y)
		COPY(z)
		COPY(rgb)
		COPY(normal[0])
		COPY(normal[1])
		COPY(normal[2])
#undef COPY
	}
	return outcloud;
}

rgbd_msgs::DepthMapPtr convertKinectDepthImageToDepthMap(const sensor_msgs::Image & depth_image, float focal_distance)
{
	rgbd_msgs::DepthMapPtr result = boost::make_shared<rgbd_msgs::DepthMap>();

	result->header = depth_image.header;
	result->no_sample_value = -1;
	result->shadow_value = -2;
	result->height = depth_image.height;
	result->width = depth_image.width;
	result->focal_distance = focal_distance;
	result->float_data.resize(result->width * result->height);

	cv_bridge::CvImagePtr cv_ptr = cv_bridge::toCvCopy(depth_image);

#if 0
	cout << "msg encoding: " << depth_image.encoding << endl;
	cout << "cv_ptr encoding: " << cv_ptr->encoding << endl;
	cout << "cv_ptr->image depth:" << cv_ptr->image.depth() << endl;
	cout << "CV_32F: " << CV_32F << endl;
	cout << "cv_ptr->image channels:" << cv_ptr->image.channels() << endl;
	cout << "rows: " << cv_ptr->image.rows << endl;
	cout << "cols: " << cv_ptr->image.cols << endl;
#endif

	for (int row = 0; row < cv_ptr->image.rows; row++) {
		for (int col = 0; col < cv_ptr->image.cols; col++) {
			float z = cv_ptr->image.at<float>(row, col);
			float& to_write = result->float_data[row * result->width + col];
			if (std::isnan(z)) {
				to_write = result->no_sample_value;
			}
			else {
				to_write = z;
			}
		}
	}

	return result;
}

sensor_msgs::ImagePtr convertDepthMapToKinectDepthImage(const rgbd_msgs::DepthMap & depth_map)
{
	if(depth_map.format != rgbd_msgs::DepthMap::format_raw) throw std::invalid_argument("depth map isn't raw");

	cv_bridge::CvImagePtr cv_image_ptr(new cv_bridge::CvImage);
	cv_image_ptr->header = depth_map.header;
	cv_image_ptr->encoding = sensor_msgs::image_encodings::TYPE_32FC1;
	cv_image_ptr->image = cv::Mat(depth_map.height, depth_map.width, CV_32FC1);

	for (int row = 0; row < depth_map.height; row++) {
		for (int col = 0; col < depth_map.width; col++) {
			float z = depth_map.float_data[row * depth_map.width + col];
			float to_write = std::numeric_limits<float>::quiet_NaN();
			if (z > 0) {
				to_write = z;
			}
			cv_image_ptr->image.at<float>(row, col) = to_write;
		}
	}

	return cv_image_ptr->toImageMsg();
}

pcl::PointCloud<pcl::PointXYZRGB>::Ptr convertKinectImageAndDepthImageToCloud(
		const sensor_msgs::Image & rgb_image,
		const sensor_msgs::Image & depth_image,
		rgbd::CameraParams & camera_params)
{
	pcl::PointCloud<pcl::PointXYZRGB>::Ptr result(new pcl::PointCloud<pcl::PointXYZRGB>);
	assert(rgb_image.width == depth_image.width);
	assert(rgb_image.height == depth_image.height);
	result->width = rgb_image.width;
	result->height = rgb_image.height;
	result->is_dense = false;
	result->points.resize(result->width * result->height);
	result->header = rgb_image.header;
	//result->sensor_origin_ = something
	//result->sensor_orientation_ = something

	cv_bridge::CvImagePtr cv_rgb_image_ptr = cv_bridge::toCvCopy(rgb_image, "bgr8");
	cv_bridge::CvImagePtr cv_depth_image_ptr = cv_bridge::toCvCopy(depth_image);

	unsigned int point_index = 0;
	for (unsigned int row = 0; row < result->height; ++row) {
		for (unsigned int col = 0; col < result->width; ++col, ++point_index) {
			pcl::PointXYZRGB & p = result->points[point_index];

			// assign color always
			const cv::Vec3b & color_vec = cv_rgb_image_ptr->image.at<cv::Vec3b>(row, col);
			p.rgb = rgbd::packRGB(color_vec[2], color_vec[1], color_vec[0]);

			// assign either nans or x,y,z
			const float & z = cv_depth_image_ptr->image.at<float>(row, col);
			if (std::isnan(z)) {
				p.x = p.y = p.z = z;
			}
			else {
				p.x = (((float)col - camera_params.centerX) * z / camera_params.focalLength);
				p.y = (((float)row - camera_params.centerY) * z / camera_params.focalLength);
				p.z = z;
			}
		}
	}

	return result;
}

} // ns
