/*
 * pclTransport: convert some form of depth map or cloud to an rgbd DepthMap
 * (there's also a node in pcl_ros that converts clouds to rgb imgs)
 */

#include <ros/ros.h>
#include <iostream>
#include <rgbd_msgs/DepthMap.h>
#include <rgbd_msgs/StringStream.h>
#include "pcl_rgbd/cloudUtils.h"
#include <zlib.h>
#include <pcl/io/pcd_io.h>
#include "rgbd_depthmaps/decompressDepth.h"
#include <image_transport/image_transport.h>
#include <std_msgs/String.h>
#include <sstream>

using std::cout;
using std::endl;

class PclTransporter {
  
public:
  
  std::string compressionMode;
  bool compressionDepth;
  int zlib_compr_mode;
  bool showStatistics;
  ros::Publisher out_dm_pub, out_cpdm_pub, out_pcl_compressed_pub, out_pcl_pub;  
  ros::Subscriber in_pcl2_sub, in_dm_sub, in_pcl_sub, in_pcl_compressed_sub;
  image_transport::Subscriber in_di_sub;
  rgbd_msgs::DepthMap out_dm_msg,  out_cpdm_msg;
  int subscription_buffer_size;

  // CONSTRUCTOR
  
  PclTransporter() 
  {   
    ros::NodeHandle nh;
    ros::NodeHandle local_nh("~");
    image_transport::ImageTransport it(nh);

    std::string in_pcl_topic = nh.resolveName("in_pcl_to_compress");
    std::string in_pcl_compressed_topic = nh.resolveName("in_pcl_to_decompress");
    
    std::string in_pcl2_topic = nh.resolveName("input_pointcloud2");
    std::string in_dm_topic = nh.resolveName("input_depthmap");
    std::string in_di_topic = nh.resolveName("input_depth_image");
    
    std::string out_dm_topic = nh.resolveName("output_depthmap");
    std::string out_cpdm_topic = nh.resolveName("output_compressed_depthmap");

    // Does this work?
    if((in_pcl2_topic == "/in" && in_dm_topic == "/in" && in_di_topic == "/in") || out_dm_topic == "/out") {
      ROS_WARN("pclTransport: either the in or out topic (or both) has not been remapped.");
    }
    
    local_nh.param("compress_depth", compressionDepth, false);
    local_nh.param("compression_mode", compressionMode, std::string("default"));
    local_nh.param("subscription_buffer_size", subscription_buffer_size, 1);
    local_nh.param("display_compression_statistics", showStatistics, true);
    
    if(compressionMode == "fastest") {
      zlib_compr_mode = Z_BEST_SPEED;
    } else if (compressionMode == "smallest") {
      zlib_compr_mode = Z_BEST_COMPRESSION;
    } else {
      zlib_compr_mode = Z_DEFAULT_COMPRESSION;
    }

    in_pcl2_sub  = nh.subscribe(in_pcl2_topic, subscription_buffer_size, &PclTransporter::callback_pcl2, this);
    in_dm_sub    = nh.subscribe(in_dm_topic, subscription_buffer_size, &PclTransporter::callback_dm, this);
    in_di_sub	 = it.subscribe(in_di_topic, subscription_buffer_size, &PclTransporter::callback_di, this);

    out_dm_pub   = nh.advertise<rgbd_msgs::DepthMap>(out_dm_topic, 1);
    out_cpdm_pub = nh.advertise<rgbd_msgs::DepthMap>(out_cpdm_topic, 1);
  }

  // Converts a PointCloud2 to DepthMap and then compresses the DepthMap with zlib
  void callback_pcl2(const sensor_msgs::PointCloud2::ConstPtr& in_msg)
  {
    pcl::PointCloud<pcl::PointXYZ> point_cloud;

    pcl::fromROSMsg(*in_msg, point_cloud);

    out_dm_msg = *rgbd::convertKinectCloudToDepthMap<pcl::PointXYZ>(point_cloud);
    
    if (out_dm_pub.getNumSubscribers() > 0) {
    	out_dm_pub.publish(out_dm_msg);
    }

    if (out_cpdm_pub.getNumSubscribers() > 0) {
    	rgbd::compressDepthMap(out_dm_msg, out_cpdm_msg);
    	out_cpdm_pub.publish(out_cpdm_msg);
    }
  }
  
  // Compresses or Decompresses a DepthMap
  void callback_dm(const rgbd_msgs::DepthMap::ConstPtr& in_msg)
  {
    if(compressionDepth)
      out_dm_msg.format = rgbd_msgs::DepthMap::format_zlib;
    else
      out_dm_msg.format = rgbd_msgs::DepthMap::format_raw;
    
    if(out_dm_msg.format == in_msg->format) {
      out_dm_pub.publish(in_msg);
      return;
    }
    
    if(in_msg->format == rgbd_msgs::DepthMap::format_zlib && out_dm_msg.format == rgbd_msgs::DepthMap::format_raw) {
      rgbd::decompressDepthMap(*in_msg, out_dm_msg);
      out_dm_pub.publish(out_dm_msg);
    }
    else {
      if(in_msg->format == rgbd_msgs::DepthMap::format_raw && out_cpdm_msg.format == rgbd_msgs::DepthMap::format_zlib) {
	rgbd::compressDepthMap(*in_msg, out_cpdm_msg);
	out_cpdm_pub.publish(out_cpdm_msg);
      }
    }
  }

  // Subscribe to depth image and publish compressed and/or uncompressed depth maps (depending on subscribers)
  void callback_di(const sensor_msgs::ImageConstPtr& in_msg)
  {
    out_dm_msg = *rgbd::convertKinectDepthImageToDepthMap(*in_msg);

    if (out_dm_pub.getNumSubscribers() > 0) {
    	out_dm_pub.publish(out_dm_msg);
    }

    if (out_cpdm_pub.getNumSubscribers() > 0) {
    	rgbd::compressDepthMap(out_dm_msg, out_cpdm_msg);
    	out_cpdm_pub.publish(out_cpdm_msg);
    }
  }
  
};
  

int main(int argc, char **argv) {
  ros::init(argc, argv, "pclTransport");
  PclTransporter transporter;
  
  ros::spin();
  
  return 0;
}
