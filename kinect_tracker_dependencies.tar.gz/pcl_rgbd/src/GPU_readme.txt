

You now have the option to have the normals computation in cloudNormals::setOrganizedNormals done on
the GPU.

To do this, you need the following:

	- a GPU-capable graphics card
	- the Nvidia OpenCL/Cuda drivers
	- the NVidia OpenCL/Cuda SDK
	- to set the right flag in icp combined node's parameters.

The Nvidia downloads are here: http://developer.nvidia.com/object/cuda_3_1_downloads.html#Linux

It's a little convoluted to figure out what you need to install to get going with OpenCL.
Here's the general outline:
	- download and install the developer driver. You'll need to kill the X server and run the
	installer as super user to do this.
	- download and install something labelled "GPU Computing SDK code samples" but which is actually
	the CUDA/OpenCL SDK.  

Once you install the SDK, take a look at:
	 <NVIDIA_GPU_Computing_SDK install folder>/OpenCL/doc/NVIDIA_OpenCL_GettingStartedLinux.pdf

Note #1: the Getting Started guide mentions various installer file names, all of which I found
to be completely different in reality.

Note #2: the Getting Started guide says that gcc up to version 4.2 is supported, but I haven't had
any trouble using gcc-4.4.

Once you get the SDK installed, I'd recommend compiling the SDK code samples and runniing some
of them just to make sure that your hardware can talk to your driver and that your driver
can talk to known sane code.

I had success with the Linux 32-bit version 256.40 of the driver and the Ubuntu 9.10 32-bit version
3.1 of the SDK, using a GeForce 9800 GT card.

	***Caution: not all CUDA driver versions include the OpenCL libraries that you need.*** 

The CMake find OpenCL package looks for the NVidia headers and library in their default
locations. If you put them some where else, you'll have to edit the FindOPENCL.cmake file.

Once you have all this set up, you'll need to add this parameter to your 
icp_combined_node_params_<whoami>.yaml file to turn on GPU processing:

	use_gpu_for_normals: true

If the CMake file can't find the OpenCL libraries and header files, or if the use_GPU_for_normals
parameter is missing or set to false, then the code will use the CPU implementation. Likewise,
if the system is configured for GPU usage but the computation fails for some reason, the code
will fallback to the CPU computation.

If you have been successful, when you run main_ns_icp_alignment.launch, you will see messages
at the beginning that look like this:

^[[0m[ INFO] [1280872393.545336756]: cloudNormals: opencl enabled: about to computeOrganizedPointCloudNormals^[[0m
^[[0m[ INFO] [1280872393.545573429]: GPUcomputeOrganizedPointCloudNormals: point size: 307200 downsample: 1 k: 3 max_z: 0.100000^[[0m
^[[0m[ INFO] [1280872393.575701633]: we have 1 platform(s)
^[[0m
^[[0m[ INFO] [1280872393.575829090]: platform id: 0 vendor:NVIDIA Corporation profile: FULL_PROFILE version:OpenCL 1.0 CUDA 3.1.1^[[0m
^[[0m[ INFO] [1280872393.575932565]: Connecting to NVIDIA Corporation GeForce 9800 GT...
^[[0m
^[[0m[ INFO] [1280872393.622900555]: Loading program 'normals.cl'
^[[0m
^[[0m[ INFO] [1280872393.622996330]: Loading program '/home/pollyp/pcl_branch/rgbd-ros-pkg/icp_mapping/../pcl_rgbd/src/normals.cl'
^[[0m
^[[0m[ INFO] [1280872393.637027534]: working directory = /home/pollyp/.ros^[[0m
^[[0m[ INFO] [1280872393.637125312]: about to compile compute_normals
^[[0m
^[[0m[ INFO] [1280872394.879878387]: created kernel for compute_normals
^[[0m
time to polly: organized normals (kernel wrapper): 1.40852s
time to set organized normals: 1.42406s
time to compute 2-d normals: 1.4838s

The first run always takes a long time because it's compiling the OpenCL code. After this initial run,
you'll see messages like this:

^[[0m[ INFO] [1280872396.954347745]: cloudNormals: opencl enabled: about to computeOrganizedPointCloudNormals^[[0m
^[[0m[ INFO] [1280872396.954508113]: GPUcomputeOrganizedPointCloudNormals: point size: 307200 downsample: 1 k: 3 max_z: 0.100000^[[0m
time to polly: organized normals (kernel wrapper): 0.0830137s
time to set organized normals: 0.0988127s
time to compute 2-d normals: 0.15991s

Questions? See Polly Powledge, pauline.s.powledge@intel.com





