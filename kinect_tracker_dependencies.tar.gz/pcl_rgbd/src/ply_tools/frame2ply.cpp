/*
 * frame2ply: write a ply for an rgbd frame
 *
 * Evan Herbst
 * 3 / 13 / 12
 */

#include <cassert>
#include <boost/filesystem.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <cv_bridge/cv_bridge.h>
#include "rgbd_util/primesensorUtils.h"
#include "rgbd_depthmaps/depthIO.h"
#include "pcl_rgbd/pointTypes.h"
#include "pcl_rgbd/depth_to_cloud_lib.h"
#include "pcl_rgbd/cloudNormals.h"
#include "pcl_rgbd/cloudTofroPLY.h"
namespace fs = boost::filesystem;

/*
 * arguments: img path, depthmap path, ply path
 */
int main(int argc, char* argv[])
{
	assert(argc == 4);
	const fs::path imgpath = argv[1], depthpath = argv[2], plypath = argv[3],
		outdir = plypath.parent_path();
	fs::create_directories(outdir);
	cv_bridge::CvImage ciMsg;
	ciMsg.encoding = "bgr8";
	ciMsg.image = cv::imread(imgpath.string());
	rgbd_msgs::DepthMap depth;
	rgbd::readDepthMap(depthpath, depth);
	const sensor_msgs::ImagePtr imgMsg = ciMsg.toImageMsg();
	const rgbd::CameraParams camParams = primesensor::getColorCamParams(rgbd::KINECT_640_DEFAULT);
	pcl::PointCloud<rgbd::pt> organizedCloud;
	image_and_depth_to_cloud(*imgMsg, depth, true, true, organizedCloud, camParams);
	boost::multi_array<bool, 2> validityGrid;
	rgbd::getValidityGrid(organizedCloud, validityGrid);
	rgbd::setOrganizedNormals(organizedCloud, validityGrid, 4, 2, .05);
	pcl::PointCloud<rgbd::pt> cloud;
	rgbd::organized2unorganizedCloud(organizedCloud, validityGrid, cloud);
	rgbd::write_ply_file(cloud, plypath);
	return 0;
}
