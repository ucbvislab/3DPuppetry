/*
 * combineCloudsWithTransforms: merge clouds into a single cloud, with a transform for each
 *
 * Evan Herbst
 * 9 / 17 / 10
 */

#include <cassert>
#include <boost/lexical_cast.hpp>
#include "xforms/xforms.h"
#include "pcl_rgbd/cloudUtils.h"
#include "pcl_rgbd/cloudTofroPLY.h"
using boost::lexical_cast;
using rgbd::eigen::Affine3f;
namespace fs = boost::filesystem;

/*
 * arguments: [plyfile xformstring]+, whether clouds are surfels, outply filepath
 */
int main(int argc, char* argv[])
{
	assert(argc % 2 == 1);
	const bool surfels = lexical_cast<bool>(argv[argc - 2]);
	const fs::path outplypath(argv[argc - 1]);
	if(surfels)
	{
		pcl::PointCloud<rgbd::surfelPt> combinedCloud;
		for(unsigned int i = 1; i < argc - 2; i += 2)
		{
			pcl::PointCloud<rgbd::surfelPt>::Ptr cloudPtr = rgbd::readRGBDPLY<rgbd::surfelPt>(argv[i]);
			const Affine3f xform = xf::parseTransformString(argv[i + 1]);
			rgbd::transform_point_cloud_in_place(xform, *cloudPtr, true/* normals */);
			rgbd::mergeInPlace(*cloudPtr, combinedCloud);
		}
		rgbd::write_ply_file(combinedCloud, outplypath);
	}
	else
	{
		pcl::PointCloud<rgbd::pt> combinedCloud;
		for(unsigned int i = 1; i < argc - 2; i += 2)
		{
			pcl::PointCloud<rgbd::pt>::Ptr cloudPtr = rgbd::readRGBDPLY<rgbd::pt>(argv[i]);
			const Affine3f xform = xf::parseTransformString(argv[i + 1]);
			rgbd::transform_point_cloud_in_place(xform, *cloudPtr, true/* normals */);
			rgbd::mergeInPlace(*cloudPtr, combinedCloud);
		}
		rgbd::write_ply_file(combinedCloud, outplypath);
	}
	return 0;
}
