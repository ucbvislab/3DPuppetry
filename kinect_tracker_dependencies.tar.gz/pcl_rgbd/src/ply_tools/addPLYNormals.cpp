/*
 * addPLYNormals: add normals to an existing ply file
 *
 * Evan Herbst
 * 5 / 1 / 12
 */

#include <cassert>
#include <boost/filesystem.hpp>
#include "pcl_rgbd/cloudNormals.h"
#include "pcl_rgbd/cloudTofroPLY.h"
namespace fs = boost::filesystem;

/*
 * arguments: input plypath[, output plypath (default is same)]
 */
int main(int argc, char* argv[])
{
	assert(argc == 2 || argc == 3);
	const fs::path inplypath = argv[1];
	pcl::PointCloud<rgbd::pt> cloud;
	sensor_msgs::PointCloud2 cloud2, cloud3;
	rgbd::read_ply_file(cloud2, inplypath);
	rgbd::packColorChannels("diffuse_red", "diffuse_green", "diffuse_blue", cloud2, cloud3);
	pcl::fromROSMsg(cloud3, cloud);

	geometry_msgs::Point32 viewpoint;
	viewpoint.x = viewpoint.y = viewpoint.z = 0;
	rgbd::computePointCloudNormals(cloud, 100/* # nbrs */, viewpoint);

	const fs::path outplypath = (argc == 3) ? fs::path(argv[2]) : inplypath;
	fs::create_directories(outplypath.parent_path());
	rgbd::write_ply_file(cloud, outplypath);

	return 0;
}
