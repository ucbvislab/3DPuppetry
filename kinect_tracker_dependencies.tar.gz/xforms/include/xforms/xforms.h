/*
 * xforms: functions on transformations, using various datatypes
 *
 * Evan Herbst
 * 2 / 24 / 10
 */

#ifndef EX_XFORMS_H
#define EX_XFORMS_H

#include <vector>
#include <string>
#include <iostream>
#include <utility> //pair
#include <boost/filesystem/path.hpp>
#include "rgbd_util/eigen/Core"
#include "rgbd_util/eigen/Geometry"
#include <geometry_msgs/Transform.h>

namespace xf
{
namespace fs = boost::filesystem;

/*
 * not marked 'experimental' like Eigen inverse(), but less accurate
 */
template <typename Real>
rgbd::eigen::Transform<Real,3,rgbd::eigen::Affine>
invertTransform(rgbd::eigen::Transform<Real,3,rgbd::eigen::Affine> const& T);

/*
 * print in 7-parameter form
 */
std::string convert_eigen_transform_to_string(rgbd::eigen::Affine3f const& t);
rgbd::eigen::Affine3f convert_string_to_eigen_transform(std::string transform_string);
/*
 * print in 4-x-4-matrix form (row-major order)
 */
std::string printXformAsMtx(const rgbd::eigen::Affine3f& xform);
rgbd::eigen::Affine3f readXformMtx(std::istream& in);
/*
 * 7-param form, human-readable for debugging
 */
std::string getTransformString(rgbd::eigen::Affine3f const& transform);

/*
 * allow any of the following:
 * - constant string "I" for identity
 * - seven-param whitespace-separated (as output by convert_eigen_transform_to_string())
 * - sixteen-param whitespace-separated (row-major matrix)
 */
rgbd::eigen::Affine3f parseTransformString(const std::string& s);

/*
 * these are for the new LM optimization
 */
void convertTransformToSTDVector(rgbd::eigen::Affine3f const& t, std::vector<float>& v);
void convertSTDVectorToTransform(std::vector<float> const& v, rgbd::eigen::Affine3f& t);

/*
 * vector order: qw, qx, qy, qz, tx, ty, tz
 */
template <typename Real>
rgbd::eigen::Matrix<Real,7,1> convertTransformToVector(rgbd::eigen::Transform<Real,3,rgbd::eigen::Affine> const& t);
template <typename Real>
rgbd::eigen::Transform<Real,3,rgbd::eigen::Affine> convertVectorToTransform(rgbd::eigen::Matrix<Real,7,1> const& v);
template <typename Real>
rgbd::eigen::Quaternion<Real> getQuaternionPart(rgbd::eigen::Matrix<Real,7,1> const& v);

void convert_eigen_transform_to_geometry_msg(rgbd::eigen::Affine3f const& eigen_transform, geometry_msgs::Transform & ros_transform);
void convert_geometry_msg_to_eigen_transform(geometry_msgs::Transform const& ros_transform, rgbd::eigen::Affine3f & eigen_transform);
geometry_msgs::Transform eigen2geomsg(rgbd::eigen::Affine3f const& eigen_transform);
rgbd::eigen::Affine3f geomsg2eigen(geometry_msgs::Transform const& ros_transform);

/*
 * read/write text-format xforms
 *
 * throw on error
 */
void read_geometry_msgs_from_file(std::string filename, std::vector<std::pair<ros::Time, geometry_msgs::Transform> >& result_vector);
std::vector<std::pair<ros::Time, geometry_msgs::Transform> > readTransformsTextFile(const fs::path& filepath);
void read_geometry_msgs_from_mit_file(std::string filename, std::vector<std::pair<ros::Time, geometry_msgs::Transform> >& result_vector);
void write_geometry_msgs_to_file(std::string filename, const std::vector<std::pair<ros::Time, geometry_msgs::Transform> >& output_vector);
void write_geometry_msgs_to_file(std::string filename, const std::map<ros::Time, geometry_msgs::Transform>& xforms);

/*
 * standardized format
 */
std::string convert_geometry_msg_to_string(geometry_msgs::Transform const& t);
geometry_msgs::Transform convert_string_to_geometry_msg(std::string const& transform_string);

/*
 * Get the translational and angular distance (in meters and radians) between two transforms
 */
void transform_difference(const rgbd::eigen::Affine3f& t1, const rgbd::eigen::Affine3f& t2, float& translation_delta, float& rotation_delta);

/*
 * return the T such that T^n = x
 *
 * pre: n > 0
 */
rgbd::eigen::Affine3f nthRoot(const rgbd::eigen::Affine3f& x, const unsigned int n);

#ifdef UNUSED
/*
 * binary files to preserve bits, which our text format doesn't
 */
std::vector<std::pair<ros::Time, geometry_msgs::Transform> > readXformsBinaryFile(const std::string& filepath);
void writeXformsBinaryFile(const std::string& filepath, const std::vector<std::pair<ros::Time, geometry_msgs::Transform> >& xforms);
#endif

} //namespace

/*
 * standardized format
 */
std::istream& operator >> (std::istream& in, geometry_msgs::Transform& t);
std::ostream& operator << (std::ostream& out, const geometry_msgs::Transform& t);

#include "xforms/xforms.ipp"

#endif //EX_XFORMS_H
