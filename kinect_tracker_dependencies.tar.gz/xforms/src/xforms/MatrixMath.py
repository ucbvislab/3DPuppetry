'''
Created on Nov 30, 2009

@author: Peter
'''
from numpy import array, eye, linalg
from math import cos, sin, sqrt
import math
def getZRotationMatrix(angleZ):
    """Returns a rotation matrix around the Z-Axis by angleZ degrees"""
    angle = angleZ * math.pi / 180
    return array([[cos(angle), sin(angle), 0],
                  [-sin(angle), cos(angle), 0],
                  [0, 0, 1]])

def getXRotationMatrix(angleX):
    angle = angleX * math.pi / 180
    return array([[1, 0, 0],
                  [0, cos(angle), sin(angle)],
                  [0, -sin(angle), cos(angle)]])

def getYRotationMatrix(angleY):
    angle = angleY * math.pi / 180
    return array([[cos(angle), 0, -sin(angle)],
                  [0, 1, 0],
                  [sin(angle), 0, cos(angle)]])

def getTrMatrix(tr):
    t = eye(4)
    t[:3, 3] = tr
    return t

def getAxisRotationMatrix(axis, angle):
    c = cos(angle)
    s = sin(angle)
    t = 1 - c
    X = axis[0]
    Y = axis[1]
    Z = axis[2]
    matx = array([[t * X * X + c, t * X * Y + s * Z, t * X * Z - s * Y, 0],
                  [t * X * Y - s * Z, t * Y * Y + c, t * Y * Z + s * X, 0],
                  [t * X * Z + s * Y, t * Y * Z - s * X, t * Z * Z + c, 0],
                  [0, 0, 0, 1]])
    return matx

def unitV(vector):
    normVal = linalg.norm(vector)
    if normVal - 1 < 1e-6:
        return vector
    return vector / normVal

def rpyFromRotMatrix(rotMatrix):

    yaw = math.atan2(rotMatrix[2][1], rotMatrix[2][2])   # rotate about x0
    pitch = math.atan2(-rotMatrix[2][0], sqrt(1.00001 - rotMatrix[2][0] * rotMatrix[2][0])) # rotate about y0
    roll = math.atan2(rotMatrix[1][0], rotMatrix[0][0]) # rotate about z0

    #print "yaw ", yaw * 180/pi
    #print "pitch a ", pitch * 180/pi
    #print "roll a ", roll * 180/pi
    #print
    return array([roll, pitch, yaw])


def rotMatrixFromRpy(rollRad, pitchRad, yawRad):

    cr = cos(rollRad)
    sr = sin(rollRad)
    cp = cos(pitchRad)
    sp = sin(pitchRad)
    cy = cos(yawRad)
    sy = sin(yawRad)

    R00 = cr * cp
    R01 = -sr * cy + cr * sp * sy
    R02 = sr * sy + cr * sp * cy

    R10 = sr * cp
    R11 = cr * cy + sr * sp * sy
    R12 = -cr * sy + sr * sp * cy

    R20 = -sp
    R21 = cp * sy
    R22 = cp * cy

    return array([[R00, R01, R02], [R10, R11, R12], [R20, R21, R22]])

def rotMatrixFromQuaternionMsg(q):
    matx = array([[0.,0.,0.],
                  [0.,0.,0.],
                  [0.,0.,0.]])
    a = q.w
    b = q.x
    c = q.y
    d = q.z
    matx[0,0] = a*a+b*b-c*c-d*d
    matx[0,1] = 2*b*c-2*a*d
    matx[0,2] = 2*b*d+2*a*c
    matx[1,0] = 2*b*c+2*a*d
    matx[1,1] = a*a-b*b+c*c-d*d
    matx[1,2] = 2*c*d-2*a*b
    matx[2,0] = 2*b*d-2*a*c
    matx[2,1] = 2*c*d+2*a*b
    matx[2,2] = a*a-b*b-c*c+d*d
    return matx

def quaternionFromRotMatrix(rotMatrix):
    rpy = rpyFromRotMatrix(rotMatrix)
    rollRad = rpy[0]
    pitchRad = rpy[1]
    yawRad = rpy[2]
    cr2 = cos(rollRad/2)
    sr2 = sin(rollRad/2)
    cp2 = cos(pitchRad/2)
    sp2 = sin(pitchRad/2)
    cy2 = cos(yawRad/2)
    sy2 = sin(yawRad/2)
    
    w = cy2*cp2*cr2+sy2*sp2*sr2
    x = sy2*cp2*cr2-cy2*sp2*sr2
    y = cy2*sp2*cr2+sy2*cp2*sr2
    z = cy2*cp2*sr2-sy2*sp2*cr2
    
    q = array([w,x,y,z])
    q = q/linalg.norm(q)
    return q
    
