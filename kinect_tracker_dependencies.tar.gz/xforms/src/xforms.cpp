/*
 * xforms: functions on transformations, using various datatypes
 *
 * Evan Herbst
 * 2 / 24 / 10
 */

#include <vector>
#include <iomanip> //setprecision
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <boost/lexical_cast.hpp>
#include "rgbd_util/ros_utility.h" //convert string <-> timestamp
#include <tf/transform_datatypes.h>
#include "xforms/xforms.h"
using std::vector;
using std::string;
using std::ifstream;
using std::ofstream;
using std::istringstream;
using std::ostringstream;
using std::cout;
using std::endl;
using std::runtime_error;
using boost::lexical_cast;
using rgbd::eigen::Matrix;
using rgbd::eigen::Matrix3f;
using rgbd::eigen::Vector3f;
using rgbd::eigen::Affine3f;
using rgbd::eigen::Quaternionf;
using rgbd::eigen::Translation3f;

namespace xf
{

void transform_difference(const rgbd::eigen::Affine3f& t1, const rgbd::eigen::Affine3f& t2, float& translation_delta, float& rotation_delta)
{
	Vector3f trans_1 = t1.translation();
	Vector3f trans_2 = t2.translation();
	Quaternionf rot_1(t1.linear());
	Quaternionf rot_2(t2.linear());

	translation_delta = (trans_1 - trans_2).norm();
	rotation_delta = rot_1.angularDistance(rot_2);
}

/*
 * return the T such that T^n = x
 *
 * pre: n > 0
 */
rgbd::eigen::Affine3f nthRoot(const rgbd::eigen::Affine3f& x, const unsigned int n)
{
	assert(n > 0);
	const Matrix3f R = x.linear();
	const Vector3f t = x.translation();
	const Quaternionf dq = Quaternionf::Identity().slerp(1.0 / n, Quaternionf(R));
	const Matrix3f dR(dq);
	Matrix3f D = Matrix3f::Identity();
	for(unsigned int j = 0; j < n - 1; j++) D = dR * D + Matrix3f::Identity();
	const Vector3f d = D.inverse() * t;
	return Translation3f(d) * dR;
}

/*
 * print in 7-parameter form
 */
std::string convert_eigen_transform_to_string(rgbd::eigen::Affine3f const& t)
{
	std::stringstream ss;
	ss.precision(10);
	rgbd::eigen::Matrix<float,7,1> vector_form = convertTransformToVector(t);
	for (int i = 0; i < 7; i++) {
		ss << vector_form[i] << " ";
	}

	return ss.str();
}
rgbd::eigen::Affine3f convert_string_to_eigen_transform(std::string transform_string)
{
	Matrix<float,7,1> vector_form;
	std::stringstream ss(transform_string);
	for (int i = 0; i < 7; i++) {
		ss >> vector_form[i];
	}

	Affine3f transform = convertVectorToTransform(vector_form);

	return transform;
}

/*
 * print in 4-x-4-matrix form (row-major order)
 */
string printXformAsMtx(const Affine3f& xform)
{
	ostringstream outstr;
	outstr << std::setprecision(10);
	for(unsigned int i = 0; i < 4; i++)
		for(unsigned int j = 0; j < 4; j++)
			outstr << xform(i, j) << ' ';
	return outstr.str();
}
rgbd::eigen::Affine3f readXformMtx(std::istream& in)
{
	Affine3f xform;
	for(unsigned int i = 0; i < 4; i++)
		for(unsigned int j = 0; j < 4; j++)
			in >> xform(i, j);
	return xform;
}

/*
 * 7-param form, easy to read for debugging
 */
std::string getTransformString(rgbd::eigen::Affine3f const& transform)
{
	Matrix<float,7,1> vector = convertTransformToVector(transform);
	std::stringstream stream;
	stream<<"Quaternion: "<<vector(0)<<", "<<vector(1)<<", "<<vector(2)<<", "<<vector(3)<<std::endl;
	stream<<"Translation: "<<vector(4)<<", "<<vector(5)<<", "<<vector(6);

	return stream.str();
}

/*
 * allow any of the following:
 * - constant string "I" for identity
 * - seven-param whitespace-separated (as output by convert_eigen_transform_to_string())
 * - sixteen-param whitespace-separated (row-major matrix)
 */
rgbd::eigen::Affine3f parseTransformString(const std::string& s)
{
	Affine3f xform;
	if(s == "I") xform.setIdentity();
	else
	{
		vector<string> tokens;
		istringstream instr(s);
		string t;
		while(instr >> t) tokens.push_back(t);
		if(tokens.size() == 7) xf::convert_geometry_msg_to_eigen_transform(xf::convert_string_to_geometry_msg(s), xform);
		else if(tokens.size() == 16)
		{
			for(unsigned int j = 0; j < 4; j++)
				for(unsigned int k = 0; k < 4; k++)
					xform(j, k) = lexical_cast<float>(tokens[j * 4 + k]);
		}
		else throw std::runtime_error("can't parse string into transform");
	}
	return xform;
}

/*
 * these are for the new LM optimization
 */
void convertTransformToSTDVector(rgbd::eigen::Affine3f const& t, std::vector<float>& v)
{
	v.resize(7);
	Matrix<float,7,1> eigen_matrix = convertTransformToVector(t);
	for (unsigned int i = 0; i < 7; i++) {
		v[i] = eigen_matrix[i];
	}
}
void convertSTDVectorToTransform(std::vector<float> const& v, rgbd::eigen::Affine3f& t)
{
	Matrix<float,7,1> eigen_matrix;
	for (unsigned int i = 0; i < 7; i++) {
		eigen_matrix[i] = v[i];
	}
	t = convertVectorToTransform(eigen_matrix);
}


void convert_eigen_transform_to_geometry_msg(rgbd::eigen::Affine3f const& eigen_transform, geometry_msgs::Transform & ros_transform)
{
	Quaternionf q(eigen_transform.linear());
	Vector3f t = eigen_transform.translation();

	ros_transform.rotation.w = q.w();
	ros_transform.rotation.x = q.x();
	ros_transform.rotation.y = q.y();
	ros_transform.rotation.z = q.z();
	ros_transform.translation.x = t.x();
	ros_transform.translation.y = t.y();
	ros_transform.translation.z = t.z();
}
void convert_geometry_msg_to_eigen_transform(geometry_msgs::Transform const& ros_transform, rgbd::eigen::Affine3f & eigen_transform)
{
	Quaternionf q(ros_transform.rotation.w,
			ros_transform.rotation.x,
			ros_transform.rotation.y,
			ros_transform.rotation.z);
	Vector3f t(ros_transform.translation.x,
			ros_transform.translation.y,
			ros_transform.translation.z);

	eigen_transform = Affine3f(q.normalized().toRotationMatrix());
	eigen_transform.pretranslate(t);
}
geometry_msgs::Transform eigen2geomsg(rgbd::eigen::Affine3f const& eigen_transform)
{
	geometry_msgs::Transform result;
	convert_eigen_transform_to_geometry_msg(eigen_transform, result);
	return result;
}
rgbd::eigen::Affine3f geomsg2eigen(geometry_msgs::Transform const& ros_transform)
{
	rgbd::eigen::Affine3f result;
	convert_geometry_msg_to_eigen_transform(ros_transform, result);
	return result;
}

std::string convert_geometry_msg_to_string(geometry_msgs::Transform const& t)
{
	std::stringstream ss;
	ss << t;
	return ss.str();
}
geometry_msgs::Transform convert_string_to_geometry_msg(std::string const& transform_string)
{
	geometry_msgs::Transform t;
	std::stringstream ss(transform_string);
	ss >> t;
	return t;
}

/*
* throw on error
*/
void read_geometry_msgs_from_file(std::string filename, std::vector<std::pair<ros::Time, geometry_msgs::Transform> >& result_vector)
{
	result_vector.clear();
	std::ifstream ifs(filename.c_str());
	if (!ifs) throw runtime_error("Failed to open file " + filename);
	std::string timestamp_string;
	std::string transform_string;
	while (getline(ifs, timestamp_string, ':'))
	{
		// allow comments with starting with #
		if (timestamp_string[0] == '#') {
			// read to ignore rest of line
			std::string ignore;
			std::getline(ifs, ignore);
			continue;
		}
		ros::Time ts = rgbd::convert_string_to_timestamp(timestamp_string);
		std::getline(ifs, transform_string);
		geometry_msgs::Transform transform = convert_string_to_geometry_msg(transform_string);
		result_vector.push_back(std::make_pair(ts, transform));
	}
}
/*
* throw on error
*/
std::vector<std::pair<ros::Time, geometry_msgs::Transform> > readTransformsTextFile(const fs::path& filepath)
{
	std::vector<std::pair<ros::Time, geometry_msgs::Transform> > xforms;
	read_geometry_msgs_from_file(filepath.string(), xforms);
	return xforms;
}

void read_geometry_msgs_from_mit_file(std::string filename, std::vector<std::pair<ros::Time, geometry_msgs::Transform> >& result_vector)
{
	// format is: % utime x y z yaw pitch roll
	// example: 1307726892118282 0.863473 0.637274 0 0.709340 0.038397 0
	// ignore both % and # as comments
	result_vector.clear();
	std::ifstream ifs(filename.c_str());
	if (!ifs) throw runtime_error("Failed to open file " + filename);
	std::string line_string;
	while (getline(ifs, line_string))
	{
		// allow comments with starting with #
		if (line_string[0] == '#' || line_string[0] == '%') {
			continue;
		}
		std::stringstream ss(line_string);
		long utime;
		ss >> utime;
		float x,y,z,yaw,pitch,roll;
		ss >> x >> y >> z >> yaw >> pitch >> roll;
		ros::Time ts;
		geometry_msgs::Transform transform;
		ts.fromNSec(1000*utime);
		tf::Quaternion tf_q = tf::createQuaternionFromRPY(roll, pitch, yaw);
		transform.rotation.w = tf_q.w();
		transform.rotation.x = tf_q.x();
		transform.rotation.y = tf_q.y();
		transform.rotation.z = tf_q.z();
		transform.translation.x = x;
		transform.translation.y = y;
		transform.translation.z = z;
		result_vector.push_back(std::make_pair(ts, transform));
	}
}

/*
* throw on error
*/
void write_geometry_msgs_to_file(std::string filename, const std::vector<std::pair<ros::Time, geometry_msgs::Transform> >& output_vector)
{
	std::ofstream ofs(filename.c_str());
	std::string timestamp_string;
	std::string transform_string;
	if (!ofs) throw runtime_error("Failed to open file " + filename);
	for (unsigned int i = 0; i < output_vector.size(); i++) {
		timestamp_string = rgbd::convert_timestamp_to_string(output_vector[i].first, " ");
		transform_string = convert_geometry_msg_to_string(output_vector[i].second);
		ofs << timestamp_string << ": " << transform_string << "\n";
	}
	ROS_INFO("Wrote transforms to file: %s", filename.c_str());
}

void write_geometry_msgs_to_file(std::string filename, const std::map<ros::Time, geometry_msgs::Transform>& xforms)
{
	std::ofstream ofs(filename.c_str());
	std::string timestamp_string;
	std::string transform_string;
	if (!ofs) throw runtime_error("Failed to open file " + filename);
	for (std::map<ros::Time, geometry_msgs::Transform>::const_iterator i = xforms.begin(); i != xforms.end(); i++)
	{
		timestamp_string = rgbd::convert_timestamp_to_string((*i).first, " ");
		transform_string = convert_geometry_msg_to_string((*i).second);
		ofs << timestamp_string << ": " << transform_string << "\n";
	}
	ROS_INFO("Wrote transforms to file: %s", filename.c_str());
}

#ifdef UNUSED
void writeXformsBinaryFile(const string& filepath, const std::vector<std::pair<ros::Time, geometry_msgs::Transform> >& xforms)
{
	ofstream outfile(filepath.c_str());
	if(!outfile) throw runtime_error("can't open '" + filepath + "' for write");
	const unsigned int numXforms = xforms.size();
	outfile.write(reinterpret_cast<const char*>(&numXforms), sizeof(unsigned int));
	for(unsigned int i = 0; i < xforms.size(); i++)
	{
		outfile.write(reinterpret_cast<const char*>(&xforms[i].first.sec), sizeof(uint32_t));
		outfile.write(reinterpret_cast<const char*>(&xforms[i].first.nsec), sizeof(uint32_t));
		outfile.write(reinterpret_cast<const char*>(&xforms[i].second.rotation.w), sizeof(double));
		outfile.write(reinterpret_cast<const char*>(&xforms[i].second.rotation.x), sizeof(double));
		outfile.write(reinterpret_cast<const char*>(&xforms[i].second.rotation.y), sizeof(double));
		outfile.write(reinterpret_cast<const char*>(&xforms[i].second.rotation.z), sizeof(double));
		outfile.write(reinterpret_cast<const char*>(&xforms[i].second.translation.x), sizeof(double));
		outfile.write(reinterpret_cast<const char*>(&xforms[i].second.translation.y), sizeof(double));
		outfile.write(reinterpret_cast<const char*>(&xforms[i].second.translation.z), sizeof(double));
	}
	ROS_INFO_STREAM("Wrote transforms to binary file: " << filepath);
}
std::vector<std::pair<ros::Time, geometry_msgs::Transform> > readXformsBinaryFile(const string& filepath)
{
	ifstream infile(filepath.c_str());
	if(!infile) throw runtime_error("can't open'" + filepath + "' for read");
	unsigned int numXforms;
	infile.read(reinterpret_cast<char*>(&numXforms), sizeof(unsigned int));
	std::vector<std::pair<ros::Time, geometry_msgs::Transform> > xforms(numXforms);
	for(unsigned int i = 0; i < numXforms; i++)
	{
		infile.read(reinterpret_cast<char*>(&xforms[i].first.sec), sizeof(uint32_t));
		infile.read(reinterpret_cast<char*>(&xforms[i].first.nsec), sizeof(uint32_t));
		infile.read(reinterpret_cast<char*>(&xforms[i].second.rotation.w), sizeof(double));
		infile.read(reinterpret_cast<char*>(&xforms[i].second.rotation.x), sizeof(double));
		infile.read(reinterpret_cast<char*>(&xforms[i].second.rotation.y), sizeof(double));
		infile.read(reinterpret_cast<char*>(&xforms[i].second.rotation.z), sizeof(double));
		infile.read(reinterpret_cast<char*>(&xforms[i].second.translation.x), sizeof(double));
		infile.read(reinterpret_cast<char*>(&xforms[i].second.translation.y), sizeof(double));
		infile.read(reinterpret_cast<char*>(&xforms[i].second.translation.z), sizeof(double));
	}
	return xforms;
}
#endif

} //namespace

/*
 * standardized format
 */
std::istream& operator >> (std::istream& in, geometry_msgs::Transform& t)
{
	return in >> t.rotation.w >> t.rotation.x >> t.rotation.y >> t.rotation.z >> t.translation.x >> t.translation.y >> t.translation.z;
}
std::ostream& operator << (std::ostream& out, const geometry_msgs::Transform& t)
{
	const std::streamsize prevPrec = out.precision(10);
	return out << t.rotation.w << " " << t.rotation.x << " " << t.rotation.y << " " << t.rotation.z
				<< " " << t.translation.x << " " << t.translation.y << " " << t.translation.z << std::setprecision(prevPrec);
}
