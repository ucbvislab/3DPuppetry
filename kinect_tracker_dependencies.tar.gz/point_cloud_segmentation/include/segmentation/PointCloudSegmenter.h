/*
 * PointCloudSegmenter.h
 *
 *  Created on: Sep 1, 2009
 *      Author: mkrainin
 */

#ifndef POINTCLOUDSEGMENTER_H_
#define POINTCLOUDSEGMENTER_H_

#include <vector>
#include <list>
#include <pcl/point_cloud.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/kdtree/impl/kdtree_flann.hpp>
#include "rgbd_util/eigen/Core"
#include "rgbd_util/eigen/Geometry"

#include <boost/multi_array.hpp>
#include <boost/shared_ptr.hpp>

namespace segmentation {

struct HandSegmentationParams
{
	float maxEdgeDist; //depth difference to be considered discontinuity
	unsigned int minSegmentSize; //segments smaller than this are thrown away
	float handRemovalDist; //pts closer than this to hand are discarded
	float proximityForAdding; //closest pt must be w/in this dist from center of fingers
	float minDistAlongWrist; //some part of the segment must go beyond this far down the wrist
	float wristLowerLimit; //no part of the segment may go this far up
};

class PointCloudSegmenter {
public:
	PointCloudSegmenter();
	virtual ~PointCloudSegmenter();

	void setResolution(unsigned int xRes, unsigned int yRes);

	/**
	 * Returns a 2D grid of size xres by yres whose entries indicate whether
	 * the 3D point (if existent) should be considered an object point.
	 *
	 * Note: this assumes that segmentUsingHandInformation has already
	 * been called. this method works on datastructures used by that method
	 *
	 * @param segmentationMap
	 */
	void getSegmentationMap(boost::shared_ptr<const boost::multi_array<bool,2> > & segmentationMap);

	/**
	 * Erodes the segmentation map by a specified number of pixels and returns the
	 * pixel indices that are still valid
	 *
	 * @param numPixels
	 * @return
	 */
	std::vector<std::pair<unsigned int, unsigned int> > erodeSegmentationMap(unsigned int numPixels);

	/**
	 * Decompose a point cloud into a collection of sub-clouds by creating
	 * links along the x-y grid and returning the connected components
	 *
	 * @param sourceCloud the cloud to segment
	 * @param maxEdgeDist maximum distance between neighboring 3D points
	 * in order to put an edge between them. this essentially defines what
	 * to consider as a depth discontinuity
	 * @param minSegmentSize minimum segment size (in # points) to return in
	 * the segment vector
	 * @return vector of segments as point-clouds. sorted with largest first
	 */
	template <typename PointT>
	std::vector<typename pcl::PointCloud<PointT>::Ptr > segmentCameraCloud(
			pcl::PointCloud<PointT> const& sourceCloud,
			float maxEdgeDist,
			unsigned int minSegmentSize,
			unsigned int gridIncrement);

	/**
	 * Returns a vector of (x,y) pairs, indicating the regions of the depth
	 * grid which contain the object being held
	 *
	 * @param pointGrid
	 * @param validityGrid
	 * @param pointKDTree
	 * @param handPointLocations
	 * @param centerOfFingers
	 * @param wristLocation
	 * @param maxEdgeDist maximum allowed depth discontinuity while segmenting
	 * @param minSegmentSize segments below this size are thrown away
	 * @param handRemovalDist points within this distance of handPointLocations
	 * 	are discarded
	 * @param proximityForAdding segment distance from centerOfFingers to
	 *  be considered as object
	 * @param minDistAlongWrist at least one point in the segment must be
	 *  at least this distance along the segment from wristLocation to centerOfFingers
	 * @param wristLowerLimit no point in the segment can be this far back
	 *  along the segment wristLocation to centerOfFingers
	 * @return
	 */
	template <typename PointT, typename Real>
	std::vector<std::pair<unsigned int, unsigned int> > segmentUsingHandInformation(
			pcl::PointCloud<PointT> const& cloud,
			typename pcl::KdTree<PointT>::Ptr kdTree,
			std::vector<rgbd::eigen::Matrix<Real,3,1> > const& handPointLocations,
			rgbd::eigen::Vector3f const& centerOfFingers, rgbd::eigen::Vector3f const& wristLocation,
			HandSegmentationParams const& handSegParams);

	/**
	 * Segment the source cloud, using hand information to decide which points
	 * are the ones of interest and returning those as a point cloud
	 *
	 * @param sourceCloud
	 * @param estimatedJointAngles
	 * @param inter
	 * @param maxEdgeDist
	 * @param minSegmentSize
	 * @param handRemovalDist don't return any points within this distance of simulatedPoints
	 * @return
	 */
//	sensor_msgs::PointCloud segmentUsingHandInformation(
//			sensor_msgs::PointCloud const& sourceCloud,
//			std::vector<float> const& estimatedJointAngles,
//			sensor_msgs::PointCloud & colorizedCloud,
//			OpenRAVEInterface *inter,
//			float maxEdgeDist,
//			unsigned int minSegmentSize,
//			float handRemovalDist,
//			float proximityForAdding,
//			float minDistAlongWrist,
//			unsigned int gridIncrement);

	/**
	 * Segment using both hand and model information. In addition to the
	 * source cloud and the robot arm information, this takes in a
	 * previously generated model of the object in the hand in global
	 * coordinates. The resulting pointcloud contains possibly multiple,
	 * somewhat disjoint segments, but not any of the model clouds.
	 * The two clouds must be merged afterwards if so desired
	 *
	 * @param sourceCloud
	 * @param modelCloud
	 * @param simulatedPoints
	 * @param pointLinks
	 * @param pixelXChannel
	 * @param pixelYChannel
	 * @param xRes
	 * @param yRes
	 * @param maxEdgeDist
	 * @param minSegmentSize
	 * @param handRemovalDist
	 * @return
	 */
//	sensor_msgs::PointCloud segmentUsingHandAndModelInformation(
//			sensor_msgs::PointCloud const& sourceCloud,
//			sensor_msgs::PointCloud const& modelCloud,
//			std::vector<rgbd::eigen::Vector3f> const& simulatedPoints,
//			std::vector<OpenRAVE::KinBody::LinkPtr > const& pointLinks,
//			float maxEdgeDist,
//			unsigned int minSegmentSize,
//			float handRemovalDist);

private:

	unsigned int m_xRes,m_yRes;

	//used for constructing a segmentation mask
	unsigned int m_gridIncrementUsed;
	bool m_segmentationDone;

	bool m_segmentationMapSet;
	boost::shared_ptr<boost::multi_array<bool,2> > m_segmentationMap;
	//typically, the extracted segments will be confined to a small region
	//of the image. store a bounding box for efficiency for when going
	//back to the segmentation map to do things like erosion
	unsigned int m_segmentationMapMinX,m_segmentationMapMaxX;
	unsigned int m_segmentationMapMinY,m_segmentationMapMaxY;

	/**
	 * Returns the connected component of the point at (xStart,yStart) as
	 * a vector of indices into the original pointCloud, where the mapping
	 * from the 2D arrays to the 1D array is given by pointIndices
	 *
	 * @param xStart
	 * @param yStart
	 * @param hasXPlusLink horizontal edges in the connectivity graph
	 * @param hasYPlusLink vertical edges in the connectivity graph
	 * @param pointIndices mapping from 2D indices to 1D indices
	 * @param containedInSegment whether each point in the point cloud
	 * has been included in a segment. This is modified by the method
	 * @return connected component of the starting pixel
	 */
	std::list<unsigned int> computeConnectedComponentDFS(
			unsigned int xStart,
			unsigned int yStart,
			std::vector<std::vector<bool> > const& hasXPlusLink,
			std::vector<std::vector<bool> > const& hasYPlusLink,
			std::vector<std::vector<unsigned int> > const& pointIndices,
			std::vector<bool> &containedInSegment);

	/**
	 * Comparator for sorting lists of vectors of indices by the number of
	 * indices in the vector.
	 *
	 * @param first
	 * @param second
	 * @return
	 */
	static bool segmentSizeComparator (
			std::vector<unsigned int> const& first,
			std::vector<unsigned int> const& second)
	{
		return (first.size() < second.size());
	}


};

} //namespace

#include "PointCloudSegmenter.ipp"

#endif /* POINTCLOUDSEGMENTER_H_ */
