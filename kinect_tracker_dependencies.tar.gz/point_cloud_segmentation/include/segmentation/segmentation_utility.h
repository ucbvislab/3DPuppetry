/*
 * segmentation_utility.h
 *
 *  Created on: 2010-07-20
 *      Author: mkrainin
 */

#ifndef SEGMENTATION_UTILITY_H_
#define SEGMENTATION_UTILITY_H_

#include <rgbd_util/eigen/Geometry>
#include <vector>

#include <pcl/point_cloud.h>
#include <pcl/sample_consensus/sac_model_plane.h>
#include <pcl/sample_consensus/msac.h>
#include <pcl/sample_consensus/sac_model_normal_plane.h>
#include <pcl/sample_consensus/ransac.h>
#include <pcl/surface/convex_hull.h>
#include <pcl/segmentation/extract_clusters.h>
#include <pcl/sample_consensus/impl/sac_model_plane.hpp>
#include <pcl/sample_consensus/impl/msac.hpp>
#include <pcl/sample_consensus/impl/sac_model_normal_plane.hpp>
#include <pcl/sample_consensus/impl/ransac.hpp>
#include <pcl/surface/impl/convex_hull.hpp>
#include <pcl/segmentation/impl/extract_clusters.hpp>

#include <std_msgs/ColorRGBA.h>
#include <visualization_msgs/Marker.h>

namespace segmentation {

/**
 * replacement for fitSACPlane that used to be in registration.
 * fits a plane to a subset (indicated by indices) of a point cloud.
 *
 * @param cloud
 * @param indices
 * @param inliers
 * @param coeff
 * @param dist_thresh
 * @param max_iterations
 * @return
 */
template <typename PointT>
bool fitSACPlane (typename pcl::PointCloud<PointT>::ConstPtr const& cloud,
		std::vector<int> &indices,
		std::vector<int> &inliers,
		std::vector<double> &coeff,
		double dist_thresh,
		int max_iterations);


/*
 * Compute a plane with prior knowledge of the normal (like ground plane)
 *
 * Requires that cloud_ptr have normals computed already
 *
 * If all_indices is empty, uses all indices
 *
 * If sample_indices is empty, uses all indices as sample indices
 */
#if 0
template <typename PointT>
bool computePlaneWithNormal(
		typename pcl::PointCloud<PointT>::ConstPtr cloud_ptr,
		const std::vector<int> & all_indices,
		const std::vector<int> & sample_indices,
		double inlier_distance,
		const rgbd::eigen::Vector3f & normal_prior,
		double max_angle_difference,
		double displacement_from_origin,
		double max_displacement_difference,
		double normal_distance_weight,
		rgbd::eigen::VectorXf& plane_coefficients,
		std::vector<int>& plane_inliers,
		typename pcl::PointCloud<PointT>::Ptr projected_inliers,
		typename pcl::PointCloud<PointT>::Ptr convex_hull,
		bool do_euclidean_clustering,
		double euclidean_tolerance);
#endif

template <typename PointT>
bool computePlane(
		typename pcl::PointCloud<PointT>::ConstPtr cloud_ptr,
		const std::vector<int> & all_indices,
		const std::vector<int> & sample_indices,
		double inlier_distance,
		rgbd::eigen::VectorXf& plane_coefficients,
		std::vector<int>& plane_inliers,
		typename pcl::PointCloud<PointT>::Ptr projected_inliers,
		typename pcl::PointCloud<PointT>::Ptr convex_hull,
		bool do_euclidean_clustering,
		double euclidean_tolerance);

/*
 * Called by the above methods
 */
template <typename PointT>
bool computePlaneSACModel(
		typename pcl::SampleConsensusModel<PointT>::Ptr sac_model,
		typename pcl::SampleConsensus<PointT>::Ptr sac_method,
		const std::vector<int> & all_indices,
		const std::vector<int> & sample_indices,
		double inlier_distance,
		rgbd::eigen::VectorXf& plane_coefficients,
		std::vector<int>& plane_inliers,
		typename pcl::PointCloud<PointT>::Ptr projected_inliers,
		typename pcl::PointCloud<PointT>::Ptr convex_hull,
		bool do_euclidean_clustering,
		double euclidean_tolerance);

template <typename PointT>
visualization_msgs::Marker getConvexHullMarker(
		typename pcl::PointCloud<PointT>::ConstPtr convex_hull,
		const std::string & ns,
		int id,
		const std_msgs::ColorRGBA & color);

// non-templated:

void removeInlierIndices(
		const std::vector<int> & indices,
		const std::vector<int> & inlier_indices,
		std::vector<int> & result);

void removeInlierIndices(
		const std::vector<int> & indices,
		const std::vector<int> & inlier_indices,
		int max_index,
		std::vector<int> & result);

std_msgs::ColorRGBA getRandomColor(float alpha = 1.0);

} //namespace

#include "segmentation/segmentation_utility.ipp"

#endif /* SEGMENTATION_UTILITY_H_ */
