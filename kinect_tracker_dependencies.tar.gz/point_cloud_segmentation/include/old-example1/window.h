/*
 * window.h
 *
 *  Created on: Jun 23, 2010
 *      Author: hdu
 */

#ifndef WINDOW_H_
#define WINDOW_H_

#include "pcl/ModelCoefficients.h"
#include "pcl/io/pcd_io.h"
#include "pcl/point_types.h"
#include "pcl/sample_consensus/method_types.h"
#include "pcl/sample_consensus/model_types.h"
#include "pcl/segmentation/sac_segmentation.h"

#include "dcloud/dcloud.h"
#include <string>
#include <QWidget>

template <class PointType>
class DCloud;

class GLWidget;

class Window : public QWidget
{
    Q_OBJECT

public:
    Window();
    ~Window();
    QSize sizeHint();
    void Init(const std::string& plyfilename);

protected:
    std::string plyfilename;

public:
    DCloud<pcl::PointXYZRGB> dcloud;
    pcl::PointIndices inliers;

protected:
    void keyPressEvent(QKeyEvent *event);

private:
    GLWidget *glWidget;
};

#endif /* WINDOW_H_ */


