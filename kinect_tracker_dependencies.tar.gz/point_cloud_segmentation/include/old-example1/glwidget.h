/*
 * glwidget.h
 *
 *  Created on: Jun 23, 2010
 *      Author: hdu
 */

#ifndef GLWIDGET_H_
#define GLWIDGET_H_

#include <QtOpenGL/QGLWidget>

class Window;

class GLWidget : public QGLWidget
{
	Q_OBJECT

#define dis_ZtoObjCenter 6.0f

public:
    GLWidget(QWidget *parent = 0);
    ~GLWidget();

public:
    enum _STATE_SHOW{
		REGULAR = 0,
		INLIAR,
	}STATE_SHOW;

protected:
    void initializeGL();
    void paintGL();
    void resizeGL(int width, int height);
    void mouseDoubleClickEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void wheelEvent(QWheelEvent *event);

protected: // for view
    float scale;
    float centerX, centerY, centerZ;
    float xRot, yRot, zRot;
    QPoint lastMousePos;

protected:
    Window* pWindow;
};


#endif /* GLWIDGET_H_ */
