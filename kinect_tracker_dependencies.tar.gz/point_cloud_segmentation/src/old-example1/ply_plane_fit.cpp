/*
 * ply_plane_fit.cpp
 *
 *  Created on: 2010-06-22
 *      Author: phenry
 */

// ros code:
#include "pcl/ModelCoefficients.h"

#include "pcl/io/pcd_io.h"
#include "pcl/point_types.h"

#include "pcl/sample_consensus/method_types.h"
#include "pcl/sample_consensus/model_types.h"
#include "pcl/segmentation/sac_segmentation.h"

#include "sensor_msgs/PointCloud2.h"

#include "pcl/ros/publisher.h"

// our code:
#include "pcl_rgbd/pointTypes.h"
#include "pcl_rgbd/cloudTofroPLY.h"
#include "pcl_rgbd/cloudUtils.h"

using std::string;


int main (int argc, char** argv)
{
	ros::init(argc, argv, "ply_plane_fit");

# if 0
	// From tutorial:

	pcl::PointCloud<pcl::PointXYZ> cloud;

	// Fill in the cloud data
	cloud.width  = 15;
	cloud.height = 1;
	cloud.points.resize (cloud.width * cloud.height);

	// Generate the data
	for (size_t i = 0; i < cloud.points.size (); ++i)
	{
	cloud.points[i].x = 1024 * rand () / (RAND_MAX + 1.0);
	cloud.points[i].y = 1024 * rand () / (RAND_MAX + 1.0);
	cloud.points[i].z = 1.0;
	}

	// Set a few outliers
	cloud.points[0].z = 2.0;
	cloud.points[3].z = -2.0;
	cloud.points[6].z = 4.0;

	std::cerr << "Point cloud data: " << cloud.points.size () << " points" << std::endl;
	for (size_t i = 0; i < cloud.points.size (); ++i)
	std::cerr << "    " << cloud.points[i].x << " " << cloud.points[i].y << " " << cloud.points[i].z << std::endl;
#endif

	// get ply file as argv[1]
	if (argc != 2) {
		ROS_ERROR("You need to specify a ply file");
		exit(-1);
	}

	typedef pcl::PointXYZRGB PointType;

	string filename = argv[1];

	// reading into templated types assumes all members of point type are exactly in ply (not true)
	//pcl::PointCloud<PointType> cloud;
	//rgbd::read_ply_file(cloud, filename);
	//ROS_INFO_STREAM("Cloud loaded with " << cloud.points.size() << " points");

	// alternate idea:
	sensor_msgs::PointCloud2 cloud_msg;
	rgbd::read_ply_file(cloud_msg, filename);
	ROS_INFO_STREAM("Cloud message loaded with " << (cloud_msg.width * cloud_msg.height) << " points");

	// assume these names for color channels
	string r_name = "diffuse_red";
	string g_name = "diffuse_green";
	string b_name = "diffuse_blue";
	sensor_msgs::PointCloud2 cloud_msg_fixed_colors;
	rgbd::packColorChannels(r_name, g_name, b_name, cloud_msg, cloud_msg_fixed_colors);

	// finally can convert to templated cloud
	pcl::PointCloud<PointType> cloud;
	pcl::fromROSMsg(cloud_msg_fixed_colors, cloud);

	// publish the cloud just to see that colors are ok...
	ros::NodeHandle nh_global;
	point_cloud::Publisher<PointType> publisher;
	publisher.advertise(nh_global, "loaded_ply_file", 1);
	cloud.header.frame_id = "/primesensor_frame"; // matches what I'm usually viewing
	publisher.publish(cloud);

	// From the tutorial again:

	pcl::ModelCoefficients coefficients;
	pcl::PointIndices inliers;
	// Create the segmentation object
	pcl::SACSegmentation<PointType> seg;
	// Optional
	seg.setOptimizeCoefficients (true);
	// Mandatory
	seg.setModelType (pcl::SACMODEL_PLANE);
	seg.setMethodType (pcl::SAC_RANSAC);
	seg.setDistanceThreshold (0.01);

	seg.setInputCloud (boost::make_shared<pcl::PointCloud<PointType> >(cloud));
	seg.segment (inliers, coefficients);

	if (inliers.indices.size () == 0)
	{
	ROS_ERROR ("Could not estimate a planar model for the given dataset.");
	return (-1);
	}

	std::cerr << "Model coefficients: " << coefficients.values[0] << " " << coefficients.values[1] << " "
									  << coefficients.values[2] << " " << coefficients.values[3] << std::endl;

	std::cerr << "Model inliers: " << inliers.indices.size () << std::endl;

	bool print_inliers = false;
	if (print_inliers) {
		for (size_t i = 0; i < inliers.indices.size (); ++i) {
		std::cerr << inliers.indices[i] << "    " << cloud.points[inliers.indices[i]].x << " "
												  << cloud.points[inliers.indices[i]].y << " "
												  << cloud.points[inliers.indices[i]].z << std::endl;
		}
	}

	return (0);
}
/* ]--- */
