/*
 * main.cpp
 *
 *  Created on: Jun 23, 2010
 *      Author: hdu
 */

#include "old-example1/window.h"
#include <QtGui/QApplication>

int main(int argc, char *argv[])
{
	ros::init(argc, argv, "ply_plane_fit");

	// get ply file as argv[1]
	if (argc != 2) {
		ROS_ERROR("You need to specify a ply file");
		exit(-1);
	}

	QApplication app(argc, argv);
    Window window;
    window.Init(argv[1]);
    window.resize(window.sizeHint());
    window.show();
    return app.exec();
}
