/*
 * window.cpp
 *
 *  Created on: Jun 23, 2010
 *      Author: hdu
 */

#include "old-example1/window.h"
#include "old-example1/glwidget.h"
#include <QtGui>

using namespace std;


void Window::Init(const std::string& plyfilename)
{
	this->plyfilename = plyfilename;
	dcloud.LoadPLY(plyfilename);
}

Window::Window()
{
	glWidget = new GLWidget(this);
	QHBoxLayout *mainLayout = new QHBoxLayout;
	mainLayout->addWidget(glWidget);
	setLayout(mainLayout);
	setWindowTitle(tr("Hello GL"));
}

Window::~Window()
{

}

QSize Window::sizeHint()
{
	return QSize(1024,768);
}

void Window::keyPressEvent(QKeyEvent *e)
{
   	if (e->key() == Qt::Key_Escape)
        close();
   	else if(e->key() == '1')
   	{
   		// Plane fit

   		pcl::ModelCoefficients coefficients;
   		// Create the segmentation object
   		pcl::SACSegmentation<pcl::PointXYZRGB> seg;
   		// Optional
   		seg.setOptimizeCoefficients (true);
   		// Mandatory
   		seg.setModelType (pcl::SACMODEL_PLANE);
   		seg.setMethodType (pcl::SAC_RANSAC);
   		seg.setDistanceThreshold (0.01);
   		seg.setMaxIterations(1000);

   		seg.setInputCloud (boost::make_shared<pcl::PointCloud<pcl::PointXYZRGB> >(dcloud.cloud));
   		seg.segment (inliers, coefficients);

   		if (inliers.indices.size () == 0)
   		{
   			ROS_ERROR ("Could not estimate a planar model for the given dataset.");
   			return;
   		}

   		std::cout << "Model coefficients: " << coefficients.values[0] << " " << coefficients.values[1] << " "
   											  << coefficients.values[2] << " " << coefficients.values[3] << std::endl;

   		std::cout << "Model inliers: " << inliers.indices.size () << std::endl;

   			/*bool print_inliers = false;
   			if (print_inliers) {
   				for (size_t i = 0; i < inliers.indices.size (); ++i) {
   				std::cerr << inliers.indices[i] << "    " << cloud.points[inliers.indices[i]].x << " "
   														  << cloud.points[inliers.indices[i]].y << " "
   														  << cloud.points[inliers.indices[i]].z << std::endl;
   				}
   			}*/

   		glWidget->STATE_SHOW = GLWidget::INLIAR;
   		glWidget->updateGL();
   	}
   	else if(e->key()== '2')
   	{
   		if(glWidget->STATE_SHOW == GLWidget::REGULAR)
   			glWidget->STATE_SHOW = GLWidget::INLIAR;
   		else if(glWidget->STATE_SHOW == GLWidget::INLIAR)
   			glWidget->STATE_SHOW = GLWidget::REGULAR;
   		glWidget->updateGL();
   	}

   	/*   	else if(e->key() == 'E')
   	{
   		cout << "Exclude [Start]\n";
   		glWidget->DeleteSelect(1);
   		cout << "Exclude [End]\n";
   	}*/

	QWidget::keyPressEvent(e);
}

