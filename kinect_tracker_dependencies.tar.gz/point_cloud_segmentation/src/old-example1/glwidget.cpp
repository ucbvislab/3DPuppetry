/*
 * glwidget.cpp
 *
 *  Created on: Jun 23, 2010
 *      Author: hdu
 */

#include "old-example1/window.h"
#include "old-example1/glwidget.h"
#include <QtGui>

GLWidget::GLWidget(QWidget *parent)
    : QGLWidget(QGLFormat(QGL::SampleBuffers), parent)
{
	this->pWindow = (Window*)parent;
}

GLWidget::~GLWidget()
{
}

void GLWidget::initializeGL()
{
	glShadeModel(GL_SMOOTH);
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	STATE_SHOW = REGULAR;
	pWindow->dcloud.get_avg_xyz(centerX, centerY, centerZ);
	scale = pWindow->dcloud.get_avg_scale();
	xRot = yRot = zRot = 0;
}

void GLWidget::paintGL()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glTranslatef(0,0,-dis_ZtoObjCenter);
    glRotatef(xRot, 1,0,0);
    glRotatef(yRot, 0,1,0);
    glRotatef(zRot, 0,0,1);

    if(STATE_SHOW == REGULAR)
    {
		glBegin(GL_POINTS);
		for(int i=0; i< (int)(pWindow->dcloud.cloud.height * pWindow->dcloud.cloud.width); i++)
		{
			float X = (pWindow->dcloud.cloud.points[i].x - centerX) / scale;
			float Y = (pWindow->dcloud.cloud.points[i].y - centerY) / scale;
			float Z = (pWindow->dcloud.cloud.points[i].z - centerZ) / scale;

			uint byte_mask = 0xFF;
			const uint *rgb_uint_ptr = reinterpret_cast<const uint*> (&pWindow->dcloud.cloud.points[i].rgb);
			uchar rr = (uchar) ((*rgb_uint_ptr) >> 16) & byte_mask;
			uchar gg = (uchar) ((*rgb_uint_ptr) >> 8) & byte_mask;
			uchar bb = (uchar) ((*rgb_uint_ptr)) & byte_mask;

			float r = rr / 256.0f;
			float g = gg / 256.0f;
			float b = bb / 256.0f;

			glColor3f(r,g,b);
			glVertex3f(X,Y,Z);
		}
		glEnd();
    }
    else if(STATE_SHOW == INLIAR)
    {
    	glColor3f(1.0f, 1.0f, 1.0f);
    	glBegin(GL_POINTS);
		for (size_t i = 0; i < pWindow->inliers.indices.size (); ++i)
		{
			float X = (pWindow->dcloud.cloud.points[pWindow->inliers.indices[i]].x - centerX) / scale;
			float Y = (pWindow->dcloud.cloud.points[pWindow->inliers.indices[i]].y - centerY) / scale;
			float Z = (pWindow->dcloud.cloud.points[pWindow->inliers.indices[i]].z - centerZ) / scale;
			glVertex3f(X,Y,Z);
		}
		glEnd();
	}


}

void GLWidget::resizeGL(int width, int height)
{
	if(height==0)
		height=1;		// prevent dividing by 0
	glViewport(0,0, width, height);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
	gluPerspective(45.0f,(GLfloat)width/(GLfloat)height,0.1f,100.0f);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void GLWidget::mouseDoubleClickEvent(QMouseEvent *event)
{
	if(! (event->buttons() & Qt::LeftButton) )
		return;

	int px = event->x();
	int py = event->y();

	GLdouble model_view[16];
	glGetDoublev(GL_MODELVIEW_MATRIX, model_view);

	GLdouble projection[16];
	glGetDoublev(GL_PROJECTION_MATRIX, projection);

	GLint viewport[4];
	glGetIntegerv(GL_VIEWPORT, viewport);

	// find nearest neighbor
	int w = -1;
	float mindis2 = 1e7;
	for(int i=0;i<(int)(pWindow->dcloud.cloud.height * pWindow->dcloud.cloud.width) ;i++)
	{
		double X = (pWindow->dcloud.cloud.points[i].x - centerX) / scale;
		double Y = (pWindow->dcloud.cloud.points[i].y - centerY) / scale;
		double Z = (pWindow->dcloud.cloud.points[i].z - centerZ) / scale;
		double winx, winy, winz;
		gluProject(X,Y,Z, model_view, projection, viewport, &winx, &winy, &winz);

		int x=winx;
		int y=(viewport[3]-winy);
		if(x>=0 && x<viewport[2] && y>=0 && y<viewport[3] && Z<dis_ZtoObjCenter)   // Is the 2D projection visible in the viewport?
		{
			float thedis2 = (x-px)*(x-px) + (y-py)*(y-py);
			if(w == -1 || mindis2 > thedis2)
			{
				mindis2 = thedis2;
				w = i;
			}
		}
	}

	if(w!=-1)
	{
		centerX = pWindow->dcloud.cloud.points[w].x;
		centerY = pWindow->dcloud.cloud.points[w].y;
		centerZ = pWindow->dcloud.cloud.points[w].z;
		updateGL();
	}
}

void GLWidget::mousePressEvent(QMouseEvent *event)
{
	lastMousePos = event->pos();
/*	if(event->buttons() & Qt::RightButton)
	{
	}*/
}

void GLWidget::mouseReleaseEvent(QMouseEvent *event)
{
}

void GLWidget::mouseMoveEvent(QMouseEvent *event)
{
	int dx = event->x() - lastMousePos.x();
	int dy = event->y() - lastMousePos.y();

	if( (event->buttons() & Qt::LeftButton) )
	{
		GLint viewport[4];
		glGetIntegerv(GL_VIEWPORT, viewport);
		float rectWinSize = std::min(viewport[2], viewport[3]);
		xRot += dy/rectWinSize*150.0f;
		yRot += dx/rectWinSize*150.0f;
		updateGL();
	}
	if( (event->buttons() & Qt::RightButton) )
	{
		GLint viewport[4];
		glGetIntegerv(GL_VIEWPORT, viewport);
		float rectWinSize = std::min(viewport[2], viewport[3]);
		zRot += dy/rectWinSize*150.0f;
		updateGL();
	}
	lastMousePos = event->pos();
}

void GLWidget::wheelEvent(QWheelEvent *event)
{
	int numDegrees = event->delta() / 8;
	int numSteps = numDegrees / 15;
	if(event->orientation() == Qt::Vertical)
	{
		scale *= 1+numSteps/10.0f;
		updateGL();
	}
	event->accept();
}
