/*
 * PointCloudSegmenter.cpp
 *
 *  Created on: Sep 1, 2009
 *      Author: mkrainin
 */

#include <segmentation/PointCloudSegmenter.h>
#include <pcl_rgbd/cloudSampling.h>
#include <deque>

namespace segmentation {

PointCloudSegmenter::PointCloudSegmenter() {
	//set some reasonable defaults
	//these can always be changed later with the setters
	m_xRes = 640;
	m_yRes = 480;
	m_segmentationDone = false;
	m_segmentationMapSet = false;
}

PointCloudSegmenter::~PointCloudSegmenter() {
}

void
PointCloudSegmenter::setResolution(unsigned int xRes, unsigned int yRes)
{
	m_xRes = xRes;
	m_yRes = yRes;
}

void
PointCloudSegmenter::getSegmentationMap(boost::shared_ptr<const boost::multi_array<bool,2> > & segmentationMap)
{
	assert(m_segmentationDone);

	if(m_segmentationMapSet){
		segmentationMap =  m_segmentationMap;
		return;
	}
	else{
		assert(false);
	}

//	//initialize map
//	segmentationMap.resize(m_xRes);
//	for(unsigned int i=0; i<m_xRes; i++)
//		segmentationMap[i] = std::vector<bool>(m_yRes,false);
//
//	if(m_segmentedCloud.points.size() == 0)
//		return;
//
//	//put true for points actually in the segment cloud
//	unsigned int minX=0,maxX=0,minY=0,maxY=0;
//	for(unsigned int i=0; i<m_segmentedCloud.points.size(); i++){
//		unsigned int x = m_segmentedCloud.channels[m_xChan].values[i];
//		unsigned int y = m_segmentedCloud.channels[m_yChan].values[i];
//		segmentationMap[x][y] = true;
//
//		//keep track of some bounds to make the next step more efficient
//		if(i == 0){
//			minX = maxX = x;
//			minY = maxY = y;
//		}
//		if(x < minX)
//			minX = x;
//		if(x > maxX)
//			maxX = x;
//		if(y < minY)
//			minY = y;
//		if(y > maxY)
//			maxY = y;
//	}
//	m_segmentationMapMinX = minX;
//	m_segmentationMapMaxX = maxX;
//	m_segmentationMapMinY = minY;
//	m_segmentationMapMaxY = maxY;
//
//	if(m_gridIncrementUsed == 1)
//		return;
//
//	//interpolate
//	for(unsigned int x=minX; x<=maxX-m_gridIncrementUsed; x+=m_gridIncrementUsed){
//		for(unsigned int y=minY; y<=maxY-m_gridIncrementUsed; y+=m_gridIncrementUsed){
//			//check the 4 corners of the box w/ (x,y) at the top left
//			if(segmentationMap[x][y] && segmentationMap[x+m_gridIncrementUsed][y] &&
//				segmentationMap[x][y+m_gridIncrementUsed] &&
//				segmentationMap[x+m_gridIncrementUsed][y+m_gridIncrementUsed])
//
//			{
//				//fill in the box
//				for(unsigned int i=0; i<=m_gridIncrementUsed; i++){
//					for(unsigned int j=0; j<=m_gridIncrementUsed; j++){
//						segmentationMap[x+i][y+j]=true;
//					}
//				}
//			}
//
//			//TODO: other cases (e.g. 3 corners). may or may not be worth it
//
//		}
//	}
//
//	m_segmentationMap = segmentationMap;
//	m_segmentationMapSet = true;
}

std::vector<std::pair<unsigned int, unsigned int> >
PointCloudSegmenter::erodeSegmentationMap(unsigned int numPixels)
{
//	boost::shared_ptr<const boost::multi_array<bool,2> > segmentationMapPtr;
//	this->getSegmentationMap(segmentationMapPtr);

	//try setting up views so that only those need to be copied
//	boost::multi_array<bool,2> segmentationMap = *segmentationMapPtr;
	boost::multi_array<bool,2> tempSegmentationMap(boost::extents[m_xRes][m_yRes]);
	std::fill(tempSegmentationMap.data(),tempSegmentationMap.data()+tempSegmentationMap.num_elements(),false);
	typedef boost::multi_array<bool,2>::index_range range;
	range xRange(m_segmentationMapMinX,m_segmentationMapMaxX+1);
	range yRange(m_segmentationMapMinY,m_segmentationMapMaxY+1);
	boost::multi_array<bool,2>::array_view<2>::type mapView = (*m_segmentationMap)[boost::indices[xRange][yRange]];
	boost::multi_array<bool,2>::array_view<2>::type tempMapView = tempSegmentationMap[boost::indices[xRange][yRange]];

	//perform the erosion
	unsigned int numRemoved = 0;
	for(unsigned int i=0; i<numPixels; i++){
//		boost::multi_array<bool,2> tempSegmentationMap = segmentationMap; //for making changes to
		tempMapView = mapView;
		for(unsigned int x=m_segmentationMapMinX; x<=m_segmentationMapMaxX; x++){
			for(unsigned int y=m_segmentationMapMinY; y<=m_segmentationMapMaxY; y++){
				//if it's already gone, no need to erode it
				if(!tempSegmentationMap[x][y])
					continue;

				bool useXMinus = x > 0;
				bool useXPlus = x < m_xRes-1;
				bool useYMinus = y > 0;
				bool useYPlus = y < m_yRes -1;
				//erode if it doesn't have all the neighbors it should
				bool erodePoint = (useXMinus&&!(*m_segmentationMap)[x-1][y]) ||
						(useXPlus&&!(*m_segmentationMap)[x+1][y]) ||
						(useYMinus&&!(*m_segmentationMap)[x][y-1]) ||
						(useYPlus&&!(*m_segmentationMap)[x][y+1]);

				//set the point to false in the TEMP segmentation map
				if(erodePoint){
					numRemoved++;
					tempSegmentationMap[x][y] = false;
				}
			}
		}
		//update the segmentation map to include the erosion step
//		segmentationMap = tempSegmentationMap;
		mapView = tempMapView;
	}
//	*m_segmentationMap = segmentationMap;

//	std::cout<<"Erosion of "<<numPixels<<" removed "<<numRemoved<<" points"<<std::endl;

	std::vector<std::pair<unsigned int, unsigned int> > toReturn;
	for(unsigned int x=m_segmentationMapMinX; x<=m_segmentationMapMaxX; x++){
		for(unsigned int y=m_segmentationMapMinY; y<=m_segmentationMapMaxY; y++){
			if((*m_segmentationMap)[x][y])
				toReturn.push_back(std::pair<unsigned int,unsigned int>(x,y));
		}
	}

	return toReturn;
}



//sensor_msgs::PointCloud
//PointCloudSegmenter::segmentUsingHandInformation(
//		sensor_msgs::PointCloud const& sourceCloud,
//		std::vector<float> const& estimatedJointAngles,
//		sensor_msgs::PointCloud & colorizedCloud,
//		OpenRAVEInterface *inter,
//		float maxEdgeDist,
//		unsigned int minSegmentSize,
//		float handRemovalDist,
//		float proximityForAdding,
//		float minDistAlongWrist,
//		unsigned int gridIncrement)
//{
//	ros::Time startTime = ros::Time::now();
//
//	//set up the colorized cloud
//	colorizedCloud.set_points_size(0);
//	colorizedCloud.channels.resize(3);
//	colorizedCloud.channels[0].name = "r";
//	colorizedCloud.channels[0].values.resize(0);
//	colorizedCloud.channels[1].name = "g";
//	colorizedCloud.channels[1].values.resize(0);
//	colorizedCloud.channels[2].name = "b";
//	colorizedCloud.channels[2].values.resize(0);
//
//	rgbd::eigen::Vector3f handColor(1.0,0,0);
//	rgbd::eigen::Vector3f objectColor(0,0,1.0);
//
//	unsigned int rayTracingIncrement = 4;
//	unsigned int gridDownsampleIncrement = gridIncrement;
//	float minDistAlongWristToReference = minDistAlongWrist;
//	//hand removal dist can only include this amount of out-of-plane distance
//	float maxOutOfPlaneDist = handRemovalDist/2;
//	bool minFingerClosure = 0.2;  //TODO: may be different on different robots
//
//	sensor_msgs::PointCloud gridDownsampledCloud;
//	gridDownsampledCloud.channels.resize(sourceCloud.get_channels_size());
//	for(unsigned int chan=0; chan<sourceCloud.get_channels_size(); chan++){
//		gridDownsampledCloud.channels[chan].name = sourceCloud.channels[chan].name;
//	}
//	for(unsigned int i=0; i<sourceCloud.points.size(); i++){
//		unsigned int xIndex = sourceCloud.channels[m_xChan].values[i];
//		unsigned int yIndex = sourceCloud.channels[m_yChan].values[i];
//		if(xIndex % gridDownsampleIncrement == 0 && yIndex % gridDownsampleIncrement == 0){
//			gridDownsampledCloud.points.push_back(sourceCloud.points[i]);
//			for(unsigned int chan=0; chan<sourceCloud.get_channels_size(); chan++){
//				gridDownsampledCloud.channels[chan].values.push_back(sourceCloud.channels[chan].values[i]);
//			}
//		}
//	}
//
//	//perform the ray-tracing
//	std::vector<std::vector<rgbd::eigen::Vector3f> > collisionPoints;
//	std::vector<std::vector<rgbd::eigen::Vector3f> > colors;
//	std::vector<std::vector<rgbd::eigen::Vector3f> > normals;
//	std::vector<std::vector<OpenRAVE::KinBody::LinkPtr > > links;
//	std::vector<std::vector<bool> > validityMap;
//	inter->setJointAngles(estimatedJointAngles);
//	inter->sample3dPoints(collisionPoints,colors,links,normals,
//			validityMap,true,rayTracingIncrement);
//
//	//convert to 1D structures
//	std::vector<rgbd::eigen::Vector3f> simulatedPoints;
//	std::vector<rgbd::eigen::Vector3f> validColors;
//	std::vector<rgbd::eigen::Vector3f> validNormals;
//	std::vector<OpenRAVE::KinBody::LinkPtr > pointLinks;
//	inter->convertTo1DVectors(collisionPoints,simulatedPoints,colors,validColors,
//			normals,validNormals,links,pointLinks,validityMap);
//
//	//get the finger tip locations
//	std::vector<rgbd::eigen::Vector3f> fingerTipLocations =
//			inter->getFingerTipLocations(estimatedJointAngles);
//	unsigned int fingerJointStart,fingerJointEnd;
//	inter->getFingerClosureDOFRange(fingerJointStart,fingerJointEnd);
//	//we expect the object to be near the average of the finger tip locations
//	rgbd::eigen::Vector3f referencePt = rgbd::eigen::Vector3f::Zero();
//	//figure out which fingers are actually closed
//	bool fingerClosed[fingerTipLocations.size()];
//	bool anyClosed = false;
//	for(unsigned int i=0; i<fingerTipLocations.size(); i++){
//		bool closed = (estimatedJointAngles[i+fingerJointStart] > minFingerClosure);
//		fingerClosed[i] = closed;
//		if(closed)
//			anyClosed=true;
//	}
//
//	unsigned int numAdded = 0;
//	for(unsigned int i=0; i<fingerTipLocations.size(); i++){
//		if(fingerClosed[i] || !anyClosed){
//			referencePt+=fingerTipLocations[i];
//			numAdded++;
//		}
//	}
//	referencePt/=numAdded;
//
//	//get the wrist COM
//	unsigned int palmLinkNum = inter->getPalmLinkNum();
//	rgbd::eigen::Vector3f wristCOM = inter->getLinkCenterOfMass(estimatedJointAngles,palmLinkNum);
//	rgbd::eigen::Vector3f wristDir = (referencePt-wristCOM).normalized();
//
//
//	//perform hand-removal downsampling
//	ros::Time startRemovalTime = ros::Time::now();
//	cloud_kdtree::KdTreeANN sourceTree(gridDownsampledCloud);
//	std::vector<bool> usePoint(gridDownsampledCloud.points.size(),true);
////	float squaredRadius = handRemovalDist*handRemovalDist;
//	std::deque<unsigned int> downsampledIndices;
//	sensor_msgs::PointCloud downsampledCloud;
//
////	std::cout<<"Performing hand removal downsampling using "<<simulatedPoints.size()
////		<<" hand points and "<<sourceCloud.points.size()<<" target points"<<std::endl;
//
//	//remove near each of the finger tips to cause a disconnect
//	for(unsigned int i=0; i<simulatedPoints.size(); i++){
//
//		geometry_msgs::Point32 center;
//		center.x = simulatedPoints[i].x();
//		center.y = simulatedPoints[i].y();
//		center.z = simulatedPoints[i].z();
//
//		std::vector<int> k_indices;
//		std::vector<float> k_distances;
//		sourceTree.radiusSearch(center,handRemovalDist,k_indices,k_distances);
//
//		for(unsigned int j=0; j<k_indices.size(); j++){
//			int index = k_indices[j];
//			if(usePoint[index]){
//				rgbd::eigen::Vector3f sourcePoint(gridDownsampledCloud.points[index].x,
//						gridDownsampledCloud.points[index].y,gridDownsampledCloud.points[index].z);
//				float outOfPlaneDist = (sourcePoint - simulatedPoints[i]).dot(validNormals[i]);
////				float inPlaneDist = sqrt(k_distances[j]-pow(outOfPlaneDist,2));
//
//				//only remove things that are roughly in the surface plane
//				if(outOfPlaneDist < maxOutOfPlaneDist)
//					usePoint[k_indices[j]] = false;
//			}
//		}
//	}
//
//	for(unsigned int i=0; i<usePoint.size(); i++){
//		if(usePoint[i])
//			downsampledIndices.push_back(i);
//		else{
//			colorizedCloud.points.push_back(gridDownsampledCloud.points[i]);
//			colorizedCloud.channels[0].values.push_back(handColor.x());
//			colorizedCloud.channels[1].values.push_back(handColor.y());
//			colorizedCloud.channels[2].values.push_back(handColor.z());
//		}
//	}
//	downsampleFromIndices(gridDownsampledCloud,downsampledCloud,downsampledIndices);
//	ros::Time endRemovalTime = ros::Time::now();
//	ros::Duration removalDur = endRemovalTime-startRemovalTime;
//	std::cout<<"Hand removal took "<<removalDur.toSec()<<" seconds"<<std::endl;
//
//	//segment the downsampled cloud
//	std::list<sensor_msgs::PointCloud> segments = this->segmentCameraCloud(
//			downsampledCloud,maxEdgeDist,minSegmentSize,gridDownsampleIncrement);
//
//
//	//find the segments close enough to the reference point
//	sensor_msgs::PointCloud toReturn;
//	bool toReturnSet = false;
////	float minDistSeen=0;
//	while(!segments.empty()){
//		//find the minimum distance for the segment
//		float segmentMinDist=0;
//		float maxSegmentWristDist=0;
//		for(unsigned i=0; i<segments.front().points.size(); i++){
//			geometry_msgs::Point32 pt = segments.front().points[i];
//			rgbd::eigen::Vector3f eigenPt(pt.x,pt.y,pt.z);
//			rgbd::eigen::Vector3f refDiff = eigenPt - referencePt;
//			rgbd::eigen::Vector3f wristDiff = eigenPt - wristCOM;
//			float dist = refDiff.norm();
//			float wristDist = wristDiff.dot(wristDir);
//
//			if(i==0 || dist < segmentMinDist){
//				segmentMinDist = dist;
//			}
//			if(i==0 || wristDist > maxSegmentWristDist){
//				maxSegmentWristDist = wristDist;
//			}
//
//			if(segmentMinDist < proximityForAdding &&
//					maxSegmentWristDist > minDistAlongWristToReference)
//				break;
//		}
//		bool add = (segmentMinDist < proximityForAdding &&
//				maxSegmentWristDist > minDistAlongWristToReference);
//
//		//add to the colorized cloud
//		if(add){
//			for(unsigned int i=0; i<segments.front().points.size(); i++){
//				colorizedCloud.points.push_back(segments.front().points[i]);
//				colorizedCloud.channels[0].values.push_back(objectColor.x());
//				colorizedCloud.channels[1].values.push_back(objectColor.y());
//				colorizedCloud.channels[2].values.push_back(objectColor.z());
//			}
//		}
//
//		//compare to previous minDist
//		if(!toReturnSet && add){
//			toReturn = segments.front();
//			toReturnSet = true;
////			minDistSeen = segmentMinDist;
//		}
//		else if(add){
//			mergeClouds(toReturn,segments.front());
//		}
//		segments.pop_front();
//	}
//
//	ros::Time endTime = ros::Time::now();
//	ros::Duration dur = endTime-startTime;
//	std::cout<<"Segmentation took "<<dur.toSec()<<" seconds"<<std::endl;
//
//	m_segmentedCloud = toReturn;
//	m_segmentationDone = true;
//	m_gridIncrementUsed = gridIncrement;
//
//	return toReturn;
//}

std::list<unsigned int>
PointCloudSegmenter::computeConnectedComponentDFS(
		unsigned int xStart,
		unsigned int yStart,
		std::vector<std::vector<bool> > const& hasXPlusLink,
		std::vector<std::vector<bool> > const& hasYPlusLink,
		std::vector<std::vector<unsigned int> > const& pointIndices,
		std::vector<bool> &containedInSegment)
{
	std::list<unsigned int> toReturn;

	//we will always return at least our own index
	toReturn.push_back(pointIndices[xStart][yStart]);
	containedInSegment[pointIndices[xStart][yStart]] = true;

	//check the base case
	bool hasXMinusNeighbor = (xStart > 0 && hasXPlusLink[xStart-1][yStart] && !containedInSegment[pointIndices[xStart-1][yStart]]);
	bool hasXPlusNeighbor = (xStart < hasXPlusLink.size() && hasXPlusLink[xStart][yStart] && !containedInSegment[pointIndices[xStart+1][yStart]]);
	bool hasYMinusNeighbor = (yStart > 0 && hasYPlusLink[xStart][yStart-1] && !containedInSegment[pointIndices[xStart][yStart-1]]);
	bool hasYPlusNeighbor = (yStart < hasYPlusLink[xStart].size() && hasYPlusLink[xStart][yStart] && !containedInSegment[pointIndices[xStart][yStart+1]]);
	//if no non-searched neighbors, bottom out by returning a list of just this point index
	if(!hasXMinusNeighbor && !hasXPlusNeighbor &&
			!hasYMinusNeighbor && !hasYPlusNeighbor)
	{
		return toReturn;
	}

	//typical case: call this method sequentially on each non-searched neighbor

	//x-minus
	hasXMinusNeighbor = (xStart > 0 && hasXPlusLink[xStart-1][yStart] && !containedInSegment[pointIndices[xStart-1][yStart]]);
	if(hasXMinusNeighbor){
		std::list<unsigned int> neighborList = computeConnectedComponentDFS(
				xStart-1,yStart,hasXPlusLink,hasYPlusLink,pointIndices,containedInSegment);
		toReturn.splice(toReturn.begin(),neighborList);
	}

	//x-plus
	hasXPlusNeighbor = (xStart < hasXPlusLink.size() && hasXPlusLink[xStart][yStart] && !containedInSegment[pointIndices[xStart+1][yStart]]);
	if(hasXPlusNeighbor){
		std::list<unsigned int> neighborList = computeConnectedComponentDFS(
				xStart+1,yStart,hasXPlusLink,hasYPlusLink,pointIndices,containedInSegment);
		toReturn.splice(toReturn.begin(),neighborList);
	}

	//y-minus
	hasYMinusNeighbor = (yStart > 0 && hasYPlusLink[xStart][yStart-1] && !containedInSegment[pointIndices[xStart][yStart-1]]);
	if(hasYMinusNeighbor){
		std::list<unsigned int> neighborList = computeConnectedComponentDFS(
				xStart,yStart-1,hasXPlusLink,hasYPlusLink,pointIndices,containedInSegment);
		toReturn.splice(toReturn.begin(),neighborList);
	}

	//y-plus
	hasYPlusNeighbor = (yStart < hasYPlusLink[xStart].size() && hasYPlusLink[xStart][yStart] && !containedInSegment[pointIndices[xStart][yStart+1]]);
	if(hasYPlusNeighbor){
		std::list<unsigned int> neighborList = computeConnectedComponentDFS(
				xStart,yStart+1,hasXPlusLink,hasYPlusLink,pointIndices,containedInSegment);
		toReturn.splice(toReturn.begin(),neighborList);
	}


	return toReturn;

}

}
