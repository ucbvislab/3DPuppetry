/*
 * extract_and_transform:
 * takes a depth map+image, runs image_and_depth_to_cloud, then applies a transform
 *
 * Mike Krainin
 * 8 / 4 / 10
 */

#include <ros/ros.h>
#include <rgbd_msgs/DepthMap.h>
#include <sensor_msgs/Image.h>
#include <pcl/point_cloud.h>
#include <pcl_ros/publisher.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include "pcl_rgbd/pointTypes.h"
#include "pcl_rgbd/depth_to_cloud_lib.h"
#include "pcl_rgbd/cloudUtils.h"

#include "rgbd_util/eigen/Core"
#include "rgbd_util/eigen/Geometry"
#include "xforms/xforms.h"

#include <tf/tfMessage.h>
#include <tf/transform_listener.h>

typedef rgbd::pt PointT;

pcl_ros::Publisher<PointT> cloud_pub;
bool include_xy_channels;
bool publish_all_points;
int subscription_buffer_size;

std::string image_chan, depth_chan, cloud_chan;
rgbd::eigen::Transform3f transform;

void callback(const sensor_msgs::ImageConstPtr& image_msg, const rgbd_msgs::DepthMapConstPtr& depth_msg) {

	pcl::PointCloud<PointT> result;
	const bool ok = image_and_depth_to_cloud<PointT>(image_msg, depth_msg, include_xy_channels, publish_all_points, result);
	if(!ok) ROS_WARN_STREAM("depth_to_cloud failed");
	else{
		rgbd::transform_point_cloud_in_place(transform,result,false);
		cloud_pub.publish(result);
	}
}

int main(int argc, char **argv) {
    ros::init(argc, argv, "extract_and_transform");

    ros::NodeHandle nh;
    ros::NodeHandle nh_local("~");

    nh_local.param("publish_all_points", publish_all_points, false);
    nh_local.param("include_xy_channels", include_xy_channels, false);
    nh_local.param("subscription_buffer_size", subscription_buffer_size, 1);

    nh_local.param("image_channel", image_chan, (std::string)"image");
    nh_local.param("depth_channel", depth_chan, (std::string)"depth");
    nh_local.param("cloud_channel", cloud_chan, (std::string)"cloud");

    bool transformFromTf;
    nh_local.param("transform_from_tf", transformFromTf, false);
    if(transformFromTf){
    	bool transform_set = false;
    	tf::TransformListener tfListener;
		tf::StampedTransform tfTransform;
		while(!transform_set){
			try{
				tfListener.lookupTransform("/wam0", "/primesensor_frame",
						ros::Time(0), tfTransform);
				transform_set = true;
			}
			catch (tf::TransformException ex){
				ROS_WARN("Lookup transform failed");
				sleep(1);
			}
		}
		ROS_INFO("Transform lookup succeeded");

		geometry_msgs::Transform geomTransform;
		tf::transformTFToMsg(tfTransform,geomTransform);
		xf::convert_geometry_msg_to_eigen_transform(geomTransform,transform);
    }
    else{
		double qw,qx,qy,qz,tx,ty,tz;
		nh_local.param("qw", qw, 1.0);
		nh_local.param("qx", qx, 0.0);
		nh_local.param("qy", qy, 0.0);
		nh_local.param("qz", qz, 0.0);
		nh_local.param("tx", tx, 0.0);
		nh_local.param("ty", ty, 0.0);
		nh_local.param("tz", tz, 0.0);
		transform = rgbd::eigen::Quaternionf(qw,qx,qy,qz);
		transform.pretranslate(rgbd::eigen::Vector3f(tx,ty,tz));
    }

    message_filters::Subscriber<sensor_msgs::Image> image_sub(nh, image_chan, subscription_buffer_size);
    message_filters::Subscriber<rgbd_msgs::DepthMap> depth_sub(nh, depth_chan, subscription_buffer_size);
    cloud_pub.advertise(nh, cloud_chan, 1);

    message_filters::TimeSynchronizer<sensor_msgs::Image, rgbd_msgs::DepthMap> sync(image_sub, depth_sub, 100);

    sync.registerCallback(boost::bind(&callback, _1, _2));

    ros::spin();
    return 0;
}

