/*
 * segmentation_utility.cpp
 *
 *  Created on: Jan 14, 2011
 *      Author: peter
 */


#include "segmentation/segmentation_utility.h"

namespace segmentation {

void removeInlierIndices(
		const std::vector<int> & indices,
		const std::vector<int> & inlier_indices,
		std::vector<int> & result)
{
	int max_index = *std::max_element(indices.begin(), indices.end());
	removeInlierIndices(indices, inlier_indices, max_index, result);
}

void removeInlierIndices(
		const std::vector<int> & indices,
		const std::vector<int> & inlier_indices,
		int max_index,
		std::vector<int> & result)
{
	std::vector<bool> useIndex(max_index,false);
	for(unsigned int i=0; i<indices.size(); i++)
		useIndex[indices[i]] = true;
	for(unsigned int i=0; i<inlier_indices.size(); i++)
		useIndex[inlier_indices[i]] = false;
	result.clear();
	for(unsigned int i=0; i <max_index; i++)
		if(useIndex[i])
			result.push_back(i);
}

std_msgs::ColorRGBA getRandomColor(float alpha) {
	std_msgs::ColorRGBA result;
	result.a = alpha;
	result.r = rand() / (float)RAND_MAX;
	result.g = rand() / (float)RAND_MAX;
	result.b = rand() / (float)RAND_MAX;
	return result;
}


} // ns
