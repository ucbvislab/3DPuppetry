/*
 * post_processor.cpp
 */

#include "rgbd_util/eigen/Core"
#include "rgbd_util/eigen/Geometry"

#include <pcl/point_cloud.h>
#include <pcl_rgbd/pointTypes.h>
#include <pcl_rgbd/cloudSampling.h>
#include <pcl_rgbd/cloudUtils.h>
#include <pcl_rgbd/cloudTofroPLY.h>


#include <vector>
#include <string>


int main (int argc, char** argv)
{
	std::string in_file = "/pr/mkrainin/surfel_cloud.ply";
	std::string out_file = "/pr/mkrainin/surfel_cloud_filtered.ply";
	sensor_msgs::PointCloud2 cloud2,cloud3;
	pcl::PointCloud<rgbd::surfelPt> cloud,downsampled;
	rgbd::read_ply_file(cloud2,in_file);
	rgbd::packColorChannels("diffuse_red","diffuse_green","diffuse_blue",cloud2,cloud3);
	pcl::fromROSMsg(cloud3,cloud);
	std::vector<unsigned int> indices = rgbd::getRadiusDownsamplingIndices(
			cloud,rgbd::eigen::Vector3f(.04,-.08,.85),0.2,true);
	rgbd::downsampleFromIndices(cloud,downsampled,indices);
	rgbd::write_ply_file(downsampled,out_file);
}
