/*
 * table_object_segmentation_node.cpp
 *
 * Provides a service for taking in a point cloud, transforming to
 * global coordinates, removing planes, then returning the largest remaining
 * object plus the parameters for the most "table-like" plane
 *
 *  Created on: 2010-08-17
 *      Author: mkrainin
 */

#include <ros/ros.h>
#include <ros/service.h>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/point_cloud_conversion.h>
#include <pcl/point_cloud.h>
#include <pcl_ros/publisher.h>
#include "pcl_rgbd/pointTypes.h"
#include "pcl_rgbd/cloudUtils.h"
#include <segmentation/PointCloudSegmenter.h>
#include <segmentation/segmentation_utility.h>
#include <point_cloud_segmentation/TableSegmentationRequest.h>

#include "rgbd_util/eigen/Core"
#include "rgbd_util/eigen/Geometry"
#include "xforms/xforms.h"

#include <tf/tfMessage.h>
#include <tf/transform_listener.h>

class TableSegmentation{

public:
	TableSegmentation()
	:nh_local("~")
	{
	    //read in parameters
	    nh_local.param("cloud_channel", in_chan, (std::string)"cloud");

	    //pose of camera in global coords
	    m_transformSet = false;
	    nh_local.param("transform_from_tf", m_transformFromTf, false);
	    if(!m_transformFromTf){
			double qw,qx,qy,qz,tx,ty,tz;
			nh_local.param("qw", qw, 1.0);
			nh_local.param("qx", qx, 0.0);
			nh_local.param("qy", qy, 0.0);
			nh_local.param("qz", qz, 0.0);
			nh_local.param("tx", tx, 0.0);
			nh_local.param("ty", ty, 0.0);
			nh_local.param("tz", tz, 0.0);
			transform = rgbd::eigen::Quaternionf(qw,qx,qy,qz);
			transform.pretranslate(rgbd::eigen::Vector3f(tx,ty,tz));
			m_transformSet = true;
	    }

	    m_xRes = 640;
	    m_yRes = 480;
	    m_segmenter.setResolution(m_xRes,m_yRes);

	    double maxAngle;
	    nh_local.param("max_iterations", m_maxIterations, 1000);
	    nh_local.param("max_out_of_plane", m_maxOutOfPlane, .015);
	    nh_local.param("min_image_frac", m_minImageFrac, .15);
	    nh_local.param("max_table_angle", maxAngle, 10.0);
	    nh_local.param("max_radius", m_maxRadius, 1.2);
    	nh_local.param("max_combining_dist", m_maxSegmentDist, .05);
    	m_maxTableAngle = maxAngle*M_PI/180;

    	m_setNormals = true;
	}

	~TableSegmentation(){}

	void start()
	{
	    ros::Subscriber cloud_sub = nh.subscribe<sensor_msgs::PointCloud2>(
				in_chan,1,&TableSegmentation::callback,this);

	    ros::ServiceServer service = nh_local.advertiseService(
	    		"table_segmentation",&TableSegmentation::processRequest,this);

	    if(m_transformFromTf)
	    	this->lookupTransform("/wam0","/openni_rgb_optical_frame");

	    ROS_INFO("Ready to process requests");
	    ros::spin();
	}


private:
	typedef rgbd::pt PointT;

    ros::NodeHandle nh, nh_local;

    bool m_transformFromTf, m_transformSet;
	std::string in_chan;
	rgbd::eigen::Transform3f transform;
	tf::TransformListener m_tfListener;

	sensor_msgs::PointCloud2ConstPtr current_cloud_ptr;

    segmentation::PointCloudSegmenter m_segmenter;
    unsigned int m_xRes, m_yRes;

    //plane fitting params
	int m_maxIterations;
	double m_maxOutOfPlane;
	double m_minImageFrac;
	double m_maxTableAngle;

	//object segmentation params
	double m_maxRadius;
    double m_maxSegmentDist;

    bool m_setNormals;

    boost::mutex mutex;

    void lookupTransform(std::string const& base_id, std::string const& sensor_id)
    {
    	if(m_transformSet)
    		return;

		tf::StampedTransform tfTransform;
		while(!m_transformSet && nh_local.ok()){
			try{
				m_tfListener.lookupTransform(base_id, sensor_id, ros::Time(0), tfTransform);
				m_transformSet = true;
			}
			catch (tf::TransformException ex){
				ROS_WARN("Lookup transform failed between %s and %s",base_id.c_str(), sensor_id.c_str());
				usleep(100000);
			}
		}

		geometry_msgs::Transform geomTransform;
		tf::transformTFToMsg(tfTransform,geomTransform);
		xf::convert_geometry_msg_to_eigen_transform(geomTransform,transform);
    }

	void callback(const sensor_msgs::PointCloud2ConstPtr& cloud_msg)
	{
		boost::unique_lock<boost::mutex> lock(mutex);
		if(!current_cloud_ptr)
			ROS_INFO("Got first cloud");
		current_cloud_ptr = cloud_msg;
	}

	bool processRequest(
			point_cloud_segmentation::TableSegmentationRequest::Request &request,
			point_cloud_segmentation::TableSegmentationRequest::Response &response)
	{
		boost::unique_lock<boost::mutex> lock(mutex);
		if(!current_cloud_ptr){
			ROS_WARN("No data yet");
			return false;
		}

		if(m_transformFromTf && !m_transformSet)
			this->lookupTransform("/wam0",current_cloud_ptr->header.frame_id);

		double maxDist = m_maxOutOfPlane;
		int maxIts = m_maxIterations;
		double minFractionOfImage = m_minImageFrac;
		unsigned int minPlaneSize = m_xRes*m_yRes*minFractionOfImage;
		float maxAngle = m_maxTableAngle;//10*M_PI/180;
		float maxRadius = m_maxRadius;
		float maxEdgeDist = .01;
		unsigned int minSegmentSize = 400;

		pcl::PointCloud<PointT>::Ptr cloud(new pcl::PointCloud<PointT>());
		if(rgbd::cloudHasField(*current_cloud_ptr,"imgX")){
			//simple conversion
			pcl::fromROSMsg(*current_cloud_ptr,*cloud);
		}
		else
		{
			//xyzrgb then pointt
			cloud = rgbd::convertKinectCloudType<PointT>(*current_cloud_ptr);
		}
		ROS_INFO("Got cloud with %i points",cloud->points.size());

		//start by transforming the cloud
		rgbd::transform_point_cloud_in_place(transform,*cloud,false); //transform normals false

		//list of all indices from which we'll subtract extracted planes
		std::vector<int> indices;
		for(int i=0; i<(int) cloud->points.size(); i++)
			indices.push_back(i);

		//TODO: MARK COEFFS AND CLOUDS AS BEING IN WAM0 COORDS

		//extract planes
		pcl::ModelCoefficients mostTableishCoeffs; //highest plane having normal close to z
		float highestZ = -1e10;
		mostTableishCoeffs.header = cloud->header;
		mostTableishCoeffs.values.resize(4);
		while(indices.size() > minPlaneSize){
			//fit the plane
			std::vector<int> inliers;
			std::vector<double> coefs;
			segmentation::fitSACPlane<PointT>(cloud,indices,inliers,coefs,maxDist,maxIts);
			ROS_INFO("Inliers.size(): %i",inliers.size());

			//check stopping criteria
			if(inliers.size() > minPlaneSize){
				//remove the plane from indices
				subtractIndices(indices,inliers,cloud->points.size());

				//check table-ness
				rgbd::eigen::Vector3f normal(coefs[0],coefs[1],coefs[2]);
				float dot = normal.dot(rgbd::eigen::Vector3f::UnitZ());
				if(fabs(dot) > 1) dot/=fabs(dot);
				float angle = acos(fabs(dot));

				ROS_DEBUG("Plane has coefs: %f, %f, %f, %f",coefs[0],coefs[1],coefs[2],coefs[3]);
				ROS_DEBUG("Plane has angle %f",angle*180/M_PI);

				if(angle < maxAngle){
					float zIntercept = -coefs[3]/coefs[2];
					if(zIntercept > highestZ){
						highestZ = zIntercept;
						if(dot < 0) for(unsigned int i=0; i<4; i++) coefs[i]*=-1; //flip normal if needed
						for(unsigned int i=0; i<4; i++) mostTableishCoeffs.values[i] = coefs[i];
					}
				}
			}
			else{
				break;
			}
		}

		//also make a cloud for what remains
		pcl::PointCloud<PointT> remainder;
		std::deque<unsigned int> remainderIndexDeque;
		toUnsignedDeque(indices,remainderIndexDeque);
		rgbd::downsampleFromIndices(*cloud,remainder,remainderIndexDeque);

		//segment the remainder
		//start with a distance removal
		pcl::PointCloud<PointT> radiusDownsampledCloud, aboveTableCloud;
		std::vector<unsigned int> acceptedIndices = rgbd::getRadiusDownsamplingIndices(
				remainder,rgbd::eigen::Vector3f::Zero(),maxRadius,true);
		rgbd::downsampleFromIndices(remainder,radiusDownsampledCloud,acceptedIndices);

		//now remove anything below the table height
		acceptedIndices.clear();
		float camVal = mostTableishCoeffs.values[0]*transform.translation().x() +
				mostTableishCoeffs.values[1]*transform.translation().y() +
				mostTableishCoeffs.values[2]*transform.translation().z() +
				mostTableishCoeffs.values[3];
		for(unsigned int i=0; i<radiusDownsampledCloud.points.size(); i++){
			float ptVal = mostTableishCoeffs.values[0]*radiusDownsampledCloud.points[i].x +
				mostTableishCoeffs.values[1]*radiusDownsampledCloud.points[i].y +
				mostTableishCoeffs.values[2]*radiusDownsampledCloud.points[i].z +
				mostTableishCoeffs.values[3];
			if(ptVal * camVal > 0) //on same side of table plane
				acceptedIndices.push_back(i);
		}
		rgbd::downsampleFromIndices(radiusDownsampledCloud,aboveTableCloud,acceptedIndices);

		//set normals in the cloud if desired
		if(m_setNormals && aboveTableCloud.points.size() > 10){
			geometry_msgs::Point32 origin;
			origin.x = transform.translation().x();
			origin.y = transform.translation().y();
			origin.z = transform.translation().z();
			rgbd::computePointCloudNormals(aboveTableCloud,40,origin);
		}

		std::vector<pcl::PointCloud<PointT>::Ptr > segments;
		
		if(aboveTableCloud.points.size() > 10)
			segments  = m_segmenter.segmentCameraCloud(
				aboveTableCloud,maxEdgeDist,minSegmentSize,1);

		unsigned int cloudIndex1 = 0;
		unsigned int cloudIndex2 = 1;
		while(true){
			if(cloudIndex1 >= segments.size())
				break;
			if(cloudIndex2 >= segments.size()){
				cloudIndex1++;
				cloudIndex2 = cloudIndex1 + 1;
				continue;
			}

			bool shouldMerge = this->shouldMergeSegments<PointT>(segments,cloudIndex1,cloudIndex2);
			if(shouldMerge){
				this->mergeSegments<PointT>(segments,cloudIndex1,cloudIndex2);
				//cloudIndex1 will still point to the same segment (now bigger)
				//and cloudIndex2 will point to the segment after the one
				//that was cloudIndex2, so we don't need to update any indices
			}
			else{
				cloudIndex2++;
			}
		}

		//find the largest
		unsigned int largestSize = 0;
		unsigned int largestIndex = 0;
		for(unsigned int i=0; i<segments.size(); i++){
			unsigned int size = segments[i]->points.size();
			if(i==0 || size > largestSize){
				largestSize = size;
				largestIndex = i;
			}
		}


		//fill in the response
		if(aboveTableCloud.points.size() > 10 && !segments.empty()){
			//largest segment
			sensor_msgs::PointCloud2 largest2,largest3;
			pcl::toROSMsg(*(segments[largestIndex]),largest2);
			largest3 = largest2;
			rgbd::convertFieldType<unsigned int,float>("imgX", largest2, largest3);
			rgbd::convertFieldType<unsigned int,float>("imgY", largest3, largest2);
			sensor_msgs::convertPointCloud2ToPointCloud(largest2,response.object);
			//all segments
			sensor_msgs::PointCloud2 remainder2,remainder3;
			pcl::toROSMsg(aboveTableCloud,remainder2);
			remainder3 = remainder2;
			rgbd::convertFieldType<unsigned int,float>("imgX", remainder2, remainder3);
			rgbd::convertFieldType<unsigned int,float>("imgY", remainder3, remainder2);
			sensor_msgs::convertPointCloud2ToPointCloud(remainder2,response.on_table);
		}

		response.plane_coeffs = mostTableishCoeffs;

		return true;
	}

    void subtractIndices(std::vector<int> & indices, std::vector<int> & toRemove,
    		unsigned int maxIndex)
    {
    	std::vector<bool> useIndex(maxIndex,false);
    	for(unsigned int i=0; i<indices.size(); i++)
    		useIndex[indices[i]] = true;
    	for(unsigned int i=0; i<toRemove.size(); i++)
    		useIndex[toRemove[i]] = false;

    	//construct the output
    	indices.clear();
    	for(unsigned int i=0;i <maxIndex; i++)
    		if(useIndex[i])
    			indices.push_back(i);
    }

    /**
     * Converts a vector of ints to a deque of unsigned ints
     *
     * @param intVec
     * @param unsignedDeque
     */
    void toUnsignedDeque(std::vector<int> const& intVec, std::deque<unsigned int> & unsignedDeque){
    	unsignedDeque.clear();
    	for(unsigned int i=0;i <intVec.size(); i++)
    		unsignedDeque.push_back((unsigned int)intVec[i]);
    }

    template <typename PointT>
    std::vector<rgbd::eigen::Vector3f> getEdgePoints(pcl::PointCloud<PointT> const& cloud)
    {
    	std::vector<rgbd::eigen::Vector3f> edgePoints;

    	std::vector<bool> falses(m_yRes,false);
    	std::vector<std::vector<bool> > isOccupied(m_xRes,falses);

    	for(unsigned int i=0; i< cloud.points.size(); i++){
    		isOccupied[cloud.points[i].imgX][cloud.points[i].imgY] = true;
    	}

    	for(unsigned int i=0; i< cloud.points.size(); i++){
    		bool isEdge = false;
    		int x = cloud.points[i].imgX;
    		int y = cloud.points[i].imgY;
    		if(x-1 > 0 && !isOccupied[x-1][y])
    			isEdge = true;
    		else if(y-1 > 0 && !isOccupied[x][y-1])
    			isEdge = true;
    		else if(x+1 < (int)m_xRes && !isOccupied[x+1][y])
    			isEdge = true;
    		else if(y+1 < (int)m_yRes && !isOccupied[x][y+1])
    			isEdge = true;

    		if(isEdge){
    			PointT const& pt = cloud.points[i];
    			edgePoints.push_back(rgbd::eigen::Vector3f(pt.x,pt.y,pt.z));
    		}
    	}

    	return edgePoints;
    }

    template <typename PointT>
    bool shouldMergeSegments(std::vector<typename pcl::PointCloud<PointT>::Ptr > const& segments,
    		unsigned int segmentIndex1, unsigned int segmentIndex2)
    {
    	float maxSquaredDist = pow(m_maxSegmentDist,2);

    	std::vector<rgbd::eigen::Vector3f> seg1EdgePts = this->getEdgePoints(*(segments[segmentIndex1]));
    	std::vector<rgbd::eigen::Vector3f> seg2EdgePts = this->getEdgePoints(*(segments[segmentIndex2]));

    	for(unsigned int index1 = 0; index1 < seg1EdgePts.size(); index1++){
        	for(unsigned int index2 = 0; index2 < seg2EdgePts.size(); index2++){
        		if((seg1EdgePts[index1]-seg2EdgePts[index2]).squaredNorm() < maxSquaredDist)
        			return true;
        	}
    	}

    	return false;
    }

    template <typename PointT>
    void mergeSegments(std::vector<typename pcl::PointCloud<PointT>::Ptr > & segments,
    		unsigned int segmentIndex1, unsigned int segmentIndex2)
    {
    	rgbd::mergeInPlace(*segments[segmentIndex2], *segments[segmentIndex1]);
    	segments.erase(segments.begin()+segmentIndex2);
    }

};

int main(int argc, char **argv) {
    ros::init(argc, argv, "extract_and_transform");
    TableSegmentation segmentation;
    segmentation.start();
    return 0;
}
