/*
 * block_modeler_node.cpp
 *
 *  Created on: 2010 SApril
 *      Author: cynthia
 *
 *  Based on planar_extraction_node.cpp, and currently contains lots of duplication.
 *  @todo clean up duplicate functions
 *  @todo actually extract blocks.
 */






// NOTE: commented out block_modeler_node from CMakeLists.txt until it
// can be converted over to pcl (MK, 7/16/10)







//#include <ros/ros.h>
#include <visualization_msgs/Marker.h>

#include <ros/node_handle.h>
#include <ros/publisher.h>
#include <ros/subscriber.h>
#include <geometry_msgs/Point.h>
#include <geometry_msgs/PointStamped.h>
#include <sensor_msgs/PointCloud.h>
#include "rgbd_util/eigen/Core"
#include "rgbd_util/eigen/Geometry"
#include <point_cloud_mapping/cloud_io.h>
#include <point_cloud_mapping/cloud_geometry.h>
#include <rgbd_msgs/PointCloudArray.h>

#include <point_cloud_icp/registration/icp_utility.h>
//#include "xforms/xforms.h"
//#include "point_clouds/cloudUtils.h"
#include "point_cloud_icp/registration/icp_utility.h"
#include "point_cloud_icp/registration/icp_combined.h"
#include <boost/make_shared.hpp>

#ifdef ENABLE_OLD_CLOUDS
#include "point_clouds/cloudUtils.h"
#include "point_clouds/cloudSearchTrees.h"
#include "point_clouds/cloudTofroPLY.h"
#include "point_clouds/cloudNormals.h"
#endif

#include <segmentation/PointCloudSegmenter.h>

#include <roslib/Header.h>
#include <vector>
#include <string>
#include <deque>


class BlockModeler
{
protected:
	ros::NodeHandle nh_global;
	ros::NodeHandle nh_local;

	//publishers
	ros::Publisher m_planesPublisher;
	ros::Publisher m_cameraDataPublisher;
	ros::Publisher m_markerPublisher;
	ros::Publisher m_cubeCloudPublisher;

	//subscribers
	std::string m_cloudSubscriberTopic;
	ros::Subscriber m_cloudSubscriber;

	unsigned int m_xRes,m_yRes;

	double m_maxOutOfPlane;
	int m_maxIterations;
	int m_gridIncrement;

	double m_blockEdgeLength;
	double m_pointSeparation;

	double m_minImageFrac;	//Reject planes smaller than this
	double m_maxImageFrac;	//Reject planes larger than this
	double m_maxArea;		//reject planes larger than this

public:

	BlockModeler ()
	: nh_global(),
	  nh_local("~")
	{
		std::string planesTopic,remainderTopic;
		nh_local.param("planes_topic", planesTopic, std::string("/rgbd/planes"));
		nh_local.param("remainder_topic", remainderTopic, std::string("/rgbd/remainder"));
		nh_local.param("subscriber_topic", m_cloudSubscriberTopic, std::string("/rgbd/cloud"));

		nh_local.param("max_out_of_plane_dist", m_maxOutOfPlane, .006); //cut off less block with table
		nh_local.param("max_iterations", m_maxIterations, 3000);
		nh_local.param("grid_downsample_increment", m_gridIncrement, 1);

		nh_local.param("plane_min_image_frac", m_minImageFrac, .001); //tiny because we want to find cube faces
		nh_local.param("plane_max_image_frac", m_maxImageFrac, .10);  //still want to ditch large planes like tables
		nh_local.param("plane_max_size", m_maxArea, 0.003);

		// Maximum number of outgoing messages to be queued for delivery to subscribers = 1
		m_planesPublisher = nh_global.advertise<rgbd_msgs::PointCloudArray> (planesTopic, 1);
		m_cameraDataPublisher = nh_global.advertise<sensor_msgs::PointCloud> (remainderTopic, 1);
		m_markerPublisher = nh_global.advertise<visualization_msgs::Marker> ("visualization_marker", 1);
		m_cubeCloudPublisher = nh_global.advertise<sensor_msgs::PointCloud> ("cube_cloud", 1);

		m_xRes = 640;
		m_yRes = 480;

		m_blockEdgeLength = 0.047; //4.7cm
		m_pointSeparation = 0.0015; //1.5mm

	}

	~BlockModeler()
	{
	}

	/**
	* Removes indices from a vector
	*
	* @param indices
	* @param toRemove
	* @param maxIndex
	*/
	void subtractIndices(std::vector<int> & indices, std::vector<int> & toRemove,
			unsigned int maxIndex)
	{
		std::vector<bool> useIndex(maxIndex,false);
		for(unsigned int i=0; i<indices.size(); i++)
			useIndex[indices[i]] = true;
		for(unsigned int i=0; i<toRemove.size(); i++)
			useIndex[toRemove[i]] = false;

		//construct the output
		indices.clear();
		for(unsigned int i=0;i <maxIndex; i++)
			if(useIndex[i])
				indices.push_back(i);
	}

	/**
	* Converts a vector of ints to a deque of unsigned ints
	*
	* @param intVec
	* @param unsignedDeque
	*/
	void toUnsignedDeque(std::vector<int> const& intVec, std::deque<unsigned int> & unsignedDeque){
		unsignedDeque.clear();
		for(unsigned int i=0;i <intVec.size(); i++)
			unsignedDeque.push_back((unsigned int)intVec[i]);
	}

	/**
	* Returns a grid indexed by x and y which gives the index into the original
	* cloud for the point at that location. -1 indicates no point
	*
	* @param cloud
	* @param cloudIndexGrid
	*/
	void getIndexGrid(const sensor_msgs::PointCloud::ConstPtr &cloud,
			std::vector<std::vector<int> > &cloudIndexGrid)
	{
		std::vector<int> invalidMarkers(m_yRes,-1);
		cloudIndexGrid = std::vector<std::vector<int> >(m_xRes,invalidMarkers);

		unsigned int xChan = rgbd::get_channel_index(*cloud,"image_x");
		unsigned int yChan = rgbd::get_channel_index(*cloud,"image_y");

		for(int i=0; i<(int) cloud->points.size(); i++){
			int x = cloud->channels[xChan].values[i];
			int y = cloud->channels[yChan].values[i];
			cloudIndexGrid[x][y] = i;
		}
	}

	/**
	* Returns just the subset of indices which lie on a sub-grid of the full
	* image grid
	*
	* @param cloud
	* @param indices
	* @param downsampledIndices
	* @param gridIncrement
	*/
	void gridDownsampleIndices(const sensor_msgs::PointCloud::ConstPtr &cloud,
			std::vector<int> const& indices, std::vector<int> & downsampledIndices,
			unsigned int gridIncrement)
	{
		unsigned int xChan = rgbd::get_channel_index(*cloud,"image_x");
		unsigned int yChan = rgbd::get_channel_index(*cloud,"image_y");

		downsampledIndices.clear();
		for(unsigned int i=0; i<indices.size(); i++)
		{
			int x = cloud->channels[xChan].values[indices[i]];
			int y = cloud->channels[yChan].values[indices[i]];

			if(x % gridIncrement == 0 && y % gridIncrement == 0)
				downsampledIndices.push_back(indices[i]);
		}
	}

	/**
	* Returns a list of indices upsampled from the one provided. This is done
	* by seeing if the indices not on the subgrid have neighbors in the list
	* and if so, whether or not there is too much of a depth difference
	*
	* @param cloud
	* @param cloudIndexGrid
	* @param indices
	* @param upsampledIndices
	* @param gridIncrement
	* @param numNeighborsNeeded
	*/
	void upsampleIndices(const sensor_msgs::PointCloud::ConstPtr &cloud,
			std::vector<std::vector<int> > const& cloudIndexGrid,
			std::vector<int> const& indices, std::vector<int> & upsampledIndices,
			unsigned int gridIncrement, unsigned int numNeighborsNeeded)
	{
		float maxZDiff = .01;

		unsigned int xChan = rgbd::get_channel_index(*cloud,"image_x");
		unsigned int yChan = rgbd::get_channel_index(*cloud,"image_y");

		std::vector<bool> indicesHasIndex(cloud->points.size(),false);
		for(unsigned int i=0; i<indices.size(); i++)
			indicesHasIndex[indices[i]] = true;

		upsampledIndices.clear();
		for(int i=0; i<(int) cloud->points.size(); i++){
			if(indicesHasIndex[i])
				upsampledIndices.push_back(i);

			int x = cloud->channels[xChan].values[i];
			int y = cloud->channels[yChan].values[i];

			unsigned int numNeighbors = 0;
			int xMinus = x - x%gridIncrement;
			int yMinus = y - y%gridIncrement;

			//on part of grid that was looked at but not in indices
			if(x % gridIncrement == 0 && y % gridIncrement == 0)
				continue;

			//check each of the 4 neighbors
			if(cloudIndexGrid[xMinus][yMinus] >= 0 && indicesHasIndex[cloudIndexGrid[xMinus][yMinus]])
			{
				float zDiff = fabs(cloud->points[i].z - cloud->points[cloudIndexGrid[xMinus][yMinus]].z);
				if(zDiff < maxZDiff)
					numNeighbors++;
			}
			if(xMinus+gridIncrement < m_xRes && cloudIndexGrid[xMinus+gridIncrement][yMinus] >= 0 &&
					indicesHasIndex[cloudIndexGrid[xMinus+gridIncrement][yMinus]])
			{
				float zDiff = fabs(cloud->points[i].z - cloud->points[cloudIndexGrid[xMinus+gridIncrement][yMinus]].z);
				if(zDiff < maxZDiff)
					numNeighbors++;
			}
			if(yMinus+gridIncrement < m_yRes && cloudIndexGrid[xMinus][yMinus+gridIncrement] >= 0 &&
					indicesHasIndex[cloudIndexGrid[xMinus][yMinus+gridIncrement]])
			{
				float zDiff = fabs(cloud->points[i].z - cloud->points[cloudIndexGrid[xMinus][yMinus+gridIncrement]].z);
				if(zDiff < maxZDiff)
					numNeighbors++;
			}
			if(xMinus+gridIncrement < m_xRes && yMinus+gridIncrement < m_yRes &&
					cloudIndexGrid[xMinus+gridIncrement][yMinus+gridIncrement] >= 0&&
					indicesHasIndex[cloudIndexGrid[xMinus+gridIncrement][yMinus+gridIncrement]])
			{
				float zDiff = fabs(cloud->points[i].z - cloud->points[cloudIndexGrid[xMinus+gridIncrement][yMinus+gridIncrement]].z);
				if(zDiff < maxZDiff)
					numNeighbors++;
			}

			if(numNeighbors >= numNeighborsNeeded)
				upsampledIndices.push_back(i);

		}
	}

	/**
	* Performs the planar extraction and creates a point cloud array of planes;
	* trampolines through to something that finds blocks from plane list.
	*
	* @param cloud
	* @todo REFACTOR.  Instead of making things into planes, then combining them
	* elsewhere for the segmenting, then replaning them (which could cause trouble),
	* instead just remove the giant planes to begin with.
	*/
	void extractPlanes(const sensor_msgs::PointCloud::ConstPtr &cloud)
	{
		double maxDist = m_maxOutOfPlane;
		int maxIts = m_maxIterations;
		//REQUIRED FOR SAMPLING
		//int gridIncrement = m_gridIncrement;

		double minFractionOfImage = m_minImageFrac;
		unsigned int minPlaneSize = m_xRes*m_yRes*minFractionOfImage;

		//@todo get rid of little bitty bits of plane (or segments) and this can be less absurdly precise
		double inlierRadius = 0.90;

		ros::Time startTime = ros::Time::now();

		//remove points outside certain radius from camera
		std::deque<unsigned int> indicesWithinSphere;
		indicesWithinSphere = registration::getRadiusDownsamplingIndices(*cloud, rgbd::eigen::Vector3f::Zero(), inlierRadius, true);
		sensor_msgs::PointCloud::Ptr downsampledCloud(new sensor_msgs::PointCloud());
		registration::downsampleFromIndices(*cloud, *downsampledCloud, indicesWithinSphere);

		//set the initial set of indices as everything
		std::vector<int> allIndices;
		for(int i=0; i<(int) downsampledCloud->points.size(); i++)
			allIndices.push_back(i);

		//grid downsample indices
		//REQUIRED FOR SAMPLING
		//   -- @todo test and see what this buys/costs, efficiency/accuracy --Cyy 2010 April
		//std::vector<int> downsampledIndices;

		//REQUIRED FOR SAMPLING
		//gridDownsampleIndices(downsampledCloud,allIndices,downsampledIndices,gridIncrement);
		std::vector<int> downsampledIndices = allIndices; //instead of downsampling

		//make a grid to be used during the interpolation step
		//REQUIRED FOR SAMPLING
		//std::vector<std::vector<int> > cloudIndexGrid;
		//getIndexGrid(downsampledCloud,cloudIndexGrid);

		//extract planes
		rgbd_msgs::PointCloudArray planes;
		while(true){
			//fit the plane
			std::vector<int> inliers;
			std::vector<double> coefs;
			registration::fitSACPlane(downsampledCloud.get(),downsampledIndices,inliers,coefs,maxDist,maxIts);

			//construct a cloud for the new plane
			sensor_msgs::PointCloud newPlane;
			std::vector<int> upsampledPlaneIndices;

			//REQUIRED FOR SAMPLING
			//IF we are not actually downsampling, don't waste time upsampling.
			//upsampleIndices(downsampledCloud,cloudIndexGrid,inliers,upsampledPlaneIndices,gridIncrement,2);
			upsampledPlaneIndices = downsampledIndices;

			//check stopping criteria
			if(upsampledPlaneIndices.size() > minPlaneSize){
				std::deque<unsigned int> planeIndexDeque;
				toUnsignedDeque(upsampledPlaneIndices,planeIndexDeque);
				registration::downsampleFromIndices(*downsampledCloud,newPlane,planeIndexDeque);
				planes.clouds.push_back(newPlane);
				//remove the plane from indices
				subtractIndices(downsampledIndices,inliers,downsampledCloud->points.size());
				//REQUIRED FOR SAMPLING
				//subtractIndices(allIndices,upsampledPlaneIndices,cloud->points.size());
			}
			else{
				break;
			}

		}

		ros::Time endTime = ros::Time::now();
		ros::Duration dur = endTime-startTime;
		std::cout<<"Extracted "<<planes.clouds.size()<<" planes in "<<dur.toSec()<<" seconds"<<std::endl;

		extractBlocks(planes);
	}

	/**
	* This is awful. What's needed is an overload of extractPlanes that takes arguments for various
	* possible parameters like image fraction and so on, or better yet, a refactoring where
	* extractPlanes and extractBlocks are less badly split.  (Maybe?)  Anyway don't call this.
	*
	* @param cloud
	* @deprecated
	* @return cloudArray
	*/
	rgbd_msgs::PointCloudArray extractPlanesB(sensor_msgs::PointCloud cloud)
	{
		double maxDist = .001;
		int maxIts = m_maxIterations;
		//int gridIncrement = m_gridIncrement;

		double minFractionOfImage = m_minImageFrac;
		unsigned int minPlaneSize = m_xRes*m_yRes*minFractionOfImage;

		//set the initial set of indices as everything
		std::vector<int> allIndices;
		for(int i=0; i<(int) cloud.points.size(); i++)
			allIndices.push_back(i);

		//extract planes
		rgbd_msgs::PointCloudArray planes;
		while(allIndices.size() >= 3) {
			//fit the plane
			std::vector<int> inliers;
			std::vector<double> coefs;
			registration::fitSACPlane(&cloud,allIndices,inliers,coefs,maxDist,maxIts);

			//construct a cloud for the new plane
			sensor_msgs::PointCloud newPlane;

			//check stopping criteria
			if(inliers.size() > minPlaneSize){
				std::deque<unsigned int> planeIndexDeque;
				toUnsignedDeque(inliers,planeIndexDeque);
				registration::downsampleFromIndices(cloud,newPlane,planeIndexDeque);
				planes.clouds.push_back(newPlane);
				//remove the plane from indices
				subtractIndices(allIndices,inliers,cloud.points.size());
			}
			else{
				break;
			}
		}
		return planes;
	}


	/**
	* Given a point cloud array of planes, fishes out ones that are block-shaped.
	*
	* @todo: stop expecting planes. Merge plane extract and block extract, quit redoing work.
	* @todo refactor, s'huge.
	*
	* @param planes
	*/
	void extractBlocks(rgbd_msgs::PointCloudArray &planes)
	{
		ros::Time startTime = ros::Time::now();

		double maxFractionOfImage = m_maxImageFrac;
		unsigned int maxPlaneSize = m_xRes*m_yRes*maxFractionOfImage; //cut off above this

		rgbd_msgs::PointCloudArray smallPlanes;

		//Loop through planes, reject huge ones
		for(unsigned int i = 0; i < planes.clouds.size(); i++) {
			sensor_msgs::PointCloud curPlane = planes.clouds[i];
			if(curPlane.points.size() <= maxPlaneSize){
				smallPlanes.clouds.push_back(curPlane);
			}
			else {
				std::cout << "  Rejected plane " << i <<" size: " << curPlane.points.size() << std::endl;
			}
		}

		//shove all the plane clouds back into one big cloud now that table plane is
		//(hopefully) gone
		sensor_msgs::PointCloud cloud = combinePointClouds(smallPlanes);
		m_cameraDataPublisher.publish(cloud);

		//segment into lumps (hopefully these will be blocks)
		segmentation::PointCloudSegmenter cloudSegmenter;
		int xchannel = rgbd::get_channel_index(cloud, "image_x");
		int ychannel = rgbd::get_channel_index(cloud, "image_y");
		cloudSegmenter.setPixelChannels(xchannel, ychannel);
		cloudSegmenter.setResolution(m_xRes,m_yRes);
		//actually do segmenting
		std::list<sensor_msgs::PointCloud> segmentList =
				cloudSegmenter.segmentCameraCloud(cloud, .02, 200, 1); //play with this

		std::cout << "1. Segment list is size " << segmentList.size() << "\n"; //SPAM @debug

		//transfer segmentation results from list to array
		rgbd_msgs::PointCloudArray segmentAry;
		unsigned int segmentListSize = segmentList.size();
		for (unsigned int i = 0; i < segmentListSize; ++i) {
			sensor_msgs::PointCloud block = segmentList.front();
			segmentAry.clouds.push_back(block);
			segmentList.pop_front();
		}

		std::cout << "2. Segment ary is size " << segmentAry.clouds.size() << "\n"; //SPAM @debug

		//Loop through block segments; break each segment into planes;
		//sanity-check (size) and color them; populate our vector of arrays
		//    first split each segment (block) up into planes again - these will be stored as a vector
		//    of PointCloudArrays, one segment per vector element, many planes per array
		std::vector<rgbd_msgs::PointCloudArray> planesOfSegments;
		for(unsigned int i = 0; i < segmentAry.clouds.size(); i++) {
			sensor_msgs::PointCloud curBlock = segmentAry.clouds[i];
			rgbd_msgs::PointCloudArray planesOfOneSegment;
			planesOfOneSegment = extractPlanesB(curBlock);
			//
			//Calculate the area of the plane, report it, possibly use it as a filter.
			//Disabled until I figure out how it's handling complex polygons and -- if
			//it's reporting the complex area, which I believe to be the case -- how
			//far apart points need to be.
			//
			//for (unsigned int j = 0; j < planesOfOneSegment.clouds.size(); ++j) {
			//	double planeArea = patchArea(planesOfOneSegment.clouds[j]); ///this appears to do complex polygons - that's bad
			//	std::cout << "Block  " << i << " plane " << j << " has area: "
			//			<< planeArea << std::endl;
			//}

			planesOfOneSegment = colorCloudsDifferent(planesOfOneSegment);
			planesOfSegments.push_back(planesOfOneSegment);
		}

		//publish biggest cube within segment.
		unsigned int segsize = planesOfSegments.size();
		int normId=1;
		int cubeId=2;

		//for each segment (block)
		for (unsigned int i = 0; i < segsize; ++i) {
			rgbd_msgs::PointCloudArray curSegment = planesOfSegments[i];
			//assuming it still contains any planes
			if (curSegment.clouds.size() > 0) {
				normId = normId+2;
				cubeId = cubeId+2;
				fitCube(curSegment, cubeId);
			}
		}

		//Squash everything back into a huge cloud before publishing.
		rgbd_msgs::PointCloudArray final;

		for (unsigned int i = 0; i < planesOfSegments.size(); ++i) {
			for (unsigned int j = 0; j < planesOfSegments[i].clouds.size() ; ++j) {
				final.clouds.push_back(planesOfSegments[i].clouds[j]);
			}
		}

		//@todo stop piggybacking on remainder.
		m_cameraDataPublisher.publish(combinePointClouds(final));

		//m_cameraDataPublisher.publish(createPointCube());

		ros::Time endTime = ros::Time::now();
		ros::Duration dur = endTime-startTime;
		std::cout<<"Block extraction took: "<<dur.toSec()<<" seconds"<<std::endl;

	}

	/**
	* Marker-up the normal of a point cloud, probably a roughly-planar one; somewhat
	* expensive.  Started life as a copy of publishNormalLines in cloudNormals.cpp.
	*
	* @param plane pointcloud
	* @param int markerId
	*/
	void publishNormalForPlanarCloud (sensor_msgs::PointCloud &points, int markerId)
	{
		double blockEdge = m_blockEdgeLength;
		ros::Publisher publisher = m_markerPublisher;
		std::string frameId = "primesensor_frame";
		double length = 0 - blockEdge; //depth of block //negated to go inward
		double width = .0004;

		visualization_msgs::Marker marker;
		marker.header.frame_id = frameId;
		marker.header.stamp = ros::Time();
		marker.ns = "normal_lines_ns";
		marker.id = markerId;
		marker.type = visualization_msgs::Marker::LINE_LIST;
		marker.action = visualization_msgs::Marker::ADD;
		marker.pose.position.x = 0;
		marker.pose.position.y = 0;
		marker.pose.position.z = 0;
		marker.pose.orientation.x = 0.0;
		marker.pose.orientation.y = 0.0;
		marker.pose.orientation.z = 0.0;
		marker.pose.orientation.w = 1.0;
		marker.scale.x = width;
		marker.scale.y = 1;
		marker.scale.z = 1;
		marker.color.a = 1.0;
		marker.color.r = 1.0;
		marker.color.g = 1.0;
		marker.color.b = 1.0;

		sensor_msgs::PointCloud center;
		cloud_geometry::nearest::computeCentroid(points,center);

		int nr_points = center.points.size ();
		unsigned int nx_idx = rgbd::get_normal_channel_index(center);

		marker.points.resize (2 * nr_points);

		//Draw a normal for each point in cloud "center".
		//Right now this is a loop over just the centroid.  Leaving as a loop because
		//we may want to improve accuracy by averaging a few points around the centroid
		//or something.
		for (int i = 0; i < nr_points; i++)
		{
			marker.points[2*i].x = center.points[i].x;
			marker.points[2*i].y = center.points[i].y;
			marker.points[2*i].z = center.points[i].z;
			marker.points[2*i+1].x = center.points[i].x + center.channels[nx_idx].values[i] * length;
			marker.points[2*i+1].y = center.points[i].y + center.channels[nx_idx+1].values[i] * length;
			marker.points[2*i+1].z = center.points[i].z + center.channels[nx_idx+2].values[i] * length;
		}

		publisher.publish (marker);
		//		ROS_INFO ("Published %d normal lines", nr_points);
	}

	/**
	* Take a point cloud, which (in a perfect world) represents a cube. Fit a cube
	* to it, using the biggest plane for the initial orientation and ICP to make it
	* fit the data as best is possible.
	*
	* @todo split fitCube and publishCube.
	*
	* @param plane pointcloud
	* @param int markerId
	*/
	void fitCube (rgbd_msgs::PointCloudArray &segment, int markerId)
	{
		double blocksize = m_blockEdgeLength;
		double half = m_blockEdgeLength/2;

		ros::Publisher publisher = m_markerPublisher;
		std::string frameId = "primesensor_frame";

		visualization_msgs::Marker cube;
		cube.header.frame_id = frameId;
		cube.header.stamp = ros::Time();
		cube.ns = "normal_lines_ns";
		cube.id = markerId;
		cube.type = visualization_msgs::Marker::CUBE;
		cube.action = visualization_msgs::Marker::ADD;

		cube.scale.x = blocksize;
		cube.scale.y = blocksize;
		cube.scale.z = blocksize;

		cube.color.a = 0.4; //translucent
		cube.color.r = 1.0;
		cube.color.g = 0.0;
		cube.color.b = 1.0;

		//get the largest plane in the array (# of points)
		sensor_msgs::PointCloud plane = segment.clouds[0];
		//for each plane in that segment
		for (unsigned int i = 0; i < segment.clouds.size(); ++i) {
			if (segment.clouds[i].points.size() > plane.points.size()) {
				plane = segment.clouds[i];
			}
			//expensive
			cloud_geometry::nearest::computePointCloudNormals(plane, 30, geometry_msgs::PointStamped());
			//we no longer visualize the normals, but we could; we'd need to recalculate marker ID
			//publishNormalForPlanarCloud(biggestPlane, normId);
		}

		//get centerpoint of plane
		sensor_msgs::PointCloud center;
		cloud_geometry::nearest::computeCentroid(plane,center);

		//get normal
		unsigned int nx_idx = rgbd::get_normal_channel_index(center);

		//first 3 addends are the centerpoint of the cube, second three are the adjustments
		//to bring it along the normal until it's resting on the face
		cube.pose.position.x = center.points[0].x - center.channels[nx_idx].values[0] * half;
		cube.pose.position.y = center.points[0].y - center.channels[nx_idx+1].values[0] * half;
		cube.pose.position.z = center.points[0].z - center.channels[nx_idx+2].values[0] * half;

		//construct normal vector
		rgbd::eigen::Vector3f plane_normal(
				center.channels[nx_idx].values[0],
				center.channels[nx_idx+1].values[0],
				center.channels[nx_idx+2].values[0]);

		rgbd::eigen::Vector3f starting_normal(1,0,0);

		//do magic to get quaternion W value
		float dot = plane_normal.dot(starting_normal);
		float angle = acos(dot);
		float angle_2 = angle * 0.5f;
		float sin_angle_2 = sin(angle_2);
		float cos_angle_2 = cos(angle_2);

		rgbd::eigen::Vector3f cross = starting_normal.cross(plane_normal);
		cross.normalize();

		cube.pose.orientation.x = cross.x() * sin_angle_2;
		cube.pose.orientation.y = cross.y() * sin_angle_2;
		cube.pose.orientation.z = cross.z() * sin_angle_2;
		cube.pose.orientation.w = cos_angle_2;


		/** Stop messing with marker, start messing with ICP **/
		//create a PointCube
		sensor_msgs::PointCloud pointCube = createPointCube();

		// initialize the transform to be applied to the PointCube
		// (rotation:) w x y z (translfitCubefitCubeation:) x y z
		// converter normalizes quaternion
		std::vector<float> transform_as_vector(7, 0.0f);
		// rotation part:
		transform_as_vector[0] = cube.pose.orientation.w;
		transform_as_vector[1] = cube.pose.orientation.x;
		transform_as_vector[2] = cube.pose.orientation.y;
		transform_as_vector[3] = cube.pose.orientation.z;
		// translation part
		transform_as_vector[4] = cube.pose.position.x;
		transform_as_vector[5] = cube.pose.position.y;
		transform_as_vector[6] = cube.pose.position.z;

		rgbd::eigen::Transform3f initial_transform;
		xf::convertSTDVectorToTransform(transform_as_vector, initial_transform);

		// now apply this transform to the "perfect block" cube
		sensor_msgs::PointCloud transformedPointCube;
		rgbd::transform_point_cloud(initial_transform, pointCube, transformedPointCube);

		sensor_msgs::PointCloud collapsedSegment = combinePointClouds(segment);

		//		cloud_geometry::nearest::computePointCloudNormals(collapsedSegment, 30, geometry_msgs::PointStamped());
		//		cloud_geometry::nearest::computePointCloudNormals(transformedPointCube, 30, geometry_msgs::PointStamped());

		const sensor_msgs::PointCloud source = collapsedSegment;
		const sensor_msgs::PointCloud target = transformedPointCube;
		//const sensor_msgs::PointCloud target = pointCube;

		// Now initialize ICP:
		registration::ICPCombinedParams global_params;
		// these are reasonable values:
		global_params.max_lm_rounds = 5; // inner //default is 50
		global_params.max_icp_rounds = 1000; // outer // will terminate before this due to error converging
		global_params.min_error_frac_to_continue = 0.0005; //default is 0.001

		global_params.optimizer = registration::OPTIMIZER_CLOSED_FORM;

		registration::ICPCombined icp_combined;
		icp_combined.setParams(global_params);

		// add this cloud pair to ICP Combined //what?
		registration::ICPCloudPairParams pair_params;
		pair_params.fixed_correspondence = false;
		pair_params.front_can_match_back = true;
		pair_params.max_distance = -1;

		std::cout << "Source points:" << source.get_points_size() << std::endl;
		std::cout << "Target points:" << target.get_points_size() << std::endl;

		pair_params.errType = registration::ICP_ERR_POINT_TO_POINT;
		pair_params.corrType = registration::ICP_CORRS_SINGLE_TREE;
		pair_params.wtType = registration::ICP_WTS_SCALAR;
		const boost::shared_ptr<registration::ICPCloudPair> cloudPair =
				boost::make_shared<registration::ICPCloudPair>(pair_params, source, target);

		icp_combined.addCloudPair(cloudPair);

		std::cout << "Starting ICP..." << std::endl;

		//icp_combined.setInitialTransform(initial_transform);
		rgbd::eigen::Transform3f icp_transform;
		bool icp_success = icp_combined.runICP(icp_transform); // <=====payload

		std::cout << "ICP Success:" << icp_success << std::endl;
		//		std::cout << "Desired Transform:\n" << getTransformString(transform) << std::endl;
		std::cout << "ICP Transform:\n" << xf::getTransformString(icp_transform) << std::endl;

		rgbd::eigen::Transform3f icp_transform_inverted = xf::invertTransform(icp_transform);

		rgbd::eigen::Transform3f final_transform = icp_transform_inverted * initial_transform;

		std::vector<float> final_transform_as_vector(7, 0.0f);
		xf::convertTransformToSTDVector(final_transform, final_transform_as_vector);

		// rotation part:
		cube.pose.orientation.w = final_transform_as_vector[0];
		cube.pose.orientation.x = final_transform_as_vector[1];
		cube.pose.orientation.y = final_transform_as_vector[2];
		cube.pose.orientation.z = final_transform_as_vector[3];
		// translation part
		cube.pose.position.x = final_transform_as_vector[4];
		cube.pose.position.y = final_transform_as_vector[5];
		cube.pose.position.z = final_transform_as_vector[6];

		//m_cameraDataPublisher.publish(transformedPointCube);

		publisher.publish (cube);

		//publishCube ()
	}

	/**
	* Given
	*
	* Given all the position and orientation parameters, markers up a cube of size blocksize
	* and translucent purple.
	*
	* @param plane pointcloud
	* @param int markerId
	*/
	void publishCube (int posX, int posY, int posZ, int orientW, int orientX, int orientY, int orientZ, int markerId)
	{
		double blocksize = m_blockEdgeLength;

		ros::Publisher publisher = m_markerPublisher;
		std::string frameId = "primesensor_frame";

		visualization_msgs::Marker cube;
		cube.header.frame_id = frameId;
		cube.header.stamp = ros::Time();
		cube.ns = "normal_lines_ns";
		cube.id = markerId;
		cube.type = visualization_msgs::Marker::CUBE;
		cube.action = visualization_msgs::Marker::ADD;

		cube.scale.x = blocksize;
		cube.scale.y = blocksize;
		cube.scale.z = blocksize;

		cube.color.a = 0.4; //translucent
		cube.color.r = 1.0;
		cube.color.g = 0.0;
		cube.color.b = 1.0;

		cube.pose.position.x = posX;
		cube.pose.position.y = posY;
		cube.pose.position.z = posZ;
		cube.pose.orientation.x = orientX;
		cube.pose.orientation.y = orientY;
		cube.pose.orientation.z = orientZ;
		cube.pose.orientation.w = orientW;

		publisher.publish (cube);
	}

	/////////// Utilities.

	/**
	*
	*/
	sensor_msgs::PointCloud createPointCube () {

		sensor_msgs::PointCloud pointCube;
		double blockEdge = m_blockEdgeLength;
		double pointSeparation = m_pointSeparation;

		//create (and name) a channel object
		sensor_msgs::ChannelFloat32 rgbChannel;
		rgbChannel.name = "rgb";
		//put new channel object in return-value point cloud
		pointCube.channels.push_back(rgbChannel);

		//add a header to the pointCube
		std::string frameId = "primesensor_frame";
		pointCube.header.frame_id = frameId;
		pointCube.header.stamp = ros::Time::now() ;

		//figure out how many points
		double half = blockEdge/2;
		int numPointsPerEdge = (blockEdge/pointSeparation);

		//create the cube
		// - Nasty, because I am sleepy - some kind of modding elegance would
		//   probably make this be five lines long - also I am doubling up points
		//   along the edges of the faces
		for (int i = 0; i < numPointsPerEdge; ++i) {
			for (int j = 0; j < numPointsPerEdge; ++j) {
				//bottom
				geometry_msgs::Point32 p1;
				p1.x = i*pointSeparation - half;
				p1.y = j*pointSeparation - half;
				p1.z = -half;
				pointCube.points.push_back(p1);
				//top
				p1.x = i*pointSeparation - half;
				p1.y = j*pointSeparation - half;
				p1.z = half;
				pointCube.points.push_back(p1);
				//
				p1.x = -half;
				p1.y = j*pointSeparation - half;
				p1.z = i*pointSeparation - half;
				pointCube.points.push_back(p1);
				//
				p1.x = half;
				p1.y = j*pointSeparation - half;
				p1.z = i*pointSeparation - half;
				pointCube.points.push_back(p1);
				//
				p1.x = j*pointSeparation - half;
				p1.y = -half;
				p1.z = i*pointSeparation - half;
				pointCube.points.push_back(p1);
				//
				p1.x = j*pointSeparation - half;
				p1.y = half;
				p1.z = i*pointSeparation - half;
				pointCube.points.push_back(p1);
			}
		}
		pointCube = colorCloud(pointCube, 0xCCCCCC);
		return pointCube;
	}

	//@todo doc me - euclidean distance
	double distance(geometry_msgs::Point32 p1, geometry_msgs::Point32 p2) {
		return sqrt(
				pow((p1.x - p2.x), 2)  +
				pow((p1.y - p2.y), 2)  +
				pow((p1.z - p2.z), 2));
	}

	/**
	* Calculate the surface area of a point-cloud.  This works best on roughly-planar
	* clouds, as it projects onto the best normal it can find.
	*
	* @param plane pointcloud
	*/
	double patchArea(sensor_msgs::PointCloud plane) {
		rgbd::eigen::Vector4d planeParams;
		double planeCurve;

		//get the normal from the planar estimate
		//@todo carry coefficients around, don't recalculate like we do here, it's expensive.
		cloud_geometry::nearest::computePointNormal(plane, planeParams, planeCurve);

		// construct the normal from the Vector4d result
		std::vector<double> norm;
		norm.push_back(planeParams(0));
		norm.push_back(planeParams(1));
		norm.push_back(planeParams(2));

		//compute area and return it
		return cloud_geometry::areas::compute2DPolygonalArea(plane, norm);
	}

	/** @todo DOCME
	*
	* @param cloud array
	* @return cloud
	*/
	sensor_msgs::PointCloud combinePointClouds(rgbd_msgs::PointCloudArray cloudsToCombine) {
		//Create a pointcloud to return the combined values
		sensor_msgs::PointCloud combined;

		if (cloudsToCombine.clouds.size() == 0) {
			std::cout << "WARNING: combinePointClouds called on empty PointCloudArray";
			return combined;
		}

		//assume all clouds in array have same channels; use first cloud as template,
		//copy its channel names into the combined cloud.
		combined.channels.resize(cloudsToCombine.clouds[0].channels.size());
		combined.header = cloudsToCombine.clouds[0].header;

		for (unsigned int i = 0; i < cloudsToCombine.clouds[0].channels.size() ; i++) {
			combined.channels[i].name = cloudsToCombine.clouds[0].channels[i].name;
		}

		for(unsigned int i = 0; i < cloudsToCombine.clouds.size(); i++) {
			for (unsigned int j = 0; j < combined.channels.size(); j++) {
				combined.channels[j].values.insert(
						combined.channels[j].values.end(),
						cloudsToCombine.clouds[i].channels[j].values.begin(),
						cloudsToCombine.clouds[i].channels[j].values.end());
			}
			combined.points.insert(
					combined.points.end(),
					cloudsToCombine.clouds[i].points.begin(),
					cloudsToCombine.clouds[i].points.end() );
		}
		return combined;
	}



	/**
	* Takes an array of PointClouds and tries to color them very distinct colors. Wraps
	* after ~21 colors. Quite a hack.
	*
	* @param clouds
	* @return clouds
	*/
	rgbd_msgs::PointCloudArray colorCloudsDifferent(rgbd_msgs::PointCloudArray cloudsToRecolor) {
		unsigned int colors[] = {0x00FF00, 0x0000FF, 0xFFFF00,
				0x00FFFF, 0xFFFFFF, 0xCCCCCC, 0xFF8080, 0x880000, 0x008800, 0x000088,
				0x888800, 0x880088, 0x008888, 0x330000, 0x003300, 0x000033, 0x333300,
				0x330033, 0x003333};

		int numColors = sizeof(colors)/sizeof(colors[0]);

		//Loop through clouds, recoloring.
		for(unsigned int i = 0; i < cloudsToRecolor.clouds.size(); i++) {
			//colorCloud(cloudsToRecolor.clouds[i], colors[i % numColors]); @todo
			//Loop through each point in this cloud & recolor
			for(unsigned int j = 0; j < cloudsToRecolor.clouds[i].channels[0].values.size(); j++) {
				//oh god so ugly - see conv_points_to_ros_cloud in fastpointlib/conversions.h
				//@todo look at EdgeViewerNode.cpp for (far) better color management
				cloudsToRecolor.clouds[i].channels[0].values[j] = *reinterpret_cast<float*>(&colors[i % numColors]);
			}
		}
		return cloudsToRecolor;
	}


	/**
	* make every point in a cloud the given color.
	*
	* @param cloud
	* @param
	* @return cloud
	*/
	sensor_msgs::PointCloud colorCloud(sensor_msgs::PointCloud cloudToRecolor, unsigned int color) {
		//unsigned int colors[] = {0xFFFFFF};
		if (cloudToRecolor.points.size() <= 0) {
			std::cout << "WARNING: block_modeler_node function colorCloud called on empty cloud" <<std::endl;
		} else {
			//Loop through each point in this cloud & recolor
			for(unsigned int j = 0; j < cloudToRecolor.channels[0].values.size(); j++) {
				//oh god so ugly - see conv_points_to_ros_cloud in fastpointlib/conversions.h
				//@todo look at EdgeViewerNode.cpp for (far) better color management
				cloudToRecolor.channels[0].values[j] = *reinterpret_cast<float*>(color);
			}
		}
		return cloudToRecolor;
	}

	std::string simpleIntToString(int i) {
		std::string s;
		std::stringstream out;
		out << i;
		s = out.str();
		return s;
	}

	/////////// End utilities.

	int run()
	{
		m_cloudSubscriber = nh_local.subscribe<sensor_msgs::PointCloud>(
				m_cloudSubscriberTopic,1,&BlockModeler::extractPlanes,this);

		ros::spin();
		return 0;
	}



};// class


int main (int argc, char** argv)
{
	ros::init (argc, argv, "planar_extraction_node");
	BlockModeler block_model_node;
	return block_model_node.run();
}
