/*
 * planar_extraction_node.cpp
 *
 *  Created on: 2010-01-27
 *      Author: mkrainin and phenry
 */

#include "rgbd_util/eigen/Core"
#include "rgbd_util/eigen/Geometry"

#include <ros/node_handle.h>
#include <ros/publisher.h>
#include <ros/subscriber.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl/point_cloud.h>
#include <pcl/ros/conversions.h>
#include "pcl/ModelCoefficients.h"
#include <pcl/sample_consensus/sac_model_plane.h>
#include <pcl/sample_consensus/msac.h>
#include <visualization_msgs/MarkerArray.h>

#include <rgbd_util/ros_utility.h>
#include <rgbd_util/CameraParams.h>
#include <rgbd_util/primesensorUtils.h>
#include <rgbd_msgs/PointCloud2Array.h>
#include <pcl_rgbd/pointTypes.h>
#include <pcl_rgbd/cloudSampling.h>
#include <pcl_rgbd/cloudUtils.h>


#include <segmentation/segmentation_utility.h>

#include <roslib/Header.h>
#include <vector>
#include <string>
#include <deque>
using namespace std;


class PlaneExtractor
{
protected:
    ros::NodeHandle nh_global;
    ros::NodeHandle nh_local;

#if 0
    // new but lazy
    static const int max_out_of_order = 50;
	message_filters::TimeSynchronizer<sensor_msgs::Image, rgbd_msgs::DepthMap> sync;
	message_filters::Subscriber<rgbd_msgs::DepthMap> depth_subscription_filtered;
	message_filters::Subscriber<sensor_msgs::Image> image_subscription_filtered;
#endif

    //publishers
    ros::Publisher m_planesPublisher;
    ros::Publisher m_remainderPublisher;
    ros::Publisher m_tableCoeffsPublisher;

    //subscribers
    ros::Subscriber m_cloudSubscriber;

#if 0
    // OLD:
    unsigned int m_xRes,m_yRes;
	double m_maxOutOfPlane;
	int m_maxIterations;
	int m_gridIncrement;
	double m_minImageFrac;
#endif

	// NEW:
	bool compute_ground_plane;
	bool compute_clusters;
	bool compute_other_planes;

	int plane_pixel_downsample;
	float ground_plane_distance_threshold;
	float ground_plane_normal_distance_weight;
	float ground_plane_max_angle_difference;
	float ground_plane_displacement_from_origin;
	float ground_plane_max_displacement_difference;
	int ground_plane_min_inliers;
	float other_plane_distance_threshold;
	int other_plane_min_inliers;
	bool other_plane_use_local_normals;
	float other_plane_normal_distance_weight;
	bool plane_do_mls;
	float plane_mls_radius;
	bool do_euclidean_clustering; // after ransac
	float euclidean_tolerance;    // after ransac
	float plane_sleep_initial;
	float plane_sleep_animate;
	float plane_sleep_end;
	float cluster_distance;
	float cluster_angle;
	float cluster_min_size;

	boost::shared_ptr<rgbd::CameraParams> rgbd_camera_params_ptr;

    ros::Publisher ground_plane_cloud_publisher;
    ros::Publisher plane_remainder_cloud_publisher;
    ros::Publisher projected_plane_cloud_publisher;
    ros::Publisher convex_hull_marker_publisher;
    ros::Publisher convex_hull_marker_array_publisher;
    ros::Publisher cluster_cloud_publisher;

public:

	PlaneExtractor ()
    : nh_global(),
      nh_local("~")
    {
		// load ros params
		rgbd::rosparam(nh_local, "compute_ground_plane", compute_ground_plane);
		rgbd::rosparam(nh_local, "compute_clusters", compute_clusters);
		rgbd::rosparam(nh_local, "compute_other_planes", compute_other_planes);
    	rgbd::rosparam(nh_local, "plane_pixel_downsample", plane_pixel_downsample);
    	rgbd::rosparam(nh_local, "ground_plane_min_inliers", ground_plane_min_inliers);
    	rgbd::rosparam(nh_local, "ground_plane_distance_threshold", ground_plane_distance_threshold);
    	rgbd::rosparam(nh_local, "ground_plane_max_angle_difference", ground_plane_max_angle_difference);
    	rgbd::rosparam(nh_local, "ground_plane_displacement_from_origin", ground_plane_displacement_from_origin);
    	rgbd::rosparam(nh_local, "ground_plane_max_displacement_difference", ground_plane_max_displacement_difference);
    	rgbd::rosparam(nh_local, "ground_plane_normal_distance_weight", ground_plane_normal_distance_weight);
    	rgbd::rosparam(nh_local, "other_plane_min_inliers", other_plane_min_inliers);
    	rgbd::rosparam(nh_local, "other_plane_distance_threshold", other_plane_distance_threshold);
    	rgbd::rosparam(nh_local, "other_plane_use_local_normals", other_plane_use_local_normals);
    	rgbd::rosparam(nh_local, "other_plane_normal_distance_weight", other_plane_normal_distance_weight);
    	rgbd::rosparam(nh_local, "plane_do_mls", plane_do_mls);
    	rgbd::rosparam(nh_local, "plane_mls_radius", plane_mls_radius);
    	rgbd::rosparam(nh_local, "do_euclidean_clustering", do_euclidean_clustering);
    	rgbd::rosparam(nh_local, "euclidean_tolerance", euclidean_tolerance);
    	rgbd::rosparam(nh_local, "plane_sleep_initial", plane_sleep_initial);
    	rgbd::rosparam(nh_local, "plane_sleep_animate", plane_sleep_animate);
    	rgbd::rosparam(nh_local, "plane_sleep_end", plane_sleep_end);
    	rgbd::rosparam(nh_local, "cluster_distance", cluster_distance);
    	rgbd::rosparam(nh_local, "cluster_angle", cluster_angle);
    	rgbd::rosparam(nh_local, "cluster_min_size", cluster_min_size);

    	rgbd_camera_params_ptr = rgbd::getCameraParamsPtrFromROSParamSearch(nh_local, "rgbd_camera_id");

#if 0
    	// old
		m_planesPublisher = nh_global.advertise<rgbd_msgs::PointCloud2Array> (planesTopic, 1);
		m_remainderPublisher = nh_global.advertise<sensor_msgs::PointCloud2> (remainderTopic, 1);
		m_tableCoeffsPublisher = nh_global.advertise<pcl::ModelCoefficients> (tableParamsTopic, 1);
#endif

		// advertise
		ground_plane_cloud_publisher = nh_global.advertise<sensor_msgs::PointCloud2>("ground_plane_cloud", 1);
		plane_remainder_cloud_publisher = nh_global.advertise<sensor_msgs::PointCloud2>("plane_remainder_cloud", 1);
		convex_hull_marker_publisher = nh_global.advertise<visualization_msgs::Marker>("convex_hull_marker", 1);
		convex_hull_marker_array_publisher = nh_global.advertise<visualization_msgs::MarkerArray>("convex_hull_marker_array", 1);
		projected_plane_cloud_publisher = nh_global.advertise<sensor_msgs::PointCloud2>("projected_plane_cloud", 1);
		cluster_cloud_publisher = nh_global.advertise<sensor_msgs::PointCloud2>("cluster_cloud", 1);


    }

    ~PlaneExtractor()
    {
    }

#if 0
    // some sample params:
# plane paramenters
plane_pixel_downsample: 5 # 0 is off
ground_plane_min_inliers: 5000
ground_plane_distance_threshold: 0.10
ground_plane_max_angle_difference: 0.5 # radians, 0 disables
ground_plane_displacement_from_origin: 1.5 # meters
ground_plane_max_displacement_difference: 0.5 # meters, 0 disables
ground_plane_normal_distance_weight: 0.2 # relative weight of normal radian angular distance to euclidian distance
other_plane_min_inliers: 500
other_plane_distance_threshold: 0.2
other_plane_use_local_normals: true
other_plane_normal_distance_weight: 0.3
plane_do_mls: false
plane_mls_radius: 0.1
do_euclidean_clustering: false
euclidean_tolerance: 0.1
plane_sleep_initial: 2.0
plane_sleep_animate: 0.5
plane_sleep_end: 2.0
cluster_distance: 0.05
cluster_angle: 0.2
cluster_min_size: 500
#endif

#if 0
    void sync_callback(sensor_msgs::ImageConstPtr current_image_ptr, rgbd_msgs::DepthMapConstPtr current_depth_ptr)
    {
		// cleanup all cloud publishers
		sensor_msgs::PointCloud2 empty_cloud;
		empty_cloud.header = curFrame.cloud_ptr->header;
		empty_cloud.width = empty_cloud.height = 1;
		plane_remainder_cloud_publisher.publish(empty_cloud);
		projected_plane_cloud_publisher.publish(empty_cloud);
		cluster_cloud_publisher.publish(empty_cloud);


		// clear out previous markers (even if there aren't any)
		std::string convex_hull_ns = "convex_hull";
		if (convex_hull_marker_array_publisher.getNumSubscribers() > 0) {
			visualization_msgs::MarkerArray marker_array;
			const unsigned int max_clear_count = 100;
			for (unsigned int i = 0; i < max_clear_count; i++) {
				visualization_msgs::Marker delete_marker;
				delete_marker.header = curFrame.cloud_ptr->header;
				delete_marker.ns = convex_hull_ns;
				delete_marker.id = i;
				delete_marker.action = visualization_msgs::Marker::DELETE;
				marker_array.markers.push_back(delete_marker);
			}
			convex_hull_marker_array_publisher.publish(marker_array);
		}

		// Do testing on new frame:

		// the cloud to use for plane extraction:
		pcl::PointCloud<rgbd::pt>::Ptr cloud_for_planes_ptr;

		// try moving least squares on input
		if (plane_do_mls) {
			ROS_INFO_STREAM("Doing MLS");
			// MLS doesn't copy colors, imgX, etc, but does compute normals
			// so initialize output as input copy
			cloud_for_planes_ptr = boost::make_shared<pcl::PointCloud<rgbd::pt> >(*curFrame.cloud_ptr);
			pcl::KdTree<rgbd::pt>::Ptr kd_tree_ptr = boost::make_shared<pcl::KdTreeFLANN<rgbd::pt> >();
			pcl::MovingLeastSquares<rgbd::pt, rgbd::pt> mls;
			mls.setInputCloud(curFrame.cloud_ptr);
			mls.setSearchMethod(kd_tree_ptr);
			mls.setSearchRadius(plane_mls_radius); // param
			mls.setSqrGaussParam(plane_mls_radius * plane_mls_radius); // as suggested in docs
			mls.setPolynomialFit(false);
			mls.reconstruct(*cloud_for_planes_ptr);
		}
		else {
			cloud_for_planes_ptr = curFrame.cloud_ptr;
			ROS_INFO_STREAM("Computing normals");
			computeNormals2d(
					*cloud_for_planes_ptr,
					normals_2d_window_size,
					normals_2d_downsample_factor,
					normals_2d_max_depth_difference,
					curFrame.image_ptr->width,
					curFrame.image_ptr->height,
					use_gpu_for_normals);
		}

		unsigned int point_count = cloud_for_planes_ptr->points.size();

		// all indices
		boost::shared_ptr<vector<int> > all_indices = boost::make_shared<vector<int> > (boost::counting_iterator<int>(0), boost::counting_iterator<int>(point_count));
		boost::shared_ptr<vector<int> > temp_indices = boost::make_shared<vector<int> >();

		// publish remainder cloud
		if (plane_remainder_cloud_publisher.getNumSubscribers() > 0) {
			pcl::PointCloud<rgbd::pt>::Ptr cloud_ptr = boost::make_shared<pcl::PointCloud<rgbd::pt> > ();
			downsampleFromIndices(*cloud_for_planes_ptr, *cloud_ptr, *all_indices);
			sensor_msgs::PointCloud2 cloud_msg;
			pcl::toROSMsg(*cloud_ptr, cloud_msg);
			plane_remainder_cloud_publisher.publish(cloud_msg);
			ROS_INFO_STREAM("Sleeping before we continue: " << plane_sleep_initial);
			ros::Duration(plane_sleep_initial).sleep();
		}

		// ground plane
		bool got_ground_plane = false;
		rgbd::eigen::VectorXf ground_plane_coefficients;
		vector<int> ground_plane_inliers;
		if (compute_ground_plane) {
			ROS_INFO_STREAM("Starting ground plane...");
			rgbd::timer t_ground;
			got_ground_plane = computeGroundPlane(cloud_for_planes_ptr, *all_indices, ground_plane_coefficients, ground_plane_inliers);
			t_ground.stop("Ground Plane");
		}

		if (got_ground_plane) {
			segmentation::removeInlierIndices(*all_indices, ground_plane_inliers, point_count, *temp_indices);
			all_indices.swap(temp_indices);
		}

		// test clustering before planes
		vector<boost::shared_ptr<vector<int> > > cluster_indices;
		if (compute_clusters) {
			ROS_INFO_STREAM("Starting clustering on entire cloud...");

			rgbd::timer t_clusters;
			vector<pcl::PointIndices> clusters;
			pcl::KdTree<rgbd::pt>::Ptr kd_tree_ptr = boost::make_shared<pcl::KdTreeFLANN<rgbd::pt> >();
			kd_tree_ptr->setInputCloud(cloud_for_planes_ptr, all_indices);
			pcl::extractEuclideanClusters(*cloud_for_planes_ptr, *cloud_for_planes_ptr, *all_indices, kd_tree_ptr, cluster_distance, clusters, cluster_angle, cluster_min_size);

			// fill in cluster indices
			for (unsigned int i = 0; i < clusters.size(); i++) {
				boost::shared_ptr<vector<int> > these_indices = boost::make_shared<vector<int> > (clusters[i].indices.begin(), clusters[i].indices.end());
				cluster_indices.push_back(these_indices);
			}

			t_clusters.stop("Clusters");

			// debug
			ROS_INFO_STREAM("Number of clusters: " << clusters.size());
			for (unsigned int i = 0; i < cluster_indices.size(); i++) {
				ROS_INFO_STREAM("Cluster " << i << " size: " << cluster_indices[i]->size());
				if (cluster_cloud_publisher.getNumSubscribers() > 0) {
					sensor_msgs::PointCloud2 cloud_msg;
					pcl::PointCloud<rgbd::pt>::Ptr cloud_ptr = boost::make_shared<pcl::PointCloud<rgbd::pt> > ();
					downsampleFromIndices(*cloud_for_planes_ptr, *cloud_ptr, *cluster_indices[i]);
					pcl::toROSMsg(*cloud_ptr, cloud_msg);
					cluster_cloud_publisher.publish(cloud_msg);
					ROS_INFO_STREAM("Sleeping for: " << plane_sleep_animate);
					ros::Duration(plane_sleep_animate).sleep();
				}
			}

			cluster_cloud_publisher.publish(empty_cloud);
			ROS_INFO_STREAM("I JUST PUBLISHED AN EMPTY CLOUD TO cluster_cloud_publisher");
		}


		// the rest of the planes
		if (compute_other_planes) {
			ROS_INFO_STREAM("Starting to search for other planes...");

			// if we didn't cluster, just a single cluster of all_indices (or if clustering failed?)
			if (cluster_indices.empty()) {
				ROS_WARN_STREAM("No clusters found...using entire cloud");
				cluster_indices.push_back(boost::make_shared<vector<int> >(*all_indices));
			}

			vector<boost::shared_ptr<vector<int> > > other_plane_indices;
			vector<pcl::PointCloud<rgbd::pt>::Ptr > convex_hulls;

			// loop over clusters (or a single cluster)
			for (unsigned int i = 0; i < cluster_indices.size(); i++) {
				ROS_INFO_STREAM("Searching for planes in cluster: " << i << " of size " << cluster_indices[i]->size());
				// copy indices again...so they are mutable here...
				boost::shared_ptr<vector<int> > indices_to_search = boost::make_shared<vector<int> > (*cluster_indices[i]);
				bool find_another = true;
				while(find_another) {
					ROS_INFO_STREAM("Remaining points to search: " << indices_to_search->size());

					// publish remainder cloud
					if (plane_remainder_cloud_publisher.getNumSubscribers() > 0) {
						pcl::PointCloud<rgbd::pt>::Ptr cloud_ptr = boost::make_shared<pcl::PointCloud<rgbd::pt> > ();
						downsampleFromIndices(*cloud_for_planes_ptr, *cloud_ptr, *indices_to_search);
						sensor_msgs::PointCloud2 cloud_msg;
						pcl::toROSMsg(*cloud_ptr, cloud_msg);
						plane_remainder_cloud_publisher.publish(cloud_msg);
					}

					rgbd::timer t_other;
					rgbd::eigen::VectorXf plane_coefficients;
					boost::shared_ptr<vector<int> > plane_inliers = boost::make_shared<vector<int> >();
					pcl::PointCloud<rgbd::pt>::Ptr projected_inliers = boost::make_shared<pcl::PointCloud<rgbd::pt> >();
					pcl::PointCloud<rgbd::pt>::Ptr convex_hull = boost::make_shared<pcl::PointCloud<rgbd::pt> >();
					find_another = computeAnotherPlane(cloud_for_planes_ptr, *indices_to_search, plane_coefficients, *plane_inliers, projected_inliers, convex_hull);

					if (find_another) {
						segmentation::removeInlierIndices(*indices_to_search, *plane_inliers, point_count, *temp_indices);
						indices_to_search.swap(temp_indices);
					}
					t_other.stop("Other plane");

					if (find_another) {
						other_plane_indices.push_back(plane_inliers);
						convex_hulls.push_back(convex_hull);

						if (projected_plane_cloud_publisher.getNumSubscribers() > 0) {
							sensor_msgs::PointCloud2 cloud_msg;
							pcl::toROSMsg(*projected_inliers, cloud_msg);
							projected_plane_cloud_publisher.publish(cloud_msg);
							ROS_INFO_STREAM("Sleeping for: " << plane_sleep_animate);
							ros::Duration(plane_sleep_animate).sleep();
						}

						if (convex_hull_marker_publisher.getNumSubscribers() > 0) {
							unsigned int last_index = convex_hulls.size() - 1;
							float hull_alpha = 0.5;
							convex_hull_marker_publisher.publish(segmentation::getConvexHullMarker<rgbd::pt>(convex_hulls[last_index], convex_hull_ns, last_index, segmentation::getRandomColor(hull_alpha)));
							ROS_INFO_STREAM("Sleeping for: " << plane_sleep_animate);
							ros::Duration(plane_sleep_animate).sleep();
						}
					}
				}
			}

			projected_plane_cloud_publisher.publish(empty_cloud);

			// done computing other planes
#if 0
			// publish convex hull markers all as one array
			if (convex_hull_marker_array_publisher.getNumSubscribers() > 0) {
				visualization_msgs::MarkerArray marker_array;
				for (unsigned int i = 0; i < convex_hulls.size(); i++) {
					marker_array.markers.push_back(segmentation::getConvexHullMarker<rgbd::pt>(convex_hulls[i], convex_hull_ns, i, segmentation::getRandomColor()));
				}
				convex_hull_marker_array_publisher.publish(marker_array);
			}
#endif
		}

		// publish remainder cloud one last time
		if (plane_remainder_cloud_publisher.getNumSubscribers() > 0) {
			pcl::PointCloud<rgbd::pt>::Ptr cloud_ptr = boost::make_shared<pcl::PointCloud<rgbd::pt> > ();
			downsampleFromIndices(*cloud_for_planes_ptr, *cloud_ptr, *all_indices);
			sensor_msgs::PointCloud2 cloud_msg;
			pcl::toROSMsg(*cloud_ptr, cloud_msg);
			plane_remainder_cloud_publisher.publish(cloud_msg);
		}

		// this is a test..do nothing else
		ROS_WARN_STREAM("Skipping rest of processing because do_plane_extraction_testing is true");

		ROS_INFO_STREAM("Sleeping at end for: " << plane_sleep_end);
		ros::Duration(plane_sleep_end).sleep();
    }
#endif


    bool computeGroundPlane(
    		pcl::PointCloud<rgbd::pt>::Ptr cloud_ptr,
    		const vector<int>& all_indices,
    		rgbd::eigen::VectorXf& ground_plane_coefficients,
    		vector<int>& ground_plane_inliers)
    {
    	rgbd::eigen::Vector3f normal_up(0,-1,0); // up in camera frame

    	// get downsample indices before segmentation
    	vector<int> sample_indices;
    	if (plane_pixel_downsample > 0) {
    		// stupid copying because of unsigned / signed
    		vector<unsigned int> all_indices_unsigned(all_indices.begin(), all_indices.end());
    		vector<unsigned int> downsample_indices = getPixelSpaceDownsamplingIndices(*cloud_ptr, all_indices_unsigned, plane_pixel_downsample);
    		sample_indices.assign(downsample_indices.begin(), downsample_indices.end());
    	}

    	pcl::PointCloud<rgbd::pt>::Ptr empty_ptr;
    	bool success = segmentation::computePlaneWithNormal<rgbd::pt>(
    			cloud_ptr,
    			all_indices,
    			sample_indices,
    			ground_plane_distance_threshold,
    			normal_up,
    			ground_plane_max_angle_difference,
    			ground_plane_displacement_from_origin,
    			ground_plane_max_displacement_difference,
    			ground_plane_normal_distance_weight,
    			ground_plane_coefficients,
    			ground_plane_inliers,
    			empty_ptr,
    			empty_ptr,
    			false,
    			0);

    	ROS_INFO_STREAM("Number of ground plane inliers: " << ground_plane_inliers.size());

    	if (success && ground_plane_inliers.size() > (size_t) ground_plane_min_inliers) {
    		// publish ground plane
    		if (ground_plane_cloud_publisher.getNumSubscribers() > 0) {
    			pcl::PointCloud<rgbd::pt>::Ptr ground_cloud_ptr = boost::make_shared<pcl::PointCloud<rgbd::pt> > ();
    			downsampleFromIndices(*cloud_ptr, *ground_cloud_ptr, ground_plane_inliers);
    			sensor_msgs::PointCloud2 cloud_msg;
    			pcl::toROSMsg(*ground_cloud_ptr, cloud_msg);
    			ground_plane_cloud_publisher.publish(cloud_msg);
    		}

    		return true;
    	}

    	return false;
    }

    bool computeAnotherPlane(
    		pcl::PointCloud<rgbd::pt>::Ptr cloud_ptr,
    		const vector<int>& all_indices,
    		rgbd::eigen::VectorXf& coefficients,
    		vector<int>& inliers,
    		pcl::PointCloud<rgbd::pt>::Ptr projected_inliers,
    		pcl::PointCloud<rgbd::pt>::Ptr convex_hull)
    {
    	// get downsample indices before segmentation
    	vector<int> sample_indices;
    	if (plane_pixel_downsample > 0) {
    		// stupid copying because of unsigned / signed
    		vector<unsigned int> all_indices_unsigned(all_indices.begin(), all_indices.end());
    		vector<unsigned int> downsample_indices = getPixelSpaceDownsamplingIndices(*cloud_ptr, all_indices_unsigned, plane_pixel_downsample);
    		sample_indices.assign(downsample_indices.begin(), downsample_indices.end());
    		const unsigned int min_sample_size = 5;
    		if (sample_indices.size() < min_sample_size) return false;
    	}

    	// debug
    	ROS_INFO_STREAM("sample_indices.size(): " << sample_indices.size());

    	bool success = false;
    	if (other_plane_use_local_normals) {
    		rgbd::eigen::Vector3f normal_empty(0,0,0);
    		success = segmentation::computePlaneWithNormal<rgbd::pt>(
    			cloud_ptr,
    			all_indices,
    			sample_indices,
    			other_plane_distance_threshold,
    			normal_empty,
    			0,
    			0,
    			0,
    			other_plane_normal_distance_weight,
    			coefficients,
    			inliers,
    			projected_inliers,
    			convex_hull,
    			do_euclidean_clustering,
    			euclidean_tolerance);
    	}
    	else {
    		success = segmentation::computePlane<rgbd::pt>(
    			cloud_ptr,
    			all_indices,
    			sample_indices,
    			other_plane_distance_threshold,
    			coefficients,
    			inliers,
    			projected_inliers,
    			convex_hull,
    			do_euclidean_clustering,
    			euclidean_tolerance);
    	}

    	ROS_INFO_STREAM("Number of other plane inliers: " << inliers.size());

    	if (success && inliers.size() > (size_t) other_plane_min_inliers) {
    		return true;
    	}

    	return false;
    }


#if 0
    /**
     * Removes indices from a vector
     *
     * @param indices
     * @param toRemove
     * @param maxIndex
     */
    void subtractIndices(std::vector<int> & indices, std::vector<int> & toRemove,
    		unsigned int maxIndex)
    {
    	std::vector<bool> useIndex(maxIndex,false);
    	for(unsigned int i=0; i<indices.size(); i++)
    		useIndex[indices[i]] = true;
    	for(unsigned int i=0; i<toRemove.size(); i++)
    		useIndex[toRemove[i]] = false;

    	//construct the output
    	indices.clear();
    	for(unsigned int i=0;i <maxIndex; i++)
    		if(useIndex[i])
    			indices.push_back(i);
    }

    /**
     * Converts a vector of ints to a deque of unsigned ints
     *
     * @param intVec
     * @param unsignedDeque
     */
    void toUnsignedDeque(std::vector<int> const& intVec, std::deque<unsigned int> & unsignedDeque){
    	unsignedDeque.clear();
    	for(unsigned int i=0;i <intVec.size(); i++)
    		unsignedDeque.push_back((unsigned int)intVec[i]);
    }

    /**
     * Returns a grid indexed by x and y which gives the index into the original
     * cloud for the point at that location. -1 indicates no point
     *
     * @param cloud
     * @param cloudIndexGrid
     */
    template <typename PointT>
    void getIndexGrid(pcl::PointCloud<PointT> const& cloud,
    		std::vector<std::vector<int> > &cloudIndexGrid)
    {
    	cloudIndexGrid.clear();
    	cloudIndexGrid.resize(m_xRes,std::vector<int>(m_yRes,-1));

    	for(unsigned int i=0; i<cloud.points.size(); i++){
    		cloudIndexGrid[cloud.points[i].imgX][cloud.points[i].imgY] = (int)i;
    	}
    }

    /**
     * Returns just the subset of indices which lie on a sub-grid of the full
     * image grid
     *
     * @param cloud
     * @param indices
     * @param downsampledIndices
     * @param gridIncrement
     */
    template <typename PointT>
    void gridDownsampleIndices(pcl::PointCloud<PointT> const& cloud,
    		std::vector<int> const& indices, std::vector<int> & downsampledIndices,
    		unsigned int gridIncrement)
    {
    	downsampledIndices.clear();
    	for(unsigned int i=0; i<indices.size(); i++)
    	{
    		int x = cloud.points[indices[i]].imgX;
    		int y = cloud.points[indices[i]].imgY;

    		if(x % gridIncrement == 0 && y % gridIncrement == 0)
    			downsampledIndices.push_back(indices[i]);
    	}
    }

    /**
     * Returns a list of indices upsampled from the one provided. This is done
     * by seeing if the indices not on the subgrid have neighbors in the list
     * and if so, whether or not there is too much of a depth difference
     *
     * @param cloud
     * @param cloudIndexGrid
     * @param indices
     * @param upsampledIndices
     * @param gridIncrement
     * @param numNeighborsNeeded
     */
    template <typename PointT>
    void upsampleIndices(pcl::PointCloud<PointT> const& cloud,
    		std::vector<std::vector<int> > const& cloudIndexGrid,
    		std::vector<int> const& indices, std::vector<int> & upsampledIndices,
    		unsigned int gridIncrement, unsigned int numNeighborsNeeded)
    {
    	float maxZDiff = .01;

    	std::vector<bool> indicesHasIndex(cloud.points.size(),false);
    	for(unsigned int i=0; i<indices.size(); i++)
    		indicesHasIndex[indices[i]] = true;

    	upsampledIndices.clear();
    	for(int i=0; i<(int) cloud.points.size(); i++){
    		if(indicesHasIndex[i])
    			upsampledIndices.push_back(i);

    		int x = cloud.points[i].imgX;
    		int y = cloud.points[i].imgY;

        	unsigned int numNeighbors = 0;
        	int xMinus = x - x%gridIncrement;
        	int yMinus = y - y%gridIncrement;

        	//on part of grid that was looked at but not in indices
    		if(x % gridIncrement == 0 && y % gridIncrement == 0)
    			continue;

    		//check each of the 4 neighbors
        	if(cloudIndexGrid[xMinus][yMinus] >= 0 && indicesHasIndex[cloudIndexGrid[xMinus][yMinus]])
        	{
        		float zDiff = fabs(cloud.points[i].z - cloud.points[cloudIndexGrid[xMinus][yMinus]].z);
        		if(zDiff < maxZDiff)
        			numNeighbors++;
        	}
        	if(xMinus+gridIncrement < m_xRes && cloudIndexGrid[xMinus+gridIncrement][yMinus] >= 0 &&
        			indicesHasIndex[cloudIndexGrid[xMinus+gridIncrement][yMinus]])
        	{
        		float zDiff = fabs(cloud.points[i].z - cloud.points[cloudIndexGrid[xMinus+gridIncrement][yMinus]].z);
        		if(zDiff < maxZDiff)
        			numNeighbors++;
        	}
        	if(yMinus+gridIncrement < m_yRes && cloudIndexGrid[xMinus][yMinus+gridIncrement] >= 0 &&
        			indicesHasIndex[cloudIndexGrid[xMinus][yMinus+gridIncrement]])
        	{
        		float zDiff = fabs(cloud.points[i].z - cloud.points[cloudIndexGrid[xMinus][yMinus+gridIncrement]].z);
        		if(zDiff < maxZDiff)
        			numNeighbors++;
        	}
        	if(xMinus+gridIncrement < m_xRes && yMinus+gridIncrement < m_yRes &&
        			cloudIndexGrid[xMinus+gridIncrement][yMinus+gridIncrement] >= 0&&
        			indicesHasIndex[cloudIndexGrid[xMinus+gridIncrement][yMinus+gridIncrement]])
        	{
        		float zDiff = fabs(cloud.points[i].z - cloud.points[cloudIndexGrid[xMinus+gridIncrement][yMinus+gridIncrement]].z);
        		if(zDiff < maxZDiff)
        			numNeighbors++;
        	}

        	if(numNeighbors >= numNeighborsNeeded)
        		upsampledIndices.push_back(i);

    	}
    }
#endif


#if 0
    /**
     * Performs the planar extraction and publishes the results
     *
     * @param cloud
     */
	void processCloud(const sensor_msgs::PointCloud2::ConstPtr &cloud)
	{
		ROS_INFO("Extracting planes from cloud");

		double maxDist = m_maxOutOfPlane;
		int maxIts = m_maxIterations;
		int gridIncrement = m_gridIncrement;
		double minFractionOfImage = m_minImageFrac;

		unsigned int minPlaneSize = m_xRes*m_yRes*minFractionOfImage;

		ros::Time startTime = ros::Time::now();

		pcl::PointCloud<rgbd::pt>::Ptr pclCloud(new pcl::PointCloud<rgbd::pt>());
		pcl::fromROSMsg(*cloud,*pclCloud);

		//set the initial set of indices as everything
		std::vector<int> allIndices;
		for(int i=0; i<(int) pclCloud->points.size(); i++)
			allIndices.push_back(i);

		//grid downsample indices
		std::vector<int> downsampledIndices;
		this->gridDownsampleIndices(*pclCloud,allIndices,downsampledIndices,gridIncrement);

		//make a grid to be used during the interpolation step
		std::vector<std::vector<int> > cloudIndexGrid;
		this->getIndexGrid(*pclCloud,cloudIndexGrid);

		//extract planes
		rgbd_msgs::PointCloud2Array planes;
		pcl::ModelCoefficients mostTableishCoeffs; //highest plane having normal close to z
		float highestZ = -1e10;
		mostTableishCoeffs.header = cloud->header;
		mostTableishCoeffs.values.resize(4);
		while(true){
			//fit the plane
			std::vector<int> inliers;
			std::vector<double> coefs;
			segmentation::fitSACPlane<rgbd::pt>(pclCloud,downsampledIndices,inliers,coefs,maxDist,maxIts);

			//get all indices for the new plane
			std::vector<int> upsampledPlaneIndices;
			this->upsampleIndices(*pclCloud,cloudIndexGrid,inliers,upsampledPlaneIndices,gridIncrement,2);

			//check stopping criteria
			if(upsampledPlaneIndices.size() > minPlaneSize){
				pcl::PointCloud<rgbd::pt> newPlane;
				planes.clouds.resize(planes.clouds.size() + 1);
				std::deque<unsigned int> planeIndexDeque;
				this->toUnsignedDeque(upsampledPlaneIndices,planeIndexDeque);
				rgbd::downsampleFromIndices(*pclCloud,newPlane,planeIndexDeque);
				pcl::toROSMsg(newPlane,planes.clouds.back());
				//remove the plane from indices
				subtractIndices(downsampledIndices,inliers,pclCloud->points.size());

				//check table-ness
				float maxAngle = 10*M_PI/180;
				rgbd::eigen::Vector3f normal(coefs[0],coefs[1],coefs[2]);
				float dot = normal.dot(rgbd::eigen::Vector3f::UnitZ());
				if(fabs(dot) > 1) dot/=fabs(dot);
				float angle = acos(fabs(dot));

				ROS_DEBUG("Plane %i has coefs: %f, %f, %f, %f",(int)planes.clouds.size(),
						coefs[0],coefs[1],coefs[2],coefs[3]);
				ROS_DEBUG("Plane %i has angle %f",(int)planes.clouds.size(),angle*180/M_PI);

				if(angle < maxAngle){
					float zIntercept = -coefs[3]/coefs[2];
					if(zIntercept > highestZ){
						highestZ = zIntercept;
						if(dot < 0) for(unsigned int i=0; i<4; i++) coefs[i]*=-1; //flip normal if needed
						for(unsigned int i=0; i<4; i++) mostTableishCoeffs.values[i] = coefs[i];
					}
				}
			}
			else{
				break;
			}


		}

		//also make a cloud for what remains
		pcl::PointCloud<rgbd::pt> remainder;
		std::vector<int> upsampledRemainderIndices; //= allIndices;
		this->upsampleIndices(*pclCloud,cloudIndexGrid,downsampledIndices,
				upsampledRemainderIndices,gridIncrement,2);

		std::deque<unsigned int> remainderIndexDeque;
		toUnsignedDeque(upsampledRemainderIndices,remainderIndexDeque);
		rgbd::downsampleFromIndices(*pclCloud,remainder,remainderIndexDeque);

		sensor_msgs::PointCloud2 remainder2;
		pcl::toROSMsg(remainder,remainder2);

		ros::Time endTime = ros::Time::now();
		ros::Duration dur = endTime-startTime;
		std::cout<<"Extracted "<<planes.clouds.size()<<" planes in "<<dur.toSec()<<" seconds"<<std::endl;

		m_planesPublisher.publish(planes);
		m_remainderPublisher.publish(remainder2);
		m_tableCoeffsPublisher.publish(mostTableishCoeffs);
	}
#endif

    int run()
    {
#if 0
    	ROS_INFO("Planar extractor subscribing to %s",m_cloudSubscriberTopic.c_str());
    	m_cloudSubscriber = nh_local.subscribe<sensor_msgs::PointCloud2>(
    			m_cloudSubscriberTopic,1,&PlaneExtractor::processCloud,this);
#endif

    	ros::spin();
    	return 0;
    }



};// class

int main (int argc, char** argv)
{
	ros::init (argc, argv, "planar_extraction_node");
	PlaneExtractor plane_node;
	return plane_node.run();
}
