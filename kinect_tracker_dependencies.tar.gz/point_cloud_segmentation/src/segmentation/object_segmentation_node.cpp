/*
 * planar_extraction_node.cpp
 *
 *  Created on: 2010-01-27
 *      Author: mkrainin
 */

#include <ros/node_handle.h>
#include <ros/publisher.h>
#include <ros/subscriber.h>
#include "rgbd_util/eigen/Core"
#include "rgbd_util/eigen/Geometry"
#include <rgbd_msgs/PointCloud2Array.h>
#include <sensor_msgs/point_cloud_conversion.h>

#include <pcl/point_cloud.h>
#include <pcl/ros/conversions.h>
#include <pcl_rgbd/pointTypes.h>
#include <pcl_rgbd/cloudSampling.h>
#include <pcl_rgbd/cloudUtils.h>

#include <segmentation/PointCloudSegmenter.h>

#include <vector>
#include <string>
#include <deque>


class ObjectSegmenter
{
protected:
    ros::NodeHandle nh_global;
    ros::NodeHandle nh_local;

    segmentation::PointCloudSegmenter m_segmenter;

    //publishers
    ros::Publisher m_biggestSegmentPubisher;
    ros::Publisher m_segmentListPublisher;

    //subscribers
    std::string m_cloudSubscriberTopic;
    ros::Subscriber m_cloudSubscriber;

    unsigned int m_xRes,m_yRes;

    double m_maxSegmentDist;


public:

    ObjectSegmenter ()
    : nh_global(),
      nh_local("~")
    {
    	std::string biggestSegmentTopic,segmentListTopic;
    	nh_local.param("biggest_segment_topic", biggestSegmentTopic, std::string("/rgbd/biggest_segment"));
    	nh_local.param("segment_list_topic", segmentListTopic, std::string("/rgbd/segment_list"));

    	nh_local.param("subscriber_topic", m_cloudSubscriberTopic, std::string("/rgbd/cloud"));

    	nh_local.param("max_combining_dist", m_maxSegmentDist, .05);



		// Maximum number of outgoing messages to be queued for delivery to subscribers = 1
    	m_biggestSegmentPubisher = nh_global.advertise<sensor_msgs::PointCloud> (biggestSegmentTopic, 1);
    	m_segmentListPublisher = nh_global.advertise<rgbd_msgs::PointCloud2Array> (segmentListTopic, 1);

		m_xRes = 640;
		m_yRes = 480;

		m_segmenter.setResolution(m_xRes,m_yRes);

    }

    ~ObjectSegmenter()
    {
    }

    template <typename PointT>
    rgbd::eigen::Vector3f getPointCloudMean(pcl::PointCloud<PointT> const& cloud)
    {
    	unsigned int cloudSize = cloud.points.size();

    	float xTotal = 0;
    	float yTotal = 0;
    	float zTotal = 0;
    	for(unsigned int i=0; i<cloudSize; i++)
    	{
    		PointT const& pt = cloud.points[i];
    		xTotal+=pt.x;
    		yTotal+=pt.y;
    		zTotal+=pt.z;
    	}

    	return rgbd::eigen::Vector3f(xTotal/cloudSize,yTotal/cloudSize,zTotal/cloudSize);
    }

    template <typename PointT>
    rgbd::eigen::Vector3f getPointClosestToLocation(
    		pcl::PointCloud<PointT> const& cloud, rgbd::eigen::Vector3f const& location)
    {
    	unsigned int cloudSize = cloud.points.size();

    	float closestSqDist = 0;
    	rgbd::eigen::Vector3f closest;

    	for(unsigned int i=0; i<cloudSize; i++)
    	{
    		PointT const& pt = cloud.points[i];
    		rgbd::eigen::Vector3f ptVec(pt.x,pt.y,pt.z);
    		float sqDist = (ptVec - location).squaredNorm();
    		if(i==0 || sqDist < closestSqDist){
    			closestSqDist = sqDist;
    			closest = ptVec;
    		}
    	}

    	return closest;
    }

    template <typename PointT>
    std::vector<rgbd::eigen::Vector3f> getEdgePoints(pcl::PointCloud<PointT> const& cloud)
    {
    	std::vector<rgbd::eigen::Vector3f> edgePoints;

    	std::vector<bool> falses(m_yRes,false);
    	std::vector<std::vector<bool> > isOccupied(m_xRes,falses);

    	for(unsigned int i=0; i< cloud.points.size(); i++){
    		isOccupied[cloud.points[i].imgX][cloud.points[i].imgY] = true;
    	}

    	for(unsigned int i=0; i< cloud.points.size(); i++){
    		bool isEdge = false;
    		int x = cloud.points[i].imgX;
    		int y = cloud.points[i].imgY;
    		if(x-1 > 0 && !isOccupied[x-1][y])
    			isEdge = true;
    		else if(y-1 > 0 && !isOccupied[x][y-1])
    			isEdge = true;
    		else if(x+1 < (int)m_xRes && !isOccupied[x+1][y])
    			isEdge = true;
    		else if(y+1 < (int)m_yRes && !isOccupied[x][y+1])
    			isEdge = true;

    		if(isEdge){
    			PointT const& pt = cloud.points[i];
    			edgePoints.push_back(rgbd::eigen::Vector3f(pt.x,pt.y,pt.z));
    		}
    	}

    	return edgePoints;
    }


    template <typename PointT>
    bool shouldMergeSegments(std::vector<typename pcl::PointCloud<PointT>::Ptr > const& segments,
    		unsigned int segmentIndex1, unsigned int segmentIndex2)
    {
    	//Note: this is the real heart of the segmentation. if you want things
    	//to perform differently, you need to change the rules for combining
    	//segments

    	float maxSquaredDist = pow(m_maxSegmentDist,2);

//    	rgbd::eigen::Vector3f segment1Mean = this->getPointCloudMean(segments[segmentIndex1]);
//    	rgbd::eigen::Vector3f segment2Mean = this->getPointCloudMean(segments[segmentIndex2]);
//
//    	rgbd::eigen::Vector3f segment1Pt = this->getPointClosestToLocation(
//    			segments[segmentIndex1],segment2Mean);
//    	rgbd::eigen::Vector3f segment2Pt = this->getPointClosestToLocation(
//    			segments[segmentIndex2],segment1Mean);
//
//    	return (segment1Pt-segment2Pt).norm() < maxSegmentDist;


    	std::vector<rgbd::eigen::Vector3f> seg1EdgePts = this->getEdgePoints(*(segments[segmentIndex1]));
    	std::vector<rgbd::eigen::Vector3f> seg2EdgePts = this->getEdgePoints(*(segments[segmentIndex2]));

    	for(unsigned int index1 = 0; index1 < seg1EdgePts.size(); index1++){
        	for(unsigned int index2 = 0; index2 < seg2EdgePts.size(); index2++){
        		if((seg1EdgePts[index1]-seg2EdgePts[index2]).squaredNorm() < maxSquaredDist)
        			return true;
        	}
    	}

    	return false;

    }

    template <typename PointT>
    void mergeSegments(std::vector<typename pcl::PointCloud<PointT>::Ptr > & segments,
    		unsigned int segmentIndex1, unsigned int segmentIndex2)
    {
    	rgbd::mergeInPlace(*segments[segmentIndex2], *segments[segmentIndex1]);
    	segments.erase(segments.begin()+segmentIndex2);
    }


    /**
     * Performs the segmentation and publishes the result
     *
     * Note: This assumes that major planes (in particular the table plane)
     * have already been removed
     *
     * @param cloud
     */
	void processCloud(const sensor_msgs::PointCloud2::ConstPtr &cloud)
	{
		float maxRadius = 1.0;
		float maxEdgeDist = .01;
		unsigned int minSegmentSize = 400;
		unsigned int gridIncrement = 1;

		ros::Time start = ros::Time::now();

		pcl::PointCloud<rgbd::pt> pclCloud;
		pcl::fromROSMsg(*cloud,pclCloud);

		//start with a distance removal
		pcl::PointCloud<rgbd::pt> downsampledCloud;
		std::vector<unsigned int> acceptedIndices = rgbd::getRadiusDownsamplingIndices(
				pclCloud,rgbd::eigen::Vector3f::Zero(),maxRadius,true);
		rgbd::downsampleFromIndices(pclCloud,downsampledCloud,acceptedIndices);

		std::vector<pcl::PointCloud<rgbd::pt>::Ptr > segments = m_segmenter.segmentCameraCloud(
				downsampledCloud,maxEdgeDist,minSegmentSize,gridIncrement);

		unsigned int cloudIndex1 = 0;
		unsigned int cloudIndex2 = 1;
		while(true){
			if(cloudIndex1 >= segments.size())
				break;
			if(cloudIndex2 >= segments.size()){
				cloudIndex1++;
				cloudIndex2 = cloudIndex1 + 1;
				continue;
			}

			bool shouldMerge = this->shouldMergeSegments<rgbd::pt>(segments,cloudIndex1,cloudIndex2);
			if(shouldMerge){
				this->mergeSegments<rgbd::pt>(segments,cloudIndex1,cloudIndex2);
				//cloudIndex1 will still point to the same segment (now bigger)
				//and cloudIndex2 will point to the segment after the one
				//that was cloudIndex2, so we don't need to update any indices
			}
			else{
				cloudIndex2++;
			}
		}

		//find the largest
		unsigned int largestSize = 0;
		unsigned int largestIndex = 0;
		for(unsigned int i=0; i<segments.size(); i++){
			unsigned int size = segments[i]->points.size();
			if(i==0 || size > largestSize){
				largestSize = size;
				largestIndex = i;
			}
		}

		ros::Time end = ros::Time::now();
		ros::Duration dur = end-start;
		std::cout<<"Generated "<<segments.size()<<" segments in "<<dur.toSec()<<" seconds"<<std::endl;


		//do the publishing
		rgbd_msgs::PointCloud2Array segmentArray;
		segmentArray.clouds.resize(segments.size());
		for(unsigned int i=0; i<segments.size(); i++){
			pcl::toROSMsg(*(segments[i]),segmentArray.clouds[i]);
		}
		sensor_msgs::PointCloud2 largest2,largest3;
		pcl::toROSMsg(*(segments[largestIndex]),largest2);
		largest3 = largest2;
		rgbd::convertFieldType<unsigned int,float>("imgX", largest2, largest3);
		rgbd::convertFieldType<unsigned int,float>("imgY", largest3, largest2);
		sensor_msgs::PointCloud largest;
		sensor_msgs::convertPointCloud2ToPointCloud(largest2,largest);
		m_segmentListPublisher.publish(segmentArray);
		m_biggestSegmentPubisher.publish(largest);

	}

    int run()
    {
    	m_cloudSubscriber = nh_local.subscribe<sensor_msgs::PointCloud2>(
    			m_cloudSubscriberTopic,1,&ObjectSegmenter::processCloud,this);

    	ros::spin();
    	return 0;
    }



};// class

int main (int argc, char** argv)
{
	ros::init (argc, argv, "object_segmentation_node");
	ObjectSegmenter segmentation_node;
	return segmentation_node.run();
}
