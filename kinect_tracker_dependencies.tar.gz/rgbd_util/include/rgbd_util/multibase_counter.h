/*
 * multibase_counter: enumerate combinations of values of independent digits each of which has its own radix
 *
 * Evan Herbst
 * 12 / 2 / 07
 */

#ifndef EX_MULTIBASE_COUNTER_H
#define EX_MULTIBASE_COUNTER_H

#include <vector>
#include <iostream>
#include <algorithm> //fill()
#include <numeric> //accumulate(), multiplies<>

/*
 * first value iterated over is <0, 0, ... 0>; then <0, 0, ... 1> ... <m_0 - 1, m_1 - 1, ... m_n - 1>
 *
 * T can be any type that can be operated on like an int: it must have a finite range and be settable to 0, incremented, etc. Can't imagine why you'd
 * ever need a non-built-in type, so shouldn't be an issue.
 */
template <typename T> class multibase_counter
{
	public:

		/*
		 * for STL (use operator = after this)
		 */
		multibase_counter() : iterDone(true) {}

		/*
		 * m[i] is the number of legal values for the ith digit (the values are 0, 1, ...)
		 *
		 * 0 is a legal value for an m[i]; it'll result in no iterands, that's all
		 *
		 * Container must have .begin() and .end() and its value type must be convertible to T
		 */
		template <class Container>
		multibase_counter(const Container& m);

		unsigned int size() const {return std::accumulate(bases.begin(), bases.end(), 1, std::multiplies<unsigned int>());}

		bool done() const;
		/*
		 * not defined if done()
		 */
		void operator ++ (int trash);
		/*
		 * not defined if done()
		 */
		const std::vector<T>& operator * () const;

		const multibase_counter& operator = (const multibase_counter& c)
		{
			bases = c.bases;
			curDigits = c.curDigits;
			iterDone = c.iterDone;
			return *this;
		}

		/*
		 * return whether we haven't been initialized
		 */
		bool operator ! () const {return bases.empty();}

		void print(std::ostream& out) const
		{
			out << "< ";
			for(typename std::vector<T>::const_iterator i = curDigits.begin(); i != curDigits.end(); i++) out << *i << ' ';
			out << ">";
		}

	private:

		std::vector<T> bases, curDigits; //max and current value of each digit
		bool iterDone; //done iterating?
};

template <typename T> std::ostream& operator << (std::ostream& out, const multibase_counter<T>& c)
{
	c.print(out); return out;
}

/*
 * m[i] is the number of legal values for the ith digit (the values are 0, 1, ...)
 *
 * 0 is a legal value for an m[i]; it'll result in no iterands, that's all
 *
 * Container must have .begin() and .end() and its value type must be convertible to T
 */
template <typename T> template <class Container>
multibase_counter<T>::multibase_counter(const Container& m) : bases(m.begin(), m.end()), curDigits(bases.size(), 0), iterDone(false)
{
	//if any base is 0, there are no legal combos
	bool zero = false;
	for(unsigned int i = 0; i < bases.size(); i++)
		if(bases[i] == 0)
		{
			zero = true;
			break;
		}
	if(zero) iterDone = true;

	//if there are no digits, there are no legal combos
	if(bases.empty()) iterDone = true;
}

template <typename T>
bool multibase_counter<T>::done() const
{
	return iterDone;
}

/*
 * not defined if done()
 */
template <typename T>
void multibase_counter<T>::operator ++ (int trash)
{
	int i = curDigits.size() - 1;
	while(i >= 0 && curDigits[i] >= bases[i] - 1) i--;
	if(i < 0) iterDone = true;
	else
	{
		curDigits[i]++;
		std::fill(curDigits.begin() + i + 1, curDigits.end(), 0);
	}
}

/*
 * not defined if done()
 */
template <typename T>
const std::vector<T>& multibase_counter<T>::operator * () const
{
	return curDigits;
}

#endif //EX_MULTIBASE_COUNTER_H
