/*
 * hashingUtils: hashing common structures
 *
 * Evan Herbst
 * 3 / 6 / 12
 */

#ifndef EX_HASHING_UTILS_H
#define EX_HASHING_UTILS_H

#include <utility>
#include <boost/functional/hash.hpp>

namespace std
{

template <>
struct hash<std::pair<int, int>>
{
	size_t operator () (const std::pair<int, int>& p) const
	{
		size_t h = 0;
		boost::hash_combine(h, p.first);
		boost::hash_combine(h, p.second);
		return h;
	}
};

}

#endif //header
