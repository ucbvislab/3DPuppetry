/*
 * geometryUtils
 *
 * Evan Herbst
 * 11 / 2 / 11
 */

#ifndef EX_RGBD_GEOMETRY_UTILS_H
#define EX_RGBD_GEOMETRY_UTILS_H

#include <boost/function.hpp>
#include "rgbd_util/eigen/Geometry"

/*
 * return the rotation matrix mapping +x to axis1 and +y to orthogonalize(axis2 wrt axis1)
 */
rgbd::eigen::Matrix3f createRotationMatrixFromAxes(rgbd::eigen::Vector3f axis1, rgbd::eigen::Vector3f axis2);

/*
 * uniformly generate a valid rotation matrix
 *
 * the distribution of rng should be symmetric about zero; it's also helpful, although not necessary, for it to have finite support (eg uniform [-1, 1])
 */
rgbd::eigen::Matrix3f generateRandomRotMtx(const boost::function<double ()>& rng);

#endif //header
