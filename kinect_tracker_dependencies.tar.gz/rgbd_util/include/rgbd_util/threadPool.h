/*
 * threadPool: allocate threads once and use them repeatedly, to reduce multithreading overhead
 *
 * Evan Herbst
 * 1 / 23 / 12
 */

#ifndef EX_RGBD_THREADPOOL_H
#define EX_RGBD_THREADPOOL_H

#include <vector>
#include <memory>
#include <boost/thread.hpp>
#include <boost/bind.hpp>
#include <boost/asio/io_service.hpp>

namespace rgbd
{

/*
 * usage pattern:
 * ---
 * threadGroup tg(NTHREADS);
 * for(i = 0; i < NTHREADS; i++) tg.addTask([i](){run(i);});
 * tg.wait();
 * for(i = 0; i < NTHREADS; i++) useResult(i);
 * ---
 *
 * 20120123: this class works well if used from a single thread, but IS NOT THREAD-SAFE: you can't use different threadGroups from different threads concurrently (TODO add a static lock that gets locked in the ctor and released in the dtor?)
 */
class threadGroup
{
	public:

		threadGroup(const uint32_t numThreads)
		{
			if(!io_service) initClass(numThreads);
			//add threads until we have enough
			for(uint32_t i = threads.size(); i < numThreads; i++)
				threads.create_thread(boost::bind(&boost::asio::io_service::run, io_service.get()));
		}

		~threadGroup()
		{
//			io_service.stop(); //TODO will need to call this somewhere?
		}

		/*
		 * to be called from the main thread
		 */
		template <typename Func>
		void addTask(Func&& f)
		{
			tasks.push_back(std::shared_ptr<boost::packaged_task<void>>(new boost::packaged_task<void>(std::move(f))));
			futures.push_back(tasks.back()->get_future());
			io_service->post(boost::bind(&boost::packaged_task<void>::operator (), tasks.back().get())); //could use the lambda [t](){(*t)();} instead of a bind() here if I copy tasks.back() to a variable t first
		}

		/*
		 * to be called from the main thread
		 */
		void wait()
		{
			boost::wait_for_all(futures.begin(), futures.end());
			futures.clear();
			tasks.clear();
		}

	private:

		void initClass(const uint32_t numThreads)
		{
			io_service.reset(new boost::asio::io_service);
			work.reset(new boost::asio::io_service::work(*io_service));
		}

		static std::shared_ptr<boost::asio::io_service> io_service;
		static std::shared_ptr<boost::asio::io_service::work> work;
		static boost::thread_group threads;
		std::vector<std::shared_ptr<boost::packaged_task<void>>> tasks; //could remove the ptrs if I preallocate the vector instead of push_back()ing
		std::vector<boost::unique_future<void>> futures;
};

} //namespace

#endif //header
