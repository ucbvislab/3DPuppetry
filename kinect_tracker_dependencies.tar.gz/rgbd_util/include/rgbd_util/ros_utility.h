/*
 * ros_utility.h
 *
 *  Created on: Feb 23, 2010
 *      Author: peter
 */

#ifndef ROS_UTILITY_H_
#define ROS_UTILITY_H_

#include <string>
#include <boost/filesystem/path.hpp>
#include <ros/node_handle.h>
#include <ros/time.h>
#include <rgbd_util/eigen/Geometry>
#include <std_msgs/ColorRGBA.h>

namespace rgbd
{

/*
 * no default value
 *
 * return whether the param server had the param (if not, result isn't set)
 */
bool ros_param(ros::NodeHandle& nh, const std::string& name, bool& result);
bool ros_param(ros::NodeHandle& nh, const std::string& name, int& result);
bool ros_param(ros::NodeHandle& nh, const std::string& name, double& result);
bool ros_param(ros::NodeHandle& nh, const std::string& name, std::string& result);
bool ros_param(ros::NodeHandle& nh, const std::string& name, boost::filesystem::path& result);
bool ros_param(ros::NodeHandle& nh, const std::string& name, float& result);
bool ros_param(ros::NodeHandle& nh, const std::string& name, unsigned int& result);

/*
 * extend NodeHandle::param() to more types
 *
 * @deprecated use rgbd::rosparam() with default
 */
void ros_param_float(ros::NodeHandle& nh, std::string const& name, float& result, float default_value);
void ros_param_uint(ros::NodeHandle& nh, std::string const& name, unsigned int& result, unsigned int default_value);

/*
 * replace NodeHandle::param() for any type for which bool rgbd::ros_param() is defined
 *
 * throw if param server doesn't have it
 */
template <typename T>
void rosparam(ros::NodeHandle& nh, const std::string& name, T& result);

/*
 * usable with any type for which bool rgbd::ros_param() is defined
 *
 * use the default if param server doesn't have it
 */
template <typename T>
void rosparam(ros::NodeHandle& nh, const std::string& name, T& result, const T& defaultVal);

std::string convert_timestamp_to_string(const ros::Time ts, const std::string separator = " ");
ros::Time convert_string_to_timestamp(const std::string s);

// looks for tx, ty, tz, qw, qx, qy, qz
rgbd::eigen::Affine3f load_eigen_transform(ros::NodeHandle& nh);

std_msgs::ColorRGBA get_color_msg(float r, float g, float b, float a = 1.0);

} //namespace

#include "rgbd_util/ros_utility.ipp"

#endif /* ROS_UTILITY_H_ */
