/*
 * colorConversion
 *
 * Evan Herbst
 * 7 / 29 / 10
 */

#include <boost/array.hpp>
#include "rgbd_util/eigen/Geometry"

namespace rgbd
{

/*
 * adapted from http://www.cs.rit.edu/~ncs/color/t_convert.html
 */
boost::array<unsigned char, 3> rgb2hsv(const boost::array<unsigned char, 3>& rgb);
/*
 * all outputs are in [0, 1)
 */
boost::array<float, 3> rgb2hsv(const boost::array<float, 3>& rgb);
rgbd::eigen::Vector3f rgb2hsv(const rgbd::eigen::Vector3f& rgb);

boost::array<float, 2> rgb2huecossin(const boost::array<float, 3>& rgb);


} //namespace
