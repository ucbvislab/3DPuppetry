/*
 * mathUtils
 *
 * Evan Herbst
 * 3 / 3 / 10
 */

#ifndef EX_RGBD_MATH_UTILS_H
#define EX_RGBD_MATH_UTILS_H

#include <vector>
#include <boost/range/metafunctions.hpp>
#include <boost/tuple/tuple.hpp>

template <typename T> T sqr(T d) {return d * d;}

/*
 * absolute value
 */
double dabs(double d);

/*
 * integer power of a float
 */
template <typename T>
T powi(T x, unsigned int n);

long round2int(double d);
/*
 * pre: d >= 0
 */
unsigned long round2uint(double d);

template <typename T>
T clamp(const T x, const T min, const T max);

template <typename T> int sgn(T x) {return x < 0 ? -1 : 1;}

/*
 * 2-d Euclidean distance squared
 */
double sqrDist2d(const double x1, const double y1, const double x2, const double y2);

/*
 * log(sinh(x))
 *
 * for large x, sinh(x) \approx e^x, so return x (else we'll hit infinity: e^700 is almost DBL_MAX)
 */
double logSinh(const double x);

/*
 * write sampleSize uniformly selected elements of the input range to the output range (without replacement), using rand()
 *
 * pre: the input range has size at least sampleSize; the output range has size at least sampleSize
 */
template <typename RandomAccessIteratorT, typename OutputIteratorT>
void randomSample(const RandomAccessIteratorT begin, const RandomAccessIteratorT end, const size_t sampleSize, OutputIteratorT obegin);

/*
 * copy the elements of values specified by indices to the output range
 */
template <typename RandomAccessRangeT, typename SinglePassRangeT, typename OutputIteratorT>
void copySelected(const RandomAccessRangeT& values, const SinglePassRangeT& indices, OutputIteratorT obegin);
/*
 * by-value version of copySelected()
 */
template <typename RandomAccessRangeT, typename ForwardRangeT>
std::vector<typename boost::range_value<RandomAccessRangeT>::type> selectByIndices(const RandomAccessRangeT& values, const ForwardRangeT& indices);

/*
 * return an index into probs
 *
 * pre: probs sum to 1
 */
unsigned int sampleDiscreteDistribution(const std::vector<double>& probs);

/*
 * linear interpolation
 *
 * alpha: in [0, 1]
 */
double linterp(const double v0, const double v1, const double alpha);

/*
 * return the sorted list of indices (in [0 .. n-1]) and edit the given range
 *
 * the given data are copied twice
 *
 * pre: the given range is writable
 */
template <typename RandomAccessIteratorT>
std::vector<unsigned int> sortWithIndices(const RandomAccessIteratorT begin, const RandomAccessIteratorT end);
template <typename RandomAccessIteratorT, typename CmpT>
std::vector<unsigned int> sortWithIndices(const RandomAccessIteratorT begin, const RandomAccessIteratorT end, CmpT cmp);

/*
 * convert flags to a vector of which flags are true
 */
void boolVectorToIndices(const std::vector<bool> & flags, std::vector<unsigned int> & indices);

/*
 * remove the specified elements from v
 *
 * EVH 20110111: for long vectors (> 50?) and small numbers of elements to remove, this is the fastest remove function
 *
 * pre: indices is sorted ascending
 *
 * post: relative order of elements may have been changed (deterministically)
 */
template <typename T, typename Alloc>
void removeFromVector(std::vector<T, Alloc>& v, const std::vector<unsigned int>& indices);
/*
 * remove the specified elements from v
 *
 * EVH 20110111: for short vectors (< 50?) and large numbers of elements to remove, this is the fastest remove function
 *
 * post: relative order of elements is unchanged
 */
template<typename T>
void removeFromVector(std::vector<T> &vec, std::vector<bool> const& shouldRemove);
/*
 * remove the specified values from v
 *
 * pre: the order of values in valsToRemove is the same as their order in v; each value in valsToRemove occurs exactly once in v
 *
 * post: relative order of elements is unchanged
 */
template<typename T, typename ForwardRangeT>
void removeUniqueValuesFromOrderedVector(std::vector<T>& v, const ForwardRangeT& valsToRemove);
/*
 * remove the specified elements from r: return an iterator to the end of the shortened part (but don't resize r, since we don't know how)
 *
 * post: relative order of elements may have been changed (deterministically, in the same way as by removeFromVector())
 */
template <typename RandomAccessRangeT>
typename boost::range_iterator<RandomAccessRangeT>::type removeFromRange(RandomAccessRangeT& r, const std::vector<unsigned int>& indices);
/*
 * remove the specified elements from r: return an iterator to the end of the shortened part (but don't resize r, since we don't know how)
 *
 * post: relative order of elements is unchanged
 */
template <typename RandomAccessRangeT>
typename boost::range_iterator<RandomAccessRangeT>::type removeFromRangeNoReorder(RandomAccessRangeT& r, const std::vector<size_t>& indices);

/*
 * toRemove: indices into vec
 *
 * optimized for a relatively small number of removals
 *
 * pre: toRemove is sorted ascending
 */
template<typename RandomAccessRangeT>
std::vector<typename boost::range_value<RandomAccessRangeT>::type> selectAllBut(const RandomAccessRangeT& vec, std::vector<unsigned int> const& toRemove);

/****************************************************************************************
 * comparison functors for STL-style sorting
 */

template <typename T1, typename T2>
struct cmpPairsByFirstDecreasing
{
	bool operator () (const std::pair<T1, T2>& p1, const std::pair<T1, T2>& p2) const
	{
		return p1.first > p2.first;
	}
};
template <typename T1, typename T2>
struct cmpPairsBySecondIncreasing
{
	bool operator () (const std::pair<T1, T2>& p1, const std::pair<T1, T2>& p2) const
	{
		return p1.second < p2.second;
	}
};
template <typename T1, typename T2>
struct cmpPairsBySecondDecreasing
{
	bool operator () (const std::pair<T1, T2>& p1, const std::pair<T1, T2>& p2) const
	{
		return p1.second > p2.second;
	}
};

template <typename BoostTupleT, const unsigned int I>
struct cmpBoostTuplesByNthIncreasing
{
	bool operator () (const BoostTupleT& t1, const BoostTupleT& t2) const
	{
		return boost::get<I>(t1) < boost::get<I>(t2);
	}
};

#include "mathUtils.ipp"

#endif //header
