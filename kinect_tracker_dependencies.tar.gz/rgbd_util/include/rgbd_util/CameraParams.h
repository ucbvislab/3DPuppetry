/*
 * CameraParams.h
 *
 *  Created on: 2010-06-07
 *      Author: mkrainin
 */

#ifndef CAMERAPARAMS_H_
#define CAMERAPARAMS_H_

#include <sensor_msgs/CameraInfo.h>

namespace rgbd{

/*
 * params for an rgbd camera
 *
 * TODO have separate rgb and IR params?
 */
struct CameraParams
{
	unsigned int xRes; //in pixels
	unsigned int yRes; //in pixels
	float centerX; //in pixels
	float centerY; //in pixels
	float focalLength; //in pixels

	float stereoBaseline; //distance between IR projector and IR camera, in meters

	float fovX, fovY; //radians
};

sensor_msgs::CameraInfo camParams2cameraInfo(const CameraParams& p);

}

#endif /* CAMERAPARAMS_H_ */
