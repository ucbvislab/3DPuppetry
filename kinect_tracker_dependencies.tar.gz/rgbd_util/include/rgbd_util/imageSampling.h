/*
 * imageSampling: simple stuff that ought to be easier to do in opencv than it is
 *
 * Evan Herbst
 * 12 / 2 / 10
 */

#ifndef EX_RGBD_IMAGE_SAMPLING_H
#define EX_RGBD_IMAGE_SAMPLING_H

#include <boost/array.hpp>
#include <opencv2/core/core.hpp>
#include <sensor_msgs/Image.h>
#include "rgbd_util/eigen/Geometry"

/*
 * single pixel, no interpolation
 *
 * pre: (x, y) in image bounds
 */
boost::array<uint8_t, 3> sampleAtPixel(const cv::Mat& img, unsigned int x, unsigned int y);
boost::array<uint8_t, 3> sampleAtPixel(const sensor_msgs::Image& img, unsigned int x, unsigned int y);
rgbd::eigen::Vector3f getColorVector(const cv::Mat& img, unsigned int x, unsigned int y);
rgbd::eigen::Vector3f getColorVector(const sensor_msgs::Image& img, unsigned int x, unsigned int y);

/*
 * bilinear interpolation
 *
 * pre: (x, y) in image bounds
 */
rgbd::eigen::Vector3f interpolateImagePixel(const cv::Mat& img, const float x, const float y);
rgbd::eigen::Vector3f interpolateImagePixel(const sensor_msgs::Image& img, const float x, const float y);

#endif //header
