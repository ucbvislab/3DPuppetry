/*
 * yamlUtils: convenience functions for use with yaml-cpp
 *
 * Evan Herbst
 * 2 / 24 / 11
 */

#ifndef EX_YAML_UTILS_H
#define EX_YAML_UTILS_H

#include <vector>
#include <string>
#include <boost/filesystem/path.hpp>
#include <yaml-cpp/yaml.h>
namespace fs = boost::filesystem;

/*
 * throw if not found
 */
std::string readYAMLString(YAML::Node& doc, const std::string& name);
/*
 * return empty if not found
 */
std::string readYAMLStringOrEmpty(YAML::Node& doc, const std::string& name);

/*
 * return empty if not found
 */
std::vector<std::string> readYAMLListOrEmpty(YAML::Node& doc, const std::string& name);

/*
 * return empty if not found
 */
void getOptionalRelativePath(YAML::Node& doc, const std::string& key, fs::path& var, const fs::path& rootDir);
void getOptionalRelativePathList(YAML::Node& doc, const std::string& key, std::vector<fs::path>& var, const fs::path& rootDir);

#endif //header
