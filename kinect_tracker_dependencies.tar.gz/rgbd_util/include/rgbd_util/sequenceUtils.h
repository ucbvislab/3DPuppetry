/*
 * sequenceUtils: functions for working with sequences/containers/ranges/whatever you like to call them
 *
 * Evan Herbst
 * 1 / 19 / 12
 */

#ifndef EX_RGBD_SEQUENCE_UTILS_H
#define EX_RGBD_SEQUENCE_UTILS_H

#include "rgbd_util/eigen/Geometry"

/*
 * copy the selected matrix rows to tgt
 *
 * tgt will be allocated
 */
template <typename SinglePassRangeT>
void copySelectedMtxRows(const rgbd::eigen::MatrixXf& src, const SinglePassRangeT& indices, rgbd::eigen::MatrixXf& tgt);

#include "sequenceUtils.ipp"

#endif //header
