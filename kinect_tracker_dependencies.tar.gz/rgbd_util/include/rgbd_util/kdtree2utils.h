/*
 * kdtree2utils
 *
 * Evan Herbst
 * 1 / 21 / 11
 */

#ifndef EX_KDTREE2_UTILS_H
#define EX_KDTREE2_UTILS_H

#include <climits> //UINT_MAX
#include <kdtree2/kdtree2.hpp>

/*
 * params for a k-d tree search
 */
struct kdtreeNbrhoodSpec
{
	/*
	 * convenience functions for using only one search type
	 */
	static kdtreeNbrhoodSpec byCount(const unsigned int n) {return kdtreeNbrhoodSpec(n, -1, false);}
	static kdtreeNbrhoodSpec byRadius(const double r) {return kdtreeNbrhoodSpec(UINT_MAX, r, true);}

	/*
	 * r: radius, NOT squared radius
	 */
	kdtreeNbrhoodSpec(const unsigned int n, const double r, const bool f) : numNbrs(n), sqrNbrhoodRadius(r * r), radiusSearchFirst(f) {}

	unsigned int numNbrs; //UINT_MAX means don't use (unless !radiusSearchFirst)
	double sqrNbrhoodRadius; //< 0 means don't use (unless radiusSearchFirst)
	bool radiusSearchFirst; //if true, search by radius, then cut off by nbr-list size; if false, do the other order
};

kdtree2_result_vector searchKDTree(const kdtree2& tree, const kdtreeNbrhoodSpec& nspec, const std::vector<float>& query);

#endif //header
