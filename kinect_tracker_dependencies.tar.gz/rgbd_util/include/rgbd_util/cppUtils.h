/*
 * cppUtils.h: deal with screwed-up pieces of C++
 *
 * Evan Herbst
 * 10 / 13 / 10
 */

#ifndef EX_RGBD_CPP_UTILS_H
#define EX_RGBD_CPP_UTILS_H

#include <vector>

namespace rgbd
{

/*
 * a solution to the vector<bool> issue
 */
typedef std::vector<char> boolVector;

} //namespace

#endif //header
