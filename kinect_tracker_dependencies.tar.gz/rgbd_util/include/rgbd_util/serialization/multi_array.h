/*
 * multi_array: serialize boost.multi_arrays with boost.serialization
 *
 * Evan Herbst
 * 7 / 15 / 09
 */

#ifndef EX_SERIALIZE_MULTI_ARRAY_H
#define EX_SERIALIZE_MULTI_ARRAY_H

#include <cstddef> //size_t
#include <array>
#include <boost/multi_array.hpp>
#include <boost/serialization/array.hpp>
#include <boost/serialization/split_free.hpp>
#include <boost/preprocessor/repetition/repeat.hpp>
//#include "serialization/array.h" apparently the compiler can't figure out which instantiations to make itself, so use boost.serialization's array stuff instead

namespace boost {
namespace serialization {

/*
 * instantiate for dimensionalities through (this - 1)
 */
#define MAX_MULTIARRAY_SERIALIZE_DIM 7

#define MULTI_ARRAY_SERIALIZATION_CREATE(z, N, ignored) \
template <typename Archive, typename T>\
void serialize(Archive &ar, boost::multi_array<T, N>& a, const unsigned int version)\
{\
	boost::serialization::split_free(ar, a, version);\
}\
template <typename Archive, typename T>\
void save(Archive &ar, const boost::multi_array<T, N>& a, const unsigned int version)\
{\
	ar << boost::serialization::make_array(a.shape(), N);\
	ar << boost::serialization::make_array(a.index_bases(), N);\
	ar << boost::serialization::make_array(a.data(), a.num_elements());\
}\
template <typename Archive, typename T>\
void load(Archive &ar, boost::multi_array<T, N>& a, const unsigned int version)\
{\
	std::array<typename boost::multi_array<T, N>::size_type, N> sizes;\
	ar >> boost::serialization::make_array(sizes.data(), N);/* TODO figure out how to get boost.serialization to do array<>s w/o explictly specializing the relevant code */\
	a.resize(sizes);\
	std::array<boost::multi_array_types::index, N> bases;\
	ar >> boost::serialization::make_array(bases.data(), N);/* ditto */\
	a.reindex(bases);\
	ar >> boost::serialization::make_array(a.data(), a.num_elements());\
}

BOOST_PP_REPEAT(MAX_MULTIARRAY_SERIALIZE_DIM, MULTI_ARRAY_SERIALIZATION_CREATE, ignored)

#undef MULTI_ARRAY_SERIALIZATION_CREATE
#undef MAX_MULTIARRAY_SERIALIZE_DIM

} //namespace
} //namespace

#endif //EX_SERIALIZE_MULTI_ARRAY_H
