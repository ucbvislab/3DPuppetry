/*
 * eigen: serialize Eigen arrays with boost.serialization
 *
 * Evan Herbst
 * 8 / 14 / 10
 */

#ifndef EX_SERIALIZE_EIGEN_H
#define EX_SERIALIZE_EIGEN_H

#include <boost/serialization/array.hpp>
#include <boost/serialization/split_free.hpp>
#include <boost/preprocessor/repetition/repeat_from_to.hpp>
#include <boost/preprocessor/seq/for_each.hpp>
#include "rgbd_util/eigen/Geometry"

namespace boost {
namespace serialization {

/*
 * instantiate for fixed-size arrays of size through (this - 1)
 */
#define MAX_EIGEN_SERIALIZE_FIXED_SIZE 5

#define EIGEN_SERIALIZATION_FIXED_CREATE(z, N, type) \
template <typename Archive>\
void serialize(Archive &ar, rgbd::eigen::Matrix<type, N, 1, rgbd::eigen::ColMajor>& a, const unsigned int version)\
{\
	ar & boost::serialization::make_array(a.data(), a.size());\
}\
\
template <typename Archive>\
void serialize(Archive &ar, rgbd::eigen::Matrix<type, N, N, rgbd::eigen::ColMajor>& a, const unsigned int version)\
{\
	ar & boost::serialization::make_array(a.data(), a.size());\
}\
\
template <typename Archive>\
void serialize(Archive &ar, rgbd::eigen::Matrix<type, N, 1, rgbd::eigen::RowMajor>& a, const unsigned int version)\
{\
	ar & boost::serialization::make_array(a.data(), a.size());\
}\
\
template <typename Archive>\
void serialize(Archive &ar, rgbd::eigen::Matrix<type, N, N, rgbd::eigen::RowMajor>& a, const unsigned int version)\
{\
	ar & boost::serialization::make_array(a.data(), a.size());\
}

#define EIGEN_SERIALIZATION_FIXED_CREATE_FOR_TYPES(z, N, typeList) \
	BOOST_PP_SEQ_FOR_EACH(EIGEN_SERIALIZATION_FIXED_CREATE, N, typeList)

/*
 * generate for each type for each size
 */
BOOST_PP_REPEAT_FROM_TO(2, MAX_EIGEN_SERIALIZE_FIXED_SIZE, EIGEN_SERIALIZATION_FIXED_CREATE_FOR_TYPES,
	(unsigned char)(char)(unsigned short)(short)(unsigned int)(int)(unsigned long)(long)(float)(double))

#undef EIGEN_SERIALIZATION_FIXED_CREATE
#undef EIGEN_SERIALIZATION_FIXED_CREATE_FOR_TYPES
#undef MAX_EIGEN_SERIALIZE_FIXED_SIZE

#define EIGEN_SERIALIZATION_DYNAMIC_CREATE(type) \
/* VectorXT */\
template <typename Archive>\
void serialize(Archive &ar, rgbd::eigen::Matrix<type, rgbd::eigen::Dynamic, 1, rgbd::eigen::ColMajor>& a, const unsigned int version)\
{\
	boost::serialization::split_free(ar, a, version);\
}\
template <typename Archive>\
void save(Archive &ar, const rgbd::eigen::Matrix<type, rgbd::eigen::Dynamic, 1, rgbd::eigen::ColMajor>& a, const unsigned int version)\
{\
	const size_t len = a.size(); /* need to give op << a reference */\
	ar << len << boost::serialization::make_array(a.data(), a.size());\
}\
template <typename Archive>\
void load(Archive &ar, rgbd::eigen::Matrix<type, rgbd::eigen::Dynamic, 1, rgbd::eigen::ColMajor>& a, const unsigned int version)\
{\
	size_t len;\
	ar >> len;\
	a.resize(len);\
	ar >> boost::serialization::make_array(a.data(), a.size());\
}\
template <typename Archive>\
void serialize(Archive &ar, rgbd::eigen::Matrix<type, rgbd::eigen::Dynamic, 1, rgbd::eigen::RowMajor>& a, const unsigned int version)\
{\
	boost::serialization::split_free(ar, a, version);\
}\
template <typename Archive>\
void save(Archive &ar, const rgbd::eigen::Matrix<type, rgbd::eigen::Dynamic, 1, rgbd::eigen::RowMajor>& a, const unsigned int version)\
{\
	const size_t len = a.size(); /* need to give op << a reference */\
	ar << len << boost::serialization::make_array(a.data(), a.size());\
}\
template <typename Archive>\
void load(Archive &ar, rgbd::eigen::Matrix<type, rgbd::eigen::Dynamic, 1, rgbd::eigen::RowMajor>& a, const unsigned int version)\
{\
	size_t len;\
	ar >> len;\
	a.resize(len);\
	ar >> boost::serialization::make_array(a.data(), a.size());\
}\
/* MatrixXT */\
template <typename Archive>\
void serialize(Archive &ar, rgbd::eigen::Matrix<type, rgbd::eigen::Dynamic, rgbd::eigen::Dynamic, rgbd::eigen::ColMajor>& a, const unsigned int version)\
{\
	boost::serialization::split_free(ar, a, version);\
}\
template <typename Archive>\
void save(Archive &ar, const rgbd::eigen::Matrix<type, rgbd::eigen::Dynamic, rgbd::eigen::Dynamic, rgbd::eigen::ColMajor>& a, const unsigned int version)\
{\
	const size_t r = a.rows(), c = a.cols(); /* need to give op << a reference */\
	ar << r << c << boost::serialization::make_array(a.data(), r * c);\
}\
template <typename Archive>\
void load(Archive &ar, rgbd::eigen::Matrix<type, rgbd::eigen::Dynamic, rgbd::eigen::Dynamic, rgbd::eigen::ColMajor>& a, const unsigned int version)\
{\
	size_t r, c;\
	ar >> r >> c;\
	a.resize(r, c);\
	ar >> boost::serialization::make_array(a.data(), r * c);\
}\
template <typename Archive>\
void serialize(Archive &ar, rgbd::eigen::Matrix<type, rgbd::eigen::Dynamic, rgbd::eigen::Dynamic, rgbd::eigen::RowMajor>& a, const unsigned int version)\
{\
	boost::serialization::split_free(ar, a, version);\
}\
template <typename Archive>\
void save(Archive &ar, const rgbd::eigen::Matrix<type, rgbd::eigen::Dynamic, rgbd::eigen::Dynamic, rgbd::eigen::RowMajor>& a, const unsigned int version)\
{\
	const size_t r = a.rows(), c = a.cols(); /* need to give op << a reference */\
	ar << r << c << boost::serialization::make_array(a.data(), r * c);\
}\
template <typename Archive>\
void load(Archive &ar, rgbd::eigen::Matrix<type, rgbd::eigen::Dynamic, rgbd::eigen::Dynamic, rgbd::eigen::RowMajor>& a, const unsigned int version)\
{\
	size_t r, c;\
	ar >> r >> c;\
	a.resize(r, c);\
	ar >> boost::serialization::make_array(a.data(), r * c);\
}

EIGEN_SERIALIZATION_DYNAMIC_CREATE(bool)
EIGEN_SERIALIZATION_DYNAMIC_CREATE(float)
EIGEN_SERIALIZATION_DYNAMIC_CREATE(double)

#undef EIGEN_SERIALIZATION_DYNAMIC_CREATE

/*
 * Transform
 */
template <typename Archive>
void serialize(Archive &ar, rgbd::eigen::Affine3f& a, const unsigned int version)
{
	serialize(ar, a.matrix(), version);
}

} //namespace
} //namespace

#endif //header
