/*
 * topK: a data structure to hold up to the top k of something, in sorted order
 *
 * Evan Herbst
 * 10 / 22 / 11
 */

#ifndef EX_TOP_K_H
#define EX_TOP_K_H

#include <algorithm>
#include <functional>

/*
 * we hold values of type ValueT and compare them with CmpT
 *
 * sort order is descending by CmpT (ie if CmpT(x, y), x comes before y)
 */
template <typename ValueT, typename CmpT = std::greater<ValueT>>
class topK
{
	public:

		/*
		 * we'll never keep more than the top maxlen items
		 */
		topK(const size_t maxlen) : maxSize(maxlen) {}

		/*
		 * return: whether v is now in the list
		 */
		bool add(const ValueT& v)
		{
			vals.push_back(v);
			std::inplace_merge(vals.begin(), vals.end() - 1, vals.end(), CmpT());
			const bool added = (vals.size() <= maxSize) || !(vals.back() == v);
			if(vals.size() > maxSize) vals.resize(maxSize);
			return added;
		}

		size_t size() const {return vals.size();}

		/*
		 * iterate through items currently in the list, from greatest ("top") to least
		 */
		typedef typename std::vector<ValueT>::const_iterator iterator;
		iterator begin() const {return vals.begin();}
		iterator end() const {return vals.end();}

		/*
		 * random access
		 */
		const ValueT& operator [] (const size_t index) const {return vals[index];}
		void remove(const size_t index) {vals.erase(vals.begin() + index, vals.begin() + index + 1);}

	private:

		size_t maxSize;
		std::vector<ValueT> vals;
};

#endif //header
