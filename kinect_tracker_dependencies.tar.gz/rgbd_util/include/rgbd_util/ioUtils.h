/*
 * ioUtils: low-level I/O
 *
 * Evan Herbst
 * 7 / 29 / 10
 */

#ifndef EX_IO_UTILS_H
#define EX_IO_UTILS_H

#include <iostream>
#include <iterator>

/***************************************************************
 * interactivity
 */

/*
 * say "waiting" and wait for a keypress
 */
void waitKey();

/***************************************************************
 * binary I/O
 */

template <typename T>
std::istream& readBinary(std::istream& in, T& t)
{
	return in.read(reinterpret_cast<char*>(&t), sizeof(T));
}

template <typename T>
std::ostream& writeBinary(std::ostream& out, const T t)
{
	return out.write(reinterpret_cast<const char*>(&t), sizeof(T));
}

template <typename T>
std::istream& readBinaryArray(std::istream& in, T* const a, const size_t size)
{
	return in.read(reinterpret_cast<char*>(a), size * sizeof(T));
}

template <typename T>
std::ostream& writeBinaryArray(std::ostream& out, const T* const a, const size_t size)
{
	return out.write(reinterpret_cast<const char*>(a), size * sizeof(T));
}

template <typename ValueT, typename OutputIteratorT>
std::istream& readBinaryRange(std::istream& in, OutputIteratorT obegin, const unsigned int count)
{
	ValueT t;
	for(unsigned int i = 0; i < count; i++)
	{
		readBinary(in, t);
		*obegin++ = t;
	}
	return in;
}

template <typename InputIteratorT>
std::ostream& writeBinaryRange(std::ostream& out, const InputIteratorT begin, const InputIteratorT end)
{
	for(InputIteratorT i = begin; i != end; i++) writeBinary(out, *i);
	return out;
}

#endif //header
