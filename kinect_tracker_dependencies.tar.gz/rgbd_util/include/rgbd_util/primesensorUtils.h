/*
 * primesensorUtils: for working with the primesensor specifically
 *
 * Evan Herbst
 * 9 / 22 / 10
 */

#ifndef EX_PRIMESENSOR_UTILS_H
#define EX_PRIMESENSOR_UTILS_H

#include <string>
#include <boost/shared_ptr.hpp>
#include <ros/ros.h> // nodehandle, log messages
#include "rgbd_util/CameraParams.h"
#include "rgbd_util/eigen/Geometry"

namespace rgbd
{

enum cameraID
{
	INVALID_CAM, //meant to always throw errors if used at runtime
	//rgbd cameras
	PRIMESENSOR_DEFAULT, //ideal primesensor webcam
	PRIMESENSOR_320_DEFAULT, // ideal primesensor in QVGA 320x240 mode
	PRIMESENSOR_0332100155, //'owned' by Xiaofeng; firmware v5.1.6
	KINECT_640_DEFAULT,
	KINECT_320_DEFAULT,
	KINECT_MIT_QUADCOPTER,
	//high-res rgb cameras
	POINT_GREY_GRASSHOPPER_7430345,
	//primesensor-and-high-res rigs
	METALSTRIP_AND_TAPE_20101013,
	FABRICATED_HOLSTER_20101119
};

struct cameraSetup
{
	cameraSetup() : cam(INVALID_CAM), hiresCam(INVALID_CAM), hiresRig(INVALID_CAM)
	{}

	/*
	 * required
	 */
	cameraID cam;
	/*
	 * optional: high-resolution cam
	 */
	cameraID hiresCam, hiresRig;
};

cameraID getCameraIDFromString(std::string camera_id_string);

/*
 * Returns a null ptr if string is empty
 * Throws error if non-empty string not recognized
 */
boost::shared_ptr<rgbd::CameraParams> getCameraParamsPtrFromString(std::string camera_id_string);

/*
 * Searches the parameter space until param_name is found....if not found, returns NULL
 */
boost::shared_ptr<rgbd::CameraParams> getCameraParamsPtrFromROSParamSearch(ros::NodeHandle & nh, std::string param_name);

} //namespace

namespace primesensor
{

/*
 * be sure the camera you ask about is actually a depth camera
 */
rgbd::CameraParams getDepthCamParams(const rgbd::cameraID cam);
/*
 * be sure the camera you ask about is actually an rgb camera
 */
rgbd::CameraParams getColorCamParams(const rgbd::cameraID cam);

/*
 * return the 3-d transform to take points from the frame of a primesensor to the frame of a high-res cam attached to it
 */
rgbd::eigen::Affine3f getLores2hiresXform(const rgbd::cameraID cam);

/*
 * return the stereo depth error (difference in depth for a 1-pixel disparity difference) at depth z meters
 */
double stereoError(const double z);
/*
 * return the ratio of the stereo depth error at depth z meters to the error at depth 1 meter
 */
double stereoErrorRatio(const double z);
/*
 * return: 1-meter equivalent depth difference
 */
double normalizedDepthDistance(const double z1, const double z2);

} //namespace

#endif //header
