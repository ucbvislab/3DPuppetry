/*
 * colorConversion
 *
 * Evan Herbst
 * 7 / 29 / 10
 */

#include "rgbd_util/colorConversion.h"
#include "math.h"

namespace rgbd
{

// todo: call float version internally
boost::array<unsigned char, 3> rgb2hsv(const boost::array<unsigned char, 3>& rgb)
{
	boost::array<unsigned char, 3> hsv;
	const double r = rgb[0] / 255.0, g = rgb[1] / 255.0, b = rgb[2] / 255.0;
	double h, s, v;

	double min, max;
	min = r; if(g < min) min = g; if(b < min) min = b;
	max = r; if(g > max) max = g; if(b > max) max = b;
	v = max;				// v

	const double delta = max - min;

	if( max > 0 )
	{
		s = delta / max;		// s
		if(delta == 0)
		{
			h = 0;
		}
		else
		{

			if( r == max )
				h = ( g - b ) / delta;		// between yellow & magenta
			else if( g == max )
				h = 2 + ( b - r ) / delta;	// between cyan & yellow
			else
				h = 4 + ( r - g ) / delta;	// between magenta & cyan

			h *= 60;				// degrees
			if( h < 0 )
				h += 360;
		}
	}
	else {
		// r = g = b = 0		// s = 0, v is undefined
		s = 0;
		h = 1;
		v = 1;
	}

	hsv[0] = h * 255 / 360;
	hsv[1] = s * 255;
	hsv[2] = v * 255;
	return hsv;
}

/*
 * all outputs are in [0, 1)
 */
boost::array<float, 3> rgb2hsv(const boost::array<float, 3>& rgb)
{
	boost::array<float, 3> hsv;
	const double r = rgb[0], g = rgb[1], b = rgb[2];
	double h, s, v;

	double min, max;
	min = r; if(g < min) min = g; if(b < min) min = b;
	max = r; if(g > max) max = g; if(b > max) max = b;
	v = max;				// v

	const double delta = max - min;

	if( max > 0 )
	{
		s = delta / max;		// s
		if(delta == 0)
		{
			h = 0;
		}
		else
		{
			if( r == max )
				h = ( g - b ) / delta;		// between yellow & magenta
			else if( g == max )
				h = 2 + ( b - r ) / delta;	// between cyan & yellow
			else
				h = 4 + ( r - g ) / delta;	// between magenta & cyan

			//put h into [0, 1)
			h /= 6;
			if( h < 0 )
				h += 1;
		}
	}
	else {
		// r = g = b = 0		// s = 0, v is undefined
		s = 0;
		h = 0;
		v = 0;
	}

	hsv[0] = h;
	hsv[1] = s;
	hsv[2] = v;
	return hsv;
}
rgbd::eigen::Vector3f rgb2hsv(const rgbd::eigen::Vector3f& rgb)
{
	const boost::array<float, 3> rgbA = {{rgb[0], rgb[1], rgb[2]}}, hsvA = rgb2hsv(rgbA);
	return rgbd::eigen::Vector3f(hsvA[0], hsvA[1], hsvA[2]);
}

boost::array<float, 2> rgb2huecossin(const boost::array<float, 3>& rgb)
{
	const boost::array<float, 3> hsv = rgbd::rgb2hsv(rgb);
	// h is between 0.0 and 1.0...take to radians
	float hue_radians = hsv[0] * M_2_PI;
	boost::array<float, 2> cos_sin;
	cos_sin[0] = cos(hue_radians);
	cos_sin[1] = sin(hue_radians);
	return cos_sin;
}

} //namespace
