/*
 * ros_utility.cpp
 *
 *  Created on: Feb 23, 2010
 *      Author: peter
 */

#include <cassert>
#include <sstream>
#include <iomanip>
#include "rgbd_util/ros_utility.h"
using std::string;

namespace rgbd
{

/*
 * no default value
 *
 * return whether the param server had the param (if not, result isn't set)
 */
bool ros_param(ros::NodeHandle& nh, const std::string& name, bool& result) {return nh.getParam(name, result);}
bool ros_param(ros::NodeHandle& nh, const std::string& name, int& result) {return nh.getParam(name, result);}
bool ros_param(ros::NodeHandle& nh, const std::string& name, double& result) {return nh.getParam(name, result);}
bool ros_param(ros::NodeHandle& nh, const std::string& name, std::string& result) {return nh.getParam(name, result);}
bool ros_param(ros::NodeHandle& nh, const std::string& name, float& result)
{
	double temp_double;
	bool has_param = nh.getParam(name, temp_double);
	if(has_param) result = (double) temp_double;
	return has_param;
}
bool ros_param(ros::NodeHandle& nh, const std::string& name, unsigned int& result)
{
	int temp_int;
	bool has_param = nh.getParam(name, temp_int);
	if(has_param) result = temp_int;
	return has_param;
}
bool ros_param(ros::NodeHandle& nh, const std::string& name, boost::filesystem::path& result)
{
	string temp;
	const bool has_param = nh.getParam(name, temp);
	if(has_param) result = temp;
	return has_param;
}

void ros_param_float(ros::NodeHandle& nh, std::string const& name, float& result, float default_value)
{
	double temp_double;
	nh.param(name, temp_double, (double) default_value);
	result = (double) temp_double;
}
void ros_param_uint(ros::NodeHandle& nh, std::string const& name, unsigned int& result, unsigned int default_value)
{
	int temp;
	nh.param(name, temp, (int)default_value);
	assert(temp >= 0);
	result = temp;
}

std::string convert_timestamp_to_string(const ros::Time ts, const std::string separator)
{
	std::stringstream ss;
	ss << ts.sec << separator << std::setfill('0') << std::setw(9) << ts.nsec;
	return ss.str();
}

ros::Time convert_string_to_timestamp(const std::string s)
{
	uint32_t sec;
	uint32_t nsec;
	char separator;
	std::stringstream ss(s);
	ss >> sec; ss.get(separator); ss >> nsec;
	return ros::Time(sec, nsec);
}

rgbd::eigen::Affine3f load_eigen_transform(ros::NodeHandle& nh)
{
	rgbd::eigen::Vector3f t;
	rosparam(nh, "tx", t.x());
	rosparam(nh, "ty", t.y());
	rosparam(nh, "tz", t.z());
	rgbd::eigen::Quaternionf q;
	rosparam(nh, "qw", q.w());
	rosparam(nh, "qx", q.x());
	rosparam(nh, "qy", q.y());
	rosparam(nh, "qz", q.z());
	rgbd::eigen::Affine3f result(q);
	result.pretranslate(t);
	return result;
}

std_msgs::ColorRGBA get_color_msg(float r, float g, float b, float a)
{
	std_msgs::ColorRGBA result;
	result.r = r;
	result.g = g;
	result.b = b;
	result.a = a;
	return result;
}

} //namespace
