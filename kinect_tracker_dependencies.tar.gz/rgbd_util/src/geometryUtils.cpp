/*
 * geometryUtils
 *
 * Evan Herbst
 * 11 / 2 / 11
 */

#include <cassert>
#include <cmath>
#include <iostream>
#include "rgbd_util/geometryUtils.h"
using std::cout;
using std::endl;
using rgbd::eigen::Vector3f;
using rgbd::eigen::Matrix3f;

/*
 * return the rotation matrix mapping +x to axis1 and +y to orthogonalize(axis2 wrt axis1)
 */
Matrix3f createRotationMatrixFromAxes(Vector3f axis1, Vector3f axis2)
{
	Matrix3f R;
	R.row(0) = axis1.normalized();
	R.row(1) = axis2.normalized();
	if(fabs(R.row(1).dot(R.row(0))) >= .99)
	{
		cout << "bad: axis1 " << axis1.normalized().transpose() << ", axis2 " << axis2.normalized().transpose() << endl;
		assert(false);
	}
	R.row(1) = (R.row(1) - R.row(1).dot(R.row(0)) * R.row(0)).normalized();
	R.row(2) = R.row(0).cross(R.row(1));
	return R;
}

/*
 * uniformly generate a valid rotation matrix
 *
 * the distribution of rng should be symmetric about zero; it's also helpful, although not necessary, for it to have finite support (eg uniform [-1, 1])
 */
Matrix3f generateRandomRotMtx(const boost::function<double ()>& rng)
{
	const double x1 = rng(), y1 = rng(), z1 = rng(); //ensure each gen call finishes before next starts
	Vector3f axis1(x1, y1, z1), axis2(1, 0, 0); //pick a random pt in the unit sphere
	axis1.normalize();
	double n = axis1.squaredNorm(); //should be 1
	while(isinf(n) || n < 1e-6) //if x1, y1, z1 were too large or small
	{
		const double x1 = rng(), y1 = rng(), z1 = rng();
		axis1 = Vector3f(x1, y1, z1).normalized();
		n = axis1.squaredNorm();
	}
	if(axis2.dot(axis1) > .9/* close to 1 */) axis2 = Vector3f(0, 1, 0);
	axis2 = (axis2 - axis1 * axis2.dot(axis1)).normalized(); //orthogonalize
	return createRotationMatrixFromAxes(axis1, axis2);
}
