/*
 * imageSampling: simple stuff that ought to be easier to do in opencv than it is
 *
 * Evan Herbst
 * 12 / 2 / 10
 */

#include <exception>
#include "rgbd_util/imageSampling.h"
using namespace std;

boost::array<uint8_t, 3> sampleAtPixel(const cv::Mat& img, unsigned int x, unsigned int y)
{
	assert(img.type() == CV_8UC3);
	boost::array<uint8_t, 3> result;
	const cv::Vec3b& col = img.at<cv::Vec3b>(y, x);
	//assume bgr encoding
	result[2] = col[0];
	result[1] = col[1];
	result[0] = col[2];
	return result;
}
boost::array<uint8_t, 3> sampleAtPixel(const sensor_msgs::Image& img, unsigned int x, unsigned int y)
{
	assert(x < img.width && y < img.height);

	boost::array<uint8_t, 3> result;
	const uint8_t *image_p = &img.data[0];
	if(img.encoding == "rgb8")
	{
		const uint8_t *color = image_p + (y * img.step + x * 3);
		result[0] = color[0];
		result[1] = color[1];
		result[2] = color[2];
	}
	else if(img.encoding == "bgr8")
	{
		const uint8_t *color = image_p + (y * img.step + x * 3);
		result[0] = color[2];
		result[1] = color[1];
		result[2] = color[0];
	}
	else throw std::invalid_argument("unsupported image encoding " + img.encoding);
	return result;
}

rgbd::eigen::Matrix<uint8_t, 3, 1> array2eigen(const boost::array<uint8_t, 3> a)
{
	return rgbd::eigen::Matrix<uint8_t, 3, 1>(a[0], a[1], a[2]);
}

rgbd::eigen::Vector3f getColorVector(const cv::Mat& img, unsigned int x, unsigned int y)
{
	return array2eigen(sampleAtPixel(img, x, y)).cast<float>() / 255.0;
}
rgbd::eigen::Vector3f getColorVector(const sensor_msgs::Image& img, unsigned int x, unsigned int y)
{
	return array2eigen(sampleAtPixel(img, x, y)).cast<float>() / 255.0;
}

rgbd::eigen::Vector3f interpolateImagePixel(const cv::Mat& img, const float x, const float y)
{
	int x_floor = (int)x, x_ceil = min(x_floor + 1, img.cols - 1);
	int y_floor = (int)y, y_ceil = min(y_floor + 1, img.rows - 1);

	//between 0 and 1
	float x_resid = x - x_floor;
	float y_resid = y - y_floor;
	//C for ceiling, F for floor
	float coefCC = x_resid*y_resid;
	float coefCF = x_resid*(1-y_resid);
	float coefFC = (1-x_resid)*y_resid;
	float coefFF = (1-x_resid)*(1-y_resid);

	const rgbd::eigen::Vector3f result = coefFF * getColorVector(img,x_floor,y_floor) +
			coefFC * getColorVector(img,x_floor,y_ceil) +
			coefCF * getColorVector(img,x_ceil,y_floor) +
			coefCC * getColorVector(img,x_ceil,y_ceil);
	return result;
}
rgbd::eigen::Vector3f interpolateImagePixel(const sensor_msgs::Image& img, const float x, const float y)
{
	int x_floor = (int)x, x_ceil = min(x_floor + 1, (signed)img.width - 1);
	int y_floor = (int)y, y_ceil = min(y_floor + 1, (signed)img.height - 1);

	//between 0 and 1
	float x_resid = x - x_floor;
	float y_resid = y - y_floor;
	//C for ceiling, F for floor
	float coefCC = x_resid*y_resid;
	float coefCF = x_resid*(1-y_resid);
	float coefFC = (1-x_resid)*y_resid;
	float coefFF = (1-x_resid)*(1-y_resid);

	const rgbd::eigen::Vector3f result = coefFF * getColorVector(img,x_floor,y_floor) +
			coefFC * getColorVector(img,x_floor,y_ceil) +
			coefCF * getColorVector(img,x_ceil,y_floor) +
			coefCC * getColorVector(img,x_ceil,y_ceil);
	return result;
}
