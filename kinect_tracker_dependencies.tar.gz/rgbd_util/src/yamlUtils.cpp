/*
 * yamlUtils: convenience functions for use with yaml-cpp
 *
 * Evan Herbst
 * 2 / 24 / 11
 */

#include <vector>
#include <string>
#include <stdexcept>
#include "rgbd_util/yamlUtils.h"
using std::vector;
using std::string;
namespace fs = boost::filesystem;

/*
 * throw if not found
 */
string readYAMLString(YAML::Node& doc, const string& name)
{
	string val;
	if(const YAML::Node *pName = doc.FindValue(name))
	{
		*pName >> val;
		return val;
	}
	else throw std::invalid_argument("can't find key '" + name + "' in yaml file");
}
/*
 * return empty if not found
 */
string readYAMLStringOrEmpty(YAML::Node& doc, const string& name)
{
	string val;
	if(const YAML::Node *pName = doc.FindValue(name)) *pName >> val;
	return val;
}

/*
 * return empty if not found
 */
vector<string> readYAMLListOrEmpty(YAML::Node& doc, const string& name)
{
	vector<string> vals;
	if(const YAML::Node *pName = doc.FindValue(name))
	{
		vals.resize(pName->size());
		for(unsigned int i = 0; i < pName->size(); i++) (*pName)[i] >> vals[i];
	}
	return vals;
}

/*
 * return empty if not found
 */
void getOptionalRelativePath(YAML::Node& doc, const string& key, fs::path& var, const fs::path& rootDir)
{
	string path = readYAMLStringOrEmpty(doc, key);
	var = path.empty() ? fs::path() : rootDir / path;
}
void getOptionalRelativePathList(YAML::Node& doc, const string& key, std::vector<fs::path>& var, const fs::path& rootDir)
{
	const vector<string> paths = readYAMLListOrEmpty(doc, key);
	var.resize(paths.size());
	for(unsigned int i = 0; i < paths.size(); i++) var[i] = rootDir / paths[i];
}
