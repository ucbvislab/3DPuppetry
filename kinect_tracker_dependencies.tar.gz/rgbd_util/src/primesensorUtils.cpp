/*
 * primesensorUtils: for working with the primesensor specifically
 *
 * Evan Herbst
 * 9 / 22 / 10
 */

#include <cmath> //M_PI, sin(), fabs()
#include <stdexcept>
#include "rgbd_util/mathUtils.h" //sqr()
#include "rgbd_util/eigen/Core"
#include "rgbd_util/primesensorUtils.h"
using rgbd::eigen::Vector3f;

namespace rgbd
{

cameraID getCameraIDFromString(std::string camera_id_string)
{
	if (camera_id_string == "PRIMESENSOR_DEFAULT") return PRIMESENSOR_DEFAULT;
	else if (camera_id_string == "PRIMESENSOR_320_DEFAULT") return PRIMESENSOR_320_DEFAULT;
	else if (camera_id_string == "PRIMESENSOR_0332100155") return PRIMESENSOR_0332100155;
	else if (camera_id_string == "POINT_GREY_GRASSHOPPER_7430345") return POINT_GREY_GRASSHOPPER_7430345;
	else if (camera_id_string == "METALSTRIP_AND_TAPE_20101013") return METALSTRIP_AND_TAPE_20101013;
	else if (camera_id_string == "FABRICATED_HOLSTER_20101119") return FABRICATED_HOLSTER_20101119;
	else if (camera_id_string == "KINECT_640_DEFAULT") return KINECT_640_DEFAULT;
	else if (camera_id_string == "KINECT_320_DEFAULT") return KINECT_320_DEFAULT;
	else if (camera_id_string == "KINECT_MIT_QUADCOPTER") return KINECT_MIT_QUADCOPTER;
	else throw std::runtime_error("Unknown camera id string " + camera_id_string);
}

boost::shared_ptr<rgbd::CameraParams> getCameraParamsPtrFromString(std::string camera_id_string)
{
	if (!camera_id_string.empty()) {
		rgbd::cameraID camera_id = rgbd::getCameraIDFromString(camera_id_string);
		boost::shared_ptr<rgbd::CameraParams> result = boost::shared_ptr<rgbd::CameraParams>(new rgbd::CameraParams());
		*result = primesensor::getColorCamParams(camera_id);
		ROS_INFO_STREAM("RGBD camera params loaded: " << camera_id_string);
		return result;
	}
	ROS_WARN_STREAM("No RGBD camera params loaded");
	return boost::shared_ptr<rgbd::CameraParams>(); // return NULL ptr if empty string
}

boost::shared_ptr<rgbd::CameraParams> getCameraParamsPtrFromROSParamSearch(ros::NodeHandle & nh, std::string param_name)
{
	std::string key;
	if (nh.searchParam(param_name, key))
	{
		std::string camera_id_string;
		nh.getParam(key, camera_id_string);
		return rgbd::getCameraParamsPtrFromString(camera_id_string);
	}
	else {
		ROS_WARN_STREAM("No parameter found: " << param_name);
		return boost::shared_ptr<rgbd::CameraParams> ();
	}
}



} // ns rgbd

namespace primesensor
{

/*
 * be sure the camera you ask about is actually a depth camera
 */
rgbd::CameraParams getDepthCamParams(const rgbd::cameraID cam)
{
	rgbd::CameraParams camParams;
	switch(cam)
	{
		case rgbd::PRIMESENSOR_DEFAULT:
			camParams.xRes = 640;
			camParams.yRes = 480;
			camParams.centerX = 320;
			camParams.centerY = 240;
			camParams.focalLength = 570.34; //pixels, from primesense's code
			camParams.fovX = camParams.fovY = 60 * M_PI / 180; //approximate; see Louis
			camParams.stereoBaseline = .072;
			break;
		case rgbd::PRIMESENSOR_320_DEFAULT:
			camParams.xRes = 320;
			camParams.yRes = 240;
			camParams.centerX = 160;
			camParams.centerY = 120;
			camParams.focalLength = (570.34 / 2.0f); //pixels, from primesense's code
			camParams.fovX = camParams.fovY = 60 * M_PI / 180; //approximate; see Louis
			camParams.stereoBaseline = .072;
			break;
		case rgbd::PRIMESENSOR_0332100155: //calibrated by Hao 20101029
			camParams.xRes = 640;
			camParams.xRes = 480;
			camParams.centerX = 342;
			camParams.centerY = 249;
			camParams.focalLength = 588;
			camParams.fovX = camParams.fovY = 60 * M_PI / 180; //approximate; see Louis
			camParams.stereoBaseline = .072;
			break;
		default: throw std::invalid_argument("unsupported cam ID");
	}
	return camParams;
}

/*
 * be sure the camera you ask about is actually an rgb camera
 */
rgbd::CameraParams getColorCamParams(const rgbd::cameraID cam)
{
	rgbd::CameraParams camParams;
	switch(cam)
	{
		case rgbd::POINT_GREY_GRASSHOPPER_7430345: //calibrated by Louis 20101119
			camParams.xRes = 1600;
			camParams.yRes = 1200;
			camParams.centerX = 823.00;
			camParams.centerY = 559.04;
			camParams.focalLength = 1300; //pixels -- Louis had 1335.8; EVH edited 20101205 to fit one of my datasets better
			camParams.fovX = camParams.fovY = 60 * M_PI / 180; //uneducated guess; TODO fix?
			//not a stereo camera, so no stereo baseline
			break;
		case rgbd::KINECT_640_DEFAULT:
			camParams.xRes = 640;
			camParams.yRes = 480;
			camParams.centerX = camParams.xRes / 2;
			camParams.centerY = camParams.yRes / 2;
			camParams.focalLength = 525.0f;
			camParams.fovX = camParams.fovY = 60 * M_PI / 180;
			camParams.stereoBaseline = .072;
			break;
		case rgbd::KINECT_320_DEFAULT:
			camParams.xRes = 320;
			camParams.yRes = 240;
			camParams.centerX = camParams.xRes / 2;
			camParams.centerY = camParams.yRes / 2;
			camParams.focalLength = 525.0f / (float) 2;
			camParams.fovX = camParams.fovY = 60 * M_PI / 180;
			camParams.stereoBaseline = .072;
			break;
		case rgbd::KINECT_MIT_QUADCOPTER:
			camParams.xRes = 640;
			camParams.yRes = 480;
			camParams.centerX = camParams.xRes / 2;
			camParams.centerY = camParams.yRes / 2;
			camParams.focalLength = 528.49404721;
			camParams.fovX = camParams.fovY = 60 * M_PI / 180;
			camParams.stereoBaseline = .072;
			break;

		default: throw std::invalid_argument("unsupported cam ID");
	}
	return camParams;
}

/*
 * return the 3-d transform to take points from the frame of a primesensor to the frame of a high-res cam attached to it
 */
rgbd::eigen::Affine3f getLores2hiresXform(const rgbd::cameraID cam)
{
	rgbd::eigen::Affine3f xform;
	switch(cam)
	{
		case rgbd::METALSTRIP_AND_TAPE_20101013:
		{
			const float roll = 0.007094, pitch = -0.000577, yaw = -0.061851;
			const float tx = -0.000354, ty = 0.041268, tz = 0.016080;
			const float cr = cos(roll), sr = sin(roll), cp = cos(pitch), sp = sin(pitch), cy = cos(yaw), sy = sin(yaw);
			xform.matrix() << cr*cp, -sr*cy + cr*sp*sy,  sr*sy + cr*sp*cy,  tx,
			         sr*cp,  cr*cy + sr*sp*sy, -cr*sy + sr*sp*cy,  ty,
			        -sp   ,  cp*sy           ,  cp*cy           ,  tz,
			         0    ,  0               ,  0               ,  1;
			break;
		}
		case rgbd::FABRICATED_HOLSTER_20101119:
		{
			const float roll = -0.006188, pitch = -0.017221, yaw = -0.033031;
			const float tx = 0.005218, ty = 0.036832, tz = -0.014811;
			const float cr = cos(roll), sr = sin(roll), cp = cos(pitch), sp = sin(pitch), cy = cos(yaw), sy = sin(yaw);
			xform.matrix() << cr*cp, -sr*cy + cr*sp*sy,  sr*sy + cr*sp*cy,  tx,
						sr*cp,  cr*cy + sr*sp*sy, -cr*sy + sr*sp*cy,  ty,
					  -sp   ,  cp*sy           ,  cp*cy           ,  tz,
						0    ,  0               ,  0               ,  1;
			break;
		}
		default: throw std::invalid_argument("unsupported cam ID");
	}
	return xform;
}

/*
 * return the stereo depth error (difference in depth for a 1-pixel disparity difference) at depth z meters
 */
double stereoError(const double z)
{
	return sqr(z) / (1 / .00285/* from some modeling by Hao, Oct '10 */ + z);
}
/*
 * return the ratio of the stereo depth error at depth z meters to the error at depth 1 meter
 */
double stereoErrorRatio(const double z)
{
	static const double err1 = stereoError(1);
	return stereoError(z) / err1;
}
/*
 * return: 1-meter equivalent depth difference
 */
double normalizedDepthDistance(const double z1, const double z2)
{
	return fabs(z1 - z2) / stereoErrorRatio((z1 + z2) / 2);
}

} //namespace
