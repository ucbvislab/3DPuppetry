/*
 * kdtree2utils
 *
 * Evan Herbst
 * 1 / 21 / 11
 */

#include <climits> //UINT_MAX
#include "rgbd_util/kdtree2utils.h"

kdtree2_result_vector searchKDTree(const kdtree2& tree, const kdtreeNbrhoodSpec& nspec, const std::vector<float>& query)
{
	kdtree2_result_vector result;
	if(nspec.radiusSearchFirst)
	{
		tree.r_nearest(query, nspec.sqrNbrhoodRadius, result);
		if(nspec.numNbrs < UINT_MAX && result.size() > nspec.numNbrs) result.resize(nspec.numNbrs);
	}
	else
	{
		tree.n_nearest(query, nspec.numNbrs, result);
		if(nspec.sqrNbrhoodRadius >= 0)
			for(unsigned int i = 0; i < result.size(); i++)
				if(result[i].dis > nspec.sqrNbrhoodRadius)
				{
					result.resize(i);
					break;
				}
	}
	return result;
}
