/*
 * ioUtils: low-level I/O
 *
 * Evan Herbst
 * 11 / 11 / 10
 */

#include <cstdio> //getchar()
#include <iostream>
#include "rgbd_util/ioUtils.h"
using std::cout;
using std::endl;

/*
 * wait for a keypress
 */
void waitKey()
{
	cout << "(paused)" << endl;
	getchar();
}
