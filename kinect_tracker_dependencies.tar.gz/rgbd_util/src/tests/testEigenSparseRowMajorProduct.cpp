#include <iostream>
#include <boost/lexical_cast.hpp>
#include "rgbd_util/eigen/Sparse"
using namespace std;
using boost::lexical_cast;
using namespace rgbd::eigen;

/*
 * a,b,c combos for matrix sizes mxn, nxp:
 * Row/Row/Row: crashes if m > p
 * Row/Col/Row: ok
 * Col/Col/Col: ok
 */
int main(int argc, char* argv[])
{
	unsigned int _ = 1;
	const unsigned int s1 = lexical_cast<unsigned int>(argv[_++]),
		s2 = lexical_cast<unsigned int>(argv[_++]),
		s3 = lexical_cast<unsigned int>(argv[_++]),
		s4 = lexical_cast<unsigned int>(argv[_++]);
	SparseMatrix<double, RowMajor> a(s1, s2);
	SparseMatrix<double, RowMajor> b(s3, s4);
	for(unsigned int i = 0; i < a.rows(); i++)
	{
		a.startVec(i);
	}
	a.finalize();
	for(unsigned int i = 0; i < b.cols(); i++)
	{
		b.startVec(i);
	}
	b.finalize();
	SparseMatrix<double, RowMajor> c = a * b;
	cout << c << endl;

	return 0;
}
