/*
 * mathUtils
 *
 * Evan Herbst
 * 3 / 3 / 10
 */

#include <ctime>
#include <stdexcept>
#include <boost/random.hpp>
#include "rgbd_util/mathUtils.h"

/*
 * absolute value
 */
double dabs(double d)
{
	return (d < 0) ? -d : d;
}

/*
 * pre: d >= 0
 */
unsigned long round2uint(double d)
{
	return (unsigned long)(d + .5);
}

long round2int(double d)
{
	return (d < 0) ? (long)(d - .5) : (long)(d + .5);
}

/*
 * 2-d Euclidean distance squared
 */
double sqrDist2d(const double x1, const double y1, const double x2, const double y2)
{
	return sqr(x2 - x1) + sqr(y2 - y1);
}

/*
 * log(sinh(x))
 *
 * for large x, sinh(x) \approx e^x, so return x (else we'll hit infinity: e^700 is almost DBL_MAX)
 */
double logSinh(const double x)
{
	static const double logP5 = log(.5);
	return (x > 700) ? (x + logP5) : log(sinh(x));
}

/*
 * return an index into probs
 */
unsigned int sampleDiscreteDistribution(const std::vector<double>& probs)
{
	static boost::mt19937 rng((unsigned int)time(NULL));
	static boost::uniform_real<> dist(0, 1);
	static boost::variate_generator<boost::mt19937&, boost::uniform_real<> > gen(rng, dist);

	// determine the index of the action
	const double r = gen();
	double sum = 0;
	for(unsigned int i = 0; i < probs.size(); i++)
	{
		sum += probs[i];
		if(sum >= r) return i;
	}
	throw std::runtime_error("control reached end of sampleDiscreteDistribution() (shouldn't happen)!");
}

/*
 * linear interpolation
 *
 * alpha: in [0, 1]
 */
double linterp(const double v0, const double v1, const double alpha)
{
	return (1 - alpha) * v0 + alpha * v1;
}

void boolVectorToIndices(const std::vector<bool> & flags, std::vector<unsigned int> & indices)
{
	indices.clear();
	for (unsigned int i = 0; i < flags.size(); i++)
		if (flags[i])
			indices.push_back(i);
}
