/*
 * depthMapCleanupNode: throw away some points near depth boundaries, since they tend to associate with the wrong depths
 *
 * Evan Herbst
 * 8 / 20 / 10
 */

#ifndef EX_DEPTH_MAP_CLEANUP_NODE_H
#define EX_DEPTH_MAP_CLEANUP_NODE_H

#include <ros/node_handle.h>
#include <ros/publisher.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include <sensor_msgs/Image.h>
#include "rgbd_msgs/DepthMap.h"

class depthMapCleanupNode
{
	public:

		depthMapCleanupNode();

		void start();
		void sync_callback(sensor_msgs::ImageConstPtr imgPtr, rgbd_msgs::DepthMapConstPtr inDepthPtr);

	protected:

		void load_ros_params();

		// subscription parameters
		int subscription_buffer_size;

		ros::NodeHandle nh_global;
		ros::NodeHandle nh_local;

		ros::Publisher publisher;

		// Queue size controlled in constructor
		static const int max_out_of_order = 50;
		message_filters::TimeSynchronizer<sensor_msgs::Image, rgbd_msgs::DepthMap> sync;
		message_filters::Subscriber<rgbd_msgs::DepthMap> depth_subscription_filtered;
		message_filters::Subscriber<sensor_msgs::Image> image_subscription_filtered;

		// is -1 before any callbacks...first callback is frame_index 0
		// we now avoid "skipping" frames in the callback, so we process every frame, making frames_processed redundant
		// also used to know when we can stop spamming ready messages to the rgbd_player
		int frame_index;
};

#endif //header
