/*
 * depthCodecQuickLZ: (de)compress depth maps using the QuickLZ library, "the world's fastest compression library" (quicklz.com/)
 *
 * Evan Herbst
 * 3 / 18 / 10
 */

#ifndef EX_DEPTH_CODEC_QUICKLZ_H
#define EX_DEPTH_CODEC_QUICKLZ_H

#include <rgbd_msgs/DepthMap.h>

namespace quicklz
{

/*
 * also copy header info
 *
 * pre: in is format_raw
 * post: return value is format_quicklz
 */
rgbd_msgs::DepthMapPtr compress(const rgbd_msgs::DepthMap& in);
void compress(const rgbd_msgs::DepthMap& in, rgbd_msgs::DepthMap& out);

/*
 * also copy header info
 *
 * pre: in is format_quicklz
 * post: return value is format_raw
 */
rgbd_msgs::DepthMapPtr decompress(const rgbd_msgs::DepthMap& in);
void decompress(const rgbd_msgs::DepthMap& in, rgbd_msgs::DepthMap& out);

} //namespace

#endif //header
