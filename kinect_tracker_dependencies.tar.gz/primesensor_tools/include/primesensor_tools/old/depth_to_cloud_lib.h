/*
 * depth_to_cloud_lib.h
 *
 *  Created on: Jan 15, 2010
 *      Author: peter
 */

#ifndef DEPTH_TO_CLOUD_LIB_H_
#define DEPTH_TO_CLOUD_LIB_H_

#include <ros/ros.h>
#include <rgbd_msgs/DepthMap.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/PointCloud.h>
#include <geometry_msgs/Point32.h>

/**
 * I copied this out of depth_to_cloud.cpp so it can be called by other classes.
 * cloud_msg holds the result
 *
 * When matching depth maps and images are received, the conversion from projective
 * coordinates to real-world coordinates is performed, RGB information
 * is looked up in the image map and associated with the points, and the
 * resulting PointCloud is returned.
 *
 * depth_msg can be compressed or not.
 *
 * @param include_xy_channels whether to include image_{x,y} channels in the cloud
 * @param publish_all_points whether to include in the cloud points with negative depth
 *
 * @return false on any error
 */
bool image_and_depth_to_cloud(
		const sensor_msgs::ImageConstPtr& image_msg,
		const rgbd_msgs::DepthMapConstPtr& depth_msg,
		bool include_xy_channels,
		bool publish_all_points,
		sensor_msgs::PointCloud& cloud_msg);
bool image_and_depth_to_cloud(
		const sensor_msgs::Image* const image_msg,
		const rgbd_msgs::DepthMap* const depth_msg,
		bool include_xy_channels,
		bool publish_all_points,
		sensor_msgs::PointCloud& cloud_msg);


#endif /* DEPTH_TO_CLOUD_LIB_H_ */
