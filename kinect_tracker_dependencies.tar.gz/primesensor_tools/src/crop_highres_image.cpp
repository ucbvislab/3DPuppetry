#include <ros/ros.h>
#include <sensor_msgs/Image.h>

/**
 * Subscribe to a high resolution (1600x1200) image topic and republishes cropped images 
 * so that they can be correctly registered with depth images.
 */
class CropHighResImage {

    public:

    sensor_msgs::Image out_msg;
    ros::Subscriber in_sub;
    ros::Publisher out_pub;

    /**
     * Constructor does the setup: subscribes to the image topic, 
     * and advertises the output image topic
     */
    CropHighResImage() {
        ros::NodeHandle nh;
        ros::NodeHandle local_nh("~");

        std::string in;
        std::string out;
        local_nh.param("in", in, std::string("image"));
        local_nh.param("out", out, std::string("image_crop"));        
        std::string in_topic = nh.resolveName(in);
        std::string out_topic = nh.resolveName(out);

        in_sub = nh.subscribe(in_topic, 1, &CropHighResImage::callback, this);
        out_pub = nh.advertise<sensor_msgs::Image>(out_topic, 1);
    }

    /**
     * Callback for incoming image messages.
     */
    void callback(const sensor_msgs::Image::ConstPtr& in_msg) {
        if(in_msg->width != 1600 || in_msg->height != 1200) {
                ROS_WARN("crop_highres_image: Received image is not of expected size (1600x1200). "
                "Republishing it unmodified.");
            out_pub.publish(in_msg);
            return;
        }
        
        out_msg.width = X_RIGHT-X_LEFT;
        out_msg.height = Y_BOTTOM-Y_TOP;
        out_msg.header = in_msg->header;
        out_msg.encoding = in_msg->encoding;
        out_msg.is_bigendian = in_msg->is_bigendian;
        out_msg.step = in_msg->step/in_msg->width*out_msg.width;
        int nChannels = in_msg->data.size()/(in_msg->width*in_msg->height);
        
        out_msg.data.clear();
        for(int j=Y_TOP; j < Y_BOTTOM; j++) {
            for(int i=X_LEFT; i < X_RIGHT; i++) {
                for(int k=0; k < nChannels; k++) {
                    out_msg.data.push_back(in_msg->data[j*in_msg->width*nChannels + i*nChannels + k]);
                }
            }
        }
        
        out_pub.publish(out_msg);
    }
    
    private:
    // Corners of cropped image.
    static const int X_LEFT = 71;
    static const int X_RIGHT = 1544;
    static const int Y_TOP = 58;
    static const int Y_BOTTOM = 1163; 

};

int main(int argc, char **argv) {
    ros::init(argc, argv, "crop_highres_image");
    CropHighResImage node;

    ros::spin();

    return 0;
}

