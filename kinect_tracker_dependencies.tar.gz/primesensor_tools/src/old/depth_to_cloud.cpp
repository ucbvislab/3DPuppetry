/*
 * depth_to_cloud: subscribe to Image and DepthMap channels and publish PointClouds created from them
 */

#include <ros/ros.h>
#include <rgbd_msgs/DepthMap.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/PointCloud.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include "primesensor_tools/depth_to_cloud_lib.h"

ros::Publisher cloud_pub;
bool include_xy_channels;
bool publish_all_points;
int subscription_buffer_size;

void callback(const sensor_msgs::ImageConstPtr& image_msg, const rgbd_msgs::DepthMapConstPtr& depth_msg) {
	sensor_msgs::PointCloud result;
	const bool ok = image_and_depth_to_cloud(image_msg, depth_msg, include_xy_channels, publish_all_points, result);
	if(!ok) ROS_WARN_STREAM("depth_to_cloud failed");
	else cloud_pub.publish(result);
}

/**
 * Main function sets up the subscriptions to depth and image topics
 * with a time synchronizer, and registers the callback function.
 *
 * Input depth maps can be compressed or not.
 *
 * input channels: image, depth
 * output channels: cloud
 */
int main(int argc, char **argv) {
    ros::init(argc, argv, "depth_to_cloud");

    ros::NodeHandle nh;
    ros::NodeHandle nh_local("~");

    nh_local.param("publish_all_points", publish_all_points, false);
    nh_local.param("include_xy_channels", include_xy_channels, false);
    nh_local.param("subscription_buffer_size", subscription_buffer_size, 1);

    message_filters::Subscriber<sensor_msgs::Image> image_sub(nh, "image", subscription_buffer_size);
    message_filters::Subscriber<rgbd_msgs::DepthMap> depth_sub(nh, "depth", subscription_buffer_size);
    cloud_pub = nh.advertise<sensor_msgs::PointCloud>("cloud", 1);

    message_filters::TimeSynchronizer<sensor_msgs::Image, rgbd_msgs::DepthMap> sync(image_sub, depth_sub, 100);

    sync.registerCallback(boost::bind(&callback, _1, _2));

    ros::spin();
    return 0;
}

