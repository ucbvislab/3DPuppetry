/*
 * testQuickLZDepthCodec: test performance and correctness of QuickLZ-based depth-map codec
 *
 * Evan Herbst
 * 3 / 18 / 10
 */

#include <cassert>
#include <iostream>
#include <ros/node_handle.h>
#include <ros/subscriber.h>
#include "rgbd_util/timer.h"
#ifdef USE_QLZ
#include "primesensor_tools/depthCodecQuickLZ.h"
#else
#include "primesensor_tools/depthCodecZlib.h"
#endif
using std::cout;
using std::endl;

void receiveDepthMap(rgbd_msgs::DepthMapConstPtr d)
{
	rgbd::timer t;
#ifdef USE_QLZ
	rgbd_msgs::DepthMapPtr compressed = quicklz::compress(*d);
#else
	rgbd_msgs::DepthMapPtr compressed = zlib::compress(*d);
#endif
	t.stop("compress");
	t.restart();
#ifdef USE_QLZ
	rgbd_msgs::DepthMapPtr decompressed = quicklz::decompress(*compressed);
#else
	rgbd_msgs::DepthMapPtr decompressed = zlib::decompress(*compressed);
#endif
	t.stop("decompress");
	cout << "msg: " << d->float_data.size() << " floats" << endl;
	cout << "compression ratio: " << ((double)(d->float_data.size() * sizeof(float)) / compressed->binary_data.size()) << endl;
	assert(d->float_data.size() == decompressed->float_data.size());
	assert(d->float_data == decompressed->float_data);
}

/*
 * input topics: depth
 */
int main(int argc, char* argv[])
{
	ros::init(argc, argv, "testQuickLZDepthCodec");
	ros::NodeHandle nh;
	ros::Subscriber depthSubscriber = nh.subscribe<rgbd_msgs::DepthMap>("depth", 0/* queue size */, receiveDepthMap);
	ros::spin();
	return 0;
}
