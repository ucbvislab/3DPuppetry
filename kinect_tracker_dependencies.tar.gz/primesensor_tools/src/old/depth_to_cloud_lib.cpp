#include <iostream>
#include <ros/ros.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/PointCloud.h>
#include <geometry_msgs/Point32.h>
#include "rgbd_msgs/DepthMap.h"
#include "primesensor_tools/decompressDepth.h"
#include "primesensor_tools/depth_to_cloud_lib.h"
using std::cout;
using std::endl;

bool image_and_depth_to_cloud(
		const sensor_msgs::ImageConstPtr& image_msg,
		const rgbd_msgs::DepthMapConstPtr& depth_msg,
		bool include_xy_channels,
		bool publish_all_points,
		sensor_msgs::PointCloud& cloud_msg)
{
	return image_and_depth_to_cloud(image_msg.get(), depth_msg.get(), include_xy_channels, publish_all_points, cloud_msg);
}
bool image_and_depth_to_cloud(
		const sensor_msgs::Image* const image_msg,
		const rgbd_msgs::DepthMap* const depth_msg,
		bool include_xy_channels,
		bool publish_all_points,
		sensor_msgs::PointCloud& cloud_msg)
{
	rgbd_msgs::DepthMap uncompressedDepth;
    const float *dm;
    if(depth_msg->format == rgbd_msgs::DepthMap::format_raw) {
        dm = &depth_msg->float_data[0];
    } else if(depth_msg->format == rgbd_msgs::DepthMap::format_zlib) {
   	 rgbd::decompressDepthMap(*depth_msg, uncompressedDepth);
   	 dm = &uncompressedDepth.float_data[0];
    } else
   {
   	 cout << "Unsupported format for depth map" << endl;
   	 return false;
   }

    /*
    if(depth_msg->height != image_msg->height || depth_msg->width != image_msg->width) {
        ROS_WARN("Depth map and image map size must match; different sizes not yet supported");
        return;
    }
    */

    cloud_msg.header = depth_msg->header;
    // need to clear it out
    cloud_msg.set_channels_size(0);
    cloud_msg.set_points_size(0);


    // TODO: This should be more flexible to enable different combinations of channels,
    // rather than depending on fixed indices
    cloud_msg.channels.resize(1);
    cloud_msg.channels[0].name = "rgb";

    if(include_xy_channels) {
        cloud_msg.channels.resize(3);
        cloud_msg.channels[1].name = "image_x";
        cloud_msg.channels[2].name = "image_y";
    }

    for(int row=0; row < depth_msg->height; row++) {
        for(int col=0; col < depth_msg->width; col++) {
            const float depth = dm[row * depth_msg->width + col];

            if((depth <= 0) && !publish_all_points) {
                continue;
            }
            const uint8_t *image_p = &image_msg->data[0];

            unsigned int image_x, image_y;
            if(depth_msg->width == image_msg->width && depth_msg->height == image_msg->height) {
                image_x = col;
                image_y = row;
            } else {
                image_x = col * image_msg->width / depth_msg->width;
                image_y = row * image_msg->height / depth_msg->height;
            }

            geometry_msgs::Point32 p;
            p.x = (((float)col - (depth_msg->width / 2)) * depth / depth_msg->focal_distance);
            p.y = (((float)row - (depth_msg->height / 2)) * depth / depth_msg->focal_distance);
            p.z = depth;

            float rgb_float;
            if(image_msg->encoding == "rgb8")
            {
            	const uint8_t *color = image_p + (image_y * image_msg->step + image_x  * 3);
            	unsigned int rgb = (color[0] << 16) | (color[1] << 8) | (color[2]);
            	rgb_float = *reinterpret_cast<float*>(&rgb);
            }
            else if(image_msg->encoding == "bgr8")
            {
            	const uint8_t *color = image_p + (image_y * image_msg->step + image_x  * 3);
					unsigned int rgb = (color[2] << 16) | (color[1] << 8) | (color[0]);
					rgb_float = *reinterpret_cast<float*>(&rgb);
            }
            else
            {
            	cout << "Unsupported image type " << image_msg->encoding << endl;
            	return false;
            }

            cloud_msg.points.push_back(p);
            cloud_msg.channels[0].values.push_back(rgb_float);

            if(include_xy_channels) {
                cloud_msg.channels[1].values.push_back(col);
                cloud_msg.channels[2].values.push_back(row);
            }
        }
    }

    return true;
}
