/*
 * depthCodecQuickLZ: (de)compress depth maps using the QuickLZ library, "the world's fastest compression library" (quicklz.com/)
 *
 * Evan Herbst
 * 3 / 18 / 10
 */

#include <cassert>
extern "C"
{
#define QLZ_COMPRESSION_LEVEL 1 //fastest
#define QLZ_STREAMING_BUFFER 0 //0 = batch mode
#include "quicklz/quicklz.h"
}
#include "primesensor_tools/depthCodecQuickLZ.h"

namespace quicklz
{

/*
 * copy all but the main data buffer and the format flag
 */
void copyHeader(const rgbd_msgs::DepthMap& src, rgbd_msgs::DepthMap& dest)
{
	dest.header = src.header;
	dest.width = src.width;
	dest.height = src.height;
	dest.focal_distance = src.focal_distance;
	dest.no_sample_value = src.no_sample_value;
	dest.shadow_value = src.shadow_value;
}

/*
 * also copy header info
 *
 * pre: in is format_raw
 * post: return value is format_quicklz
 */
rgbd_msgs::DepthMapPtr compress(const rgbd_msgs::DepthMap& in)
{
	rgbd_msgs::DepthMapPtr out(new rgbd_msgs::DepthMap);
	compress(in, *out);
	return out;
}
void compress(const rgbd_msgs::DepthMap& in, rgbd_msgs::DepthMap& out)
{
	assert(in.format == rgbd_msgs::DepthMap::format_raw);
	out.format = rgbd_msgs::DepthMap::format_quicklz;
	copyHeader(in, out);

	const size_t insize = in.float_data.size() * sizeof(float);
	char qlzScratchBuf[QLZ_SCRATCH_COMPRESS];
	out.binary_data.resize(insize + 400); //always allocate source_size + 400 bytes for compression
	const size_t outsize = qlz_compress(in.float_data.data(), reinterpret_cast<char*>(out.binary_data.data()), insize, qlzScratchBuf);
	out.binary_data.resize(outsize);
}

/*
 * also copy header info
 *
 * pre: in is format_quicklz
 * post: return value is format_raw
 */
rgbd_msgs::DepthMapPtr decompress(const rgbd_msgs::DepthMap& in)
{
	rgbd_msgs::DepthMapPtr out(new rgbd_msgs::DepthMap);
	decompress(in, *out);
	return out;
}
void decompress(const rgbd_msgs::DepthMap& in, rgbd_msgs::DepthMap& out)
{
	assert(in.format == rgbd_msgs::DepthMap::format_quicklz);
	out.format = rgbd_msgs::DepthMap::format_raw;
	copyHeader(in, out);

	char qlzScratchBuf[QLZ_SCRATCH_DECOMPRESS];
	const size_t outsize = qlz_size_decompressed(reinterpret_cast<const char*>(in.binary_data.data()));
	assert(outsize == out.width * out.height * sizeof(float));
	out.float_data.resize(outsize / sizeof(float));
	const size_t outsize2 = qlz_decompress(reinterpret_cast<const char*>(in.binary_data.data()), out.float_data.data(), qlzScratchBuf);
	assert(outsize2 == outsize);
}

} //namespace
