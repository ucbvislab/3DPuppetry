/*
 * color_balance_node: use a moving average of r,g,b levels to rescale the channels of each new image
 *
 * Evan Herbst
 * 4 / 1 / 10
 */

#include <deque>
#include <iostream>
#include <algorithm> //min()
#include <boost/bind.hpp>
#include "rgbd_util/eigen/Core"
#include <ros/node_handle.h>
#include <ros/subscriber.h>
#include <cv_bridge/CvBridge.h>
#include "rgbd_util/ros_utility.h"
using std::deque;
using std::cout;
using std::endl;

class colorBalanceNode
{
	public:

		colorBalanceNode() : nh_local("~")
		{
			rgbd::ros_param_uint(nh_local, "numPrevFrames", maxPrevFrames, 10);

			imgSubscriber = nh.subscribe<sensor_msgs::Image>("in_img", 0, boost::bind(&colorBalanceNode::receiveImg, this, _1));

			imgPublisher = nh.advertise<sensor_msgs::Image>("out_img", 0);
		}

		void receiveImg(sensor_msgs::ImageConstPtr img);

	private:

		ros::NodeHandle nh, nh_local;
		ros::Subscriber imgSubscriber;
		ros::Publisher imgPublisher;

		typedef rgbd::eigen::Vector3d rgbAvg;

		/*
		 * average color in each prev frame
		 */
		deque<rgbAvg> prevFrameAvgs;
		unsigned int maxPrevFrames;
};

void colorBalanceNode::receiveImg(sensor_msgs::ImageConstPtr img)
{
	sensor_msgs::CvBridge bridge;

	/*
	 * get average color in this frame
	 */
	IplImage* cvImg = bridge.imgMsgToCv(img, "rgb8");
	rgbAvg avg(0, 0, 0);
	for(unsigned int i = 0; i < (unsigned)cvImg->height; i++)
		for(unsigned int j = 0; j < (unsigned)cvImg->width; j++)
		{
			const CvScalar c = cvGet2D(cvImg, i, j);
			for(unsigned int k = 0; k < 3; k++) avg[k] += c.val[k];
		}
	avg /= (img->width * img->height);

	if(!prevFrameAvgs.empty())
	{
		/*
		 * get moving-average color
		 */
		rgbAvg prevAvg(0, 0, 0);
		for(unsigned int i = 0; i < prevFrameAvgs.size(); i++) prevAvg += prevFrameAvgs[i];
		prevAvg /= prevFrameAvgs.size();

		/*
		 * fix color in this frame
		 */
		for(unsigned int i = 0; i < (unsigned)cvImg->height; i++)
			for(unsigned int j = 0; j < (unsigned)cvImg->width; j++)
			{
				CvScalar c = cvGet2D(cvImg, i, j);
				for(unsigned int k = 0; k < 3; k++) c.val[k] = (unsigned char)std::max(0., std::min(255., (prevAvg[k] / avg[k]) * c.val[k]));
				cvSet2D(cvImg, i, j, c);
			}
		sensor_msgs::ImagePtr balancedImg = bridge.cvToImgMsg(cvImg, "rgb8");
		balancedImg->header = img->header;
		imgPublisher.publish(balancedImg);
	}
	else imgPublisher.publish(img);

	/*
	 * update moving average
	 */
	if(prevFrameAvgs.size() == maxPrevFrames) prevFrameAvgs.pop_front();
	prevFrameAvgs.push_back(avg);
}

/*
 * input channels: in_img
 * output channels: out_img
 */
int main(int argc, char **argv)
{
	ros::init(argc, argv, "color_balance_node");
	colorBalanceNode node;
	ros::spin();
	return 0;
}
