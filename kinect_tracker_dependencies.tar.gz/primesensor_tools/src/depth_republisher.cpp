#include <ros/ros.h>
#include <rgbd_msgs/DepthMap.h>
#include <rgbd_msgs/GeneralKill.h>
#include <iostream>
#include "rgbd_depthmaps/decompressDepth.h"
using std::cout;
using std::endl;

/**
 * Subscribes to a depth topic and republishes it.  It can subscribe
 * to either raw or zlibbed depth topics, and can republish in
 * either depending on the settings on the ROS parameter server.
 * 
 * This node will terminate when receiving rgbd_msgs::GeneralKill that is sent to topic '/rgbd/general_kill'
 */
class DepthRepublisher {

    public:

    bool compress_depth;
    std::string compression_mode;
    int zlib_compr_mode;
    rgbd_msgs::DepthMap out_msg;
    ros::Subscriber in_sub, kill_sub;
    ros::Publisher out_pub;

    /**
     * Constructor does the setup: reads the parameters from the
     * parameter server, subscribes to the depth topic, and
     * advertises the output depth topic
     */
    DepthRepublisher() {
        ros::NodeHandle nh;
        ros::NodeHandle local_nh("~");

        std::string in_topic = nh.resolveName("in");
        std::string out_topic = nh.resolveName("out");

        if(in_topic == "/in" || out_topic == "/out") {
            ROS_WARN("depth_republisher: either the in or out topic (or both) has not been "
                "remapped.  Typical usage: ./depth_republisher in:=/primesensor/depth out:=/output/topic");
        }

        local_nh.param("compress_depth", compress_depth, false);
        local_nh.param("compression_mode", compression_mode, std::string("default"));
        
        if(compression_mode == "fastest") {
            zlib_compr_mode = Z_BEST_SPEED;
        } else if (compression_mode == "smallest") {
            zlib_compr_mode = Z_BEST_COMPRESSION;
        } else {
            zlib_compr_mode = Z_DEFAULT_COMPRESSION;
        }
//        cout << "cmp? " << compress_depth << "; mode " << compression_mode << endl;

        in_sub = nh.subscribe(in_topic, 1, &DepthRepublisher::callback, this);
        out_pub = nh.advertise<rgbd_msgs::DepthMap>(out_topic, 1);
	kill_sub = nh.subscribe("/rgbd/general_kill", 1, &DepthRepublisher::callback_GeneralKill, this);
    }

    /**
     * Callback for incoming depth messages.  If the input and
     * output formats match, the incoming message is simply
     * republished.  If the output format is different than the
     * input format, a new DepthMap is constructed and the data are
     * copied in the requested output format before it is published.
     */
    void callback(const rgbd_msgs::DepthMap::ConstPtr& in_msg) {
        if(compress_depth)
           out_msg.format = rgbd_msgs::DepthMap::format_zlib;
        else
            out_msg.format = rgbd_msgs::DepthMap::format_raw;

        if(out_msg.format == in_msg->format) {
            out_pub.publish(in_msg);
            return;
        }
        
        if(in_msg->format == rgbd_msgs::DepthMap::format_zlib && out_msg.format == rgbd_msgs::DepthMap::format_raw)
        {
      	  rgbd::decompressDepthMap(*in_msg, out_msg);
        }
        else if(in_msg->format == rgbd_msgs::DepthMap::format_raw && out_msg.format == rgbd_msgs::DepthMap::format_zlib)
        {
      	  rgbd::compressDepthMap(*in_msg, out_msg);
        }

        out_pub.publish(out_msg);
    }

    
    /** 
     * Callback for GeneralKill.  It terminates the node. 
     */
    void callback_GeneralKill(const rgbd_msgs::GeneralKill::ConstPtr& generalkill_msg) {
	ros::shutdown();
    }
	
};

int main(int argc, char **argv) {
    ros::init(argc, argv, "depth_republisher");
    DepthRepublisher republisher;

    ros::spin();

    return 0;
}

