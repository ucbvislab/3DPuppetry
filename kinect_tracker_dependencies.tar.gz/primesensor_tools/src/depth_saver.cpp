/*
 * depth_saver.cpp
 *
 *  Created on: 2010-12-14
 *      Author: mkrainin
 */

#include <ros/ros.h>
#include <ros/service.h>
#include <rgbd_msgs/DepthMap.h>
#include <sensor_msgs/Image.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include <primesensor_tools/SaveDepth.h>

#include <cv_bridge/CvBridge.h>
#include <opencv2/highgui/highgui.hpp>


class DepthSaver{

public:
	DepthSaver()
	:nh_local("~")
	{
	    //read in parameters
	    nh_local.param("image_channel", image_chan, (std::string)"image");
	    nh_local.param("depth_channel", depth_chan, (std::string)"depth");

	    nh_local.param("output_dir", m_output_dir, (std::string)"/");
	    m_current_num = 0;
	}

	~DepthSaver(){}

	void start()
	{
	    message_filters::Subscriber<sensor_msgs::Image> image_sub(nh, image_chan, 0);
	    message_filters::Subscriber<rgbd_msgs::DepthMap> depth_sub(nh, depth_chan, 0);

	    message_filters::TimeSynchronizer<sensor_msgs::Image, rgbd_msgs::DepthMap> sync(image_sub, depth_sub, 100);

	    sync.registerCallback(boost::bind(&DepthSaver::callback,this, _1, _2));

	    ros::ServiceServer service = nh_local.advertiseService(
	    		"save_depth",&DepthSaver::processRequest,this);

	    ROS_INFO("Listening to %s and %s. Writing to %s",image_chan.c_str(),depth_chan.c_str(),m_output_dir.c_str());
	    ROS_INFO("Ready to save. Call service programmatically or with rosservice call.");

	    ros::spin();
	}


private:

    ros::NodeHandle nh, nh_local;

	std::string image_chan, depth_chan;

	sensor_msgs::ImageConstPtr current_image_ptr;
	rgbd_msgs::DepthMapConstPtr current_depth_ptr;

	std::string m_output_dir;
	unsigned int m_current_num;

    boost::mutex mutex;

	void callback(const sensor_msgs::ImageConstPtr& image_msg,
			const rgbd_msgs::DepthMapConstPtr& depth_msg)
	{
		boost::unique_lock<boost::mutex> lock(mutex);
		current_image_ptr = image_msg;
		current_depth_ptr = depth_msg;
	}

	bool processRequest(
			primesensor_tools::SaveDepth::Request &request,
			primesensor_tools::SaveDepth::Response &response)
	{
		boost::unique_lock<boost::mutex> lock(mutex);

		if(!current_image_ptr || !current_depth_ptr){
			ROS_WARN("Haven't recieved image+depth yet");
			return false;
		}

		//come up with filenames
		char depthFilename[1000], imageFilename[1000];
		sprintf(depthFilename,"%s/depth%05i.png",m_output_dir.c_str(),m_current_num);
		sprintf(imageFilename,"%s/image%05i.png",m_output_dir.c_str(),m_current_num);

		//save the image
		sensor_msgs::CvBridge bridge;
		bridge.fromImage(*current_image_ptr,"bgr8");
		IplImage *img = bridge.toIpl();
		cvSaveImage(imageFilename,img);

        // convert the depth map to disparity
        cv::Mat depth_mat(current_depth_ptr->height, current_depth_ptr->width, CV_16UC1,cv::Scalar(0));
        for (unsigned int row = 0; row < current_depth_ptr->height; row++) {
           for (unsigned int col = 0; col < current_depth_ptr->width; col++) {
              const float depth = current_depth_ptr->float_data[row * current_depth_ptr->width + col];
                 if(depth > 0.0) {
                    depth_mat.at<uint16_t>(row, col) = round(1000*depth);
                 }
           }
        }

        //save the depth map
        std::vector<int> params(2);
        params[0] = CV_IMWRITE_PNG_COMPRESSION;
        params[1] = 0;
        cv::imwrite(depthFilename, depth_mat, params);

        m_current_num++;
        return true;
	}

};

int main(int argc, char **argv) {
    ros::init(argc, argv, "depth_saver");
    DepthSaver saver;
    saver.start();
    return 0;
}
