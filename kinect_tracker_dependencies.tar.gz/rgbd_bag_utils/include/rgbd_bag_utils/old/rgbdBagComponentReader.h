/*
 * rgbdBagComponentReader: provide a nicer interface than RGBDReader and allow getting the image, depth map and cloud individually
 *
 * Evan Herbst
 * 3 / 22 / 10
 */

#ifndef EX_RGBD_BAG_COMPONENT_READER_H
#define EX_RGBD_BAG_COMPONENT_READER_H

#include <string>
#include <boost/filesystem/path.hpp>
#include <boost/unordered_map.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/optional.hpp>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/PointCloud.h>
#include "rgbd_msgs/DepthMap.h"
#include "rgbd_bag_utils/RGBDReader.h"

namespace rgbd
{
namespace fs = boost::filesystem;

class rgbdBagComponentReader
{
	public:

		/*
		 * if maxFrameIndex is beyond the end of the bag, things will be ok as long as you use hasNext() to tell you how big the bag is
		 *
		 * frameSkip: # frames to actually skip (eg 4 to use every 5th)
		 *
		 * numKeptPrevFrames: conserve memory; if empty, no limit; 0 means delete frame i as soon as i + 1 is loaded
		 */
		rgbdBagComponentReader(const fs::path& bagFilepath, const std::string& depthTopic, const std::string& imgTopic, const unsigned int minFrame, const unsigned int maxFrame, const unsigned int frameSkip, const boost::optional<unsigned int> numKeptPrevFrames);

		unsigned int getMinFrameIndex() const {return minFrameIndex;}

		/*
		 * is the given frame currently loaded?
		 */
		bool hasFrame(const unsigned int frame) const {return imgs.find(frame) != imgs.end();}

		/*
		 * return false if we were already at the end of the bag or had reached the max requested index
		 */
		bool readOne();
		/*
		 * throw if the bag doesn't contain enough frames
		 */
		void readThrough(const unsigned int frameIndex);

		/*
		 * read frames as necessary
		 *
		 * throw if we don't have the desired frame stored
		 */
		const sensor_msgs::Image& getImg(long frameIndex);
		const rgbd_msgs::DepthMap& getDepthMap(long frameIndex);
		const sensor_msgs::PointCloud& getCloud(long frameIndex);

		/*
		 * return the last one read
		 *
		 * throw if we haven't read anything
		 */
		const sensor_msgs::Image& getLastImg();
		const rgbd_msgs::DepthMap& getLastDepthMap();
		const sensor_msgs::PointCloud& getLastCloud();

		const sensor_msgs::ImageConstPtr getLastImgPtr();
		const rgbd_msgs::DepthMapConstPtr getLastDepthMapPtr();

	private:

		void erase(const long frameIndex);

		rgbd_bag_utils::RGBDReader reader;
		const unsigned int minFrameIndex, maxFrameIndex, frameskip;

		boost::unordered_map<unsigned int, boost::shared_ptr<sensor_msgs::Image> > imgs;
		boost::unordered_map<unsigned int, boost::shared_ptr<rgbd_msgs::DepthMap> > depthMaps;
		boost::unordered_map<unsigned int, sensor_msgs::PointCloud> clouds;
		long lastFrameRead, lastVirtualFrameRead; //'virtual frame' index increments while lastFrameRead jumps by frameskip

		boost::optional<unsigned int> numPrevFramesToKeep; //conserve memory; empty = no limit
};

} //namespace

#endif //header
