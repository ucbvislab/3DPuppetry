#include <ros/ros.h>
#include <rosrecord/Recorder.h>

#include <rgbd_msgs/DepthMap.h>
#include <sensor_msgs/Image.h>

#include <string>

namespace rgbd_bag_utils {

    /**
     * \brief Class for writing RGBD frames to a ROS bag file.
     * 
     * Class for writing RGBD frames to a ROS bag file.  An RGBD frame consists of an
     * rgbd_msgs::DepthMap and a sensor_msgs::Image with identical timestamps.
     *
     * Bag files that are recorded with rosrecord try to replicate the exact conditions that
     * existed when the messages were recorded.  The messages in the bag are stamped with
     * the times that they were logged, which is independent of any timestamps in the 
     * messages themselves.  As such, it is possible for rosrecord to replicate a situation
     * where messages with stamps that differ from the time that they were actually
     * published.  RGBDWriter aims more for preservation of the integrity and ease-of-use
     * of the data in image/depth pairs.  Image/depth pairs will always be stored in the
     * bag file as if they were logged at exactly the time that appears in the stamps in
     * their headers.
     */
    class RGBDWriter {
        public:
        RGBDWriter(std::string filename, std::string depth_topic="/rgbd/depth",
                   std::string image_topic="/rgbd/image");
        ~RGBDWriter();

        void write_frame(rgbd_msgs::DepthMap &depth_map, sensor_msgs::Image &image);

        protected:
        ros::record::Recorder *_recorder;
        std::string _depth_topic;
        std::string _image_topic;
    };

}

