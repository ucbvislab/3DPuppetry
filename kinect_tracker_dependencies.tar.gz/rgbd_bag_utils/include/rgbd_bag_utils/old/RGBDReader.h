#include <ros/ros.h>
#include <rosrecord/Player.h>

#include <rgbd_msgs/DepthMap.h>
#include <sensor_msgs/Image.h>

#include <string>


namespace rgbd_bag_utils {

    /**
     * \brief Class for reading RGBD frames from a ROS bag file.
     *
     * Class for reading RGBD frames from a ROS bag file.  An RGBD frame consists of an
     * rgbd_msgs::DepthMap and a sensor_msgs::Image with identical timestamps.
     * 
     * A simple method is provided for querying the next frame.  With this class, it is
     * trivial to read RGBD frames from a bag file for offline processing.  Since your
     * application can request the next frame as it is ready for it, processing can happen
     * as fast as possible, without ever dropping any frames.
     *
     * This class could be subclassed and extended to include other messages (in addition
     * to depth maps and images) with each frame.
     */
    class RGBDReader {
        public:
        RGBDReader(std::string filename, std::string depth_topic="/rgbd/depth", 
                   std::string image_topic="/rgbd/image");
        ~RGBDReader();
        
        void set_verbose(bool verbose);
        bool read_frame(rgbd_msgs::DepthMap *&depth_map, sensor_msgs::Image *&image);

        protected:
        bool _verbose;
        ros::record::Player *_player;
        rgbd_msgs::DepthMap *_latest_depth;
        sensor_msgs::Image *_latest_image;

        ros::Time _prev_frame_time;

        void depth_handler(std::string name, rgbd_msgs::DepthMap *depth_map,
                           ros::Time t, ros::Time t_shift, void *n);
        void image_handler(std::string name, sensor_msgs::Image *image, ros::Time t,
                           ros::Time t_shift, void *n);
    };

}

