/*
 * rgbdBagReader: read rgbd frames from a bag using the ros::Bag interface
 *
 * Evan Herbst
 * 6 / 14 / 10
 */

#ifndef EX_RGBD_BAG_READER_H
#define EX_RGBD_BAG_READER_H

#include <map>
#include <string>
#include <utility>
#include <boost/filesystem/path.hpp>
#include <boost/unordered_map.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/scoped_ptr.hpp>
#include <boost/optional.hpp>
#include <boost/variant/variant.hpp>
#include <rosbag/bag.h>
#include <rosbag/view.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/CompressedImage.h>
#include <pcl/point_cloud.h>
#include "rgbd_util/CameraParams.h"
#include "rgbd_util/primesensorUtils.h"
#include "pcl_rgbd/pointTypes.h"
#include "rgbd_msgs/DepthMap.h"

namespace rgbd
{
namespace fs = boost::filesystem;

struct cmpRosTimes
{
	bool operator () (const ros::Time& t1, const ros::Time& t2) const {return t1.sec < t2.sec || (t1.sec == t2.sec && t1.nsec < t2.nsec);}
};

/*
 * enumerate the types of image we can handle
 */
typedef boost::variant<sensor_msgs::ImageConstPtr, sensor_msgs::CompressedImageConstPtr> someImageConstPtr;

template <typename PointT = rgbd::pt>
class rgbdBagReader
{
	public:

		typedef PointT pointT;

		/*
		 * if maxFrameIndex is beyond the end of the bag, things will be ok as long as you use readOne() to tell you how big the bag is
		 *
		 * frameSkip: # frames to actually skip (eg 4 to use every 5th)
		 *
		 * minFrame, maxFrame and frameSkip define a "virtual" frame index starting at zero and incrementing with each batch of raw-bag frames skipped
		 *
		 * numKeptPrevFrames: conserve memory; if empty, no limit; 0 means delete frame i as soon as i + 1 is loaded
		 *
		 * depth2imgXform, camParams: describe how to sample colors for depth pts
		 */
		rgbdBagReader(const fs::path& bagFilepath, const std::string& depthTopic, const std::string& imgTopic, const uint32_t minFrame, const uint32_t maxFrame, const uint32_t frameSkip,
				const boost::optional<unsigned int> numKeptPrevFrames,
				const rgbd::CameraParams& camparams, const rgbd::CameraParams& depthCamParams, const rgbd::eigen::Affine3f& depth2img = rgbd::eigen::Affine3f::Identity());

		/*
		 * is the given frame currently loaded?
		 */
		bool hasFrame(const uint32_t frame) const {return imgs.find(frame) != imgs.end();}

		/*
		 * read one frame, then frame-skip as appropriate
		 *
		 * return false if we were already at the end of the bag or had reached the max requested index
		 */
		bool readOne();
		/*
		 * this is the "virtual" frame index: start at zero and add one for each readOne()
		 *
		 * throw if the bag doesn't contain enough frames
		 *
		 * post: lastVirtualFrameRead == frameIndex
		 */
		void readThroughFrame(const uint32_t frameIndex);
		/*
		 * read frames until the last frame read is at or after t
		 *
		 * throw if the bag doesn't contain enough frames
		 */
		void readThroughTime(const ros::Time t);

		/*
		 * read frames as necessary
		 *
		 * this is the "virtual" frame index: start at zero and add one for each readOne()
		 *
		 * throw if we don't have the desired frame stored or you ask for the wrong img format
		 */
		const sensor_msgs::Image& getImg(const uint32_t frameIndex);
		const sensor_msgs::CompressedImage& getCompressedImg(const uint32_t frameIndex);
		/*
		 * return uncompressed regardless of whether the bag contains compressed
		 */
		const sensor_msgs::ImageConstPtr getUncompressedImgPtr(const uint32_t frameIndex);
		const rgbd_msgs::DepthMap& getDepthMap(const uint32_t frameIndex);
		//compute cloud from img & depth
		const pcl::PointCloud<PointT>& getCloud(const uint32_t frameIndex);

		/*
		 * return the last one read
		 *
		 * throw if we haven't read anything
		 */
		const ros::Time getLastFrameTime();
		const sensor_msgs::Image& getLastImg();
		const sensor_msgs::CompressedImage& getLastCompressedImg();
		const rgbd_msgs::DepthMap& getLastDepthMap();
		//compute cloud from img & depth
		const pcl::PointCloud<PointT>& getLastCloud();

		const sensor_msgs::ImageConstPtr getLastImgPtr();
		const sensor_msgs::CompressedImageConstPtr getLastCompressedImgPtr();
		/*
		 * return uncompressed regardless of whether the bag contains compressed
		 */
		const sensor_msgs::ImageConstPtr getLastUncompressedImgPtr();
		const rgbd_msgs::DepthMapConstPtr getLastDepthMapPtr();

	private:

		/*
		 * read until we hit end of bag or get a complete frame
		 *
		 * return <empty, empty> if hit end of bag
		 */
		std::pair<rgbd_msgs::DepthMapConstPtr, rgbd::someImageConstPtr> readOneFrame();

		void erase(const uint32_t frameIndex);

		/*
		 * depth cam-visual cam calibration
		 */
		rgbd::eigen::Affine3f depth2imgXform;
		rgbd::CameraParams camParams;
		boost::shared_ptr<rgbd::CameraParams> depthCamParamsPtr;

		rosbag::Bag bag;
		boost::scoped_ptr<rosbag::View> view;
		rosbag::View::iterator iter, endIter;
		const uint32_t minFrameIndex, maxFrameIndex, frameskip;
		/*
		 * buffers to account for msgs being out of order in bags (each channel's msgs are in order, but you might have img-img-img-img-depth, eg)
		 */
		std::map<ros::Time, rgbd::someImageConstPtr, cmpRosTimes> imgBuffer;
		std::map<ros::Time, rgbd_msgs::DepthMapConstPtr, cmpRosTimes> depthBuffer;

		/*
		 * buffers of past frames
		 *
		 * indexed by virtual frame index
		 */
		boost::unordered_map<uint32_t, rgbd::someImageConstPtr> imgs;
		boost::unordered_map<uint32_t, rgbd_msgs::DepthMapConstPtr> depthMaps;
		boost::unordered_map<uint32_t, pcl::PointCloud<PointT> > clouds; //computed, not read

		int32_t lastFrameRead, lastVirtualFrameRead; //'virtual frame' index increments while lastFrameRead jumps by frameskip
		ros::Time lastFrameTimeRead;

		boost::optional<unsigned int> numPrevFramesToKeep; //conserve memory; empty = no limit
};

} //namespace

#include "rgbdBagReader.ipp"

#endif //header
