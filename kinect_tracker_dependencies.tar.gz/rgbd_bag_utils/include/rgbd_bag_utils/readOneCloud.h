/*
 * readOneCloud: get a cloud from some file format based on a spec
 *
 * Evan Herbst
 * 5 / 9 / 10
 */

#ifndef EX_READ_ONE_CLOUD_H
#define EX_READ_ONE_CLOUD_H

#include <string>
#include <pcl/point_cloud.h>

/*
 * possible formats for framespec:
 * - ply_filepath
 * - bag_filepath:frame_index
 * - bag_filepath:time_sec:time_nsec
 */
template <typename PointT>
void readCloud(pcl::PointCloud<PointT>& cloud, const std::string& framespec);

#include "readOneCloud.ipp"

#endif //header
