/*
 * contents: programmatically get bag contents info
 *
 * Evan Herbst
 * 4 / 5 / 10
 */

#ifndef EX_RGBD_BAG_CONTENTS_H
#define EX_RGBD_BAG_CONTENTS_H

#include <string>
#include <vector>
#include <boost/shared_ptr.hpp>
#include <boost/filesystem/path.hpp>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/CompressedImage.h>
#include "rgbd_msgs/DepthMap.h"

namespace rgbd
{
namespace fs = boost::filesystem;

/*
 * look at the bag to figure out its rgbd data format
 *
 * throw on any error
 */
void determineRGBDBagSchema(const fs::path& bagFilepath, std::string& depthTopic, std::string& imgTopic, bool& depthCompressed, bool& imgCompressed);

struct bagTopicInfo
{
	bagTopicInfo() {}
	bagTopicInfo(const std::string& n, const std::string& d, const std::string& m) : name(n), datatype(d), md5sum(m), count(1) {}

	std::string name, datatype, md5sum;
	unsigned int count;
};

/*
 * don't check md5sum
 *
 * post: the return value's count isn't valid
 */
bagTopicInfo getSomeTopicOfType(const fs::path& bagFilepath, const std::string& datatype);
/*
 * find a single topic of any of the given types
 */
bagTopicInfo getSomeTopicOfTypeN(const fs::path& bagFilepath, const std::vector<std::string>& datatype_vector);

/*
 * deep-copy the first message in the file on this topic
 */
boost::shared_ptr<rgbd_msgs::DepthMap> getFirstDepthMessageOnTopic(const fs::path& bagFilepath, const std::string& topic);
boost::shared_ptr<sensor_msgs::Image> getFirstImgMessageOnTopic(const fs::path& bagFilepath, const std::string& topic);
boost::shared_ptr<sensor_msgs::CompressedImage> getFirstCompressedImgMessageOnTopic(const fs::path& bagFilepath, const std::string& topic);

} //namespace

#endif //header
