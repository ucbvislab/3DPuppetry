/*
 * rgbdCompressedImageSubscriber: programmatically do what the ros compressed-to-raw image converter does (by calling that code)
 *
 * Evan Herbst
 * 4 / 26 / 11
 */

#ifndef EX_RGBD_COMPRESSED_IMG_SUBSCRIBER_H
#define EX_RGBD_COMPRESSED_IMG_SUBSCRIBER_H

#include <boost/bind.hpp>
#include <boost/ref.hpp>
#include <compressed_image_transport/compressed_subscriber.h>

namespace rgbd
{

class rgbdCompressedImageSubscriber : public compressed_image_transport::CompressedSubscriber
{
	public:

		virtual ~rgbdCompressedImageSubscriber() {}

		sensor_msgs::ImageConstPtr decompress(const sensor_msgs::CompressedImageConstPtr& cimg)
		{
			sensor_msgs::ImageConstPtr img;
			const Callback func = boost::bind(&rgbdCompressedImageSubscriber::receiveImg, this, _1, boost::ref(img));
			compressed_image_transport::CompressedSubscriber::internalCallback(cimg, func);
			return img;
		}

		void receiveImg(const sensor_msgs::ImageConstPtr& src, sensor_msgs::ImageConstPtr& dest) {dest = src;}
};

} //namespace

#endif //header
