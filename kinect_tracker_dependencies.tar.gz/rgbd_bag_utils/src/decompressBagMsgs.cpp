/*
 * decompressBagMsgs: rewrite a bag with possibly compressed depth and imgs into one with both uncompressed
 * (copy just the image and depth channels)
 *
 * Evan Herbst
 * 10 / 30 / 10
 */

#include <cassert>
#include <iostream>
#include <boost/filesystem/path.hpp>
#include <rosbag/bag.h>
#include "rgbd_depthmaps/decompressDepth.h"
#include "rgbd_msgs/imageCompression.h"
#include "rgbd_bag_utils/contents.h"
#include "rgbd_bag_utils/rgbdBagReader.h"
using std::string;
using std::cout;
using std::endl;
namespace fs = boost::filesystem;

/*
 * arguments: inbag filepath, outbag filepath [image topic]
 * If image topic is provided, it will be used and assumed to be compressed
 */
int main(int argc, char* argv[])
{
	assert(argc == 3 || argc == 4);
	const fs::path inbagFilepath(argv[1]), outbagFilepath(argv[2]);
	string inputImageTopic;
	if (argc == 4) {
		inputImageTopic = argv[3];
	}

	string depthTopic, imgTopic;
	bool depthCompressed, imgCompressed;
	rgbd::determineRGBDBagSchema(inbagFilepath, depthTopic, imgTopic, depthCompressed, imgCompressed);
	cout << "depth compressed?: " << depthCompressed << "; img compressed?: " << imgCompressed << endl;
	if (inputImageTopic.length() > 0) {
		assert(imgCompressed); // might not even be the requested image topic
		cout << "Using provided image topic:" << inputImageTopic << endl;
		imgTopic = inputImageTopic;
	}
	const string outdepthTopic = "/rgbd/depth", outimgTopic = "/rgbd/image";
	//string depthTopicCompressed = depthTopic + "/compressed";
	//string imgTopicCompressed = imgTopic + "/compressed";
	rgbd::rgbdBagReader<> frameReader(inbagFilepath, depthTopic, imgTopic, 0/* start frame */, 1000000/* max end frame index */, 0/* frameskip */, 1/* num prev frames to keep */,
		primesensor::getColorCamParams(rgbd::KINECT_640_DEFAULT), primesensor::getColorCamParams(rgbd::KINECT_640_DEFAULT));

	rosbag::Bag writer(outbagFilepath.string(), rosbag::bagmode::Write);
	unsigned int numFrames = 0;
	while(frameReader.readOne())
	{
		if(imgCompressed)
		{
			const sensor_msgs::CompressedImageConstPtr cimg = frameReader.getLastCompressedImgPtr();
			sensor_msgs::Image img;
			rgbd::decompressImg(*cimg, img);
			writer.write(outimgTopic, img.header.stamp, img);
		}
		else
		{
			const sensor_msgs::ImageConstPtr img = frameReader.getLastImgPtr();
			writer.write(outimgTopic, img->header.stamp, img);
		}
		const rgbd_msgs::DepthMapConstPtr depth = frameReader.getLastDepthMapPtr();
		switch(depth->format)
		{
			case rgbd_msgs::DepthMap::format_raw:
			{
				writer.write(outdepthTopic, depth->header.stamp, *depth);
				break;
			}
			case rgbd_msgs::DepthMap::format_zlib:
			{
				rgbd_msgs::DepthMap uncompressedDepth;
				rgbd::decompressDepthMap(*depth, uncompressedDepth);
				writer.write(outdepthTopic, uncompressedDepth.header.stamp, uncompressedDepth);
				break;
			}
			default: assert(false);
		}
		numFrames++;
	}
	writer.close();
	cout << "copied " << numFrames << " frames" << endl;

	return 0;
}
