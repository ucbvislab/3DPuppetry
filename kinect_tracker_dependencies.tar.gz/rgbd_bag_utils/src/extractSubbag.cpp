/*
 * extractSubbag: write specified bag rgbd frames (image + depth) to another bag (which you could call a 'box' if you prefer)
 *
 * Evan Herbst
 * 7 / 28 / 10
 */

#include <cassert>
#include <iostream>
#include <boost/lexical_cast.hpp>
#include <boost/filesystem/path.hpp>
#include <rosbag/bag.h>
#include "rgbd_bag_utils/contents.h"
#include "rgbd_bag_utils/rgbdBagReader.h"
using std::string;
using std::cout;
using std::endl;
using boost::lexical_cast;
namespace fs = boost::filesystem;

/*
 * arguments: infilepath, start frame, frameskip (0 for none), end frame (inclusive; use a large number if you want 'until the end'), outfilepath
 */
int main(int argc, char* argv[])
{
	assert(argc == 6);
	unsigned int _ = 1;
	const fs::path infilepath(argv[_++]);
	const unsigned int startFrame = lexical_cast<unsigned int>(argv[_++]), frameskip = lexical_cast<unsigned int>(argv[_++]), endFrame = lexical_cast<unsigned int>(argv[_++]);
	const fs::path outfilepath(argv[_++]);

	string depthTopic, imgTopic;
	bool depthCompressed, imgCompressed;
	rgbd::determineRGBDBagSchema(infilepath, depthTopic, imgTopic, depthCompressed, imgCompressed);
	rgbd::rgbdBagReader<> frameReader(infilepath, depthTopic, imgTopic, startFrame, endFrame, frameskip, 0u/* num prev frames to keep */,
		primesensor::getColorCamParams(rgbd::KINECT_640_DEFAULT), primesensor::getColorCamParams(rgbd::KINECT_640_DEFAULT));
	rosbag::Bag outbag(outfilepath.string(), rosbag::bagmode::Write);
	unsigned int numFrames = 0;
	while(frameReader.readOne())
	{
		const rgbd_msgs::DepthMap& depth = frameReader.getLastDepthMap();
		const sensor_msgs::ImageConstPtr& img = frameReader.getLastUncompressedImgPtr();
		outbag.write(depthTopic, depth.header.stamp, depth);
		outbag.write(imgTopic, img->header.stamp, *img);
		numFrames++;
	}
	cout << "processed " << numFrames << " frames" << endl;

	return 0;
}
