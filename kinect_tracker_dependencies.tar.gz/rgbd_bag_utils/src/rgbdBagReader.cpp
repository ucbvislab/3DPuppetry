/*
 * rgbdBagReader: read rgbd frames from a bag using the ros::Bag interface
 *
 * Evan Herbst
 * 11 / 10 / 10
 */

#include <boost/variant/get.hpp>
#include "rgbd_bag_utils/rgbdBagReader.h"

namespace rgbd
{

/*
 * avoid duplicate definitions of templated functions 'get<>' in boost.variant and boost.graph
 */
sensor_msgs::ImageConstPtr getImgAux(const rgbd::someImageConstPtr& p)
{
	return boost::get<sensor_msgs::ImageConstPtr>(p);
}
sensor_msgs::CompressedImageConstPtr getCompressedImgAux(const rgbd::someImageConstPtr& p)
{
	return boost::get<sensor_msgs::CompressedImageConstPtr>(p);
}
sensor_msgs::ImageConstPtr* getImgPtrAux(rgbd::someImageConstPtr* const p)
{
	return boost::get<sensor_msgs::ImageConstPtr>(p);
}
sensor_msgs::CompressedImageConstPtr* getCompressedImgPtrAux(rgbd::someImageConstPtr* const p)
{
	return boost::get<sensor_msgs::CompressedImageConstPtr>(p);
}

} //namespace
