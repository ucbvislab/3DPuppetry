#include "rgbd_bag_utils/RGBDReader.h"

#include <stdio.h>

#define INFO(...) if(_verbose) printf(__VA_ARGS__)

namespace rgbd_bag_utils {

    /**
     * Constructs an RGBDReader for reading RGBD data directly from a ROS bag file.
     * 
     * @param filename path to the bag file to read
     * @param depth_topic the name of the depth topic (of type rgbd_msgs::DepthMap)
     * @param image_topic the name of the image topic (of type sensor_msgs::Image)
     */
    RGBDReader::RGBDReader(std::string filename, std::string depth_topic, 
                           std::string image_topic) {
        _verbose = false;
        _latest_depth = NULL;
        _latest_image = NULL;
        _prev_frame_time = ros::Time(0);

        _player = new ros::record::Player;
        if(!_player->open(filename, ros::Time())) {
            fprintf(stderr, "Can't open %s\n", filename.c_str());
            throw "Can't open bag file";
        }

        _player->addHandler<rgbd_msgs::DepthMap, RGBDReader>(depth_topic,
            &RGBDReader::depth_handler, this, NULL);
        _player->addHandler<sensor_msgs::Image, RGBDReader>(image_topic,
            &RGBDReader::image_handler, this, NULL);
    }

    /**
     * Standard destructor; frees the bag file reader.
     */
    RGBDReader::~RGBDReader() {
        _player->close();
        delete _player;
    }

    /**
     * Sets whether or not the RGBDReader should output informational messages while it is
     * operating.  May provide useful information for debugging problems.
     *
     * @param verbose whether or not to print debug information
     */
    void RGBDReader::set_verbose(bool verbose) {
        _verbose = verbose;
    }

    /**
     * Reads the next frame (consisting of a depth map/image pair with synchronized
     * timestamps) from the bag file.
     *
     * The pointers returned are valid until the next call to read_frame.  If you want to
     * keep the data around after that, you'll need to copy off the messages.
     *
     * Returns true if a frame was read from the bag file and the pointers are valid, or
     * false if there were no more frames in the bag file; in this case the pointers are set
     * to NULL.
     *
     * @param depth_map a reference to a pointer where the depth map is stored
     * @param image a reference to a pointer where the image is stored
     * @return true if a frame has been read; false if the end of the bag file was reached
     */
    bool RGBDReader::read_frame(rgbd_msgs::DepthMap *&depth_map, 
                                sensor_msgs::Image *&image) {
   	 const ros::Time prev_depth_time = _latest_depth ? _latest_depth->header.stamp : ros::Time(0);
   	 const ros::Time prev_img_time = _latest_image ? _latest_image->header.stamp : ros::Time(0);
   	 while(true) {
      	  if(!_player->nextMsg()) {
                // reached the end of the bag
                depth_map = NULL;
                image = NULL;
                return false;
            }

            if(_latest_depth == NULL || _latest_image == NULL) {
                // we haven't gotten one or the other message type yet
                continue;
            }

            if(_latest_depth->header.stamp > prev_depth_time) depth_map = _latest_depth;
            if(_latest_image->header.stamp > prev_img_time) image = _latest_image;

            if(_latest_depth->header.stamp == _latest_image->header.stamp && _latest_depth->header.stamp > _prev_frame_time)
            {
                // we have a matching pair
                INFO("[%d.%09d] Complete frame\n", _latest_depth->header.stamp.sec,
                    _latest_depth->header.stamp.nsec);
                _prev_frame_time = _latest_depth->header.stamp;
                return true;
            }
        }
    }

    /**
     * Callback function for handling depth messages from the bag file.
     */
    void RGBDReader::depth_handler(std::string name, rgbd_msgs::DepthMap *depth_map,
                                   ros::Time t, ros::Time t_shift, void *n) {
        INFO("[%d.%09d] Depth map\n", 
            depth_map->header.stamp.sec, depth_map->header.stamp.nsec);
        _latest_depth = depth_map;
    }

    /**
     * Callback function for handling uncompressed image messages from the bag file.
     */
    void RGBDReader::image_handler(std::string name, sensor_msgs::Image *image,
                                   ros::Time t, ros::Time t_shift, void *n) {
       INFO("[%d.%09d] Image\n", 
            image->header.stamp.sec, image->header.stamp.nsec);
        _latest_image = image;
    }

}

