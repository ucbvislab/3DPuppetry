/* This file shows an example of how to use rgbd_bag_utils::RGBDReader to read complete
 * frames from a bag file containing RGBD data (DepthMap and Image messages.) It doesn't
 * do anything useful by itself, but it shows where the data could be used.
 *
 * Brian Mayton <bmayton@bdm.cc>
 * Intel Labs Seattle
 * ROS RGBD Stack
 * January 2010
 */
#include <rgbd_bag_utils/RGBDReader.h>

#include <rgbd_msgs/DepthMap.h>
#include <sensor_msgs/Image.h>

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    if(argc < 4) {
        fprintf(stderr, "Usage:\n");
        fprintf(stderr, "  %s <bagfile.bag> <depth_topic> <image_topic>\n", argv[0]);
        exit(1);
    }

    std::string filename(argv[1]);
    std::string depth_topic(argv[2]);
    std::string image_topic(argv[3]);

    rgbd_msgs::DepthMap *depth_map;
    sensor_msgs::Image *image;

    rgbd_bag_utils::RGBDReader reader(filename, depth_topic, image_topic);
    reader.set_verbose(true);
    
    while(reader.read_frame(depth_map, image)) {
        // Do something with the depth map and image here.
        // Note that if the image/depth map are needed outside of this iteration of the
        // loop, you will need to make copies; the pointers are only valid for this
        // iteration.

        // Here we just print out some of the fields from the depth map as an example
        printf("Depth map is %dx%d\n", depth_map->width, depth_map->height);
    }

    return 0;
}

