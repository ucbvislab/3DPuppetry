/*
 * hires2loresBag: take a synced bag with high-res imgs and low-res depth (and maybe other channels) and output a bag with high-res imgs sampled at the low-res depth pts and low-res depth (and no other channels)
 *
 * Evan Herbst
 * 10 / 30 / 10
 */

#include <cassert>
#include <iostream>
#include <boost/lexical_cast.hpp>
#include <boost/filesystem/path.hpp>
#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <rosbag/view.h>
#include <cv_bridge/CvBridge.h>
#include "rgbd_util/timer.h"
#include "rgbd_util/CameraParams.h"
#include "rgbd_util/primesensorUtils.h"
#include "rgbd_bag_utils/contents.h"
#include "rgbd_bag_utils/rgbdBagReader.h"
#include "hirezify/sampleHighResImg.h"
using std::vector;
using std::string;
using std::cout;
using std::endl;
using boost::lexical_cast;
namespace fs = boost::filesystem;
using rgbd::eigen::Vector3f;
using rgbd::eigen::Transform3f;

/*
 * arguments: inbagpath, input img topic, outbagpath
 */
int main(int argc, char* argv[])
{
	assert(argc == 4);
	const fs::path inpath(argv[1]), outpath(argv[3]);
	const string inImgTopic(argv[2]);

	const rgbd::CameraParams loresCamParams = primesensor::getColorCamParams(rgbd::getCameraIDFromString(?)),
		hiresCamParams = primesensor::getColorCamParams(rgbd::POINT_GREY_GRASSHOPPER_7430345);
	const Transform3f lores2hiresXform = primesensor::getLores2hiresXform(rgbd::PRIMESENSOR_WITH_HIRES);

	string depthTopic, imgTopic;
	bool depthCompressed, imgCompressed;
	rgbd::determineRGBDBagSchema(inpath, depthTopic, imgTopic, depthCompressed, imgCompressed);
	rgbd::rgbdBagReader<> frameReader(inpath, depthTopic, inImgTopic, 0/* start frame */, 1000000/* end frame */, 0/* frameskip */, 1/* num prev frames to keep */);
	rosbag::Bag outbag(outpath.string(), rosbag::bagmode::Write);
	unsigned int numFrames = 0;
	while(frameReader.readOne())
	{
		rgbd::timer t;
		const sensor_msgs::Image& hiresImg = frameReader.getLastImg();
		const rgbd_msgs::DepthMap& depth = frameReader.getLastDepthMap();

		const vector<Vector3f> sampledCols = sampleHighResColors(depth, hiresImg, loresCamParams, lores2hiresXform, hiresCamParams);
		assert(sampledCols.size() == depth.width * depth.height);
		cv::Mat outImg(depth.height, depth.width, CV_8UC3);
		unsigned int c1 = 0, c2 = 0, c3 = 0;
		for(int y = 0, i = 0; y < depth.height; y++)
		{
			unsigned char* pix = outImg.ptr<unsigned char>(y);
			for(int x = 0; x < depth.width; x++, i++)
				if(sampledCols[i][0] == -1) //not visible
				{
					*pix++ = 0;
					*pix++ = 255;
					*pix++ = 0;
					c1++;
				}
				else if(sampledCols[i][0] == -2) //invalid depth
				{
					*pix++ = 0;
					*pix++ = 0;
					*pix++ = 255;
					c2++;
				}
				else
				{
					for(unsigned int j = 0; j < 3; j++) *pix++ = rint(255 * sampledCols[i][j]);
					c3++;
				}
		}
		cout << "#ok " << c3 << "; #invisible " << c1 << "; #invalid " << c2 << endl;

//		cv::imwrite("loframe" + lexical_cast<string>(numFrames) + ".png", outImg);

		sensor_msgs::CvBridge bridge;
		IplImage ipl = outImg;
		sensor_msgs::ImagePtr imgPtr = bridge.cvToImgMsg(&ipl);
		imgPtr->header = hiresImg.header;

		outbag.write(depthTopic, depth.header.stamp, depth);
		outbag.write(inImgTopic, imgPtr->header.stamp, *imgPtr);

		t.stop("process one frame");
		numFrames++;
	}
	cout << "processed " << numFrames << " frames" << endl;

	return 0;
}
