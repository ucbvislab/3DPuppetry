/*
 * rgbdBagComponentReader: provide a nicer interface than RGBDReader and allow getting the image, depth map and cloud individually
 *
 * Evan Herbst
 * 3 / 22 / 10
 */

#include <cassert>
#include <iostream>
#include <stdexcept>
#include <boost/make_shared.hpp>
#include "primesensor_tools/depth_to_cloud_lib.h"
#include "rgbd_bag_utils/rgbdBagComponentReader.h"
using std::string;
using std::cout;
using std::endl;
using std::runtime_error;
using std::invalid_argument;
using sensor_msgs::PointCloud;

namespace rgbd
{

/*
 * if maxFrameIndex is beyond the end of the bag, things will be ok as long as you use hasNext() to tell you how big the bag is
 *
 * frameSkip: # frames to actually skip (eg 4 to use every 5th)
 *
 * numKeptPrevFrames: conserve memory; if empty, no limit; 0 means delete frame i as soon as i + 1 is loaded
 */
rgbdBagComponentReader::rgbdBagComponentReader(const fs::path& bagFilepath, const string& depthTopic, const string& imgTopic, const unsigned int minFrame, const unsigned int maxFrame, const unsigned int frameSkip, const boost::optional<unsigned int> numKeptPrevFrames)
: reader(bagFilepath.string(), depthTopic, imgTopic), minFrameIndex(minFrame), maxFrameIndex(maxFrame), frameskip(frameSkip), lastFrameRead((long)minFrameIndex - 1), lastVirtualFrameRead(lastFrameRead), numPrevFramesToKeep(numKeptPrevFrames)
{
	for(int i = 0; i < ((long)minFrameIndex - 1); i++)
	{
		sensor_msgs::Image* imgptr; //these will be released by rgbdreader
		rgbd_msgs::DepthMap* depthptr;
		const bool ok = reader.read_frame(depthptr, imgptr);
		if(!ok) throw runtime_error("rgbdreader failed before start frame (perhaps bag isn't as long as you thought?)");
	}
}

/*
 * return false if we were already at the end of the bag or had reached the max requested index
 */
bool rgbdBagComponentReader::readOne()
{
	if(lastFrameRead >= maxFrameIndex) return false;
	sensor_msgs::Image* imgptr; //these will be released by rgbdreader
	rgbd_msgs::DepthMap* depthptr;
	const bool ok = reader.read_frame(depthptr, imgptr);
	if(!ok) //if at end of bag
	{
		return false;
	}
	else
	{
		depthMaps[lastVirtualFrameRead + 1] = boost::make_shared<rgbd_msgs::DepthMap>(*depthptr);
		imgs[lastVirtualFrameRead + 1] = boost::make_shared<sensor_msgs::Image>(*imgptr);
		PointCloud& cloud = clouds[lastVirtualFrameRead + 1];
		const bool ok = image_and_depth_to_cloud(imgs[lastVirtualFrameRead + 1].get(), depthMaps[lastVirtualFrameRead + 1].get(), true, false, cloud);
		if(!ok) throw runtime_error("image_and_depth_to_cloud failed");
		lastFrameRead++;
		lastVirtualFrameRead++;

		if(numPrevFramesToKeep) erase(lastVirtualFrameRead - 1 - *numPrevFramesToKeep);

		for(unsigned int i = 0; i < frameskip && lastFrameRead < maxFrameIndex; i++)
			if(!reader.read_frame(depthptr, imgptr)) return false;
			else lastFrameRead++;
		return true;
	}
}
/*
 * throw if the bag doesn't contain enough frames
 */
void rgbdBagComponentReader::readThrough(const unsigned int frameIndex)
{
	while(lastVirtualFrameRead < frameIndex)
		if(!readOne())
			throw std::invalid_argument("not enough frames left in bag");
}

/*
 * read frames as necessary
 *
 * throw if we don't have the desired frame stored
 */
const sensor_msgs::Image& rgbdBagComponentReader::getImg(long frameIndex)
{
	readThrough(frameIndex);
	if(imgs.find(frameIndex) == imgs.end()) throw invalid_argument("bad index");
	return *imgs[frameIndex];
}
const rgbd_msgs::DepthMap& rgbdBagComponentReader::getDepthMap(long frameIndex)
{
	readThrough(frameIndex);
	if(depthMaps.find(frameIndex) == depthMaps.end()) throw invalid_argument("bad index");
	return *depthMaps[frameIndex];
}
const PointCloud& rgbdBagComponentReader::getCloud(long frameIndex)
{
	readThrough(frameIndex);
	if(clouds.find(frameIndex) == clouds.end()) throw invalid_argument("bad index");
	return clouds[frameIndex];
}

/*
 * return the last one read
 *
 * throw if we haven't read anything
 */
const sensor_msgs::Image& rgbdBagComponentReader::getLastImg()
{
	return getImg(lastVirtualFrameRead);
}
const rgbd_msgs::DepthMap& rgbdBagComponentReader::getLastDepthMap()
{
	return getDepthMap(lastVirtualFrameRead);
}
const sensor_msgs::PointCloud& rgbdBagComponentReader::getLastCloud()
{
	return getCloud(lastVirtualFrameRead);
}

const sensor_msgs::ImageConstPtr rgbdBagComponentReader::getLastImgPtr()
{
	const long frameIndex = lastVirtualFrameRead;
	readThrough(frameIndex);
	if(imgs.find(frameIndex) == imgs.end()) throw invalid_argument("bad index");
	return imgs[frameIndex];
}
const rgbd_msgs::DepthMapConstPtr rgbdBagComponentReader::getLastDepthMapPtr()
{
	const long frameIndex = lastVirtualFrameRead;
	readThrough(frameIndex);
	if(depthMaps.find(frameIndex) == depthMaps.end()) throw invalid_argument("bad index");
	return depthMaps[frameIndex];
}

void rgbdBagComponentReader::erase(const long frameIndex)
{
	imgs.erase(frameIndex);
	depthMaps.erase(frameIndex);
	clouds.erase(frameIndex);
}

} //namespace
