/*
 * extract just the image and depth topics from an rgbd bag, make sure the timestamps of those two streams are synced in the output, and make sure
 * each output frame has both image and depth
 *
 * Brian Mayton <bmayton@bdm.cc>
 * Intel Labs Seattle
 * ROS RGBD Stack
 * January 2010
 */
#include <rgbd_bag_utils/RGBDReader.h>
#include <rgbd_bag_utils/RGBDWriter.h>

#include <rgbd_msgs/DepthMap.h>
#include <sensor_msgs/Image.h>

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    if(argc < 5) {
        fprintf(stderr, "Usage:\n");
        fprintf(stderr, "  %s <infile.bag> <outfile.bag> <depth_topic> <image_topic>\n", argv[0]);
        exit(1);
    }

    std::string filename(argv[1]);
    std::string out_filename(argv[2]);
    std::string depth_topic(argv[3]);
    std::string image_topic(argv[4]);

    rgbd_msgs::DepthMap *depth_map;
    sensor_msgs::Image *image;

    rgbd_bag_utils::RGBDReader reader(filename, depth_topic, image_topic);
    rgbd_bag_utils::RGBDWriter writer(out_filename, depth_topic, image_topic);
    
    while(reader.read_frame(depth_map, image)) {
        printf("Writing frame\n");
        writer.write_frame(*depth_map, *image);
    }

    return 0;
}

