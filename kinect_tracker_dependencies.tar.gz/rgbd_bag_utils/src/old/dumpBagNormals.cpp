/*
 * dumpBagNormals: write normals for clouds for all frames of a bag to disk
 *
 * Evan Herbst
 * 12 / 20 / 10
 */

#include <boost/lexical_cast.hpp>
#include <boost/filesystem.hpp>
#include "rgbd_util/ros_utility.h"
#include "rgbd_bag_utils/contents.h"
#include "rgbd_bag_utils/rgbdBagReader.h"
#include "pcl_rgbd/depth_to_cloud_lib.h"
#include "pcl_rgbd/cloudNormals.h"
#include "pcl_rgbd/normalsIO.h"
using std::string;
using boost::lexical_cast;
namespace fs = boost::filesystem;

/*
 * arguments: bag filepath, start frame index, end frame index (use -1 for no limit), outdir
 *
 * write outdir/normals-TIMESTAMP.bin
 */
int main(int argc, char **argv)
{
	assert(argc == 5);
	unsigned int _ = 1;
	const fs::path bagFilepath(argv[_++]);
	const unsigned int startFrameIndex = lexical_cast<unsigned int>(argv[_++]), endFrameIndex = lexical_cast<unsigned int>(argv[_++]);
	const fs::path outdir(argv[_++]);
	fs::create_directories(outdir);

	string depthTopic, imgTopic;
	bool depthCompressed, imgCompressed;
	rgbd::determineRGBDBagSchema(bagFilepath, depthTopic, imgTopic, depthCompressed, imgCompressed);
	rgbd::rgbdBagReader<> frameReader(bagFilepath, depthTopic, imgTopic, startFrameIndex, endFrameIndex, 0/* frameskip */, 1/* num prev frames to keep */);
	unsigned int frameIndex = startFrameIndex;
	while(frameReader.readOne())
	{
		const rgbd_msgs::DepthMap& depth = frameReader.getLastDepthMap();
		pcl::PointCloud<rgbd::pt> cloud;
		depth_to_cloud(depth, true, true/* organized */, cloud);
		boost::multi_array<bool, 2> validityGrid;
		rgbd::getValidityGrid(cloud, validityGrid);
		rgbd::setOrganizedNormals(cloud, validityGrid, 4/* window halfwidth */, 1/* downsampling */, .1/* max dz */);
		const fs::path filepath = outdir / ("normals-" + rgbd::convert_timestamp_to_string(depth.header.stamp, "-") + ".bin");
		rgbd::writeNormals(cloud, filepath.string());

		frameIndex++;
	}

	return 0;
}
