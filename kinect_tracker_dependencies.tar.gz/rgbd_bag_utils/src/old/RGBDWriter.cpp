#include "rgbd_bag_utils/RGBDWriter.h"

#include <stdio.h>

namespace rgbd_bag_utils {

    /**
     * Constructs an RGBDWriter for writing RGBD frames directly to a ROS bag file.
     *
     * @param filenabe path to the bag file to write
     * @param depth_topic the name of the topic in which depth maps should be written
     * @param image_topic the name of the topic in which images should be written
     */
    RGBDWriter::RGBDWriter(std::string filename, std::string depth_topic,
                           std::string image_topic) {
        _depth_topic = depth_topic;
        _image_topic = image_topic;

        _recorder = new ros::record::Recorder;
        if(!_recorder->open(filename)) {
            fprintf(stderr, "Can't open %s\n", filename.c_str());
            throw "Can't open bag file for writing";
        }
    }

    /**
     * Standard destructor; frees the bag file writer.
     */
    RGBDWriter::~RGBDWriter() {
        _recorder->close();
        delete _recorder;
    }

    /**
     * Writes an RGBD frame, consisting of a depth map and an image, to the bag file.
     *
     * It is assumed that the depth map and image will have the same timestamp.  If this is
     * not true, a warning will be printed and the timestamp from the depth map will be
     * used for the time that the messages were "logged"; the stamps in the headers of the
     * two messages will be preserved as-is.
     *
     * @param depth_map the depth map to write
     * @param image_map the image to write
     */
    void RGBDWriter::write_frame(rgbd_msgs::DepthMap &depth_map,
                                 sensor_msgs::Image &image) {
        if(depth_map.header.stamp.sec != image.header.stamp.sec ||
           depth_map.header.stamp.nsec != image.header.stamp.nsec) {
            fprintf(stderr, "warning: timestamps on depth map and image differ\n");
        }

        ros::Time stamp(depth_map.header.stamp);

        // This is really stupid.
        // rosrecord will *only* take a boost shared pointer to the message to write to
        // the bag file.  That means that even though it has no reason to keep around
        // pointers to the message after it's written, we *still* have to *copy* it so
        // we can get a boost shared pointer for it.  !@#$%^
        //
        // Forutnately, it looks like this will be fixed in the next ROS, but we're not
        // quite there yet.  So, we make a copy of data in memory only to throw it away for
        // now.  Hooray efficiency! \o/
        rgbd_msgs::DepthMap::Ptr depth_map_ptr(new rgbd_msgs::DepthMap(depth_map));
        sensor_msgs::Image::Ptr image_ptr(new sensor_msgs::Image(image));

        // When ROS 0.12 comes along, we should be able to drop the _ptr from the below two
        // lines, and delete the two lines above.
        printf("%d %d\n", depth_map_ptr->serializationLength(),
            image_ptr->serializationLength());

        // Geh, I really hope this is fixed in the next ROS... if this isn't filled, it's
        // uninitialized, and we end up writing gigabytes of zeros for each message!
        depth_map_ptr->__serialized_length = depth_map_ptr->serializationLength();
        image_ptr->__serialized_length = image_ptr->serializationLength();

        _recorder->record(_depth_topic, depth_map_ptr, stamp);
        _recorder->record(_image_topic, image_ptr, stamp);
    }

}

