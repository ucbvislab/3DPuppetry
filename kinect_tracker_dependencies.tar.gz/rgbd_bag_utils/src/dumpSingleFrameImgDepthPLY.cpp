/*
 * dumpSingleFrameImgDepthPLY: dump an image, a depth map and a PLY for a single frame from an rgbd bag
 *
 * Evan Herbst
 * 6 / 13 / 10
 */

#include <boost/lexical_cast.hpp>
#include <boost/format.hpp>
#include <boost/filesystem.hpp>
#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <cv_bridge/cv_bridge.h>
#include "rgbd_depthmaps/depthIO.h"
#include "rgbd_bag_utils/contents.h"
#include "rgbd_bag_utils/rgbdBagReader.h"
#include "pcl_rgbd/cloudTofroPLY.h"
using std::string;
using boost::lexical_cast;
namespace fs = boost::filesystem;

/*
 * arguments: bag filepath, frame index, outdirPlusFilebase (a string)
 *
 * write outdirPlusFilebase.{ply,dm,png}
 */
int main(int argc, char **argv)
{
	assert(argc == 4);
	const fs::path bagFilepath(argv[1]);
	const uint32_t frameIndex = lexical_cast<uint32_t>(argv[2]);
	const fs::path outdirPlusFilebase = argv[3];
	fs::create_directories(outdirPlusFilebase.parent_path());

	string depthTopic, imgTopic;
	bool depthCompressed, imgCompressed;
	rgbd::determineRGBDBagSchema(bagFilepath, depthTopic, imgTopic, depthCompressed, imgCompressed);
	rgbd::rgbdBagReader<> frameReader(bagFilepath, depthTopic, imgTopic, frameIndex, 1000000/* end frame index */, 0/* frameskip */, 1/* num prev frames to keep */,
		primesensor::getColorCamParams(rgbd::KINECT_640_DEFAULT), primesensor::getColorCamParams(rgbd::KINECT_640_DEFAULT));
	assert(frameReader.readOne());
	const pcl::PointCloud<rgbd::pt>& cloud = frameReader.getLastCloud();
	const sensor_msgs::ImageConstPtr img = frameReader.getLastUncompressedImgPtr();
	const rgbd_msgs::DepthMapConstPtr depth = frameReader.getLastDepthMapPtr();
	const fs::path plypath = outdirPlusFilebase.string() + ".ply";
	rgbd::write_ply_file(cloud, plypath.string());
	const fs::path imgpath = outdirPlusFilebase.string() + ".png";
	cv_bridge::CvImageConstPtr ciMsg = cv_bridge::toCvShare(img, "bgr8");
	cv::imwrite(imgpath.string(), ciMsg->image);
	const fs::path depthpath = outdirPlusFilebase.string() + ".dm";
	rgbd::writeDepthMap(*depth, depthpath);
	return 0;
}
