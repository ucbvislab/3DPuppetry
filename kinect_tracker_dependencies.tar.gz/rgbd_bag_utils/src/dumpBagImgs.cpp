/*
 * dumpBagImgs: play a bag and write each image
 *
 * Evan Herbst
 * 9 / 1 / 10
 */

#include <iostream>
#include <boost/lexical_cast.hpp>
#include <boost/filesystem.hpp>
#include <opencv/highgui.h>
#include <cv_bridge/cv_bridge.h>
#include "rgbd_util/ros_utility.h"
#include "rgbd_bag_utils/contents.h"
#include "rgbd_bag_utils/rgbdBagReader.h"
using std::string;
using std::cout;
using std::endl;
using std::vector;
using boost::lexical_cast;
namespace fs = boost::filesystem;

/*
 * arguments: bag filepath, start frame index, end frame index (use -1 for no limit), outdir[, img topic]
 *
 * write outdir/TIMESTAMP.png
 */
int main(int argc, char **argv)
{
	assert(argc == 5 || argc == 6);
	const fs::path bagFilepath(argv[1]);
	const unsigned int startFrameIndex = lexical_cast<unsigned int>(argv[2]), endFrameIndex = lexical_cast<unsigned int>(argv[3]);
	const fs::path outdir(argv[4]);
	fs::create_directories(outdir);

	string depthTopic, imgTopic;
	bool depthCompressed, imgCompressed;
	rgbd::determineRGBDBagSchema(bagFilepath, depthTopic, imgTopic, depthCompressed, imgCompressed);
	if(argc == 6) imgTopic = argv[5];
	cout << "dumping topic " << imgTopic << endl;
	rgbd::rgbdBagReader<> frameReader(bagFilepath, depthTopic, imgTopic, startFrameIndex, endFrameIndex, 0/* frameskip */, 1/* num prev frames to keep */,
		primesensor::getColorCamParams(rgbd::KINECT_640_DEFAULT), primesensor::getColorCamParams(rgbd::KINECT_640_DEFAULT));
	while(frameReader.readOne())
	{
		const sensor_msgs::Image::ConstPtr imgPtr = frameReader.getLastUncompressedImgPtr();
		const fs::path filepath = outdir / (rgbd::convert_timestamp_to_string(imgPtr->header.stamp, "-") + ".png");
		cv_bridge::CvImageConstPtr ciMsg = cv_bridge::toCvShare(imgPtr, "bgr8");
		vector<int> params(2);
		params[0] = CV_IMWRITE_PNG_COMPRESSION;
		params[1] = 9; //9 = most compressed
		cv::imwrite(filepath.string().c_str(), ciMsg->image, params);
	}

	return 0;
}
