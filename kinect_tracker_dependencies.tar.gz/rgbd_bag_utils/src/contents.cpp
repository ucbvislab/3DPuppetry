/*
 * contents: programmatically get bag contents info
 *
 * Evan Herbst
 * 4 / 5 / 10
 */

#include <iostream>
#include <stdexcept>
#include <boost/make_shared.hpp>
#include <rosbag/bag.h>
#include <rosbag/view.h>
#include "rgbd_util/timer.h"
#include "rgbd_bag_utils/contents.h"
using std::string;
using std::cout;
using std::endl;
using std::runtime_error;
using std::vector;

namespace rgbd
{

/*
 * look at the bag to figure out its rgbd data format
 *
 * throw on any error
 */
void determineRGBDBagSchema(const fs::path& bagFilepath, std::string& depthTopic, std::string& imgTopic, bool& depthCompressed, bool& imgCompressed)
{
	rgbd::timer t1;
	const rgbd::bagTopicInfo depthInfo = rgbd::getSomeTopicOfType(bagFilepath.string(), "rgbd_msgs/DepthMap");
	t1.stop("rgbd::getSomeTopicOfType(DepthMap)");
	depthTopic = depthInfo.name;
	if(depthInfo.md5sum != ros::message_traits::MD5Sum<rgbd_msgs::DepthMap>::value()) throw runtime_error("bag depth topic has wrong md5");

	vector<string> image_types;
	image_types.push_back("sensor_msgs/Image");
	image_types.push_back("sensor_msgs/CompressedImage");
	rgbd::timer t2;
	// let it throw if it doesn't have one of the image types
	const rgbd::bagTopicInfo imgInfo = rgbd::getSomeTopicOfTypeN(bagFilepath.string(), image_types);
	imgTopic = imgInfo.name;
	if (imgInfo.datatype == image_types[0]) {
		// uncompressed image
		if(imgInfo.md5sum != ros::message_traits::MD5Sum<sensor_msgs::Image>::value()) throw runtime_error("bag img topic has wrong md5");
		imgCompressed = false;
	}
	else if (imgInfo.datatype == image_types[1]) {
		// compressed image
		if(imgInfo.md5sum != ros::message_traits::MD5Sum<sensor_msgs::CompressedImage>::value()) throw runtime_error("bag (compressed) img topic has wrong md5");
		imgCompressed = true;
	}
	else {
		throw runtime_error("how did you get here?");
	}
	t2.stop("getSomeTopicOfTypeN(image or compressed image)");

	const boost::shared_ptr<rgbd_msgs::DepthMap> depthMsg = rgbd::getFirstDepthMessageOnTopic(bagFilepath.string(), depthTopic);
	switch(depthMsg->format)
	{
	  case rgbd_msgs::DepthMap::format_raw: depthCompressed = false; break;
	  case rgbd_msgs::DepthMap::format_packed: throw runtime_error("found depth-map format known to be unused as of 20100405");
	  case rgbd_msgs::DepthMap::format_zlib: depthCompressed = true; break;
	  case rgbd_msgs::DepthMap::format_png: throw runtime_error("found depth-map format known to be unused as of 20100405");
	}
}

/*
 * don't check md5sum
 *
 * post: the return value's count isn't valid
 */
bagTopicInfo getSomeTopicOfType(const fs::path& bagFilepath, const string& datatype)
{
	rosbag::Bag bag;
	bag.open(bagFilepath.string(), rosbag::bagmode::Read);
	rosbag::View view(bag, rosbag::TypeQuery(datatype));
	bagTopicInfo info;
	info.datatype = datatype;
	rosbag::View::iterator m = view.begin();
	const rosbag::MessageInstance& msg = *m;
	info.name = msg.getTopic();
	info.md5sum = msg.getMD5Sum();
	if(info.name.empty()) throw std::runtime_error("no msg of given type in bag");
	info.count = 0; //prevent accidental use of count
	return info;
}

/*
 * find a single topic of any of the given types
 */
bagTopicInfo getSomeTopicOfTypeN(const fs::path& bagFilepath, const std::vector<string>& datatype_vector)
{
	rosbag::Bag bag;
	bag.open(bagFilepath.string(), rosbag::bagmode::Read);
	rosbag::View view(bag, rosbag::TypeQuery(datatype_vector));
	bagTopicInfo info;
	for(rosbag::View::iterator m = view.begin(); m != view.end() && info.name.empty(); m++)
	{
		const rosbag::MessageInstance& msg = *m;
		for(unsigned int i = 0; i < datatype_vector.size(); i++)
			if(msg.getDataType() == datatype_vector[i])
			{
				info.datatype = msg.getDataType();
				info.name = msg.getTopic();
				info.md5sum = msg.getMD5Sum();
				break;
			}
	}
	if(info.name.empty()) throw std::runtime_error("no msg of given type in bag");
	info.count = 0; //prevent accidental use of count
	return info;
}

/*********************************************************************************************/

/*
 * deep-copy the first message in the file on this topic
 */
boost::shared_ptr<sensor_msgs::Image> getFirstImgMessageOnTopic(const fs::path& bagFilepath, const string& topic)
{
	rosbag::Bag bag;
	bag.open(bagFilepath.string(), rosbag::bagmode::Read);
	rosbag::View view(bag, rosbag::TopicQuery(topic));
	rosbag::View::iterator m = view.begin();
	const rosbag::MessageInstance& msg = *m;
	boost::shared_ptr<sensor_msgs::Image> img = msg.instantiate<sensor_msgs::Image>();
	if(!img) throw std::runtime_error("no img message in bag file");
	return img;
}

/*
 * deep-copy the first message in the file on this topic
 */
boost::shared_ptr<sensor_msgs::CompressedImage> getFirstCompressedImgMessageOnTopic(const fs::path& bagFilepath, const string& topic)
{
	rosbag::Bag bag;
	bag.open(bagFilepath.string(), rosbag::bagmode::Read);
	rosbag::View view(bag, rosbag::TopicQuery(topic));
	rosbag::View::iterator m = view.begin();
	const rosbag::MessageInstance& msg = *m;
	boost::shared_ptr<sensor_msgs::CompressedImage> img = msg.instantiate<sensor_msgs::CompressedImage>();
	if(!img) throw std::runtime_error("no img message in bag file");
	return img;
}

/*
 * deep-copy the first message in the file on this topic
 */
boost::shared_ptr<rgbd_msgs::DepthMap> getFirstDepthMessageOnTopic(const fs::path& bagFilepath, const string& topic)
{
	rosbag::Bag bag;
	bag.open(bagFilepath.string(), rosbag::bagmode::Read);
	rosbag::View view(bag, rosbag::TopicQuery(topic));
	rosbag::View::iterator m = view.begin();
	const rosbag::MessageInstance& msg = *m;
	boost::shared_ptr<rgbd_msgs::DepthMap> dm = msg.instantiate<rgbd_msgs::DepthMap>();
	if(!dm) throw std::runtime_error("no depth message in bag file");
	return dm;
}

} //namespace
