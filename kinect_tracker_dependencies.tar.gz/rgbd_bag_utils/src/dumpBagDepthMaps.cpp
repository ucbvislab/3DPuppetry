/*
 * dumpBagDepthMaps: play a bag and write each depth map to a binary file
 *
 * Evan Herbst
 * 8 / 13 / 10
 */

#include <boost/lexical_cast.hpp>
#include <boost/filesystem.hpp>
#include "rgbd_util/ros_utility.h"
#include "rgbd_depthmaps/depthIO.h"
#include "rgbd_depthmaps/decompressDepth.h"
#include "rgbd_bag_utils/contents.h"
#include "rgbd_bag_utils/rgbdBagReader.h"
using std::string;
using boost::lexical_cast;
namespace fs = boost::filesystem;

/*
 * arguments: bag filepath, start frame index, end frame index (use -1 for no limit), outdir
 *
 * write outdir/TIMESTAMP.dm
 */
int main(int argc, char **argv)
{
	assert(argc == 5);
	const fs::path bagFilepath(argv[1]);
	const unsigned int startFrameIndex = lexical_cast<unsigned int>(argv[2]), endFrameIndex = lexical_cast<unsigned int>(argv[3]);
	const fs::path outdir(argv[4]);
	fs::create_directories(outdir);

	string depthTopic, imgTopic;
	bool depthCompressed, imgCompressed;
	rgbd::determineRGBDBagSchema(bagFilepath, depthTopic, imgTopic, depthCompressed, imgCompressed);
	rgbd::rgbdBagReader<> frameReader(bagFilepath, depthTopic, imgTopic, startFrameIndex, endFrameIndex, 0/* frameskip */, 1/* num prev frames to keep */,
		primesensor::getColorCamParams(rgbd::KINECT_640_DEFAULT), primesensor::getColorCamParams(rgbd::KINECT_640_DEFAULT));
	while(frameReader.readOne())
	{
		const rgbd_msgs::DepthMap& depth = frameReader.getLastDepthMap();
		const fs::path filepath = outdir / (rgbd::convert_timestamp_to_string(depth.header.stamp, "-") + ".dm");
		switch(depth.format)
		{
			case rgbd_msgs::DepthMap::format_raw:
			{
				rgbd_msgs::DepthMap compressedDepth;
				rgbd::compressDepthMap(depth, compressedDepth);
				rgbd::writeDepthMap(compressedDepth, filepath);
				break;
			}
			case rgbd_msgs::DepthMap::format_zlib:
				rgbd::writeDepthMap(depth, filepath);
				break;
			default: assert(false && "unhandled");
		}
	}

	return 0;
}
