/*
 * restampLoresMsgsToSync: whenever we get an rgbd+high-res frame, edit the timestamps of the low-res msgs to match the high-res
 *
 * Evan Herbst
 * 10 / 30 / 10
 */

#include <cassert>
#include <iostream>
#include <boost/array.hpp>
#include <boost/filesystem/path.hpp>
#include <ros/node_handle.h>
#include <rosbag/bag.h>
#include <rosbag/view.h>
#include <message_filters/subscriber.h>
#include <message_filters/synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>
#include "rgbd_util/ros_utility.h"
#include "rgbd_bag_utils/contents.h"
#include "rgbd_bag_utils/rgbdBagReader.h"
using std::vector;
using std::string;
using std::cout;
using std::endl;
namespace fs = boost::filesystem;

void callback(const sensor_msgs::ImageConstPtr& loresImg, const rgbd_msgs::DepthMapConstPtr& depth, const sensor_msgs::ImageConstPtr& hiresImg, vector<boost::array<ros::Time, 3> >& frameOrigTimes)
{
	const boost::array<ros::Time, 3> times = {{loresImg->header.stamp, depth->header.stamp, hiresImg->header.stamp}};
//	cout << "adding frame: " << rgbd::convert_timestamp_to_string(times[0]) << ", " << rgbd::convert_timestamp_to_string(times[1]) << ", " << rgbd::convert_timestamp_to_string(times[2]) << endl;
	frameOrigTimes.push_back(times);
}

/*
 * arguments: inbagpath, low-res img topic, high-res img topic, outbagpath
 */
int main(int argc, char* argv[])
{
	ros::init(argc, argv, "restamp");
	assert(argc == 5);
	const fs::path inpath(argv[1]), outpath(argv[4]);
	const string loresImgTopic(argv[2]), hiresImgTopic(argv[3]);

	ros::NodeHandle nh;

	string depthTopic, imgTopic;
	bool depthCompressed, imgCompressed;
	rgbd::determineRGBDBagSchema(inpath, depthTopic, imgTopic, depthCompressed, imgCompressed);

	/*
	 * build a list of original times of msgs that we'll retime to match
	 */
	vector<boost::array<ros::Time, 3> > frameOrigTimes; //(lores img, depth, hires img) frame
	message_filters::Subscriber<sensor_msgs::Image> imgSubscriber(nh, loresImgTopic, 20/* buffer */);
	message_filters::Subscriber<sensor_msgs::Image> hiresImgSubscriber(nh, hiresImgTopic, 20/* buffer */);
	message_filters::Subscriber<rgbd_msgs::DepthMap> depthSubscriber(nh, depthTopic, 20/* buffer */);
	typedef message_filters::sync_policies::ApproximateTime<sensor_msgs::Image, rgbd_msgs::DepthMap, sensor_msgs::Image> syncPolicy;
	message_filters::Synchronizer<syncPolicy> sync(syncPolicy(20), imgSubscriber, depthSubscriber, hiresImgSubscriber);
	sync.registerCallback(boost::bind(callback, _1, _2, _3, boost::ref(frameOrigTimes)));
	rosbag::Bag bag;
	bag.open(inpath.string(), rosbag::bagmode::Read);
	vector<string> topics;
	topics.push_back(loresImgTopic);
	topics.push_back(depthTopic);
	topics.push_back(hiresImgTopic);
	rosbag::View view(bag, rosbag::TopicQuery(topics));
	for(rosbag::View::iterator m = view.begin(); m != view.end(); m++)
		if(m->getTopic() == loresImgTopic) sync.add<0>(m->instantiate<sensor_msgs::Image>());
		else if(m->getTopic() == depthTopic) sync.add<1>(m->instantiate<rgbd_msgs::DepthMap>());
		else if(m->getTopic() == hiresImgTopic) sync.add<2>(m->instantiate<sensor_msgs::Image>());
	bag.close();

	/*
	 * copy frames from input to output bag, retiming msgs
	 */
	boost::array<unsigned int, 3> nextMsgIndex = {{0, 0, 0}};
	rosbag::Bag bag2;
	bag2.open(inpath.string(), rosbag::bagmode::Read);
	rosbag::View view2(bag2, rosbag::TopicQuery(topics));
	rosbag::Bag outbag;
	outbag.open(outpath.string(), rosbag::bagmode::Write);
	for(rosbag::View::iterator m = view2.begin(); m != view2.end(); m++)
	{
		if(m->getTopic() == loresImgTopic && nextMsgIndex[0] < frameOrigTimes.size())
		{
			const sensor_msgs::ImagePtr msgptr = m->instantiate<sensor_msgs::Image>();
			if(msgptr->header.stamp == frameOrigTimes[nextMsgIndex[0]][0])
			{
//				cout << m->getTopic() << ' ' << nextMsgIndex[0] << ' ' << frameOrigTimes.size() << ' ' << rgbd::convert_timestamp_to_string(msgptr->header.stamp) << endl;
				msgptr->header.stamp = frameOrigTimes[nextMsgIndex[0]++][2];
				outbag.write(topics[0], m->getTime(), msgptr);
			}
		}
		else if(m->getTopic() == depthTopic && nextMsgIndex[1] < frameOrigTimes.size())
		{
			const rgbd_msgs::DepthMapPtr msgptr = m->instantiate<rgbd_msgs::DepthMap>();
			if(msgptr->header.stamp == frameOrigTimes[nextMsgIndex[1]][1])
			{
//				cout << m->getTopic() << ' ' << nextMsgIndex[1] << ' ' << frameOrigTimes.size() << ' ' << rgbd::convert_timestamp_to_string(msgptr->header.stamp) << endl;
				msgptr->header.stamp = frameOrigTimes[nextMsgIndex[1]++][2];
				outbag.write(topics[1], m->getTime(), msgptr);
			}
		}
		else if(m->getTopic() == hiresImgTopic && nextMsgIndex[2] < frameOrigTimes.size())
		{
			const sensor_msgs::ImagePtr msgptr = m->instantiate<sensor_msgs::Image>();
			if(msgptr->header.stamp == frameOrigTimes[nextMsgIndex[2]][2])
			{
//				cout << m->getTopic() << ' ' << nextMsgIndex[2] << ' ' << frameOrigTimes.size() << ' ' << rgbd::convert_timestamp_to_string(msgptr->header.stamp) << endl;
				msgptr->header.stamp = frameOrigTimes[nextMsgIndex[2]++][2];
				outbag.write(topics[2], m->getTime(), msgptr);
			}
		}
	}
	bag.close();
	outbag.close();
	for(unsigned int i = 0; i < 3; i++) assert(nextMsgIndex[i] == frameOrigTimes.size());

	return 0;
}
