/*
 * compressBagMsgs: rewrite a bag with uncompressed depth and imgs into one with both compressed
 * (copy just the image and depth channels)
 *
 * Evan Herbst
 * 10 / 19 / 10
 */

#include <cassert>
#include <iostream>
#include <boost/filesystem/path.hpp>
#include <rosbag/bag.h>
#include "rgbd_depthmaps/decompressDepth.h"
#include "rgbd_msgs/imageCompression.h"
#include "rgbd_bag_utils/contents.h"
#include "rgbd_bag_utils/rgbdBagReader.h"
using std::string;
using std::cout;
using std::endl;
namespace fs = boost::filesystem;

/*
 * arguments: inbag filepath, outbag filepath [, image topic]
 * If image topic is provided, it will be used and assumed to be uncompressed (temp fix for bags with hires)
 * Note that I'm just now extracting primesense data and leaving out hires data for later...
 */
int main(int argc, char* argv[])
{
	assert(argc == 3 || argc == 4);
	const fs::path inbagFilepath(argv[1]), outbagFilepath(argv[2]);
	string inputImageTopic;
	if (argc == 4) {
		inputImageTopic = argv[3];
	}

	string depthTopic, imgTopic;
	bool depthCompressed, imgCompressed;
	rgbd::determineRGBDBagSchema(inbagFilepath, depthTopic, imgTopic, depthCompressed, imgCompressed);
	cout << "depth compressed?: " << depthCompressed << "; img compressed?: " << imgCompressed << endl;
	if (inputImageTopic.length() > 0) {
		assert(!imgCompressed); // might not even be the requested image topic
		cout << "Using provided image topic:" << inputImageTopic << endl;
		imgTopic = inputImageTopic;
	}
	string depthTopicCompressed = depthTopic + "/compressed";
	string imgTopicCompressed = imgTopic + "/compressed";
	rgbd::rgbdBagReader<> frameReader(inbagFilepath, depthTopic, imgTopic, 0/* start frame */, 1000000/* max end frame index */, 0/* frameskip */, 1/* num prev frames to keep */,
		primesensor::getColorCamParams(rgbd::KINECT_640_DEFAULT), primesensor::getColorCamParams(rgbd::KINECT_640_DEFAULT));

	rosbag::Bag writer(outbagFilepath.string(), rosbag::bagmode::Write);
	unsigned int numFrames = 0;

	// eventually move to command line options?
	rgbd::imgCompressionOptions img_compression_options;
	img_compression_options.format = rgbd::imgCompressionOptions::FMT_JPG;
	img_compression_options.jpgQuality = 90;

	while(frameReader.readOne())
	{
		if(imgCompressed)
		{
			const sensor_msgs::CompressedImageConstPtr img = frameReader.getLastCompressedImgPtr();
			writer.write(imgTopic, img->header.stamp, *img);
		}
		else
		{
			const sensor_msgs::ImageConstPtr img = frameReader.getLastImgPtr();
			sensor_msgs::CompressedImage cimg;
			rgbd::compressImg(*img, cimg, img_compression_options);
			writer.write(imgTopicCompressed, cimg.header.stamp, cimg);
		}
		const rgbd_msgs::DepthMapConstPtr depth = frameReader.getLastDepthMapPtr();
		switch(depth->format)
		{
			case rgbd_msgs::DepthMap::format_raw:
			{
				rgbd_msgs::DepthMap compressedDepth;
				rgbd::compressDepthMap(*depth, compressedDepth);
				writer.write(depthTopicCompressed, compressedDepth.header.stamp, compressedDepth);
				break;
			}
			case rgbd_msgs::DepthMap::format_zlib:
			{
				writer.write(depthTopic, depth->header.stamp, *depth);
				break;
			}
			default: assert(false);
		}
		numFrames++;
	}
	writer.close();
	cout << "copied " << numFrames << " frames" << endl;

	return 0;
}
