/*
 * depthImgs2depthMaps: convert all msgs on a single topic from images to DepthMaps; pass through all other topics
 *
 * Evan Herbst
 * 3 / 15 / 12
 */

#include <cassert>
#include <string>
#include <boost/filesystem.hpp>
#include <rosbag/bag.h>
#include <rosbag/view.h>
#include "pcl_rgbd/cloudUtils.h"
namespace fs = boost::filesystem;

/*
 * arguments: input bagpath, topic name, output bagpath
 */
int main(int argc, char* argv[])
{
	assert(argc == 4);
	const fs::path inbagpath = argv[1], outbagpath = argv[3];
	const std::string depthImgTopic = argv[2];

	rosbag::Bag bag(inbagpath.string(), rosbag::bagmode::Read);
	rosbag::View view(bag, rosbag::View::TrueQuery());
	rosbag::Bag outbag(outbagpath.string(), rosbag::bagmode::Write);
	for(rosbag::View::iterator i = view.begin(); i != view.end(); i++)
	{
		rosbag::MessageInstance& m = *i;
		if(m.getTopic() == depthImgTopic)
		{
			sensor_msgs::ImagePtr img = m.instantiate<sensor_msgs::Image>();
			const rgbd_msgs::DepthMapConstPtr dm = rgbd::convertKinectDepthImageToDepthMap(*img);
			outbag.write(m.getTopic(), m.getTime(), dm);
		}
		else
		{
			outbag.write(m.getTopic(), m.getTime(), m);
		}
	}
	return 0;
}
