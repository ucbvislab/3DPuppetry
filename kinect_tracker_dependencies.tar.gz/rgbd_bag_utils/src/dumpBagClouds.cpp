/*
 * dumpBagClouds: play a bag and write each cloud to a ply
 *
 * Evan Herbst
 * 4 / 14 / 10
 */

#include <boost/lexical_cast.hpp>
#include <boost/filesystem.hpp>
#include "rgbd_util/ros_utility.h"
#include "rgbd_bag_utils/contents.h"
#include "rgbd_bag_utils/rgbdBagReader.h"
#include "pcl_rgbd/cloudNormals.h"
#include "pcl_rgbd/cloudTofroPLY.h"
using std::string;
using boost::lexical_cast;
namespace fs = boost::filesystem;

/*
 * arguments: bag filepath, start frame index, end frame index (use -1 for no limit), frame skip, whether to add normals (calculated in 2-d), outdir
 *
 * write outdir/TIMESTAMP.ply
 */
int main(int argc, char **argv)
{
	assert(argc == 7);
	unsigned int _ = 1;
	const fs::path bagFilepath(argv[_++]);
	const unsigned int startFrameIndex = lexical_cast<unsigned int>(argv[_++]), endFrameIndex = lexical_cast<unsigned int>(argv[_++]), frameSkip = lexical_cast<unsigned int>(argv[_++]);
	const bool calcNormals = lexical_cast<bool>(argv[_++]);
	const fs::path outdir(argv[_++]);
	fs::create_directories(outdir);

	string depthTopic, imgTopic;
	bool depthCompressed, imgCompressed;
	rgbd::determineRGBDBagSchema(bagFilepath, depthTopic, imgTopic, depthCompressed, imgCompressed);
	rgbd::rgbdBagReader<> frameReader(bagFilepath, depthTopic, imgTopic, startFrameIndex, endFrameIndex, frameSkip/* frameskip */, 1/* num prev frames to keep */,
		primesensor::getColorCamParams(rgbd::KINECT_640_DEFAULT), primesensor::getColorCamParams(rgbd::KINECT_640_DEFAULT));
	unsigned int frameIndex = startFrameIndex;
	while(frameReader.readOne())
	{
		const sensor_msgs::Image& img = frameReader.getLastImg();
		pcl::PointCloud<rgbd::pt> cloud = frameReader.getLastCloud();
		if(calcNormals)
		{
			rgbd::computeNormals2d(cloud, 4/* window halfwidth */, 1/* downsampling */, .1/* max dz */, img.width, img.height);
		}
		const fs::path filepath = outdir / (rgbd::convert_timestamp_to_string(img.header.stamp, "-") + ".ply");
		rgbd::write_ply_file(cloud, filepath.string());

		frameIndex++;
	}

	return 0;
}
