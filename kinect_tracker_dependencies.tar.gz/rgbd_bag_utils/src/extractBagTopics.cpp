/*
 * extractBagTopics: put selected topics into a new bag
 *
 * Evan Herbst
 * 11 / 24 / 10
 */

#include <cassert>
#include <iostream>
#include <boost/filesystem/path.hpp>
#include <rosbag/bag.h>
#include <rosbag/view.h>
using std::vector;
using std::string;
using std::cout;
using std::endl;
using boost::lexical_cast;
namespace fs = boost::filesystem;

/*
 * arguments: infilepath, outfilepath, [topic]+
 */
int main(int argc, char* argv[])
{
	assert(argc >= 4);
	const fs::path infilepath(argv[1]), outfilepath(argv[2]);
	vector<string> topicNames;
	for(unsigned int i = 3; i < argc; i++) topicNames.push_back(argv[i]);

	rosbag::Bag bag(infilepath.string(), rosbag::bagmode::Read);
	rosbag::View view(bag, rosbag::TopicQuery(topicNames));
	rosbag::Bag outbag(outfilepath.string(), rosbag::bagmode::Write);
	for(rosbag::View::iterator m = view.begin(); m != view.end(); m++) outbag.write((*m).getTopic(), (*m).getTime(), *m);

	return 0;
}
