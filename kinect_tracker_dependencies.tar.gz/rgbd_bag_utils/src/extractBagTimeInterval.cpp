/*
 * extractBagTimeInterval: write all msgs in a given time interval to a new bag
 *
 * Evan Herbst
 * 12 / 3 / 10
 */

#include <cassert>
#include <iostream>
#include <boost/filesystem.hpp>
#include <rosbag/bag.h>
#include <rosbag/view.h>
#include "rgbd_util/ros_utility.h"
using std::cout;
using std::endl;
namespace fs = boost::filesystem;

/*
 * arguments: infilepath, start SEC-NSEC, end SEC-NSEC (inclusive; if beyond bag end, we'll take until end), outfilepath (dir will be created)
 */
int main(int argc, char* argv[])
{
	assert(argc == 5);
	unsigned int _ = 1;
	const fs::path infilepath(argv[_++]);
	const ros::Time startTime = rgbd::convert_string_to_timestamp(argv[_++]), endTime = rgbd::convert_string_to_timestamp(argv[_++]);
	const fs::path outfilepath(argv[_++]);
	fs::create_directories(outfilepath.parent_path());
	cout << "time interval: " << rgbd::convert_timestamp_to_string(startTime) << " -> " << rgbd::convert_timestamp_to_string(endTime) << endl;

	rosbag::Bag bag(infilepath.string(), rosbag::bagmode::Read);
	rosbag::View view(bag, rosbag::View::TrueQuery());
	rosbag::Bag outbag(outfilepath.string(), rosbag::bagmode::Write);
	unsigned int count = 0;
	for(rosbag::View::iterator i = view.begin(); i != view.end(); i++)
	{
		rosbag::MessageInstance& m = *i;
//		cout << "got " << m.getDataType() << " @ " << rgbd::convert_timestamp_to_string(m.getTime()) << endl;
		if(m.getTime() >= startTime && m.getTime() <= endTime)
		{
			outbag.write(m.getTopic(), m.getTime(), m);
			count++;
		}
	}
	cout << "processed " << count << " msgs" << endl;
	return 0;
}
