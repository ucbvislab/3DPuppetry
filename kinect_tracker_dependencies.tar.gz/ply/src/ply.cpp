/*
 * ply: read & write PLY files in a completely runtime manner (not type-safe, and no schema checking)
 *
 * Evan Herbst
 * 2 / 9 / 10
 */

#include <sstream>
#include <stdexcept>
#include <boost/lexical_cast.hpp>
#include <boost/detail/endian.hpp>
#include "ply/ply.h"
using namespace std;
using boost::lexical_cast;

namespace ply
{

/*
 * on whitespace
 *
 * yell if line is empty
 */
vector<string> splitNonempty(const string& s)
{
	vector<string> result;
	istringstream instr(s);
	string str;
	while(instr >> str) result.push_back(str);
	if(result.empty()) throw invalid_argument("splitNonempty() given empty string");
	return result;
}

/*
 * call getline() until the line isn't a comment
 */
void getlineIgnoreComments(istream& in, string& line)
{
	getline(in, line);
	while(line.size() >= 7 && line.substr(0, 7) == "comment") getline(in, line);
}

/*
 * throw on any parse error
 */
schema readHeader(istream& in)
{
	string line;
	getline(in, line);
	if(line != "ply") throw invalid_argument("incorrect magic number");

	getlineIgnoreComments(in, line);
	vector<string> tokens = splitNonempty(line);
	if(tokens[0] != "format") throw invalid_argument("missing format line");
	if(tokens.size() != 3) throw invalid_argument("wrong number of tokens on format line");
	schema s;
	if(tokens[1] == "ascii") s.fmt = ply::FMT_ASCII;
	else if(tokens[1] == "binary_little_endian") s.fmt = ply::FMT_LITTLE_ENDIAN;
	else if(tokens[1] == "binary_big_endian") s.fmt = ply::FMT_BIG_ENDIAN;
	else throw invalid_argument("unknown format '" + tokens[1] + "'");
	s.fmtVersion = tokens[2];

	getlineIgnoreComments(in, line);
	tokens = splitNonempty(line);
	while(tokens[0] == "element")
	{
		if(tokens.size() != 3) throw invalid_argument("wrong number of tokens on element line");
		s.elements.resize(s.elements.size() + 1);
		element& e = s.elements.back();
		e.name = tokens[1];
		e.count = lexical_cast<unsigned int>(tokens[2]);

		/*
		 * read properties
		 */
		getlineIgnoreComments(in, line);
		tokens = splitNonempty(line);
		while(tokens[0] == "property")
		{
			switch(tokens.size())
			{
				case 3:
				{
					e.props.resize(e.props.size() + 1);
					property& p = e.props.back();
					p.type = tokens[1];
					p.name = tokens[2];
					break;
				}
				case 5:
				{
					assert(tokens[1] == "list");
					e.props.resize(e.props.size() + 1);
					property& p = e.props.back();
					p.countType = tokens[2];
					p.type = tokens[3];
					p.name = tokens[4];
					break;
				}
				default: throw invalid_argument("wrong number of tokens on property line");
			}
			getlineIgnoreComments(in, line);
			tokens = splitNonempty(line);
		}
	}

	if(tokens.size() != 1 || tokens[0] != "end_header") throw invalid_argument("can't parse expected end_header line");
	return s;
}

/*
 * throw on any error
 */
void writeHeader(ostream& out, const schema& s)
{
	out << "ply" << endl; //magic number
	string fmtStr;
	switch(s.fmt)
	{
		case ply::FMT_ASCII: fmtStr = "ascii"; break;
		case ply::FMT_LITTLE_ENDIAN: fmtStr = "binary_little_endian"; break;
		case ply::FMT_BIG_ENDIAN: fmtStr = "binary_big_endian"; break;
		default: throw std::invalid_argument("unknown format type");
	}
	out << "format " << fmtStr << " " << s.fmtVersion << endl;
	for(unsigned int i = 0; i < s.elements.size(); i++)
	{
		out << "element " << s.elements[i].name << ' ' << s.elements[i].count << endl;
		for(unsigned int j = 0; j < s.elements[i].props.size(); j++)
			if(s.elements[i].props[j].countType.empty())
				out << "property " << s.elements[i].props[j].type << ' ' << s.elements[i].props[j].name << endl;
			else
				out << "property list " << s.elements[i].props[j].countType << ' ' << s.elements[i].props[j].type << ' ' << s.elements[i].props[j].name << endl;
	}
	out << "end_header" << endl;
}

} //namespace
