/*
 * streamReaderCommon: shared by istreamReader and ostreamWriter
 *
 * Evan Herbst
 * 12 / 27 / 11
 */

#include <algorithm> //swap()
#include "ply/streamReaderCommon.h"

namespace ply
{
namespace detail
{

template <> void swapBytes<0>(char* c) {}
template <> void swapBytes<1>(char* c) {}
template <> void swapBytes<2>(char* c)
{
	std::swap(c[0], c[1]);
}
template <> void swapBytes<4>(char* c)
{
	std::swap(c[0], c[3]);
	swapBytes<2>(c + 1);
}
template <> void swapBytes<6>(char* c)
{
	std::swap(c[0], c[5]);
	swapBytes<4>(c + 1);
}
template <> void swapBytes<8>(char* c)
{
	std::swap(c[0], c[7]);
	swapBytes<6>(c + 1);
}

} //namespace
} //namespace
