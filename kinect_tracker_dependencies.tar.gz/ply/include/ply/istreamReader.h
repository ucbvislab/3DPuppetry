/*
 * istreamReader: generically read from a stream of text or binary format
 *
 * Evan Herbst
 * 2 / 9 / 10
 */

#ifndef EX_ISTREAM_READER_H
#define EX_ISTREAM_READER_H

#include <iostream>
#include "ply/plyTypes.h"
#include "ply/streamReaderCommon.h"

namespace ply
{

/*
 * I'd like to subclass this rather than having fmt as a field, but member function templates can't be virtual
 */
class istreamReader
{
	public:

		template <typename T> struct result {typedef void type;}; //for fusion

		istreamReader(const ply::format f, std::istream& i) : fmt(f), in(i) {}

		ply::format getFormat() const {return fmt;}

		/*
		 * read into t (a single tuple element)
		 */
		template <typename T, const bool IsListType = ply::detail::typeIsList<T>::value>
		void operator () (T& t) const;

		/*
		 * for non-list properties
		 */
		template <typename T> void readText(T& t) const;
		template <typename T> void readLittleEndian(T& t) const;
		template <typename T> void readBigEndian(T& t) const;

		/*
		 * for list properties
		 */
		template <typename T> void readListText(T& t) const;
		template <typename T> void readListLittleEndian(T& t) const;
		template <typename T> void readListBigEndian(T& t) const;

	protected:

		const ply::format fmt;

		/*
		 * terrible hack to make GCC 4.6 work
		 */
		#if __GNUC__ == 4 && __GNUC_MINOR__ == 6
		std::istream& in;
		#else
		mutable std::istream& in;
		#endif
};

} //namespace

#include "istreamReader.ipp"

#endif //header
