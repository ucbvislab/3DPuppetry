/*
 * ply: read & write PLY files in a completely runtime manner (not type-safe, and no schema checking)
 *
 * Evan Herbst
 * 2 / 9 / 10
 */

#ifndef EX_PLY_H
#define EX_PLY_H

#include <vector>
#include <string>
#include <iostream>
#include <boost/multi_array.hpp>
#include <boost/fusion/include/vector.hpp>
#include "plyTypes.h"
#include "istreamReader.h"
#include "ostreamWriter.h"

namespace ply
{
namespace fusion = boost::fusion;

/*
 * throw on any parse error
 */
schema readHeader(std::istream& in);

/**************************************************************************************************
 * you can either read tuples of known types and of length known at compile time or read from the istream yourself, eg using an istreamReader
 */

/*
 * read numValues element values of the requested type; return them as tuples
 *
 * wherever espec has a property list, FusionVectorT should have a std::pair<length type, std::vector<value type>>
 *
 * throw on any parse error
 */
template <typename FusionVectorT>
std::vector<FusionVectorT> readValues(std::istream& in, const ply::format fmt, const element& espec);

/*
 * read e.count values of the requested number of properties, casting every value to ValueT
 *
 * the returned array has one element per row
 *
 * throw on any parse error
 */
template <typename ValueT>
boost::multi_array<ValueT, 2> readElements(std::istream& in, const ply::format fmt, const element& e);

/*
 * throw on any error
 */
void writeHeader(std::ostream& out, const schema& s);

/*
 * write all the elements in v
 *
 * wherever an element of FusionVectorT has the form pair<X, vector<Y>>, we'll write a property list with count type X and element type Y
 *
 * throw on any error
 */
template <typename FusionVectorT>
void writeValues(std::ostream& out, const ply::format fmt, const std::vector<FusionVectorT>& v);

} //namespace

#include "ply.ipp"

#endif //EX_PLY_H
