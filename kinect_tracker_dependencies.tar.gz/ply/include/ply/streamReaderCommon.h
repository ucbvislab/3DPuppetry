/*
 * streamReaderCommon: shared by istreamReader and ostreamWriter
 *
 * Evan Herbst
 * 11 / 11 / 11
 */

#ifndef EX_PLY_STREAM_READER_COMMON_H
#define EX_PLY_STREAM_READER_COMMON_H

#include <vector>
#include <utility>
#include <type_traits>

namespace ply
{
namespace detail
{

/*
 * is T a std::vector?
 */
template <typename T>
struct typeIsVector {static const bool value = false;};
template <>
template <typename X>
struct typeIsVector<std::vector<X>> {static const bool value = true;};

/*
 * is T something we should expect a list for?
 */
template <typename T>
struct typeIsList {static const bool value = false;};
template <>
template <typename X, typename Y>
struct typeIsList<std::pair<X, Y>> {static const bool value = std::is_integral<X>::value && ply::detail::typeIsVector<Y>::value;};

/*
 * big <-> little endian for N bytes starting at c
 */
template <const size_t N> void swapBytes(char* c);

} //namespace
} //namespace

#endif //header
