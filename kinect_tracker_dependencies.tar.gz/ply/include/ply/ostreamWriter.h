/*
 * ostreamWriter: generically write to a stream of text or binary format
 *
 * Evan Herbst
 * 6 / 26 / 10
 */

#ifndef EX_OSTREAM_WRITER_H
#define EX_OSTREAM_WRITER_H

#include <iostream>
#include "ply/plyTypes.h"
#include "ply/streamReaderCommon.h"

namespace ply
{

class ostreamWriter
{
	public:

		template <typename T> struct result {typedef void type;}; //for fusion

		ostreamWriter(const ply::format f, std::ostream& o) : fmt(f), out(o) {}

		ply::format getFormat() const {return fmt;}

		/*
		 * write t
		 */
		template <typename T, const bool IsListType = ply::detail::typeIsList<T>::value>
		void operator () (const T& t) const;

		/*
		 * for non-list properties
		 */
		template <typename T> void writeText(const T& t) const;
		template <typename T> void writeLittleEndian(const T& t) const;
		template <typename T> void writeBigEndian(const T& t) const;

		/*
		 * for list properties
		 */
		template <typename T> void writeListText(const T& t) const;
		template <typename T> void writeListLittleEndian(const T& t) const;
		template <typename T> void writeListBigEndian(const T& t) const;

	protected:

		const ply::format fmt;

		/*
		 * terrible hack to make GCC 4.6 work
		 */
		#if __GNUC__ == 4 && __GNUC_MINOR__ == 6
		std::ostream& out;
		#else
		mutable std::ostream& out;
		#endif
};

} //namespace

#include "ostreamWriter.ipp"

#endif //header
