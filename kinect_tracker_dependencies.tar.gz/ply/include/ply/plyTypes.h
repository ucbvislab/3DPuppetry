/*
 * plyTypes
 *
 * Evan Herbst
 * 11 / 11 / 11
 */

#ifndef EX_PLY_TYPES_H
#define EX_PLY_TYPES_H

#include <vector>
#include <string>

namespace ply
{

enum format {FMT_ASCII, FMT_LITTLE_ENDIAN, FMT_BIG_ENDIAN};

struct property
{
	std::string type, name,
		countType; //if countType isn't empty, this property is a list
};
struct element
{
	std::string name;
	std::vector<property> props;
	unsigned int count;
};
struct schema
{
	ply::format fmt;
	std::string fmtVersion;
	std::vector<element> elements;
};

} //namespace

#endif //header
