%symbolic differentiation

clear all;

syms t0 t1 t2 x0 x1 x2 y0 y1 y2 n0 n1 n2 r00 r01 r02 r10 r11 r12 r20 r21 r22 q0 q1 q2 s1 s2 s3 c1 c2 c3 real;
syms x y t n R q J real;
x = [x0 x1 x2]';
y = [y0 y1 y2]';
n = [n0 n1 n2]';
t = [t0 t1 t2]';
q = [q0 q1 q2]';

s1 = sin(q0);
s2 = sin(q1);
s3 = sin(q2);
c1 = cos(q0);
c2 = cos(q1);
c3 = cos(q2);
r00 = c2 * c3;
r01 = c3 * s1 * s2 - c1 * s3;
r02 = c1 * c3 * s2 + s1 * s3;
r10 = c2 * s3;
r11 = c1 * c3 + s1 * s2 * s3;
r12 = c1 * s2 * s3 - c3 * s1;
r20 = -s2;
r21 = c2 * s1;
r22 = c1 * c2;
R = [r00 r01 r02; r10 r11 r12; r20 r21 r22];

%pt-to-plane
%J = (n' * (R * x + t - y))^2;

%jx is the equivalent of J from Xiaofeng's script, edited by me -- does match J
%jx = (-((cos(q2)*sin(q0)-cos(q0)*sin(q1)*sin(q2))*x2-x1*(sin(q1)*sin(q2)*sin(q0)+cos(q0)*cos(q2))+y1-t1-x0*cos(q1)*sin(q2))*n1+(t0+x1*(cos(q2)*sin(q1)*sin(q0)-cos(q0)*sin(q2))-y0+(cos(q0)*cos(q2)*sin(q1)+sin(q2)*sin(q0))*x2+x0*cos(q1)*cos(q2))*n0+n2*(t2+cos(q1)*x1*sin(q0)-x0*sin(q1)-y2+cos(q0)*cos(q1)*x2))^2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%

%pt-to-pt
J = (R * x + t - y)' * (R * x + t - y);

