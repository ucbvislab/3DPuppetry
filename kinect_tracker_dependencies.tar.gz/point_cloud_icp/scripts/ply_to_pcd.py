'''
Created on Jul 14, 2009

@author: peter
'''

import sys
import os

"""
ply
format ascii 1.0
element face 0
property list uchar int vertex_indices
element vertex 17339
property float x
property float y
property float z
property uchar diffuse_red
property uchar diffuse_green
property uchar diffuse_blue
end_header
"""

"""
COLUMNS x y z valid
POINTS 307200
ARRAY 640 480
DATA ascii
"""

def convert_ply_to_pcd(input_filename, output_filename):
    point_count = None
    channel_list = []
    point_string_list = []
    for line in open(input_filename).readlines():
        if line[0].isalpha():
            line_split = line.split()
            if len(line_split) < 2: continue
            if line_split[0] == 'element' and line_split[1] == 'vertex':
                point_count = int(line_split[2])
            elif line_split[0] == 'property':
                if line_split[1] == 'list': continue
                property_type = line_split[1]
                property_name = line_split[2]
                channel_list.append((property_type, property_name))
        else:
            point_string_list.append(line)
    assert int(point_count) > 0
    output_file = open(output_filename, 'w')
    column_list = ' '.join([channel[1] for channel in channel_list])
    print >> output_file, 'COLUMNS', column_list
    print >> output_file, 'POINTS', point_count
    print >> output_file, 'DATA ascii'
    for point_line in point_string_list:
        print >> output_file, point_line.strip()
        

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print "Usage: [program] <file1.ply> [<file2.ply> ...]"
        exit(1)
    filename_list = sys.argv[1:]
    for input_filename in filename_list:
        extension = input_filename[-3:]
        if extension != 'ply':
            print '%s is not a ply file...skipping' % input_filename
            continue
        output_filename = input_filename[:-3] + 'pcd'
        print 'Converting %s to %s' % (input_filename, output_filename)
        convert_ply_to_pcd(input_filename, output_filename)
    
    