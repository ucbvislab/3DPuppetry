'''
Created on Jul 14, 2009

@author: peter
'''

import sys
import os

"""
Nothing given..sample line:
-0.708029 -0.692492 1.531866 180 113 98 5.000000 56.000000
assume:
x y z b g r y x
"""

"""
COLUMNS x y z valid
POINTS 307200
ARRAY 640 480
DATA ascii
"""

def convert_pts_to_pcd(input_filename, output_filename):
    point_string_list = []
    for line in open(input_filename).readlines():
        if len(line.strip()) > 0:
            point_string_list.append(line)
    point_count = len(point_string_list)
    output_file = open(output_filename, 'w')
    column_list = "x y z b g r image_y image_x"
    print >> output_file, 'COLUMNS', column_list
    print >> output_file, 'POINTS', point_count
    print >> output_file, 'DATA ascii'
    for point_line in point_string_list:
        print >> output_file, point_line.strip()
        

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print "Usage: [program] <file1.pts> [<file2.pts> ...]"
        exit(1)
    filename_list = sys.argv[1:]
    for input_filename in filename_list:
        extension = input_filename[-3:]
        if extension != 'pts':
            print '%s is not a pts file...skipping' % input_filename
            continue
        output_filename = input_filename[:-3] + 'pcd'
        print 'Converting %s to %s' % (input_filename, output_filename)
        convert_pts_to_pcd(input_filename, output_filename)
    
    