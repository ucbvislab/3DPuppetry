#!/usr/bin/ruby
# Mike Krainin
# script for running surfel node multiple times and processing output
time = Time.now
filename = "results/results_noise.csv"
surfel_output = "results/joints.txt"

numPerSetting = ARGV[0].to_i
priorWeight = ARGV[1].to_f
startSeed = 1

# export settings used by surfel.launch
ENV['SURFEL_PRIOR_WEIGHT'] = priorWeight.to_s

# open up the results file
resultsExists = File.exists?(filename)
results = File.new(filename,"a")

#write the header if needed
if (!resultsExists)
	puts "Writing header"
	results.puts "Detect_Object, Noise_Level, Prior_Weight, Average_Noisy_RMS, Final_Noisy_RMS, "+
		"Average_ICP_RMS, Final_ICP_RMS, Average_Noisy_EE-dist, Final_Noisy_EE-dist, "+
		"Average_ICP_EE-dist, Final_ICP_EE-dist"
end

#alter the noise level
noiseIncrement = 0.2
noiseStart = 0.0
numSettings = 26

# loop through trials
current = 1
while current <= numPerSetting do 
ENV['SURFEL_SEED'] = (startSeed + current).to_s


#loop through object settings
detectObjectState = 0
detectObject = "false"
while detectObjectState < 2  
ENV['SURFEL_DETECT_OBJECT'] = detectObject


#loop through noise settings
stateNum = 0
noiseRate = noiseStart
while stateNum < numSettings  
ENV['SURFEL_NOISE_RATE'] = noiseRate.to_s
	
		puts "Running trial number " + current.to_s + " for noise rate " + noiseRate.to_s + " and detect object " + detectObject
	
		if(File.exists?(surfel_output))
			File.delete(surfel_output)
		end

		`roslaunch launch/surfel_multigrasp_experiments.launch > output.log`
		
		result = ""
		
		cloudCount = 0
		avgNoisyRMS=avgICPRMS=0
		lastNoisyRMS=lastICPRMS=0
		avgNoisyEEDist=avgICPEEDist=0
		lastNoisyEEDist=lastICPEEDist=0
		file = File.open(surfel_output)
		
		#read the file
		while (!file.eof?) do
			file.gets #skip cloud number
			
			# read the real joint angles
			real = file.readline.split(", ")
			real[0] = real[0].split(": ")[1] #remove the label
			real.map! { |i| i=i.to_f }
			
			# read the noisy joint angles
			noisy = file.readline.split(", ")
			noisy[0] = noisy[0].split(": ")[1] #remove the label
			noisy.map! { |i| i=i.to_f }
			
			# read the icp joint angles
			icp = file.readline.split(", ")
			icp[0] = icp[0].split(": ")[1] #remove the label
			icp.map! { |i| i=i.to_f }
			
			
			file.gets #skip cloud number
			
			# read the real joint end effector
			realEE = file.readline.split(", ")
			realEE[0] = realEE[0].split(": ")[1] #remove the label
			realEE.map! { |i| i=i.to_f }
			
			# read the noisy joint end effector
			noisyEE = file.readline.split(", ")
			noisyEE[0] = noisyEE[0].split(": ")[1] #remove the label
			noisyEE.map! { |i| i=i.to_f }
			
			# read the icp joint end effector
			icpEE = file.readline.split(", ")
			icpEE[0] = icpEE[0].split(": ")[1] #remove the label
			icpEE.map! { |i| i=i.to_f }
			
			# get the SSEs
			noisySSE = icpSSE = 0
			(0...real.size).each do |i|
				noisySSE += (noisy[i]-real[i])*(noisy[i]-real[i])
				icpSSE += (icp[i]-real[i])*(icp[i]-real[i])
			end
			
			# compute the RMS
			lastNoisyRMS = Math.sqrt(noisySSE/real.size)
			lastICPRMS = Math.sqrt(icpSSE/real.size)
				
			avgNoisyRMS+=lastNoisyRMS
			avgICPRMS+=lastICPRMS
			
			#get the end effector distances
			noisySqDist = icpSqDist = 0
			(0...realEE.size).each do |i|
				noisySqDist += (noisyEE[i]-realEE[i])*(noisyEE[i]-realEE[i])
				icpSqDist += (icpEE[i]-realEE[i])*(icpEE[i]-realEE[i])
			end
			lastNoisyEEDist= Math.sqrt(noisySqDist)
			lastICPEEDist=Math.sqrt(icpSqDist)
			
			avgNoisyEEDist+=lastNoisyEEDist
			avgICPEEDist+=lastICPEEDist
				
			cloudCount+=1
		end
		
		avgNoisyRMS/=cloudCount
		avgICPRMS/=cloudCount
		
		avgNoisyEEDist/=cloudCount
		avgICPEEDist/=cloudCount
			
		file.close
		
		results.puts detectObject + ", " + noiseRate.to_s + ", " + priorWeight.to_s + ", " +
			avgNoisyRMS.to_s + ", " + lastNoisyRMS.to_s + ", " + avgICPRMS.to_s + ", " + lastICPRMS.to_s + ", " +
			avgNoisyEEDist.to_s + ", " + lastNoisyEEDist.to_s + ", " + avgICPEEDist.to_s + ", " + lastICPEEDist.to_s
	
		
		#close the file and reopen it in append mode. if we only open the file at the beginning and
		#close it at the very end, we can't view the intermediate results because they don't 
		#actually get written until the close
		results.close
		results = File.new(filename,"a")
		
	
noiseRate+=noiseIncrement
stateNum+=1
end #for each setting of noise

detectObjectState+=1
detectObject = "true"
end #for each setting of noise


current+=1
end #while current <= numPerSetting


results.close
