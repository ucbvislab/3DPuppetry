#!/usr/bin/ruby
# Mike Krainin
# script for running surfel node multiple times and processing output
time = Time.now
filename = "results/results_object.csv"
surfel_output = "results/joints.txt"

numPerSetting = ARGV[0].to_i
noiseRate = ARGV[1].to_i
priorWeight = ARGV[2].to_f
detectObject = "false"
current = 1

# export settings used by surfel.launch
ENV['SURFEL_NOISE_RATE'] = ARGV[1]
ENV['SURFEL_PRIOR_WEIGHT'] = ARGV[2]
ENV['SURFEL_DETECT_OBJECT'] = "false"

# open up the results file
resultsExists = File.exists?(filename)
results = File.new(filename,"a")

#write the header if needed
if (!resultsExists)
	puts "Writing header"
	results.puts "Detect Object, Noise Level, Prior Weight, Average Noisy RMS, Final Noisy RMS, "+
		"Average ICP RMS, Final ICP RMS, Average Noisy EE-dist, Final Noisy EE-dist, "+
		"Average ICP EE-dist, Final ICP EE-dist"
end

#alter surfel_detect_object
stateNum = 0
while stateNum < 2
	ENV['SURFEL_DETECT_OBJECT'] = detectObject
	
	current = 1
	while current <= numPerSetting do
	
		ENV['SURFEL_SEED'] = current.to_s
	
		puts "Running trial number " + current.to_s + " for detect object " + detectObject
	
		if(File.exists?(surfel_output))
			File.delete(surfel_output)
		end
		
		launcher = Thread.new do
			`roslaunch launch/surfel_experiments.launch > output.log`
		end
		player = Thread.new do
		  	`rosplay -r .15 -t 25 data/new_primesense/mug_c2.bag`
		end
		
		launcher.join
		player.join
		
		result = ""
		
		cloudCount = 0
		avgNoisyRMS=avgICPRMS=0
		lastNoisyRMS=lastICPRMS=0
		avgNoisyEEDist=avgICPEEDist=0
		lastNoisyEEDist=lastICPEEDist=0
		file = File.open(surfel_output)
		
		#read the file
		while (!file.eof?) do
			file.gets #skip cloud number
			
			# read the real joint angles
			real = file.readline.split(", ")
			real[0] = real[0].split(": ")[1] #remove the label
			real.map! { |i| i=i.to_f }
			
			# read the noisy joint angles
			noisy = file.readline.split(", ")
			noisy[0] = noisy[0].split(": ")[1] #remove the label
			noisy.map! { |i| i=i.to_f }
			
			# read the icp joint angles
			icp = file.readline.split(", ")
			icp[0] = icp[0].split(": ")[1] #remove the label
			icp.map! { |i| i=i.to_f }
			
			
			file.gets #skip cloud number
			
			# read the real joint end effector
			realEE = file.readline.split(", ")
			realEE[0] = realEE[0].split(": ")[1] #remove the label
			realEE.map! { |i| i=i.to_f }
			
			# read the noisy joint end effector
			noisyEE = file.readline.split(", ")
			noisyEE[0] = noisyEE[0].split(": ")[1] #remove the label
			noisyEE.map! { |i| i=i.to_f }
			
			# read the icp joint end effector
			icpEE = file.readline.split(", ")
			icpEE[0] = icpEE[0].split(": ")[1] #remove the label
			icpEE.map! { |i| i=i.to_f }
			
			# get the SSEs
			noisySSE = icpSSE = 0
			(0...real.size).each do |i|
				noisySSE += (noisy[i]-real[i])*(noisy[i]-real[i])
				icpSSE += (icp[i]-real[i])*(icp[i]-real[i])
			end
			
			# compute the RMS
			lastNoisyRMS = Math.sqrt(noisySSE/real.size)
			lastICPRMS = Math.sqrt(icpSSE/real.size)
				
			avgNoisyRMS+=lastNoisyRMS
			avgICPRMS+=lastICPRMS
			
			#get the end effector distances
			noisySqDist = icpSqDist = 0
			(0...realEE.size).each do |i|
				noisySqDist += (noisyEE[i]-realEE[i])*(noisyEE[i]-realEE[i])
				icpSqDist += (icpEE[i]-realEE[i])*(icpEE[i]-realEE[i])
			end
			lastNoisyEEDist= Math.sqrt(noisySqDist)
			lastICPEEDist=Math.sqrt(icpSqDist)
			
			avgNoisyEEDist+=lastNoisyEEDist
			avgICPEEDist+=lastICPEEDist
				
			cloudCount+=1
		end
		
		avgNoisyRMS/=cloudCount
		avgICPRMS/=cloudCount
		
		avgNoisyEEDist/=cloudCount
		avgICPEEDist/=cloudCount
			
		file.close
		
		results.puts detectObject + ", " + noiseRate.to_s + ", " + priorWeight.to_s + ", " +
			avgNoisyRMS.to_s + ", " + lastNoisyRMS.to_s + ", " + avgICPRMS.to_s + ", " + lastICPRMS.to_s + ", " +
			avgNoisyEEDist.to_s + ", " + lastNoisyEEDist.to_s + ", " + avgICPEEDist.to_s + ", " + lastICPEEDist.to_s
	
		
		#close the file and reopen it in append mode. if we only open the file at the beginning and
		#close it at the very end, we can't view the intermediate results because they don't 
		#actually get written until the close
		results.close
		results = File.new(filename,"a")
		
		current+=1
	end #while current <= numPerSetting
	
	detectObject = "true"
	stateNum+=1
end #for each setting

results.close
