#!/usr/bin/ruby
# Mike Krainin
# script for running kalman filter multiple times and processing output
time = Time.now
filename = "results/results.csv"
kalman_output = "results/joints.txt"

numPerSetting = ARGV[0].to_i
noiseLevel = ARGV[1].to_i
priorWeight = ARGV[2].to_f
detectObject = "false"
current = 1

# export settings used by kalman.launch
ENV['KALMAN_NOISE_LEVEL'] = ARGV[1]
ENV['KALMAN_PRIOR_WEIGHT'] = ARGV[2]
ENV['KALMAN_DETECT_OBJECT'] = "false"

# open up the results file
resultsExists = File.exists?(filename)
results = File.new(filename,"a")

#write the header if needed
if (!resultsExists)
	puts "Writing header"
	results.puts "Detect Object, Noise Level, Prior Weight, Average Noisy RMS, Final Noisy RMS, "+
		"Average ICP RMS, Final ICP RMS, Average Kalman RMS, Final Kalman RMS, Average Noisy EE-dist, Final Noisy EE-dist, "+
		"Average ICP EE-dist, Final ICP EE-dist, Average Kalman EE-dist, Final Kalman EE-dist"
end

#alter prior weight
# priorWeight = 0.5

#alter kalman_detect_object
stateNum = 0
while stateNum < 2
	ENV['KALMAN_DETECT_OBJECT'] = detectObject
	
	current = 1
	while current <= numPerSetting do
	
		puts "Running trial number " + current.to_s + " for detect object " + detectObject
	
		if(File.exists?(kalman_output))
			File.delete(kalman_output)
		end
		
		launcher = Thread.new do
			`roslaunch kalman.launch`
		end
		player = Thread.new do
#		  	`rosplay -r .1 new_arm_recordings/calibration/2009-09-09-15-25-14-topic.bag`
			`rosplay -r .1 new_arm_recordings/mug_rotate_only/2009-09-09-15-02-48-topic.bag`
		end
		
		launcher.join
		player.join
		
		result = ""
		
		cloudCount = 0
		avgNoisyRMS=avgICPRMS=avgKalmanRMS=0
		lastNoisyRMS=lastICPRMS=lastKalmanRMS=0
		avgNoisyEEDist=avgICPEEDist=avgKalmanEEDist=0
		lastNoisyEEDist=lastICPEEDist=lastKalmanEEDist=0
		file = File.open(kalman_output)
		
		#read the file
		while (!file.eof?) do
			file.gets #skip cloud number
			
			# read the real joint angles
			real = file.readline.split(", ")
			real[0] = real[0].split(": ")[1] #remove the label
			real.map! { |i| i=i.to_f }
			
			# read the noisy joint angles
			noisy = file.readline.split(", ")
			noisy[0] = noisy[0].split(": ")[1] #remove the label
			noisy.map! { |i| i=i.to_f }
			
			# read the icp joint angles
			icp = file.readline.split(", ")
			icp[0] = icp[0].split(": ")[1] #remove the label
			icp.map! { |i| i=i.to_f }
			
			# read the kalman joint angles
			kalman = file.readline.split(", ")
			kalman[0] = kalman[0].split(": ")[1] #remove the label
			kalman.map! { |i| i=i.to_f }
			
			
			file.gets #skip cloud number
			
			# read the real joint end effector
			realEE = file.readline.split(", ")
			realEE[0] = realEE[0].split(": ")[1] #remove the label
			realEE.map! { |i| i=i.to_f }
			
			# read the noisy joint end effector
			noisyEE = file.readline.split(", ")
			noisyEE[0] = noisyEE[0].split(": ")[1] #remove the label
			noisyEE.map! { |i| i=i.to_f }
			
			# read the icp joint end effector
			icpEE = file.readline.split(", ")
			icpEE[0] = icpEE[0].split(": ")[1] #remove the label
			icpEE.map! { |i| i=i.to_f }
			
			# read the kalman joint end effector
			kalmanEE = file.readline.split(", ")
			kalmanEE[0] = kalmanEE[0].split(": ")[1] #remove the label
			kalmanEE.map! { |i| i=i.to_f }
			
			# get the SSEs
			noisySSE = icpSSE = kalmanSSE = 0
			(0...real.size).each do |i|
				noisySSE += (noisy[i]-real[i])*(noisy[i]-real[i])
				icpSSE += (icp[i]-real[i])*(icp[i]-real[i])
				kalmanSSE += (kalman[i]-real[i])*(kalman[i]-real[i])
			end
			
			# compute the RMS
			lastNoisyRMS = Math.sqrt(noisySSE/real.size)
			lastICPRMS = Math.sqrt(icpSSE/real.size)
			lastKalmanRMS = Math.sqrt(kalmanSSE/real.size)
				
			avgNoisyRMS+=lastNoisyRMS
			avgICPRMS+=lastICPRMS
			avgKalmanRMS+=lastKalmanRMS
			
			#get the end effector distances
			noisySqDist = icpSqDist = kalmanSqDist = 0
			(0...realEE.size).each do |i|
				noisySqDist += (noisyEE[i]-realEE[i])*(noisyEE[i]-realEE[i])
				icpSqDist += (icpEE[i]-realEE[i])*(icpEE[i]-realEE[i])
				kalmanSqDist += (kalmanEE[i]-realEE[i])*(kalmanEE[i]-realEE[i])
			end
			lastNoisyEEDist= Math.sqrt(noisySqDist)
			lastICPEEDist=Math.sqrt(icpSqDist)
			lastKalmanEEDist=Math.sqrt(kalmanSqDist)
			
			avgNoisyEEDist+=lastNoisyEEDist
			avgICPEEDist+=lastICPEEDist
			avgKalmanEEDist+=lastKalmanEEDist
				
			cloudCount+=1
		end
		
		avgNoisyRMS/=cloudCount
		avgICPRMS/=cloudCount
		avgKalmanRMS/=cloudCount
		
		avgNoisyEEDist/=cloudCount
		avgICPEEDist/=cloudCount
		avgKalmanEEDist/=cloudCount
			
		file.close
		
		results.puts detectObject + ", " + noiseLevel.to_s + ", " + priorWeight.to_s + ", " +
			avgNoisyRMS.to_s + ", " + lastNoisyRMS.to_s + ", " + avgICPRMS.to_s + ", " + lastICPRMS.to_s + ", " +
			avgKalmanRMS.to_s + ", " + lastKalmanRMS.to_s + ", " +
			avgNoisyEEDist.to_s + ", " + lastNoisyEEDist.to_s + ", " + avgICPEEDist.to_s + ", " + lastICPEEDist.to_s + ", " +
			avgKalmanEEDist.to_s + ", " + lastKalmanEEDist.to_s 
	
		
		#close the file and reopen it in append mode. if we only open the file at the beginning and
		#close it at the very end, we can't view the intermediate results because they don't 
		#actually get written until the close
		results.close
		results = File.new(filename,"a")
		
		current+=1
	end #while current <= numPerSetting
	
	detectObject = "true"
	stateNum+=1
end #for each setting

results.close
