/*
 * icpPlanarPatch: ICP planar-patch-to-planar-patch error function
 *
 * Evan Herbst
 * 7 / 19 / 10
 */

#ifndef EX_ICP_PLANARPATCH_H
#define EX_ICP_PLANARPATCH_H

#include <vector>
#include "rgbd_util/eigen/Geometry"

namespace icp
{
namespace planarPatch
{

/*
 * PointVectorT must be vector<Vector3f> or vector<Vector4f, aligned_allocator>
 */
template <typename PointVectorT>
void getSourceErrorVector(const PointVectorT& sourcePoints, const PointVectorT& sourceNormals, const PointVectorT& targetPoints, const PointVectorT& targetNormals, const std::vector<float>& pointWeights,
									rgbd::eigen::Affine3f const& transform, const std::vector<int>& correspondence_indices, std::vector<float> & result);
template <typename PointVectorT>
void getTargetErrorVector(const PointVectorT& targetPoints, const PointVectorT& targetNormals, const std::vector<float>& pointWeights,
									const std::vector<int>& correspondence_indices, std::vector<float> & result);

} //namespace
} //namespace

#include "icpPlanarPatch.ipp"

#endif //header
