/*
 * icpPoint2Point.h
 *
 *  Created on: Mar 30, 2010
 *      Author: peter
 *
 * Parallels icpPoint2Plane.h
 *
 * Provides source and target error vectors for ICP
 */

#ifndef ICPPOINT2POINTREPROJECTION_H_
#define ICPPOINT2POINTREPROJECTION_H_

#include <vector>
#include "rgbd_util/eigen/Geometry"
#include "rgbd_util/CameraParams.h"

namespace icp
{
namespace point2pointReprojection
{

/*
 * PointVectorT must be vector<Vector3f> or vector<Vector4f, aligned_allocator>
 */
template <typename PointVectorT>
void getSourceErrorVector(
		boost::shared_ptr<rgbd::CameraParams> const& rgbd_camera_params_ptr,
		float stereo_baseline,
		const PointVectorT& sourcePoints,
		const std::vector<float>& pointWeights,
		rgbd::eigen::Affine3f const& transform,
		const std::vector<int>& correspondence_indices,
		std::vector<float> & result);
template <typename PointVectorT>
void getTargetErrorVector(
		boost::shared_ptr<rgbd::CameraParams> const& rgbd_camera_params_ptr,
		float stereo_baseline,
		const PointVectorT& targetPoints,
		const std::vector<float>& pointWeights,
		const std::vector<int>& correspondence_indices,
		std::vector<float> & result);

} // ns
} // ns

#include "icpPoint2PointReprojection.ipp"

#endif /* ICPPOINT2POINT_H_ */
