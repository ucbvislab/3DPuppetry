/*
 * icpPoint2Plane: ICP point-to-plane error function
 *
 * Evan Herbst
 * 3 / 25 / 10
 */

#ifndef EX_ICP_POINT2PLANE_H
#define EX_ICP_POINT2PLANE_H

#include <vector>
#include "rgbd_util/eigen/Geometry"

namespace icp
{
namespace point2plane
{

/*
 * PointVectorT must be vector<Vector3f> or vector<Vector4f, aligned_allocator>
 */
template <typename PointVectorT>
void getSourceErrorVector(const PointVectorT& sourcePoints, const PointVectorT& targetNormals, const std::vector<float>& pointWeights,
									rgbd::eigen::Affine3f const& transform, const std::vector<int>& correspondence_indices, std::vector<float> & result);
template <typename PointVectorT>
void getTargetErrorVector(const PointVectorT& targetPoints, const PointVectorT& targetNormals, const std::vector<float>& pointWeights,
									const std::vector<int>& correspondence_indices, std::vector<float> & result);

/*
 * covs gives covariance matrices for source points, with zeros in the last row and col
 *
 * calculate expected error
 *
 * PointVectorT must be vector<Vector3f> or vector<Vector4f, aligned_allocator>
 */
template <typename PointVectorT>
void getSourceErrorVector(const PointVectorT& sourcePoints, const PointVectorT& targetPoints, const PointVectorT& targetNormals, const std::vector<rgbd::eigen::Matrix4f>& covs,
									rgbd::eigen::Affine3f const& transform, const std::vector<int>& correspondence_indices, std::vector<float> & result);
template <typename PointVectorT>
void getTargetErrorVector(const PointVectorT& targetPoints, const PointVectorT& targetNormals, const std::vector<rgbd::eigen::Matrix4f>& covs,
									const std::vector<int>& correspondence_indices, std::vector<float> & result);

} //namespace
} //namespace

#include "icpPoint2Plane.ipp"

#endif //header
