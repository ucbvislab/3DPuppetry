/*
 * icpPoint2Line.h
 *
 *  Created on: May 18, 2010
 *      Author: mkrainin
 *
 * Parallels icpPoint2Plane.h
 *
 * Provides source and target error vectors for ICP
 */

#ifndef ICPPOINT2LINE_H_
#define ICPPOINT2LINE_H_

#include <vector>
#include "rgbd_util/eigen/Geometry"

namespace icp
{
namespace point2line
{

/*
 * PointVectorT must be vector<Vector3f> or vector<Vector4f, aligned_allocator>
 */
template <typename PointVectorT>
void getSourceErrorVector(const PointVectorT& sourcePoints, const PointVectorT& targetNormals1, const NormalVectorT& targetNormals2,
	const std::vector<float>& pointWeights, rgbd::eigen::Affine3f const& transform, const std::vector<int>& correspondence_indices, std::vector<float> & result);
template <typename PointVectorT>
void getTargetErrorVector(const PointVectorT& targetPoints, const PointVectorT& targetNormals1, const NormalVectorT& targetNormals2,
	const std::vector<float>& pointWeights, const std::vector<int>& correspondence_indices, std::vector<float> & result);

} // ns
} // ns

#include "icpPoint2Line.ipp"

#endif /* ICPPOINT2LINE_H_ */
