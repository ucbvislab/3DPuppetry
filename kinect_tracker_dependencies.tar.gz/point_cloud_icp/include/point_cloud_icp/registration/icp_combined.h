/*
 * icp_combined.h
 *
 *  Created on: Jan 27, 2010
 *      Author: peter
 *
 * cleaner implementation of combined icp (multiple clouds, multiple error functions, priors, and fixed correspondences)
 */

#ifndef ICP_COMBINED_H_
#define ICP_COMBINED_H_

#include <vector>
#include <deque>
#include <string>
#include <boost/shared_ptr.hpp>
#include <boost/optional.hpp>
#include <boost/tuple/tuple.hpp>
#include <boost/utility/enable_if.hpp>
#include <boost/mpl/logical.hpp> //and_, not_
#include "kdtree2/kdtree2.hpp"
#include "rgbd_util/eigen/Core"
#include "rgbd_util/eigen/Geometry"
#include <pcl/point_cloud.h>
#include <sensor_msgs/Image.h>
#include "rgbd_util/CameraParams.h"
#include "pcl_rgbd/pointTypes.h"
#include "ros/publisher.h"
#include "pcl_rgbd/cloudMarkers.h"

//PCL
#include <pcl/ModelCoefficients.h>


namespace registration
{

enum ICPCombinedNonlinearOptimizer {OPTIMIZER_LEVMAR, OPTIMIZER_CMINPACK_LM, OPTIMIZER_EIGEN_LM, OPTIMIZER_CLOSED_FORM};

/*
 * Defines the overall behavior for all pairs of clouds
 */
struct ICPCombinedParams
{
	// which optimizer
	ICPCombinedNonlinearOptimizer optimizer;

	// maximum rounds for LM optimizer to run
	int max_lm_rounds;

	// termination criteria:

	// maximum number of rounds to run icp
	int max_icp_rounds;

	// Will continue icp iterations if any of these conditions is met :

	// Minimum translation size (in m; negative turns off)
	float min_dist_to_continue;

	// Minimum rotation component size (in rad; negative turns off)
	float min_rot_to_continue;

	// Minimum fractional change in overall error (negative turns off)
	float min_error_frac_to_continue;

	ICPCombinedParams()
	: optimizer(OPTIMIZER_EIGEN_LM), // really the user should set this...could even default to NONE to enforce
	  max_lm_rounds(100),
	  max_icp_rounds(100),
	  min_dist_to_continue(-1),
	  min_rot_to_continue(-1),
	  min_error_frac_to_continue(-1),
	  enable_alignment_with_ty_rx_rz_restrictions(false)
	  {}

	//ground plane use

	bool enable_alignment_with_ty_rx_rz_restrictions;
	float translation_penalty_weight;
	float rotational_penalty_weight;

	float ground_plane_norm_alignment_penalty_weight;
	float ground_plane_y_intersect_alignment_penalty_weight;


};

enum errorFunction {ICP_ERR_POINT_TO_POINT, ICP_ERR_POINT_TO_PLANE, ICP_ERR_POINT_TO_LINE, ICP_ERR_PLANAR_PATCH, ICP_ERR_REPROJECTION};
enum correspondencesType {ICP_CORRS_SINGLE_TREE, ICP_CORRS_COLOR_BINNING, ICP_CORRS_COLOR_6D_SEARCH, ICP_CORRS_COLOR_5D_LAB_SEARCH, ICP_CORRS_COLOR_5D_HSV_SEARCH, ICP_CORRS_COLOR_COMPATIBILITY, ICP_CORRS_REPROJECTION};
enum weightsType
{
	ICP_WTS_SCALAR, //spherical gaussian
	ICP_WTS_MATRIX //covariance matrix
};
/*
 * Defines the parameters specific to a particular pair of point clouds.
 */
struct ICPCloudPairParams
{
public:
	ICPCloudPairParams()
	: errType(ICP_ERR_POINT_TO_POINT),
	  corrType(ICP_CORRS_SINGLE_TREE),
	  wtType(ICP_WTS_SCALAR),
	  fixed_correspondence(false),
	  max_distance(-1),
	  front_can_match_back(true),
	  use_average_point_error(false),
	  outlier_percentage(-1),
	  extract_all_normals(false),
	  max_normal_angle(-1),
	  no_many_to_one_correspondences(false),
	  filter_on_geometric_consistency(false)
	{}

	errorFunction errType;

	correspondencesType corrType;

	weightsType wtType;

	// if the correspondences are fixed (two clouds must be the same size)
	// for example, to put RANSAC pairs in
	bool fixed_correspondence;

	// ignore correspondences larger than this
	// If <= 0, ignored
	// if ICP_CORRS_REPROJECTION this is in PIXELS and must be positive
	float max_distance;

	//whether an "inside" surface can match to an "outside" surface
	// if this is false (no longer the default), then normals are required for both clouds
	bool front_can_match_back;

	// use the average error over all points in the pair instead of total error
	bool use_average_point_error;

	// discard this percentage of highest correspondence distances (-1.0 for off)
	float outlier_percentage;

	// require both clouds to have normals (and extract them) regardless of error function
	// current use is using ICP with SBA
	bool extract_all_normals;

	// maximum angle between normals in radians
	// negative values turn off this check
	// NOTE: This is a general version of the above "front can match back"
	float max_normal_angle;

	// Experimental.  Eliminate all correspondences where more than one source point go to a target point
	bool no_many_to_one_correspondences;

	//after computing initial correspondences, find a geometrically consistent subset of them and invalidate the rest
	bool filter_on_geometric_consistency;
};


/*
 * Determines multi-threading behavior. NOTE: Must be reset after creating a cloud if you want non-default values.
 * NOTE: Threads > 1 can be unstable if shared variables are carefully accounted for (Robin 1/30/12)
 */
struct ICPThreadParams
{
public:
	ICPThreadParams()
	: search_threads(0)
	{}

	// Manually set number of threads to use while finding correspondences.
	// Setting <= 0 reverts to original method of assigning numThreads based on the size of the source point cloud.
	int search_threads;
};



/*
 * This class holds the information needed to align a pair of clouds as part of the joint optimization
 */
class ICPCloudPair
{
public:
	//pick Vector3f or Vector4f
	typedef std::vector<rgbd::eigen::Vector4f, rgbd::eigen::aligned_allocator<rgbd::eigen::Vector4f> > srcPtVecT;
	typedef std::vector<rgbd::eigen::Vector4f, rgbd::eigen::aligned_allocator<rgbd::eigen::Vector4f> > tgtPtVecT;
	typedef std::vector<rgbd::eigen::Vector4f, rgbd::eigen::aligned_allocator<rgbd::eigen::Vector4f> > normalVecT;
	typedef srcPtVecT::value_type srcPtT;
	typedef tgtPtVecT::value_type tgtPtT;
	typedef normalVecT::value_type normalT;


	struct colorMatchingParams
	{
		colorMatchingParams() : errorTermWeight(0), maxIntensity(1), colorDimensionScaling(0), colorCompatibilityMaxDist(0) {}
		colorMatchingParams(const sensor_msgs::ImageConstPtr& tgtImg, const rgbd::CameraParams& cp, const float w, const float i, const float s, const float cc)
		: targetImage(tgtImg), camParams(cp), errorTermWeight(w), maxIntensity(i), colorDimensionScaling(s), colorCompatibilityMaxDist(cc)
		{}

		sensor_msgs::ImageConstPtr targetImage;
		rgbd::CameraParams camParams;

		//for color based error terms (0 weight to disable)
		float errorTermWeight;
		float maxIntensity;

		// when using ICP_CORRS_COLOR_6D_SEARCH (set separately), this specifies the scaling of the
		// r,g,b dimensions relative to the x,y,z dimensions
		float colorDimensionScaling;

		//when using ICP_CORRS_COLOR_COMPATIBILITY (set separately), this specifies the maximum
		// r,g,b color distance (where r,g, and b are each in [0,1]) for a correspondence
		float colorCompatibilityMaxDist;
	};

	template <typename PointT1, typename PointT2>
	ICPCloudPair(const ICPCloudPairParams& params, const pcl::PointCloud<PointT1>& sourceCloud, const pcl::PointCloud<PointT2>& targetCloud, const boost::optional<colorMatchingParams>& cmparams = boost::none);
	~ICPCloudPair();

	/*
	 * EXPERIMENTAL
	 * for running with many source clouds against the same target, to minimize recomputation of indices
	 *
	 * you'll also have to reset point weights and whatever other src-dependent things you've set
	 */
	template <typename PointT1>
	void replaceSourceCloud(const pcl::PointCloud<PointT1>& newSourceCloud);

	/*
	 * for when you have a good estimate of the Targets's position and don't want the match influenced by distance points in the source
	 * Added by Robin 12/7/11
	 *
	 * you'll also have to reset point weights and whatever other src-dependent things you've set
	 */
	template <typename PointT1>
	void replaceTargetCloud(const pcl::PointCloud<PointT1>& newTargetCloud);

	/*
	 * Correspondences to boundary points are ignored. By default, no
	 * target points are marked as boundary
	 */
	void setTargetIsBoundary(const std::vector<bool>& target_pt_is_boundary);

	void setScalarWeights(const std::vector<float>& point_weights = std::vector<float>());
	void setMatrixWeights(const std::vector<rgbd::eigen::Matrix3f>& point_weights = std::vector<rgbd::eigen::Matrix3f>());

	/*
	 * Get the correspondence indices for source points from target points under transformation;
	 * an index will be -1 if no valid correspondence is found (for example, if the distance between points is greater than max_distance)
	 *
	 * simply look up each source point in a k-d tree of the target cloud, so it is possible for one target point to be assigned to many source points
	 *
	 * return the number of valid correspondences
	 */
	int getCorrespondenceIndices(rgbd::eigen::Affine3f const& transform, std::vector<int>& correspondence_indices) const;

	/*
	 * Get the source part of the error function.
	 * This will be called by the LM optimization
	 *
	 * vector length depends on params
	 */
	void getSourceErrorVector(rgbd::eigen::Affine3f const& transform, std::vector<int> const& correspondence_indices, std::vector<float> & result) const;

	/*
	 * Get the target part of the error function.
	 * This will be called by the LM optimization
	 *
	 * vector length depends on params
	 */
	void getTargetErrorVector(std::vector<int> const& correspondence_indices, std::vector<float> & result) const;

	/*
	 * Compute the error under the given correspondences and transformation.
	 *
	 * This calls getSourceErrorVector and getTargetErrorVector, takes the pairwise difference, squares, then sums
	 */
	float getError(rgbd::eigen::Affine3f const& transform, std::vector<int> const& correspondence_indices) const;

	void getPoints(std::vector<rgbd::eigen::Vector3f> &source_points, std::vector<rgbd::eigen::Vector3f> &target_points);

	/*
	 * Access individual points and normals.  These call vector.at(i) for primitive bounds checking
	 */
	ICPCloudPair::srcPtT getSourcePoint(unsigned int i);
	ICPCloudPair::normalT getSourceNormal(unsigned int i);
	ICPCloudPair::tgtPtT getTargetPoint(unsigned int i);
	ICPCloudPair::normalT getTargetNormal(unsigned int i);

	/*
	 * throw if we aren't using scalar weights
	 */
	const std::vector<float>& getPointWeights();

	float getMaxDistance();
	void setMaxDistance(float new_value);

	/*
	 * This may be dangerous.
	 */
	void setParams(const ICPCloudPairParams & params);

	/*
	 * This may be dangerous.
	 */
	void setThreadParams(const ICPThreadParams & thread_params);

	/*
	 * Sets params.errType to ICP_ERR_REPROJECTION
	 */
	void setReprojectionError(
			boost::shared_ptr<rgbd::CameraParams> const& rgbd_camera_params_ptr,
			float stereo_baseline);

	/*
	 * Sets params.corrType to ICP_CORRS_REPROJECTION
	 */
	void setReprojectionCorrs(
			boost::shared_ptr<rgbd::CameraParams> const& rgbd_camera_params_ptr,
			float stereo_baseline);

	// accourding to rgbd_camera_params_ptr and stereo_baseline
	ICPCloudPair::srcPtT projectSourcePoint(const ICPCloudPair::srcPtT & p) const;
	ICPCloudPair::tgtPtT projectTargetPoint(const ICPCloudPair::tgtPtT & p) const;


protected:

	/*
	 * based on params, in case the user forgets to call set*Weights()
	 */
	void setDefaultWeights();

	/*
	 * Enables color matching error terms. Weight is relative to the
	 * spatial distance terms.
	 *
	 * Requires that source cloud has r, g, and b and that the target cloud
	 * has image_x and image_y channels
	 */
	template <typename PointT1, typename PointT2>
	void enableColorMatching(const pcl::PointCloud<PointT1>& sourceCloud, const pcl::PointCloud<PointT2>& targetCloud, const colorMatchingParams& cmparams,
										const typename boost::enable_if<boost::mpl::and_<rgbd::pointHasImgXY<PointT1>, rgbd::pointHasImgXY<PointT2> > >::type* ignored = NULL); //disable this template for point types without .img{X,Y}
	template <typename PointT1, typename PointT2>
	void enableColorMatching(const pcl::PointCloud<PointT1>& sourceCloud, const pcl::PointCloud<PointT2>& targetCloud, const colorMatchingParams& cmparams,
										const typename boost::enable_if<boost::mpl::not_<boost::mpl::and_<rgbd::pointHasImgXY<PointT1>, rgbd::pointHasImgXY<PointT2> > > >::type* ignored = NULL); //disable this template for point types with .img{X,Y}

	/*
	 * return (whether source-cloud normals are needed, whether target-cloud normals are needed)
	 *
	 * pre: m_params has been set
	 */
	std::pair<bool, bool> areNormalsNeeded() const;
	template <typename PointT1>
	void extractSrcNormalsIfNeeded(const pcl::PointCloud<PointT1>& sourceCloud);
	template <typename PointT2>
	void extractTgtNormalsIfNeeded(const pcl::PointCloud<PointT2>& targetCloud);

	template <typename PointT>
	void initSingleTreeCorrs(const pcl::PointCloud<PointT>& targetCloud);

	template <typename PointT1, typename PointT2>
	void initColorBinning(const pcl::PointCloud<PointT1>& sourceCloud, const pcl::PointCloud<PointT2>& targetCloud);

	template <typename PointT>
	void initColor6DSearchCorrs(const pcl::PointCloud<PointT>& targetCloud);

	template <typename PointT>
	void initColor5DLABSearchCorrs(const pcl::PointCloud<PointT>& targetCloud);

	template <typename PointT>
	void initColor5DHSVSearchCorrs(const pcl::PointCloud<PointT>& targetCloud);

	/*
	 * These do not filter, but simply return the nearest point and corresponding distance squared
	 */
	void getSingleKDTreeCorrespondenceIndicesThreadMain(rgbd::eigen::Affine3f const& transform, std::vector<int> & correspondence_indices, std::vector<float> & correspondence_distances_squared, const unsigned int firstIndex, const unsigned int lastIndex, unsigned int& invalid_count) const;
	int getSingleKDTreeCorrespondenceIndices(rgbd::eigen::Affine3f const& transform, std::vector<int> & correspondence_indices, std::vector<float> & correspondence_distances_squared) const;

	void getColorBinningCorrespondenceIndicesThreadMain(rgbd::eigen::Affine3f const& transform, std::vector<int> & correspondence_indices, std::vector<float> & correspondence_distances_squared, const unsigned int firstIndex, const unsigned int lastIndex, unsigned int& invalid_count) const;
	int getColorBinningCorrespondenceIndices(rgbd::eigen::Affine3f const& transform, std::vector<int> & correspondence_indices, std::vector<float> & correspondence_distances_squared) const;

	void getColor5DSearchCorrespondenceIndicesThreadMain(rgbd::eigen::Affine3f const& transform, std::vector<int> & correspondence_indices, std::vector<float> & correspondence_distances_squared, const unsigned int firstIndex, const unsigned int lastIndex) const;
	int getColor5DSearchCorrespondenceIndices(rgbd::eigen::Affine3f const& transform, std::vector<int> & correspondence_indices, std::vector<float> & correspondence_distances_squared) const;

	void getColor6DSearchCorrespondenceIndicesThreadMain(rgbd::eigen::Affine3f const& transform,std::vector<int> & correspondence_indices,std::vector<float> & correspondence_distances_squared,const unsigned int firstIndex, const unsigned int lastIndex) const;
	int getColor6DSearchCorrespondenceIndices(rgbd::eigen::Affine3f const& transform, std::vector<int> & correspondence_indices, std::vector<float> & correspondence_distances_squared) const;

	void getColorCompatibilityCorrespondenceIndicesThreadMain(rgbd::eigen::Affine3f const& transform,std::vector<int> & correspondence_indices,std::vector<float> & correspondence_distances_squared,const unsigned int firstIndex, const unsigned int lastIndex, unsigned int& invalid_count) const;
	int getColorCompatibilityCorrespondenceIndices(rgbd::eigen::Affine3f const& transform, std::vector<int> & correspondence_indices, std::vector<float> & correspondence_distances_squared) const;

	void getReprojectionCorrespondenceIndicesThreadMain(rgbd::eigen::Affine3f const& transform, std::vector<int> & correspondence_indices, std::vector<float> & correspondence_distances_squared, const unsigned int firstIndex, const unsigned int lastIndex, unsigned int& invalid_count) const;
	int getReprojectionCorrespondenceIndices(rgbd::eigen::Affine3f const& transform, std::vector<int> & correspondence_indices, std::vector<float> & correspondence_distances_squared) const;

	/*
	 * Use max_distance, front_can_match_back, and soon sorting to discard correspondences
	 *
	 * Returns the number of valid correspondences
	 */
	int filterCorrespondenceIndices(rgbd::eigen::Affine3f const& transform, std::vector<int> & correspondence_indices, const std::vector<float> & correspondence_distances_squared) const;

	/*
	 * Get the number of valid correspondences for average point error
	 * Currently counts the number of entries >= 0, so if we change correspondence validity, this function should be changed to match (eg, keeping a percentage of points)
	 */
	int getValidCorrespondenceIndexCount(const std::vector<int> & correspondence_indices) const;

	/*
	 * Used in color matching
	 */
	float getTargetIntensity(rgbd::eigen::Vector2f const& projection,rgbd::eigen::Vector2f const& corrPixel) const;

	ICPCloudPairParams m_params;

	ICPThreadParams	m_thread_params;

	/********************
	 * for single k-d tree
	 */

	boost::shared_ptr<kdtree2> m_target_kdtree_ptr;

	/********************
	 * for color binning
	 */

	/*
	 * create 2n - 1 bins in each dim, n - 1 of which halfway overlap the "base" bins
	 * (create extra overlapping bins to reduce quantization effects)
	 */
	static const unsigned int hueBinSize = 64, valueBinSize = 64; //must be powers of 2
	static const unsigned int numHueBins = 2 * (256 / hueBinSize) - 1, numValueBins = 2 * (256 / valueBinSize) - 1;

	/*
	 * indexed by (hue, value) bins
	 */
	boost::multi_array<boost::shared_ptr<kdtree2>, 2> targetKDTreesByColor;
	boost::multi_array<std::vector<unsigned int>, 2> targetKDTreeIndices; //for each subcloud, list of whole-cloud indices in it

	std::vector<boost::array<unsigned int, 2> > sourcePtKDTreeIndices; //source pt index -> index into targetKDTrees to use (doesn't change over iterations)

	/********************
	 * for 6-d search w/ color
	 */

	boost::shared_ptr<kdtree2> m_6dsearch_target_kdtree_ptr;

	/********************
	 * for 5-d search w/ LAB color or HSV color (with H as sin, cos)
	 */
	boost::shared_ptr<kdtree2> m_5dsearch_target_kdtree_ptr;

	/********************/
	/*
	 * we don't allow empty clouds, so if any of these vectors is empty, it's because it hasn't been computed
	 *
	 * use Vector4f to speed up transformations
	 */
	srcPtVecT m_source_eigen_points;
	tgtPtVecT m_target_eigen_points;
	normalVecT m_source_eigen_normals, m_target_eigen_normals;
	std::vector<rgbd::eigen::Vector3f> m_source_colors, m_target_colors;
	// for reprojection based corrs:
	tgtPtVecT m_target_eigen_points_projected;
	std::vector<std::vector<int> > m_target_eigen_projected_points_grid; // indices into m_target_eigen_points_projected

	/********************
	 * for removing boundary matches
	 */
	std::vector<bool> m_target_is_boundary;

	/********************
	 * for scalar weights
	 */

	// external weights on the points.
	// These errors will be squared by the LM optimization
	std::vector<float> m_scalar_weights;

	/********************
	 * for matrix weights
	 */

	// external weights on the points.
	std::vector<rgbd::eigen::Matrix4f> m_matrix_weights;


	/********************
	 * for color matching
	 */
	bool m_color_error_term_enabled;
	float m_color_matching_weight;
	float m_color_matching_max_intensity; //ignore possible specular reflections
	float m_color_dimension_scaling; //for 6D correspondence search
	float m_color_compatibility_max_dist; //for closest compatible point searchmake
	rgbd::CameraParams m_camera_params;
	std::vector<float> m_source_intensities;
	std::vector<std::vector<float> > m_target_intensity_grid;
	std::vector<std::vector<rgbd::eigen::Vector2f> > m_target_gradient_grid;
	std::vector<std::pair<int, int> > m_targetImgCoords; //image_{x,y}

	/*
	 * For reprojection error
	 */
	boost::shared_ptr<rgbd::CameraParams> m_rgbd_camera_params_ptr;
	float m_stereo_baseline;

public:
	EIGEN_MAKE_ALIGNED_OPERATOR_NEW // needed for 16B alignment
};

/************************************************************************************************************************/

/*
 * The overall class that manages joint alignment of several pointclouds by various error functions
 */
class ICPCombined
{
  
public:

	/**
	 * Constructor:
	 *
	 * Set params after construction
	 */
	ICPCombined();

	~ICPCombined();

	void setParams(ICPCombinedParams const& params);

	/*
	 * This function may be misleading...some cloud pair setup is based on params
	 */
	void setCloudPairParams(unsigned int cloud_pair_index, ICPCloudPairParams const& params);

	/*
	 * Added this as a separate function to avoid breaking existing use of setCloudPairParams
	 */
	void setCloudThreadPrams(unsigned int cloud_pair_index, ICPThreadParams const& thread_params);

	/*
	 * Add a new pair of clouds to the combined optimization after calling computeNormalsIfNeeded() on it
	 *
	 * @param cloud_pair_weight The weight to apply to this pair when combining
	 */
	void addCloudPair(boost::shared_ptr<ICPCloudPair> p, float cloud_pair_weight = 1.0f);

	/*
	 * Set the weight of a cloud pair by index
	 */
	void setCloudPairWeight(unsigned int cloud_pair_index, float cloud_pair_weight);

	/*
	 * Get access to a particular cloud pair.
	 * This breaks the encapsulation somewhat...
	 */
	boost::shared_ptr<ICPCloudPair> getCloudPair(unsigned int index);

	unsigned int numClouds() const {return m_cloud_pair_list.size();}

	/**
	 * Set the initial transformation (defaults to identity)
	 */
	void setInitialTransform(rgbd::eigen::Affine3f const& t);

	/**
	 * Set the ground plane
	 */
	void setGroundPlaneCoefficients(
			const pcl::ModelCoefficients& curr_ground_plane_coefficients,
			const pcl::ModelCoefficients& prev_ground_plane_coefficients);

	/*
	 * Actually run the full procedure (don't call multiple times--currently things aren't all reinitialized--20100413)
	 *
	 * @param result Where the resulting transform is stored
	 * @return The error.  Error is negative if ICP was unable to even estimate a transform (ie don't trust "result")
	 */
	float runICP(rgbd::eigen::Affine3f& result, const bool verbose = false);
	float runICP2(const bool verbose = false);
	/*
	 * to be called after running ICP
	 */
	const std::deque<rgbd::eigen::Affine3f,rgbd::eigen::aligned_allocator<rgbd::eigen::Affine3f> >& getTransformHistory() const {return m_transform_history;}
	const std::vector<double>& getTotalErrorHistory() const {return m_totalErrorHistory;}
	const std::vector<std::vector<std::vector<int> > >& getCorrespondencesHistory() const {return m_correspondencesHistory;}
	const std::vector<std::vector<std::vector<float> > >& getErrorVecsHistory() const {return m_errorVecsHistory;}

	int getMaxICPIterations();
	void setMaxICPIterations(int new_value);

	/*
	 * To interface with SBA, this gets up to max_points correspondences according to transform
	 */
	void getCorrespondencesForSBA(
			const rgbd::eigen::Affine3f & transform,
			int cloud_pair,
			int max_points,
			std::vector<unsigned int> &source_indices,
			std::vector<unsigned int> &target_indices);

	/*
	 * Returns the overall error of all clouds under this transform
	 */
	float getError(rgbd::eigen::Affine3f const& transform);

	/*
	 * Computes the error of each cloud pair individually and outputs the breakdown before returning
	 * the error.  The result of this function should be (up to float precision issues) equal to getError
	 */
	float getErrorBreakdown(rgbd::eigen::Affine3f const& transform, bool verbose);

#if 0
	void getCorrespondencesForSBA(
			const rgbd::eigen::Affine3f & transform,
			int cloud_pair,
			int max_points,
			ICPCloudPair::srcPtVecT & source_points,
			ICPCloudPair::normalVecT & source_normals,
			ICPCloudPair::tgtPtVecT & target_points,
			ICPCloudPair::normalVecT & target_normals);
#endif

	rgbd::eigen::Affine3f result;
	float final_error;

	/*
	 * Set a prior on the transformation.
	 *
	 * Todo: This!
	 */
	//void setTransformPriors()

private:
	// members
	ICPCombinedParams m_params;
	rgbd::eigen::Affine3f m_initial_transform;
	std::vector<boost::shared_ptr<ICPCloudPair> > m_cloud_pair_list;
	std::vector<float> m_cloud_pair_weights;
	std::vector<std::vector<int> > m_correspondence_lists;

	/*
	 * per-iteration details
	 */
	std::deque<rgbd::eigen::Affine3f,rgbd::eigen::aligned_allocator<rgbd::eigen::Affine3f> > m_transform_history; //in temporal order from head to tail (head is oldest)
	std::vector<double> m_totalErrorHistory;
	std::vector<std::vector<std::vector<int> > > m_correspondencesHistory;//indexed by (timestep, cloud pair, src point)
	std::vector<std::vector<std::vector<float> > > m_errorVecsHistory; //indexed by (timestep, cloud pair, src point)

	/*
	 * Count the number of times the LM error function is called
	 */
	int error_function_call_count;


	/**
	 * ground plane
	 */
	bool m_use_ground_plane_coefficients;
	pcl::ModelCoefficients m_target_ground_plane_coefficients;
	pcl::ModelCoefficients m_source_ground_plane_coefficients;


	// private functions

	/*
	 * Returns true if the error or transform has changed significantly
	 *
	 * Also returns true if none of the underlying conditions on error or transform are set
	 */
	bool shouldContinue(float previous_error,
			float new_error,
			rgbd::eigen::Affine3f const& previous_transform,
			rgbd::eigen::Affine3f const& new_transform,
			bool verbose);

	/*
	 * Get the source part of the error function (assuming m_correspondence_indices is correct)
	 * This will be called by the LM optimization.
	 *
	 * It calls the function of the same name on all cloud pairs, and adds the prior components
	 */
	void getSourceErrorVector(rgbd::eigen::Affine3f const& transform,
			std::vector<float> & result);

	/*
	 * Get the target part of the error function (assuming m_correspondence_indices is correct)
	 * This will be called by the LM optimization
	 *
	 * It calls the function of the same name on all cloud pairs, and adds the prior components
	 */
	void getTargetErrorVector(std::vector<float> & result);

	/*
	 * push onto m_errorVecsHistory the error vecs for the given xform
	 */
	void pushErrorVecsHistory(const rgbd::eigen::Affine3f& xform);


	/*
	 * top-level single-iteration function
	 */
	rgbd::eigen::Affine3f optimize(rgbd::eigen::Affine3f const& transform);

	/*
	 * choose an optimizer
	 */

	/*
	 * use Horn's method for point-to-point error
	 */
	rgbd::eigen::Affine3f optimizeClosedForm();

	/*
	 * use levmar, a C++ Levenberg-Marquardt
	 */
	rgbd::eigen::Affine3f optimizeLevmar(rgbd::eigen::Affine3f const& transform);
	static void optimizeLevmarErrorFunction(float *p, float *x, int m, int n, void *data);

	/*
	 * use c/c++ minpack, a thread-safe C minpack
	 * (see http://devernay.free.fr/hacks/cminpack.html)
	 */
	// Evan says this doesn't work...
	// Mike says it should work now because he copied in settings that work in SurfelAICP
	rgbd::eigen::Affine3f optimizeCMinpackLM(rgbd::eigen::Affine3f const& transform);
	static int optimizeCMinpackLMErrorFunction(void* data, int funcOutputDim, int funcInputDim, const double* x, double* funcVals, int flag);

	/*
	 * Use Eigen's "unsupported" LM implementation
	 */
	rgbd::eigen::Affine3f optimizeEigenLM(rgbd::eigen::Affine3f const& transform);


public:
	EIGEN_MAKE_ALIGNED_OPERATOR_NEW // needed for 16B alignment
};

template <typename PointT1, typename PointT2>
void debugICPPublish(ICPCombined & icp_combined,
		unsigned int which_cloud_pair,
		pcl::PointCloud<PointT1> & source_cloud,
		pcl::PointCloud<PointT2> & target_cloud,
		const rgbd::eigen::Affine3f & transform_to_world,
		float animation_predelay,
		float animation_delay,
		float correspondence_line_width,
		ros::Publisher & source_cloud_publisher,
		ros::Publisher & target_cloud_publisher,
		ros::Publisher & marker_publisher,
		const std::string & frame_id);

} //namespace

#include "icp_combined.ipp"

#endif //header
