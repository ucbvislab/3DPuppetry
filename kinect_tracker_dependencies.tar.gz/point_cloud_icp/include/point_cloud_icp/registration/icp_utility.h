/*
 * icp_utility.h
 *
 *  Created on: Jul 7, 2009
 *      Author: peter
 */

#ifndef ICP_UTILITY_H_
#define ICP_UTILITY_H_

#include <vector>
#include <deque>
#include <sensor_msgs/Image.h>
#include <pcl/point_cloud.h>
#include <pcl/kdtree/kdtree_flann.h>
#include "rgbd_util/eigen/Core"
#include "rgbd_util/eigen/Geometry"

namespace registration
{
	template <typename Real>
	void transform_points(rgbd::eigen::Transform<Real,3,rgbd::eigen::Affine> const& t,
			std::vector<rgbd::eigen::Matrix<Real,3,1> > const& points,
			std::vector<bool> const& transform_point,
			std::vector<rgbd::eigen::Matrix<Real,3,1> > & transformed_points);

	template <typename Real>
	void transform_points(rgbd::eigen::Transform<Real,3,rgbd::eigen::Affine> const& t,
			std::vector<rgbd::eigen::Matrix<Real,4,1>,
				rgbd::eigen::aligned_allocator<rgbd::eigen::Matrix<Real,4,1> > > const& points,
			std::vector<unsigned int> const& to_transform,
			rgbd::eigen::Matrix<Real,4,1> *transformed_points);

	/*
	 * from Berthold Horn, "Closed-form Solution of Absolute Orientation Using Unit Quaternions", Journal of the Optical Society of America A, April 1987
	 */
	void optimalClosedFormRotation(const std::vector<rgbd::eigen::Vector3f>& srcPts, const std::vector<rgbd::eigen::Vector3f>& tgtPts, std::vector<float> const& correspondence_weights,
		rgbd::eigen::Quaternionf &rotation);
	void runClosedFormAlignment(std::deque<std::pair<rgbd::eigen::Vector3f,rgbd::eigen::Vector3f> > const& correspondences, std::vector<float> const& correspondence_weights,
		rgbd::eigen::Quaternionf &rotation, rgbd::eigen::Vector3f &translation);

	/**
	 * Estimates the direction of an edge (1d line in 3d space) by the
	 * first principal component of the covariance matrix of nearby points
	 * also on the edge
	 *
	 * @param edgeCloud
	 * @param edgeTree
	 * @param edgePtIndex
	 * @param k number of neighbors
	 * @return direction vector parallel to the edge
	 */
	template <typename PointT>
	rgbd::eigen::Vector3f getEdgeDirection(const pcl::PointCloud<PointT>& edgeCloud, pcl::KdTreeFLANN<PointT> &edgeTree, unsigned int edgePtIndex, int k);

	/**
	 * Returns which 3D correspondences are consistent with a given transform
	 * for a certain distance threshold.
	 *
	 * @param sourcePoints
	 * @param targetPoints
	 * @param correspondences index source/targetPoints, or give 3-d points directly
	 * @param inlierCorrs
	 * @param inlierIndices indices into correspondences
	 */
	void getInlierCorrespondencesOld(std::vector<rgbd::eigen::Vector3f> const& sourcePoints, std::vector<rgbd::eigen::Vector3f> const& targetPoints,
		std::vector<std::pair<int, int> > const& correspondences, float inlierDist, rgbd::eigen::Affine3f const& transform, std::vector<std::pair<int, int> > & inlierCorrs);
	/*
	 * allow Eigen to use SSE when transforming pts
	 */
	void getInlierCorrespondencesUniform(std::vector<rgbd::eigen::Vector4f, rgbd::eigen::aligned_allocator<rgbd::eigen::Vector4f> > const& sourcePoints, std::vector<rgbd::eigen::Vector4f, rgbd::eigen::aligned_allocator<rgbd::eigen::Vector4f> > const& targetPoints,
		std::vector<std::pair<int, int> > const& correspondences, float inlierDist, rgbd::eigen::Affine3f const& transform, std::vector<std::pair<int, int> > & inlierCorrs);

	/*
	 * use distance-dependent inlier threshold
	 */
	void getInlierCorrespondencesUniformWithDepth(std::vector<rgbd::eigen::Vector4f, rgbd::eigen::aligned_allocator<rgbd::eigen::Vector4f> > const& sourcePoints, std::vector<rgbd::eigen::Vector4f, rgbd::eigen::aligned_allocator<rgbd::eigen::Vector4f> > const& targetPoints,
		std::vector<std::pair<int, int> > const& correspondences, float inlierDistAt1m, rgbd::eigen::Affine3f const& transform, std::vector<std::pair<int, int> > & inlierCorrs);

	enum RansacInlierFunction {RANSAC_INLIER_UNIFORM, RANSAC_INLIER_UNIFORM_WITH_DEPTH};

	RansacInlierFunction getRansacInlierFunctionFromString(const std::string& s);

	/**
	 * Performs RANSAC on two sets of points
	 *
	 * pre: sampleSize >= 3
	 *
	 * @param minSampleDist min distance, in meters, we want between samples taken for model-building
	 * @param resultInliers including sampled points
	 *
	 * @return whether RANSAC succeeded
	 */
	bool runRANSAC(
			std::vector<rgbd::eigen::Vector3f> const& sourcePoints,
	        std::vector<rgbd::eigen::Vector3f> const& targetPoints,
	        std::vector<std::pair<int, int> > const& correspondences,
	        float inlierDist,
	        RansacInlierFunction ransac_inlier_function,
	        rgbd::eigen::Affine3f &resultTransform,
	        std::vector<std::pair<int, int> > & resultInliers,
	        unsigned int numSamples, unsigned int sampleSize=3,
	        float minSampleDist=0,
	        bool weightByInverseSquareDistance = false,
	        bool verbose = true,
	        unsigned int maxSampleAttempts = 100);

	/*
	 * Uses the size of sampledIndices (resize it before calling this function)
	 */
	bool sampleSpatiallyDispersedCorrespondences(
			float minSquaredDistance,
			unsigned int maxSampleAttempts,
			bool verbose,
			std::vector<rgbd::eigen::Vector3f> const& sourcePoints,
	        std::vector<rgbd::eigen::Vector3f> const& targetPoints,
	        std::vector<std::pair<int, int> > const& correspondences,
	        std::vector<unsigned int> & sampleIndices);


	/**
	 * Computes the partial derivative for the rotational part of the
	 * transform for a specific point.
	 *
	 * i.e. computes partial(R(x_i)_j)/partial(q_k)
	 * where R is specified via currentTransform
	 * x_i is specified by toRegisterPoint
	 * j is the physicalPointComponent
	 * k is the quaternionComponent
	 *
	 * @param currentTransform
	 * @param toRegisterPoint
	 * @param physicalPointComponent
	 * @param quaternionComponent
	 * @return
	 */
	float getRotationPartialDerivative(
			rgbd::eigen::Matrix<float,7,1> const& currentTransform,
			rgbd::eigen::Vector3f const& toRegisterPoint,
			unsigned int physicalPointComponent,
			unsigned int quaternionComponent);

    /*
     * downsample individual points in ICP by depth (high depth values are unreliable) according to a model of primesensor uncertainty
     */
    template <typename PointT>
    void getPtWeightsByDistFromCam(const pcl::PointCloud<PointT>& cloud, std::vector<float>& result_vector);

    /*
     * target_is_boundary set to true for boundary points in organized cloud.  Doesn't actually modify organized cloud, but stupid PCL makes me discard const
     */
    template <typename PointT>
    int getBoundaryPoints(pcl::PointCloud<PointT> &organized_cloud, float max_depth_difference, std::vector<bool> & target_is_boundary);
    /*
     * Another boundary point function, this time for disorganized clouds
     *
     * If max_depth_difference < 0, ignored
     */
    template <typename PointT>
    void getBoundaryPoints(pcl::PointCloud<PointT> &cloud, float max_depth_difference, unsigned int width, unsigned int height, std::vector<bool> & target_is_boundary);

    /*
     * Brought over from icp_combined_node for use within loop closure
     */
    template <typename PointT>
    typename pcl::PointCloud<PointT>::Ptr prepare_general_icp_cloud(
    		typename pcl::PointCloud<PointT>::ConstPtr input_cloud_ptr,
    		float random_downsample_rate,
    		int min_random_downsample_points,
    		float max_distance,
    		bool sanity_check = false);
}

#include "icp_utility.ipp"

#endif /* ICP_UTILITY_H_ */
