/*
 * JointAngleICP.h
 *
 *  Created on: Jul 29, 2009
 *      Author: mkrainin
 */

#ifndef JOINTANGLEICP_H_
#define JOINTANGLEICP_H_


#include <vector>
#include <point_cloud_mapping/kdtree/kdtree_ann.h>
#include <point_cloud_icp/lbfgs/lbfgs.h>
#include "geometry_msgs/Point32.h"
#include "sensor_msgs/PointCloud.h"
#include <point_cloud_icp/openrave_interface.h>

#include <opencv/cv.h>
#include <opencv/highgui.h>


namespace registration
{

//in what order the joints should be considered
static const int s_jointHierarchyOrder[] = {0,1,2,3,4,5,6,10,7,8,9};
static const int s_jointHierarchyBreakpoints[] = {2,3,6,7,10}; //shoulder, elbow, wrist, spread, fingers

struct JointAngleICPParams
{
public:

	//maximum correspondence distance
	float max_distance;

	//termination criteria
	int max_rounds;
	float min_angle_diff;
	float min_error_diff_fraction;

	//non-linear optimizer parameters
	bool numeric_gradient;
	int max_optimizer_iterations;
	float interpolation_rate;

	//joint hierarchy options
	bool use_joint_hierarchy;
	int joint_hierarchy_steps;

	//weights on matching of points
	float upper_arm_weight;
	float lower_arm_weight;
	float hand_weight;
	float fixed_corr_weight;

	//ray tracing capture
	int ray_tracing_pixel_increment;

	//finger checking
	float min_finger_point_ratio;
	float max_finger_point_dist;

	//number of closest points to use when calculating normsl
	int normals_k;

	//weight for normals in extended kd-tree
	float normals_weight;

	JointAngleICPParams()
	{
		max_distance = -1.0;

		max_rounds = 3;
		min_error_diff_fraction = .0001;
		min_angle_diff = .01*M_PI/180;

		numeric_gradient = false;
		max_optimizer_iterations = 0;
		interpolation_rate = .4;

		ray_tracing_pixel_increment = 2;

		use_joint_hierarchy = true;
		joint_hierarchy_steps = 5;

		upper_arm_weight = 1.0;
		lower_arm_weight = 1.0;
		hand_weight = 1.0;
		fixed_corr_weight = 1.0;

		min_finger_point_ratio = .8;
		max_finger_point_dist = .005;

		normals_k = 40;

		normals_weight = 0.01;
	}
};


class JointAngleICP
{

public:

	/**
	 * Constructor. Requires on OpenRAVEInterface, and a target point cloud
	 *
	 * @param interface
	 * @param targetCloud
	 * @param globalCoords whether the targetCloud is in the global (i.e. robot
	 * model) coordinates or in the camera coordinates
	 * @return
	 */
	JointAngleICP(OpenRAVEInterface *interface,
			const sensor_msgs::PointCloud &targetCloud,
			bool globalCoords);

	/**
	 * Destructor
	 *
	 * @return
	 */
	~JointAngleICP();

	/**
	 * Resets the local variables so that ICP can be run again
	 */
	void reset();

	void setParams(JointAngleICPParams const& params)
	{
		m_params = params;
	}

	/**
	 * Does the actual alignment
	 *
	 * @return estimated joint angles
	 */
	std::vector<float> runICP();

	/**
	 * Returns a vector of bools indicating which joint angles were actually
	 * registered during ICP
	 *
	 * @return
	 */
	std::vector<bool> getAnglesRegistered();

	/**
	 * Find the corresponding target points for the points to register
	 * given the joint angles
	 *
	 * @param currentAngles
	 * @param correspondenceIndices
	 * @param useCorrespondence
	 */
	void getCorrespondenceIndices(
			std::vector<float> const& state,
			std::vector<unsigned int> &correspondenceIndices,
			std::vector<bool> &useCorrespondence,
			std::vector<float> & correspondenceWeights);

	/**
	 * Returns the points (and associated information) of exactly the points
	 * that ICP is trying to register. These include any grasped object points,
	 * and they exclude any points removed in downsampling, if any
	 *
	 * @param toRegister
	 * @param links
	 * @param normals
	 * @param acquisitionAngles
	 */
	void getPointsToRegister(std::vector<rgbd::eigen::Vector3f> &toRegister,
			std::vector<OpenRAVE::KinBody::LinkPtr > &links,
			std::vector<rgbd::eigen::Vector3f> &normals,
			std::vector<float> &acquisitionAngles);

	std::vector<rgbd::eigen::Vector3f> getTargetNormals()
	{
		if(!m_targetNormalsSet)
			this->generateNormals();
		return m_targetNormals;
	}

	std::vector<rgbd::eigen::Vector3f> getTargetPoints()
	{
		return m_targetPoints;
	}

	void getFixedPointRange(unsigned int &start, unsigned int &end){
		if(m_fixedCorrsSet){
			start = m_fixedPointsStart;
			end = m_fixedPointsEnd;
		}
		else{
			start = 0;
			end = 0;
		}
	}


	void setTargetNormals(std::vector<rgbd::eigen::Vector3f> const& targetNormals)
	{
		m_targetNormals = targetNormals;
		m_targetNormalsSet = true;
	}


	/**
	 * Set the points to register from a pre-computed ray-traced scan.
	 * Doesn't have to be taken from exactly the same angles and perspective
	 * as the target cloud.
	 *
	 * That said, the 3D points need to be in the
	 * same coordinate frame as the target cloud (i.e. transformed into the
	 * frame of the camera based on calibration info), and the angles should
	 * be close enough that the corresponding points would exist in the
	 * target cloud.
	 *
	 * @param toRegister
	 * @param links
	 * @param acquisitionAngles
	 */
	void setRayTracedScan(const std::vector<rgbd::eigen::Vector3f> &toRegister,
			const std::vector<OpenRAVE::KinBody::LinkPtr > &links,
			const std::vector<rgbd::eigen::Vector3f> &normals,
			const std::vector<float> &acquisitionAngles);


	/**
	 * Set correspondences that should not change due to updates in the
	 * registration (e.g. ones that come from reliable features).
	 *
	 * Model points are associated with a link in the model and are
	 * assumed to be specified within the LOCAL frame of that link
	 *
	 * Since there isn't (at least currently...) a LinkPtr that can be used
	 * to indicate "object", a vector of bools is also required to say whether
	 * each point is actually a part of the object. if so, the link entry is
	 * ignored.
	 *
	 * @param modelPoints
	 * @param modelNormals
	 * @param links
	 * @param linkIsObject
	 * @param targetPoints
	 * @param targetNormals
	 */
	void setFixedCorrespondences(
			std::vector<rgbd::eigen::Vector3f> const& modelPoints,
			std::vector<rgbd::eigen::Vector3f> const& modelNormals,
			std::vector<OpenRAVE::KinBody::LinkPtr> const& links,
			std::vector<bool> const& linkIsObject,
			std::vector<rgbd::eigen::Vector3f> const& targetPoints,
			std::vector<rgbd::eigen::Vector3f> const& targetNormals);

	/**
	 * Sets additional points to register. These are considered to be
	 * rigidly attached to the palm (i.e. the link called wam7)
	 *
	 * Note that this cloud is assumed to be in the local coordinate frame
	 * of the palm.
	 *
	 * This method takes both the points and the normals and assumes they're
	 * already downsampled. This is useful if you want to avoid recomputing
	 * normals and re-downsampling if that data is already available
	 *
	 * @param objectPts
	 * @param objectNormals
	 */
	void setGraspedObjectToRegister(
			sensor_msgs::PointCloud const& objectCloud,
			std::vector<rgbd::eigen::Vector3f> const& objectNormals);

	void setObjectAdjustmentDisabled();

	void setObjectAdjustmentEnabled(
			rgbd::eigen::Transform3f const& correctionTransform,
			rgbd::eigen::Matrix<float,7,7> correctionCovariance);

	/**
	 * Introduce an extra error factor which penalizes deviations from
	 * a prior expectation of the joint angles
	 *
	 * @param angles
	 * @param covariance
	 * @param priorStrength the coefficient in the exponential penalty term
	 */
	void setJointAnglePriors(
			rgbd::eigen::VectorXf const& angles,
			rgbd::eigen::MatrixXf const& covariance,
			float priorStrength = .5);

	/**
	 * Disable global ICP. You only need to call this if you previously
	 * enabled it but later want to disable it
	 */
	void setCalibAdjustmentDisabled();

	/**
	 * Allow the ICP algorithm to adjust the global pose of the model at
	 * the same time that it's adjusting the joints. The mean is assumed to
	 * be the identity transform, which can always be accomplished by transforming
	 * the target points appropriately.
	 *
	 * If global ICP is enabled, the result of ICP will be appended with a
	 * 7-dimensional vector of the global transformation from the source
	 * cloud to the target cloud. This consists of (quaternion,translation)
	 *
	 * @param globalICPCovariance 7x7 matrix with the following order:
	 * quaternion(w,x,y,z), translation(x,y,z)
	 */
	void setCalibAdjustmentEnabled(
			rgbd::eigen::Transform3f const& calibrationCorrection,
			rgbd::eigen::Matrix<float,7,7> const& adjustmentCovariance);

	/**
	 * Set the starting point for ICP
	 *
	 * @param angles
	 */
	void setInitialAngles(const std::vector<float> &angles);

	/**
	 * Indicate which links exist in the target
	 * (e.g. if the shoulder links aren't visible in the target cloud,
	 * set them to false so they can be ignored in the source cloud)
	 *
	 * @param linkExists
	 */
	void setInitialTargetLinkExistence(const std::vector<bool> &linkExists){
		m_linkExistsInTarget = linkExists;
	}

	std::vector<float> getInitialAngles();

	bool usesGlobalCoords(){
		return m_useGlobalCoords;
	}

private:
	//OpenRAVE interface
	OpenRAVEInterface *m_interface;

	//Parameters
	JointAngleICPParams m_params;

	//clouds
	sensor_msgs::PointCloud m_targetCloud;
	sensor_msgs::PointCloud m_objectCloud;

	//points
	std::vector<rgbd::eigen::Vector3f> m_toRegister;
	std::vector<rgbd::eigen::Vector3f> m_targetPoints;

	//object stuff
	bool m_objectPointsSet;
	unsigned int m_objectPointsStart;
	unsigned int m_objectPointsEnd; //TODO: use this
	std::vector<rgbd::eigen::Vector3f> m_objectPoints;
	std::vector<rgbd::eigen::Vector3f> m_objectNormals;

	bool m_allowObjectAdjustment;
	rgbd::eigen::Matrix<float,7,1> m_objectAdjustment;
	rgbd::eigen::Matrix<float,7,7> m_objectCovarianceInverse;

	//normals
	std::vector<rgbd::eigen::Vector3f> m_toRegisterNormals;
	std::vector<rgbd::eigen::Vector3f> m_targetNormals;
	bool m_targetNormalsSet;

	//things associated to the points
	std::vector<OpenRAVE::KinBody::LinkPtr > m_links;

	//kd-tree
	cloud_kdtree::KdTreeANN m_targetTree;
	cv::flann::Index *m_targetTreeExtended;

	//which points to register
	std::vector<unsigned int> m_toRegisterIndices;

	//joint angles
	unsigned int m_numAngles;
	unsigned int m_currentDOF;
	unsigned int m_lastDOFIncrease;
	unsigned int m_currentDOFStage;
	std::vector<float> m_acquisitionAngles;
	std::vector<float> m_initialAngles;
	std::vector<float> m_initialState;
	std::deque<std::vector<float> > m_stateHistory;

	//current round
	unsigned int m_round;

	//bool whether the points to register have been loaded
	bool m_toRegisterLoaded;

	bool m_useGlobalCoords;

	//whether the links have corresponding links in the target point cloud
	std::vector<bool> m_linkExistsInTarget;

	//priors over joint angles
	bool m_usePriors;
	rgbd::eigen::VectorXf m_anglePriorMean;
	rgbd::eigen::MatrixXf m_anglePriorCovarianceInverse;
	float m_priorStrength;

	//regular ICP (i.e. moving the base or camera) at the same time
	bool m_allowCalibAdjustment;
	rgbd::eigen::Matrix<float,7,1> m_calibAdjustment;
	rgbd::eigen::Matrix<float,7,7> m_calibCovarianceInverse;

	//fixed correspondences (for features and such)
	bool m_fixedCorrsSet;
	unsigned int m_fixedPointsStart;
	unsigned int m_fixedPointsEnd;
	std::vector<unsigned int> m_fixedCorrs;
	std::vector<bool> m_fixedPtIsObject;
	std::vector<rgbd::eigen::Vector3f> m_fixedPtLocalCoords;
	std::vector<rgbd::eigen::Vector3f> m_fixedPtLocalNormals;

	//TODO: features that are matched by combination of proximity and feature similarity

	void initializeVariables();


	/**
	 * Generate a ray-traced point cloud of the arm given the joint angles
	 *
	 * @param jointAngles
	 */
	void captureRayTracedScan(std::vector<float> &state);

	/**
	 * Checks whether finger points in the ray-traced scan have decent correspondences
	 * in the target cloud. If not, the finger is marked to be ignored
	 *
	 * @param currentAngles
	 */
	void checkForFingers(std::vector<float> const &state);

	/**
	 * Computes normals for the target cloud
	 *
	 */
	void generateNormals();

	/**
	 * Weights the correspondence by the link that the toRegister point is on
	 * and by the similarity of the normals of the points.
	 * If the normals are considerably off, it is more likely that the
	 * correspondence is wrong
	 *
	 * @param linkIndex
	 * @param toRegisterNormal
	 * @param targetNormal
	 * @return
	 */
	float getCorrespondenceWeight(
			unsigned int linkIndex,
			rgbd::eigen::Vector3f const& toRegisterNormal,
			rgbd::eigen::Vector3f const& targetNormal);

	/**
	 * Returns the weight of any points on a specific link.
	 * In early stages of ICP, points closer to the shoulder are weighted
	 * more heavily
	 *
	 * @param linkIndex
	 * @return
	 */
	float getCurrentLinkWeight(unsigned int linkIndex);

	/**
	 * Get the error for a choice of joint angles given the correspondences
	 *
	 * @param angles
	 * @param correspondenceIndices
	 * @param useCorrespondence
	 * @return
	 */
	float getError(std::vector<float> const &state,
			std::vector<unsigned int> const &correspondenceIndices,
			std::vector<bool> const &useCorrespondence,
			std::vector<float> const& correspondenceWeights);


	float getFixedCorrError(std::vector<float> const &state,
			std::vector<float> const& correspondenceWeights);

	/**
	 * Returns the error gradient given joint angles and point correspondences.
	 * Note that the returned gradient makes use of getCurrentAdjustableDOF,
	 * and will only compute the gradient over angles currently being optimized
	 * over. The order of angles is given in the hierarchy order
	 *
	 * @param angles
	 * @param correspondenceIndices
	 * @param useCorrespondence
	 * @return
	 */
	rgbd::eigen::VectorXf getErrorGradient(std::vector<float> const &state,
			std::vector<unsigned int> const &correspondenceIndices,
			std::vector<bool> const &useCorrespondence,
			std::vector<float> const& correspondenceWeights);

	rgbd::eigen::VectorXf getErrorGradientNumeric(std::vector<float> const &state,
			std::vector<unsigned int> const &correspondenceIndices,
			std::vector<bool> const &useCorrespondence,
			std::vector<float> const& correspondenceWeights);

	rgbd::eigen::VectorXf getFixedCorrGradient(
			std::vector<float> const &state,
			std::vector<float> const& correspondenceWeights);

	/**
	 * Get the number of degrees of freedom that the algorithm is
	 * currently optimizing over. We start at the shoulder and then
	 * add in more degrees of freedom as rounds progress
	 *
	 * @param currentAngles
	 * @param forceIncrease forces the DOF to increase even if the normal round requirement
	 * has not been met yet
	 * @return
	 */
	unsigned int getCurrentAdjustableDOF(std::vector<float> const& state,
			bool forceIncrease = false);

	void getJointKinematics(unsigned int joint,
			std::vector<float> const& state,
			rgbd::eigen::Vector3f & jointBase,
			rgbd::eigen::Vector3f & jointAxis);

	bool adjustCalibration(std::vector<float> const& state);
	bool adjustObject(std::vector<float> const& state);

//	rgbd::eigen::Transform3f getXAxisAligningTransform(std::vector<float> const& currentAngles, unsigned int jointIndex);
//	rgbd::eigen::Transform3f getYawPitchRollAxesTransform(std::vector<float> const& currentAngles, unsigned int startIndex);

	void getNewPointLocations(std::vector<float> const& state,
			std::vector<rgbd::eigen::Vector3f> &newPoints);

	void getNewPointLocations(std::vector<float> const& state,
			std::vector<bool> const& useCorrespondences,
			std::vector<rgbd::eigen::Vector3f> &newPoints);

	void getNewNormals(std::vector<float> const& state,
			std::vector<rgbd::eigen::Vector3f> &newNormals);

	void getNewNormals(std::vector<float> const& state,
			std::vector<bool> const& useCorrespondences,
			std::vector<rgbd::eigen::Vector3f> &newNormals);


	/**
	 * Run a non-linear optimizer to find the best joint angles given
	 * a set of correspondneces
	 *
	 * @param prevAngles
	 * @param correspondenceIndices
	 * @param useCorrespondence
	 * @return
	 */
	std::vector<float> runLBFGSAlignment(
			std::vector<float> &prevState,
			std::vector<unsigned int> &correspondenceIndices,
			std::vector<bool> &useCorrespondence,
			std::vector<float> const& correspondenceWeights);

	std::vector<float> runLMAlignment(
			std::vector<float> &prevState,
			std::vector<unsigned int> &correspondenceIndices,
			std::vector<bool> &useCorrespondence,
			std::vector<float> const& correspondenceWeights);

	/**
	 * Tells runICP when to terminate
	 *
	 * @param prevAngles
	 * @param newAngles
	 * @param correspondenceIndices
	 * @param useCorrespondence
	 * @return
	 */
	bool shouldContinue(
			std::vector<float> &prevState,
			std::vector<float> &newState,
			std::vector<unsigned int> &correspondenceIndices,
			std::vector<bool> &useCorrespondence,
			std::vector<float> const& correspondenceWeights);

	std::deque<unsigned int> getLBFGSStateIndices(std::vector<float> const& state);

	void getStateDiffAndInverseCovariance(
			std::vector<float> const& state,
			rgbd::eigen::VectorXf & stateDiff,
			rgbd::eigen::MatrixXf & inverseCovariance);

	/**
	 * Converts joint angles to LBFGS array format
	 *
	 * @param angles
	 * @return
	 */
	ap::real_1d_array convertStateToLBFGSArray(std::vector<float> const& state);

	/**
	 * Converts LBFGS array format to joint angles
	 *
	 * @param array
	 * @return
	 */
	std::vector<float> convertLBFGSArrayToState(ap::real_1d_array const& array);

};

}

#endif /* JOINTANGLEICP_H_ */
