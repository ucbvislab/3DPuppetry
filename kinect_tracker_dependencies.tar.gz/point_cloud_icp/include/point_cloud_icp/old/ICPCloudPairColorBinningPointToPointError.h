/*
 * ICPCloudPairColorBinningPointToPointError: point-to-point error metric disallowing matches between dissimilar colors
 *
 * Evan Herbst
 * 4 / 2 / 10
 */

#ifndef EX_ICP_CLOUDPAIR_COLORBINS_POINTTOPOINT_H
#define EX_ICP_CLOUDPAIR_COLORBINS_POINTTOPOINT_H

#include "point_cloud_icp/registration/ICPCloudPairColorBinning.h"
#include "point_cloud_icp/registration/ICPCloudPairPointToPointError.h"
#include "point_cloud_icp/registration/ICPCloudPairScalarWeights.h"

namespace registration
{

class ICPCloudPairColorBinningPointToPointError : virtual public ICPCloudPairColorBinning, virtual public ICPCloudPairPointToPointError, virtual public ICPCloudPairScalarWeights
{
	public:

		/*
		 * If no weights are given, default to 1.
		 *
		 * yell if either cloud is empty; we don't allow that
		 */
		ICPCloudPairColorBinningPointToPointError(ICPCloudPairParams const& params,
				sensor_msgs::PointCloud const& source_pointcloud,
				sensor_msgs::PointCloud const& target_pointcloud,
				std::vector<float> const& point_weights = std::vector<float>());
		virtual ~ICPCloudPairColorBinningPointToPointError() {}

		/*
		 * Get the source part of the error function.
		 * This will be called by the LM optimization
		 */
		virtual void getSourceErrorVector(rgbd::eigen::Transform3f const& transform, std::vector<int> const& correspondence_indices, std::vector<float> & result) const;

		/*
		 * Get the target part of the error function.
		 * This will be called by the LM optimization
		 */
		virtual void getTargetErrorVector(std::vector<int> const& correspondence_indices, std::vector<float> & result) const;
};

} //namespace

#endif //header
