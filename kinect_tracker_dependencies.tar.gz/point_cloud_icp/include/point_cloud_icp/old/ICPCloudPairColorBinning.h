/*
 * ICPCloudPairColorBinning: cloud pairs in which a point can only match another point of similar color
 *
 * Evan Herbst
 * 3 / 21 / 10
 */

#ifndef EX_ICP_CLOUDPAIR_COLORBINNING_H
#define EX_ICP_CLOUDPAIR_COLORBINNING_H

#include <vector>
#include <boost/array.hpp>
#include <boost/multi_array.hpp>
#include <boost/shared_ptr.hpp>
#include "rgbd_util/eigen/Geometry"
#include "kdtree2/kdtree2.hpp"
#include "point_cloud_icp/registration/icp_combined.h"

namespace registration
{

class ICPCloudPairColorBinning : public ICPCloudPair
{
	public:

		/*
		 * yell if either cloud is empty; we don't allow that
		 */
		ICPCloudPairColorBinning(ICPCloudPairParams const& params,
				sensor_msgs::PointCloud const& source_pointcloud,
				sensor_msgs::PointCloud const& target_pointcloud);
		virtual ~ICPCloudPairColorBinning() {}

		/*
		 * Get the correspondence indices for source points from target points under transformation;
		 * an index will be -1 if no valid correspondence is found (for example, if the distance between points is greater than max_distance)
		 *
		 * simply look up each source point in a k-d tree of the target cloud, so it is possible for one target point to be assigned to many source points
		 *
		 * return the number of valid correspondences
		 */
		virtual int getCorrespondenceIndices(rgbd::eigen::Transform3f const& transform, std::vector<int>& correspondence_indices) const;

		/*
		 * Get the source part of the error function.
		 * This will be called by the LM optimization
		 */
		virtual void getSourceErrorVector(rgbd::eigen::Transform3f const& transform, std::vector<int> const& correspondence_indices, std::vector<float> & result) const = 0;

		/*
		 * Get the target part of the error function.
		 * This will be called by the LM optimization
		 */
		virtual void getTargetErrorVector(std::vector<int> const& correspondence_indices, std::vector<float> & result) const = 0;

		void getPoints(std::vector<rgbd::eigen::Vector3f> &source_points, std::vector<rgbd::eigen::Vector3f> &target_points);

	protected:

		/*
		 * common ctor code
		 *
		 * pre: m_params has been set
		 */
		void initialize(const sensor_msgs::PointCloud& source_pointcloud, const sensor_msgs::PointCloud& target_pointcloud);

		void getCorrespondenceIndicesThreadMain(rgbd::eigen::Transform3f const& transform, std::vector<int> & correspondence_indices, const unsigned int firstIndex, const unsigned int lastIndex, unsigned int& invalid_count) const;

		/*
		 * indexed by (hue, value) bins
		 */
		boost::multi_array<boost::shared_ptr<kdtree2>, 2> targetKDTreesByColor;
		boost::multi_array<std::vector<unsigned int>, 2> targetKDTreeIndices; //for each subcloud, list of whole-cloud indices in it

		std::vector<boost::array<unsigned int, 2> > sourcePtKDTreeIndices; //source pt index -> index into targetKDTrees to use (doesn't change over iterations)

		/*
		 * we don't allow empty clouds, so if any of these vectors is empty, it's because it hasn't been computed
		 */
		std::vector<rgbd::eigen::Vector3f> m_source_eigen_points, m_target_eigen_points;
};

} //namespace

#endif //header
