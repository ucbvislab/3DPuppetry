/*
 * JointAngleKalmanFilter.h
 *
 *  Created on: Aug 5, 2009
 *      Author: mkrainin
 */

#ifndef JOINTANGLEKALMANFILTER_H_
#define JOINTANGLEKALMANFILTER_H_

#include <point_cloud_icp/openrave_interface.h>
#include <point_cloud_icp/registration/JointAngleICP.h>
#include <point_cloud_icp/registration/ICP.h>
#include <point_cloud_icp/registration/PointCloudSegmenter.h>
#include <point_cloud_icp/registration/feature_utility.h>
#include <point_cloud_icp/registration/FeatureExtractor.h>
#include "rgbd_util/eigen/Core"
#include "rgbd_util/eigen/Geometry"
#include <sensor_msgs/PointCloud.h>
#include <sensor_msgs/Image.h>

#include <opencv/cv.h>
#include <cv_bridge/CvBridge.h>

namespace registration{

struct KalmanParams
{
public:

	//initial uncertainties
	float init_joint_uncertainty;
	float init_camera_trans_uncertainty;
	float init_camera_quaternion_uncertainty;
	float init_object_trans_uncertainty;
	float init_object_quaternion_uncertainty;

	//icp uncertainties
	float icp_arm_uncertainty;
	float icp_wrist_uncertainty;
	float icp_finger_uncertainty;
	float icp_camera_trans_uncertainty;
	float icp_camera_quaternion_uncertainty;
	float icp_object_trans_uncertainty;
	float icp_object_quaternion_uncertainty;


	//motion uncertainty
	float motion_uncertainty_ratio;
	float min_motion_uncertainty;

	//icp parameters (e.g. rounds, max distance threshold, etc)
	registration::JointAngleICPParams icp_params;
	//prior strengths
	float icp_prior_strength;
	bool allow_calibration_adjustment;
	bool allow_object_adjustment;

	//icp outlier rejection
	float outlier_standard_deviations;

	//ray tracing capture
	int ray_tracing_pixel_increment;
	//when do we need a new scan rather than just modify an old one
	float ray_tracing_max_angle_diff;

	//what links to expect to see
	int first_link_in_camera;
	//how far away we care about
	float radius_downsample_radius;
	//how much downsampling to do
	float target_downsample_rate;

	//object in hand stuff
	bool detect_object_in_hand;
	//artificially make things run slower when objects are not being detected
	float no_detection_sleep;
	float object_segmentation_max_edge_dist;
	float object_segmentation_min_hand_dist;
	int object_segmentation_min_points;
	float object_segmentation_min_wrist_dist;
	float object_segmentation_proximity;
	int object_segmentation_grid_increment;
	float object_downsample_rate;
	float object_density_downsample_radius;

	KalmanParams()
	{
		init_joint_uncertainty = 5*M_PI/180;
		init_camera_trans_uncertainty = .05;
		init_camera_quaternion_uncertainty = .05;
		init_object_trans_uncertainty = .02;
		init_object_quaternion_uncertainty = .02;


		icp_arm_uncertainty = 5*M_PI/180;
		icp_wrist_uncertainty = 10*M_PI/180;
		icp_finger_uncertainty = 10*M_PI/180;
		icp_camera_trans_uncertainty = .05;
		icp_camera_quaternion_uncertainty = .05;
		icp_object_trans_uncertainty = .02;
		icp_object_quaternion_uncertainty = .02;

		motion_uncertainty_ratio = .1;
		min_motion_uncertainty = 1*M_PI/180;

		outlier_standard_deviations = 1.5;

		ray_tracing_pixel_increment = 2;
		ray_tracing_max_angle_diff = 10*M_PI/180;

		first_link_in_camera = 0;

		detect_object_in_hand = false;
		no_detection_sleep = 0;

		object_segmentation_max_edge_dist = .005;
		object_segmentation_min_hand_dist = .02;
		object_segmentation_min_points = 1000;
		object_segmentation_proximity = .1;
		object_segmentation_min_wrist_dist = .2;
		object_segmentation_grid_increment = 2;
		object_downsample_rate = 0.2;
		object_density_downsample_radius = .005;

		icp_prior_strength = .5;
		allow_calibration_adjustment = false;
		allow_object_adjustment = true;

		radius_downsample_radius = 1.0;
		target_downsample_rate = 0.2;
	}
};


class JointAngleKalmanFilter
{
public:
	/**
	 * Constructor
	 *
	 * @param interface
	 * @return
	 */
	JointAngleKalmanFilter(OpenRAVEInterface *interface);

	/**
	 * Destructor
	 *
	 * @return
	 */
	~JointAngleKalmanFilter();

	/**
	 * Provides an covariance matrix that can be used to initialize the filter
	 * based upon parameters passed into the kalman filter and/or reasonable
	 * defaults
	 */
	rgbd::eigen::MatrixXf getInitialCovariance();

	/**
	 * Returns the result of ICP from the last performUpdate.
	 * May be useful for debugging purposes
	 *
	 * @return
	 */
	std::vector<float> getLastICPResult();

	/**
	 * Gets the information that ICP had to work with
	 *
	 * @param toRegister
	 * @param links
	 * @param normals
	 * @param acquisitionAngles
	 */
	void getLastPointsToRegister(
			std::vector<rgbd::eigen::Vector3f> &toRegister,
			std::vector<OpenRAVE::KinBody::LinkPtr > &links,
			std::vector<rgbd::eigen::Vector3f> &normals,
			std::vector<float> &acquisitionAngles);

	void getLastICPCorrespondences(
			std::vector<unsigned int> &correspondenceIndices,
			std::vector<bool> &useCorrespondence,
			std::vector<float> &correspondenceWeights);

	/**
	 * Return the object model that has been built up so far
	 *
	 * @return
	 */
	sensor_msgs::PointCloud getObjectCloud();

	sensor_msgs::PointCloud getDownsampledObjectCloud();

	sensor_msgs::PointCloud getLastTargetCloud();

	std::vector<rgbd::eigen::Vector3f> getLastTargetPoints()
	{
		return m_lastICPTargetPts;
	}

	void getLastFixedPointRange(unsigned int &start, unsigned int &end)
	{
		start = m_lastFixedPointStart;
		end = m_lastFixedPointEnd;
	}


	sensor_msgs::PointCloud getLastObjectCloud();

	sensor_msgs::PointCloud getColorizedCloud();

	/**
	 * Get the scan being used for ICP
	 *
	 * @param points
	 * @param links
	 * @param acquisitionAngles
	 */
	void getCurrentRayTracedScan(
			std::vector<rgbd::eigen::Vector3f> &points,
			std::vector<OpenRAVE::KinBody::LinkPtr > &links,
			std::vector<float> &acquisitionAngles);

	/**
	 * Returns the current state of the Kalman filter
	 *
	 * @param meanState
	 * @param covariance
	 */
	void getState(std::vector<float> &meanState,
			rgbd::eigen::MatrixXf &covariance);

	/**
	 * Updates the Kalman filter
	 *
	 * @param reportedAngles
	 * @param observation
	 * @param globalCoords whether the point cloud is in global frame (i.e. robot model)
	 * coordinates or in the current camera frame coordinates
	 * @param imagePtr optional argument giving visual data to be used during
	 * the matching stage
	 */
	void performUpdate(const std::vector<float> &reportedAngles,
			const sensor_msgs::PointCloud &observation,bool globalCoords,
			sensor_msgs::ImageConstPtr const imagePtr = sensor_msgs::ImageConstPtr());

	/**
	 * Sets the initial state of the Kalman filter. Call this before
	 * calling performUpdate for the first time
	 *
	 * @param meanAngles
	 * @param covariance
	 */
	void setInitialState(std::vector<float> &meanAngles,
			rgbd::eigen::MatrixXf &covariance);

	void setParams(KalmanParams const& params){
		m_params = params;
	}

private:

	OpenRAVEInterface *m_inter;
	unsigned int m_numAngles;

	KalmanParams m_params;

	PointCloudSegmenter m_segmenter;
	unsigned int m_xChannel,m_yChannel;

	//state of the filter
	std::vector<float> m_currentMean;
	rgbd::eigen::MatrixXf m_currentCovariance;

	//control is the difference in angles, so we need to keep around the
	//previous ones
	std::vector<float> m_lastReportedAngles;

	//result of ICP from last call of performUpdate
	std::vector<float> m_lastICPAngles;
	std::vector<rgbd::eigen::Vector3f> m_lastICPToRegister;
	std::vector<OpenRAVE::KinBody::LinkPtr > m_lastICPLinks;
	std::vector<rgbd::eigen::Vector3f> m_lastICPNormals;
	std::vector<float> m_lastICPAcquisitionAngles;
	unsigned int m_lastFixedPointStart;
	unsigned int m_lastFixedPointEnd;

	std::vector<rgbd::eigen::Vector3f> m_lastICPTargetPts;
	std::vector<unsigned int> m_lastICPCorrespondences;
	std::vector<bool> m_lastICPUseCorrespondences;
	std::vector<float> m_lastICPWeights;

	//ray traced scan information
	std::vector<rgbd::eigen::Vector3f> m_points;
	std::vector<rgbd::eigen::Vector3f> m_normals;
	std::vector<OpenRAVE::KinBody::LinkPtr > m_links;
	std::vector<float> m_acquisitionAngles;

	sensor_msgs::PointCloud m_lastTargetCloud;

	//object tracking
	bool m_haveObjectCloud;
	sensor_msgs::PointCloud m_objectCloud;
	sensor_msgs::PointCloud m_downsampledObjectCloud;
	sensor_msgs::PointCloud m_lastObjectCloudUpdate;
	sensor_msgs::PointCloud m_colorizedCloud;
	std::vector<rgbd::eigen::Vector3f> m_downsampledObjectNormals;

	// features on the object
	FeatureExtractor m_extractor;
	std::vector<Keypoint> m_objectKeypoints;
	std::vector<std::vector<float> > m_objectDescriptors;
	std::vector<rgbd::eigen::Vector3f> m_objectFeaturePoints; //in local coordinates
	std::vector<rgbd::eigen::Vector3f> m_objectFeatureNormals; //in local coordinates

	/**
	 * Returns which state components are valid after performing
	 * outlier rejection on the components of the measured state.
	 *
	 * @param predictedState
	 * @param predictedCovariance
	 * @param measuredState
	 * @param measuredCovariance
	 * @param anglesRegistered which angles are actually relevant to the measurement
	 * @return vector of valid indices into measuredState
	 */
	std::vector<unsigned int> getDimensionsToUse(
			const rgbd::eigen::VectorXf &predictedState,
			const rgbd::eigen::MatrixXf &predictedCovariance,
			const rgbd::eigen::VectorXf &measuredState,
			const std::vector<bool> &anglesRegistered);

	/**
	 * Returns the uncertainty in state transition between one timestep and the next
	 *
	 * @param reportedChange estimated joint angle motion
	 * @return
	 */
	rgbd::eigen::MatrixXf getMotionUpdateCovariance(
			rgbd::eigen::VectorXf const& reportedChange);

	/**
	 * Returns the uncertainty we would expect in the result of ICP
	 *
	 * @return
	 */
	rgbd::eigen::MatrixXf getICPCovariance();

	/**
	 * Reduces the dimensions of a MatrixXf to just those specified in a list
	 *
	 * @param matrix
	 * @param dimensions
	 * @return
	 */
	rgbd::eigen::MatrixXf reduceMatrixDimensions(
			const rgbd::eigen::MatrixXf & matrix,
			const std::vector<unsigned int> & dimensions);

	/**
	 * Reduces the dimensions in a VectorXf to just those specified in a list
	 *
	 * @param vector
	 * @param dimensions
	 * @return
	 */
	rgbd::eigen::VectorXf reduceVectorDimensions(
			const rgbd::eigen::VectorXf & vector,
			const std::vector<unsigned int> & dimensions);


	/**
	 * Decides when the current ray traced scan is sufficient and can just
	 * be deformed to the estimated angles and when a whole new scan is
	 * needed because correspondences wouldn't be good. This then calls
	 * setRayTracedScan in JointAngleICP
	 *
	 * @param icp
	 */
	void setRayTracedScan(registration::JointAngleICP &icp);

	/**
	 * Converts rgbd::eigen::VectorXf to std::vector
	 *
	 * @param v
	 * @return
	 */
	std::vector<float> eigenToStd(rgbd::eigen::VectorXf &v){
		std::vector<float> toReturn(v.size());
		for(int i=0; i<v.size(); i++)
			toReturn[i] = v(i);
		return toReturn;
	}

	/**
	 * Converts std::vector to rgbd::eigen::VectorXf
	 *
	 * @param v
	 * @return
	 */
	rgbd::eigen::VectorXf stdToEigen(std::vector<float> &v){
		rgbd::eigen::VectorXf toReturn(v.size());
		for(unsigned int i=0; i<v.size(); i++)
			toReturn(i) = v[i];
		return toReturn;
	}

	/**
	 * Use the new cloud as well as the filter's state and the old
	 * object model to update the model
	 *
	 * @param newCloud
	 * @param estimatedJointAngles
	 *
	 * @return success
	 */
	bool updateObjectModel(sensor_msgs::PointCloud const& newCloud,
			std::vector<float> const& estimatedJointAngles);

	/**
	 * Put the new cloud into the object cloud and the downsampled object cloud
	 *
	 * @param cloud
	 * @return success
	 */
	bool mergeCloudWithModel(sensor_msgs::PointCloud const& cloud);

	void updateObjectFeatures(std::vector<float> const& icpResult,
			std::vector<Keypoint> const& validKeypoints,
			std::vector<std::vector<float> > const& validDescriptors,
			std::vector<rgbd::eigen::Vector3f> const& validPoints,
			std::vector<rgbd::eigen::Vector3f> const& validNormals,
			std::vector<std::pair<int, int> > const& surfPairs);

};

}


#endif /* JOINTANGLEKALMANFILTER_H_ */
