std::deque<unsigned int> getDensityDownsamplingIndices(
			sensor_msgs::PointCloud const& cloud,
			float radius, int maxWithinRadius);

void mergeCloudsWithDensity(sensor_msgs::PointCloud &toMergeInto,
			sensor_msgs::PointCloud const& toAdd, float densityRadius);

void add_indices(int total_indices, const std::vector<unsigned int>& indices_before, const std::vector<unsigned int>& indices_to_add, std::vector<unsigned int>& result);
void remove_indices(int total_indices, const std::vector<unsigned int>& indices_before, const std::vector<unsigned int>& indices_to_remove, std::vector<unsigned int>& result);
void invert_indices(int total_indices, const std::vector<unsigned int>& indices_before, std::vector<unsigned int>& result);

//I don't think this would compile, so apparently it's unused -- EVH 20100329
	template <class T>
	void downsampleFromIndices(
			std::vector<T> const& vector,
			std::vector<T> & downsampledVector,
			const std::deque<unsigned int>& acceptedIndices)
	{
		unsigned int finalNumPts = acceptedIndices.size();
		downsampledVector.resize(finalNumPts);
		unsigned int ptCount = 0;
		while(!acceptedIndices.empty()){
			unsigned int ptIndex = acceptedIndices.front();
			downsampledVector[ptCount] = vector[ptIndex];
			acceptedIndices.pop_front();
			ptCount++;
		}
	}

float getMedianSSE(
		std::deque<std::pair<rgbd::eigen::Vector3f,rgbd::eigen::Vector3f> > const& correspondences,
		rgbd::eigen::Transform3f const& transform);

void get_sqrt_weights_based_on_distance_from_camera(sensor_msgs::PointCloud const& cloud, std::vector<float>& result_vector);

bool write_sift_descriptors(std::vector<unsigned int> const& cloud_indices,
    		std::vector<std::pair<int, int> > const& image_points,
    		std::vector<rgbd::eigen::Vector3f> const& depth_points,
    		std::vector<std::vector<float> > const& descriptors,
    		std::string filename);
