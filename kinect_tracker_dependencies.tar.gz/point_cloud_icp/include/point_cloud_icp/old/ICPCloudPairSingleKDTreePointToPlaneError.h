/*
 * ICPCloudPairSingleKDTreePointToPlaneError: point-to-plane error metric using only 3-d position info
 *
 * Evan Herbst
 * 3 / 21 / 10
 */

#ifndef EX_ICP_CLOUDPAIR_SINGLE_KDTREE_POINTTOPLANE_H
#define EX_ICP_CLOUDPAIR_SINGLE_KDTREE_POINTTOPLANE_H

#include "point_cloud_icp/registration/ICPCloudPairSingleKDTree.h"
#include "point_cloud_icp/registration/ICPCloudPairPointToPlaneError.h"
#include "point_cloud_icp/registration/ICPCloudPairScalarWeights.h"

namespace registration
{

class ICPCloudPairSingleKDTreePointToPlaneError : virtual public ICPCloudPairSingleKDTree, virtual public ICPCloudPairPointToPlaneError, virtual public ICPCloudPairScalarWeights
{
public:
	/*
	 * If no weights are given, default to 1.
	 *
	 * yell if either cloud is empty; we don't allow that
	 */
	ICPCloudPairSingleKDTreePointToPlaneError(ICPCloudPairParams const& params,
			sensor_msgs::PointCloud const& source_pointcloud,
			sensor_msgs::PointCloud const& target_pointcloud,
			std::vector<float> const& point_weights = std::vector<float>());
	ICPCloudPairSingleKDTreePointToPlaneError(const ICPCloudPairParams& params,
			const sensor_msgs::PointCloud& sourceCloud,
			const sensor_msgs::PointCloud& targetCloud,
			boost::shared_ptr<kdtree2> targetKDTree,
			const std::vector<float>& pointWeights = std::vector<float>());
	virtual ~ICPCloudPairSingleKDTreePointToPlaneError() {}

	/*
	 * Get the source part of the error function.
	 * This will be called by the LM optimization
	 */
	virtual void getSourceErrorVector(rgbd::eigen::Transform3f const& transform, std::vector<int> const& correspondence_indices, std::vector<float> & result) const;

	/*
	 * Get the target part of the error function.
	 * This will be called by the LM optimization
	 */
	virtual void getTargetErrorVector(std::vector<int> const& correspondence_indices, std::vector<float> & result) const;

protected:

	/*
	 * return whether we need to calculate (source, target) normals
	 */
	virtual boost::tuple<bool, bool> getNeedSourceTargetNormals() const;
};

} //namespace

#endif //header
