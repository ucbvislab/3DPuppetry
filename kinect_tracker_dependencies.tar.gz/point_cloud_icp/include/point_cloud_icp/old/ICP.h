/*
 * ICP.h
 *
 *  Created on: Jun 26, 2009
 *      Author: mkrainin
 */

#ifndef ICP_H_
#define ICP_H_

#include <vector>
#include <deque>
#include "rgbd_util/eigen/Core"
#include "rgbd_util/eigen/Geometry"
#include <point_cloud_mapping/kdtree/kdtree_ann.h>
#include <point_cloud_icp/lbfgs/lbfgs.h>
//#include <point_cloud_icp/lm/minlm.h>
#include "geometry_msgs/Point32.h"
#include "sensor_msgs/PointCloud.h"

USING_PART_OF_NAMESPACE_EIGEN


namespace registration
{

enum ErrorFunction {MSE, MSE_NONLINEAR, GENERALIZED, POINT_TO_PLANE, CAUCHY, LORENTZIAN, NONE_SET};
enum DownsamplingType {NO_DOWNSAMPLING, RANDOM, UNIFORM, DENSITY, SALIENCY};
enum NonlinearOptimizer {LM, LBFGS};

struct ICPParams
{
public:
	ErrorFunction error_function;
	DownsamplingType downsampling;
	NonlinearOptimizer optimizer;

	//Winsorization
	float max_distance;

	//termination criteria
	int max_rounds;
	float min_dist_to_continue;
	float min_rot_to_continue;
	float min_error_frac_to_continue;

	//accelerated ICP
	bool use_accelerated;
	float max_accel_angle;
	float max_accel_ratio;

	//Cauchy kernel
	float cauchy_constant;

	float downsample_rate; //used in RANDOM downsampling
	float downsample_voxel_size; //used in UNIFORM downsampling
	float downsample_density_radius; //used in DENISTY downsampling
	unsigned int downsample_density_kmax; //used in DENSITY downsampling

	// SALIENCY downsampling
	float saliency_basepoint_ratio;
	float saliency_binning_degrees;
	float saliency_max_radius;
	float saliency_radius_delta;
	unsigned int saliency_max_regions;
	unsigned int saliency_min_points;

	// interleaved ICP
	bool interleave;

	// removing close and far points
	bool do_near_remove;
	float near_remove_radius;
	bool do_far_remove;
	float far_remove_radius;

	// weight error by normal agreement
	bool weight_error_with_normals;
	bool front_can_match_back;

	int max_lm_rounds;

	// new experimental
	bool do_multiple_error_functions;

	ICPParams()
	{
		error_function = MSE;
		downsampling = NO_DOWNSAMPLING;
		optimizer = LBFGS;
		max_distance = -1.0;


		max_rounds = -1;
		min_dist_to_continue = .0001;
		min_rot_to_continue = .0001;
		min_error_frac_to_continue = .001;

		use_accelerated = true;
		max_accel_angle = 15 * (2*M_PI/360);
		max_accel_ratio = 25;
		cauchy_constant = 1.0;
		downsample_rate = 0.1;
		downsample_voxel_size = 0.5;
		downsample_density_radius = 0.1;
		downsample_density_kmax = 40;
		saliency_basepoint_ratio = .05;
		saliency_binning_degrees = 3.0;
		saliency_max_radius = 1.0;
		saliency_radius_delta = 0.1;
		saliency_max_regions = 20;
		saliency_min_points = 50;
		interleave = false;
		do_near_remove = false;
		near_remove_radius = 0.0;
		do_far_remove = false;
		far_remove_radius = 0.0;
		weight_error_with_normals = false;
		front_can_match_back = false;

		max_lm_rounds = 50;

		do_multiple_error_functions = false;
	}

	void set_downsampling_from_string(std::string s) {
    	if (s == "NO_DOWNSAMPLING")
    		downsampling = NO_DOWNSAMPLING;
    	else if (s == "RANDOM")
    		downsampling = RANDOM;
    	else if (s == "UNIFORM")
    		downsampling = UNIFORM;
    	else if (s == "DENSITY")
    		downsampling = DENSITY;
    	else if (s == "SALIENCY")
    		downsampling = SALIENCY;
    	else
    	{
    		std::cerr << "Bad downsampling string:" << s << std::endl;
    		assert(false);
    	}
	}

	void set_error_function_from_string(std::string s) {
    	if (s == "MSE")
    		error_function = MSE;
    	else if (s == "MSE_NONLINEAR")
    		error_function = MSE_NONLINEAR;
    	else if (s == "GENERALIZED")
    		error_function = GENERALIZED;
    	else if (s == "CAUCHY")
    		error_function = CAUCHY;
    	else if (s == "LORENTZIAN")
    		error_function = LORENTZIAN;
    	else if (s == "POINT_TO_PLANE")
			error_function = POINT_TO_PLANE;
    	else
    	{
    		std::cerr << "Bad error function string:" << s << std::endl;
    		assert(false);
    	}
	}

	void set_optimizer_from_string(std::string s) {
    	if (s == "LM")
    		optimizer = LM;
    	else if (s == "LBFGS")
    		optimizer = LBFGS;
    	else
    	{
    		std::cerr << "Bad optimizer string:" << s << std::endl;
    		assert(false);
    	}
	}
};

class ICP
{
public:


	/**
	 * Constructor for ICP. Takes the points to register and the points to
	 * register to.
	 *
	 * @param toRegister the points to be moved into alignment
	 * @param target the points to align to
	 * @return
	 */
	ICP(const sensor_msgs::PointCloud &toRegister,
			const sensor_msgs::PointCloud &target);

	/**
	 * Destructor
	 *
	 * @return
	 */
	~ICP();


	/*
	 * For multiple error functions, start with two empty clouds, then call this...
	 */
	void
	addCloudsWithWeightsAndErrorFunction(
			const sensor_msgs::PointCloud &source,
			const sensor_msgs::PointCloud &target,
			const std::vector<float> &source_weights,
			ErrorFunction error_function_for_added_points);


	/**
	 * Use a "default" initial transform. This will be something like aligning
	 * the centroids and perhaps aligning the principal components
	 */
	void setInitialTransform();

	/**
	 * Set the transform to apply to the points to register as an initialization
	 *
	 * @param t	void ICP::setFixedPointPairsAndWeights(
			std::vector<std::pair<rgbd::eigen::Vector3f, rgbd::eigen::Vector3f> > fixed_point_pairs,
			std::vector<float> fixed_point_weights)
	 */
	void setInitialTransform(rgbd::eigen::Transform3f &t);


	/**
	 * Set normal vectors for each of the points in the two original point
	 * clouds. Normals are not needed for all operations. If they are not
	 * specified when they are needed, though, normals will automatically
	 * be generated using generateNormals. To save time and to potentially
	 * get better normals, it may be better to set them in this way.
	 *
	 * @param toRegisterNormals
	 * @param targetNormals
	 */
	void setNormals(const std::vector<rgbd::eigen::Vector3f> &toRegisterNormals,
			const std::vector<rgbd::eigen::Vector3f> &targetNormals);

	/**
	 * Get the normals that have already been computed by ICP.
	 * Returns false if the normals are not actually set, true otherwise.
	 * If true, the arguments are set to copies of the normals.
	 *
	 * @param toRegisterNormals
	 * @param targetNormals
	 * @return normals successfully obtained
	 */
	bool getNormals(std::vector<rgbd::eigen::Vector3f> &toRegisterNormals,
			std::vector<rgbd::eigen::Vector3f> &targetNormals);

	void setWeights(std::vector<float> const& toRegisterWeights);

	/**
	 * Run the ICP algorithm
	 *
	 * @param useMSE whether to minimize the standard MSE or to use a different
	 * error function. Using MSE allows the use of the closed form alignment.
	 * Otherwise, a non-linear optimizer will be used
	 * @return Transformation to apply to the points to register to align them
	 * with the target points. This is the total transform, not the transform
	 * to apply after the initial transform.
	 */
	rgbd::eigen::Transform3f runICP();

	bool ICPSucceeded(){
		return m_icpSuccess;
	}

	std::deque<rgbd::eigen::Transform3f,rgbd::eigen::aligned_allocator<rgbd::eigen::Transform3f> > getTransformHistory()
	{
		return m_transformHistory;
	}

	std::deque<float> getErrorHistory()
	{
		return m_errorHistory;
	}
	
	void setParams(const ICPParams& new_params)
	{
		m_params = new_params;
	}

	void setTransformPriors(
			rgbd::eigen::Matrix<float,7,1> const& transform,
			rgbd::eigen::Matrix<float,7,7> const& covariance,
			float priorStrength = .5);

	void setSimpleTransformPriors(
			rgbd::eigen::Matrix<float,7,1> const& transform,
			float priorStrength);

	/**
	 * Get a point cloud of the downsampled points
	 *
	 * @return
	 */
	sensor_msgs::PointCloud getDownsampledCloud();

	std::vector<unsigned int>& getSourceIndices();
	std::vector<unsigned int>& getTargetIndices();

	// should be private eventually
	void prepareForICP();
	void removePointsInsideRadius(geometry_msgs::Point32 center, float radius);
	void removePointsOutsideRadius(geometry_msgs::Point32 center, float radius);
	sensor_msgs::PointCloud getPlanePointCloud();

	void setFixedPointPairsAndWeights(
			std::vector<std::pair<rgbd::eigen::Vector3f, rgbd::eigen::Vector3f> > const& fixed_point_pairs,
			std::vector<float> const& fixed_point_weights);

	static void newErrorFunction(float *p, float *x, int m, int n, void *data);

private:

	// params
	ICPParams m_params;

	//clouds
	sensor_msgs::PointCloud m_toRegisterCloud;
	sensor_msgs::PointCloud m_targetCloud;

	//points
	std::vector<rgbd::eigen::Vector3f> m_toRegister;
	std::vector<float> m_toRegisterWeights;
	std::vector<rgbd::eigen::Vector3f> m_targetPoints;

	// for combined ICP
	std::vector<ErrorFunction> m_toRegisterErrorFunctions;

	//kd-tree
	//cloud_kdtree::KdTreeANN m_toRegisterTree;
	//cloud_kdtree::KdTreeANN m_targetTree;
	cloud_kdtree::KdTreeANN *m_toRegisterTreePtr;
	cloud_kdtree::KdTreeANN *m_targetTreePtr;

	// need multiple KD trees for multiple error functions (want edge - edge, general - general)
	// this is hacky
	cloud_kdtree::KdTreeANN *m_targetTreePointToPointPtr;
	cloud_kdtree::KdTreeANN *m_targetTreePointToPlanePtr;
	unsigned int m_targetTreePointToPointPtrOffset;
	unsigned int m_targetTreePointToPlanePtrOffset;


	//which points to register -- allows for downsampling
	std::vector<unsigned int> m_toRegisterIndices;

	//normals
	std::vector<rgbd::eigen::Vector3f> m_toRegisterNormals;
	std::vector<rgbd::eigen::Vector3f> m_targetNormals;
	bool m_normalsSet;

	//transforms
	rgbd::eigen::Transform3f m_initialTransform;
	std::deque<rgbd::eigen::Transform3f,rgbd::eigen::aligned_allocator<rgbd::eigen::Transform3f> > m_transformHistory;

        // Error history
        std::deque<float> m_errorHistory;
        
	// plane cloud
	sensor_msgs::PointCloud m_planeCloud;

	//current round
	int m_round;
	bool m_icpSuccess;

	//priors
	rgbd::eigen::Matrix<float,7,1> m_priorTransform;
	rgbd::eigen::Matrix<float,7,7> m_priorCovarianceInverse;
	bool m_usePriors;
	bool m_useSimplePriors; // just ssd * strength
	float m_priorStrength;


	// hacks to get levmar to work
	std::vector<bool> lm_use_correspondence;
	std::vector<unsigned int> lm_correspondence_indices;
	std::vector<float> lm_correspondence_weights;

	// these will have fixed corr's and always use point-to-point error
	std::vector<std::pair<rgbd::eigen::Vector3f, rgbd::eigen::Vector3f> > lm_fixed_point_pairs;
	std::vector<float> lm_fixed_point_weights;

	/**
	 * Generates normals for each point in the two point clouds by looking
	 * at the nearest neighbors.
	 */
	void generateNormals();

	/**
	 * Find the correspondences to m_toRegister based on a transformation
	 * currentRegistrationTransform to m_toRegister. Returns whether an index
	 * into m_targetPoints for each point in m_toRegister as well as whether
	 * that correspondence should be used (based on distance threshold, edge
	 * point considerations, etc)
	 *
	 * @param currentRegistrationTransform transform to apply to m_toRegister
	 * @param correspondenceIndices indices into m_targetPoints indicating
	 * the correspondences
	 * @param useCorrespondence whether to use each correspondence
	 * @param correspondenceWeights
	 * @return whether enough correspondences could be found
	 */
	bool getCorrespondenceIndices(
			rgbd::eigen::Transform3f const& currentRegistrationTransform,
			std::vector<unsigned int> &correspondenceIndices,
			std::vector<bool> &useCorrespondence,
			std::vector<float> &correspondenceWeights);

	/**
	 * Get the error for a transform given a the correspondences for the points
	 * to register and flags indicating which correspondences to use.
	 *
	 * Note: this is a wrapper around getMSE and any other error functions.
	 * Its argument "function" indicates which error function is actually used
	 *
	 * @param transform
	 * @param correspondenceIndices
	 * @param useCorrespondence
	 * @return error for transform given correspondences
	 */
	float getError(rgbd::eigen::Transform3f const& transform,
			std::vector<unsigned int> const& correspondenceIndices,
			std::vector<bool> const& useCorrespondence,
			std::vector<float> const& correspondenceWeights);

	/**
	 * The error functions are of the form sum_i f_i^2(transform).
	 * This returns f_i (transform) where i is the index into m_toRegisterIndices
	 * (i = component here)
	 *
	 * @param transform
	 * @param correspondenceIndices
	 * @param useCorrespondence
	 * @param component
	 * @return
	 */
	float getComponentError(rgbd::eigen::Transform3f const& transform,
			std::vector<unsigned int> const& correspondenceIndices,
			std::vector<bool> const& useCorrespondence,
			unsigned int component);

	float getCorrespondenceWeight(
			rgbd::eigen::Vector3f const& toRegisterNormal,
			rgbd::eigen::Vector3f const& targetNormal);

	rgbd::eigen::Matrix<float,7,1> getErrorGradient(rgbd::eigen::Transform3f const& transform,
			std::vector<unsigned int> const& correspondenceIndices,
			std::vector<bool> const& useCorrespondence,
			std::vector<float> const& correspondenceWeights);

	rgbd::eigen::Matrix<float,7,1> getErrorGradientAnalytic(rgbd::eigen::Transform3f const& transform,
			std::vector<unsigned int> const& correspondenceIndices,
			std::vector<bool> const& useCorrespondence,
			std::vector<float> const& correspondenceWeights);

	/**
	 * Get the covariance matrices used in Generalized ICP generated from normals.
	 * This is the C^A or C^B in equation 2 in the Generalized ICP paper
	 *
	 * @param normal
	 * @return covariance matrix with large components in plane and a small
	 * component in the normal direction
	 */
	rgbd::eigen::Matrix3f getGeneralizedICPCovarianceMatrix(rgbd::eigen::Vector3f & normal);

	/**
	 * Calls the appropriate downsampling method
	 */
	void performDownsampling();

	/**
	 * Do the random downsampling
	 */
	void performDownsamplingRandom();

	/**
	 * Do the Voxelized downsampling
	 */
	void performDownsamplingWithVoxels();

	/**
	 * Removes points if there are too many nearby neighbors (first does random downsampling)
	 */
	void performDownsamplingUsingDensity();

	/**
	 * Picks points in regions that seem interesting (first does density downsampling)
	 */
	void performDownsamplingUsingSaliency();

	/**
	 * Run the closed-form alignment based on the correspondences passed in.
	 * This is run once in each iteration of ICP.
	 *
	 * Algorithm is as described in:
	 *  Closed-form solution of absolute orientation using unit quaternions
	 *  by Berthold K. P. Horn
	 *
	 * @param correspondenceIndices indices into m_targetPoints (one for each
	 * point to register)
	 * @param useCorrespondence whether to use each correspondence
	 * @return transformation of m_toRegister to align those points with
	 * m_targetPoints
	 */
	rgbd::eigen::Transform3f runClosedFormAlignment(
			std::vector<unsigned int> &correspondenceIndices,
			std::vector<bool> &useCorrespondence,
			std::vector<float> const& correspondenceWeights);

	/**
	 * Run the a nonlinear optimizer (LBFGS) to minimize the error function based
	 * on the correspondences passed in. This is run once in each iteration of ICP.
	 * The algorithm used can be found here:
	 * http://www.alglib.net/optimization/lbfgs.php
	 *
	 * @param prevTransform unlike the closed-form alignment, LBFGS requires
	 * a start-state. for this, we use the previous transform we found
	 * @param correspondenceIndices indices into m_targetPoints (one for each
	 * point to register)
	 * @param useCorrespondence whether to use each correspondence
	 * @return transformation of m_toRegister to align those points with
	 * m_targetPoints
	 */
	rgbd::eigen::Transform3f runLBFGSAlignment(
			rgbd::eigen::Transform3f &prevTransform,
			std::vector<unsigned int> &correspondenceIndices,
			std::vector<bool> &useCorrespondence,
			std::vector<float> const& correspondenceWeights);

	/**
	 * Run the a nonlinear optimizer (Levenberg-Marquardt) to minimize the error function based
	 * on the correspondences passed in. This is run once in each iteration of ICP.
	 * The algorithm used can be found here:
	 * http://www.alglib.net/optimization/levenbergmarquardt.php
	 *
	 * @param prevTransform unlike the closed-form alignment, LM requires
	 * a start-state. for this, we use the previous transform we found
	 * @param correspondenceIndices indices into m_targetPoints (one for each
	 * point to register)
	 * @param useCorrespondence whether to use each correspondence
	 * @return transformation of m_toRegister to align those points with
	 * m_targetPoints
	 */
#if 0
	rgbd::eigen::Transform3f runLMAlignment(
			rgbd::eigen::Transform3f &prevTransform,
			std::vector<unsigned int> &correspondenceIndices,
			std::vector<bool> &useCorrespondence,
			std::vector<float> const &correspondenceWeights);
#endif


	/*
	 * Uses levmar library
	 */
	rgbd::eigen::Transform3f runNewLMAlignment(
			rgbd::eigen::Transform3f &prevTransform,
			std::vector<unsigned int> &correspondenceIndices,
			std::vector<bool> &useCorrespondence,
			std::vector<float> const &correspondenceWeights);


	/**
	 * Perform the registration with a non-linear optimizer, adjusting
	 * correspondences at every step of the optimization
	 *
	 * @return transform
	 */
	rgbd::eigen::Transform3f runICPInterleaved();

	/**
	 * Returns whether there is a large enough difference between successive
	 * transforms to warrant continuing with another round of ICP
	 *
	 *
	 * @param prevTransform
	 * @param newTransform
	 * @param correspondenceIndices
	 * @param useCorrespondence
	 * @return whether to continue
	 */
	bool shouldContinue(
			rgbd::eigen::Transform3f &prevTransform,
			rgbd::eigen::Transform3f & newTransform,
			std::vector<unsigned int> &correspondenceIndices,
			std::vector<bool> &useCorrespondence,
			std::vector<float> const& correspondenceWeights);

	/**
	 * Encode a transform as a 7-element array for LBFGS
	 *
	 * @param t transform
	 * @return array
	 */
	ap::real_1d_array TransformToLBFGSArray(rgbd::eigen::Transform3f const& t);

	/**
	 * De-encode a 7-element LBFGS array
	 *
	 * @param a array
	 * @return transform
	 */
	rgbd::eigen::Transform3f LBFGSArrayToTransform(ap::real_1d_array const& a);
};

}

#endif /* ICP_H_ */
