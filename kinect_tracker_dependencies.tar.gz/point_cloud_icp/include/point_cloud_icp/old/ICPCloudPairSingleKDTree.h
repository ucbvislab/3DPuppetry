/*
 * ICPCloudPairSingleKDTree: cloud pairs for ICPCombined that use a single k-d tree for the whole cloud
 *
 * Evan Herbst
 * 3 / 21 / 10
 */

#ifndef EX_ICP_CLOUDPAIR_POINTSONLY_H
#define EX_ICP_CLOUDPAIR_POINTSONLY_H

#include <boost/tuple/tuple.hpp>
#include <boost/shared_ptr.hpp>
#include "rgbd_util/eigen/Geometry"
#include "kdtree2/kdtree2.hpp"
#include "point_cloud_icp/registration/icp_combined.h" //ICPCloudPair
#include <fastpointlib/fastpointlib.h>

namespace registration
{

class ICPCloudPairSingleKDTree : virtual public ICPCloudPair
{
	public:

		/*
		 * yell if either cloud is empty; we don't allow that
		 */
		ICPCloudPairSingleKDTree(ICPCloudPairParams const& params,
				sensor_msgs::PointCloud const& source_pointcloud,
				sensor_msgs::PointCloud const& target_pointcloud);
		ICPCloudPairSingleKDTree(const ICPCloudPairParams& params,
				const sensor_msgs::PointCloud& sourceCloud,
				const sensor_msgs::PointCloud& targetCloud,
				boost::shared_ptr<kdtree2> targetKDTree);
		virtual ~ICPCloudPairSingleKDTree();

		/*
		 * Get the correspondence indices for source points from target points under transformation;
		 * an index will be -1 if no valid correspondence is found (for example, if the distance between points is greater than max_distance)
		 *
		 * simply look up each source point in a k-d tree of the target cloud, so it is possible for one target point to be assigned to many source points
		 *
		 * return the number of valid correspondences
		 */
		virtual int getCorrespondenceIndices(rgbd::eigen::Transform3f const& transform, std::vector<int>& correspondence_indices) const;

		void getPoints(std::vector<rgbd::eigen::Vector3f> &source_points, std::vector<rgbd::eigen::Vector3f> &target_points);

	protected:

		/*
		 * common ctor code
		 *
		 * pre: m_params has been set
		 */
		void initialize(const sensor_msgs::PointCloud& source_pointcloud, const sensor_msgs::PointCloud& target_pointcloud);

		void getCorrespondenceIndicesThreadMain(rgbd::eigen::Transform3f const& transform, std::vector<int> & correspondence_indices, const unsigned int firstIndex, const unsigned int lastIndex, unsigned int& invalid_count) const;

		boost::shared_ptr<kdtree2> m_target_kdtree_ptr;

		/*
		 * we don't allow empty clouds, so if any of these vectors is empty, it's because it hasn't been computed
		 */
		std::vector<rgbd::eigen::Vector3f> m_source_eigen_points, m_target_eigen_points;

		/*
		 * To experiment with the fastpointlib.  Contains the same points as m_source_eigen_points
		 */
		fastpointlib::b_vector4 * m_source_fpl_points;

		/*
		 * Allocated once to be the same size as m_source_fpl_points
		 */
		fastpointlib::b_vector4 * m_source_fpl_points_temp;
};

} //namespace

#endif //header
