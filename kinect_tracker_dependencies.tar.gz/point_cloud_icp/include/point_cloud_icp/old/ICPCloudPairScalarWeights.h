/*
 * ICPCloudPairScalarWeights: per-source-cloud-point isotropic weights
 *
 * Evan Herbst
 * 5 / 15 / 10
 */

#ifndef EX_ICP_CLOUD_PAIR_SCALAR_WEIGHTS_H
#define EX_ICP_CLOUD_PAIR_SCALAR_WEIGHTS_H

#include "point_cloud_icp/registration/icp_combined.h" //ICPCloudPair

namespace registration
{

class ICPCloudPairScalarWeights: virtual public ICPCloudPair
{
	public:

		/*
		 * If no weights are given, default to 1.
		 */
		ICPCloudPairScalarWeights(ICPCloudPairParams const& params, const sensor_msgs::PointCloud& sourceCloud,
						const sensor_msgs::PointCloud& targetCloud, std::vector<float> const& point_weights = std::vector<float>());

		virtual ~ICPCloudPairScalarWeights() {}

		std::vector<float> getPointWeights(){return m_point_weights;}

	protected:

		// external weights on the points.
		// These errors will be squared by the LM optimization
		std::vector<float> m_point_weights;
};

} //namespace

#endif //header
