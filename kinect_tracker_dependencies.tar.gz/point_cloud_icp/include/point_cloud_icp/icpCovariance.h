/*
 * icpCovariance: functions to compute covariance of ICP transform (eg for toro)
 *
 * Evan Herbst
 * 4 / 25 / 10
 */

#ifndef EX_ICP_COVARIANCE_H
#define EX_ICP_COVARIANCE_H

#include <vector>
#include <pcl/point_cloud.h>
#include "rgbd_util/eigen/Geometry"
#include "pcl_rgbd/cloudUncertainty.h"

namespace registration
{

/*
 * return an empirical covariance matrix for the three translation components and roll, pitch, yaw as used by TORO
 *
 * pre: each ith point in alignee corresponds to the ith point in alignand; alignand has normals
 */
template <typename PointT, typename PointT2>
rgbd::eigen::Matrix<double, 6, 6> getPointToPlaneICPXformCovarianceXlateRPY(const pcl::PointCloud<PointT>& alignee, const pcl::PointCloud<PointT2>& alignand);
template <typename PointT, typename PointT2>
rgbd::eigen::Matrix<double, 6, 6> getPointToPointICPXformCovarianceXlateRPY(const pcl::PointCloud<PointT>& alignee, const pcl::PointCloud<PointT2>& alignand);

} //namespace

#include "icpCovariance.ipp"

#endif //header
