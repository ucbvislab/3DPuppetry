/*
 * result: yes, covariances do get smaller as cloud size increases, as they should
 */

#include <cstdlib> //max()
#include <boost/random.hpp>
#include "rgbd_util/eigen/Geometry"
#include "pcl_rgbd/pointTypes.h"
#include "point_cloud_icp/icpCovariance.h"
using std::cout;
using std::endl;
using rgbd::eigen::Vector3d;

/*
 * if using pt-2-pt, give the ptfilepath again for the normals one since they're unused
 */
int main(int argc, char* argv[])
{
	boost::mt19937 rng;
	boost::normal_distribution<double> dist(0, .04);
	boost::normal_distribution<double> dist1(0, 1);
	boost::variate_generator<boost::mt19937&, boost::normal_distribution<double> > gen(rng, dist);
	boost::variate_generator<boost::mt19937&, boost::normal_distribution<double> > gen1(rng, dist1);

	for(unsigned int n = 100; n < 1000; n += 100)
	{
		pcl::PointCloud<rgbd::pt> aligneeCloud, alignandCloud;
		aligneeCloud.points.resize(n);
		aligneeCloud.width = aligneeCloud.points.size();
		aligneeCloud.height = 1;
		alignandCloud.points.resize(n);
		alignandCloud.width = alignandCloud.points.size();
		alignandCloud.height = 1;
		for(unsigned int i = 0; i < n; i++)
		{
			Vector3d x = Vector3d(0 + gen1(), 0 + gen1(), std::max(1.0, 3 + gen1()));
			aligneeCloud.points[i].x = x[0];
			aligneeCloud.points[i].y = x[1];
			aligneeCloud.points[i].z = x[2];
			alignandCloud.points[i].x = x[0] + gen();
			alignandCloud.points[i].y = x[1] + .1 + gen();
			alignandCloud.points[i].z = x[2] + gen();
			Vector3d v = Vector3d(0 + gen(), -1 + gen(), 0 + gen()).normalized();
			for(unsigned int j = 0; j < 3; j++) alignandCloud.points[i].normal[j] = v[j];
		}
		rgbd::eigen::Matrix<double, 6, 6> cov = registration::getPointToPlaneICPXformCovarianceXlateRPY(aligneeCloud, alignandCloud);
		cout << n << "pts: " << cov << endl << endl;
	}

	return 0;
}
