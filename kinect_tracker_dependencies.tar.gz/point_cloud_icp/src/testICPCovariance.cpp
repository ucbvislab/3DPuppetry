/*
 * testICPCovariance: use simple test-case clouds to make sure my icp covariance matrices look reasonable
 *
 * Evan Herbst
 * 4 / 28 / 10
 */

#include <string>
#include <iostream>
#include "pcl_rgbd/pointTypes.h"
#include "pcl_rgbd/cloudUtils.h"
#include "pcl_rgbd/cloudNormals.h"
#include "point_cloud_icp/icpCovariance.h"
using std::vector;
using std::string;
using std::cout;
using std::endl;
using rgbd::eigen::Vector3f;
using rgbd::eigen::Matrix;
using rgbd::eigen::Translation3f;
using rgbd::eigen::Affine3f;
using rgbd::eigen::AngleAxisf;

void printCloudNNormals(const pcl::PointCloud<rgbd::pt>& cloud, const string& name)
{
	cout << name << " cloud: " << endl;
	for(unsigned int i = 0; i < cloud.points.size(); i++)
		cout << Vector3f(cloud.points[i].x, cloud.points[i].y, cloud.points[i].z).transpose() << " , " << Vector3f(cloud.points[i].normal[0], cloud.points[i].normal[1], cloud.points[i].normal[2]).transpose() << endl;
	cout << endl;
}

/*
 * test creators: create two clouds of the same size whose ith points correspond
 */

void createHallwayTest(pcl::PointCloud<rgbd::pt>& src, pcl::PointCloud<rgbd::pt>& tgt, const Affine3f xform)
{
	const unsigned int N = 12;
	tgt.points.resize(3 * N * N);
	tgt.width = tgt.points.size();
	tgt.height = 1;
	for(unsigned int i = 0; i < N; i++)
		for(unsigned int j = 0; j < N; j++)
		{
			const unsigned int
				k0 = 0 * N * N + i * N + j,
				k1 = 1 * N * N + i * N + j,
				k2 = 2 * N * N + i * N + j;

			tgt.points[k0].x = 0;
			tgt.points[k0].y = 1.0 / N * j;
			tgt.points[k0].z = 1 + 1.0 / N * i;

			tgt.points[k1].x = 1.0 / N * j;
			tgt.points[k1].y = 0;
			tgt.points[k1].z = 1 + 1.0 / N * i;

			tgt.points[k2].x = 1;
			tgt.points[k2].y = 1.0 / N * j;
			tgt.points[k2].z = 1 + 1.0 / N * i;
		}
#if 0 //exact normals everywhere
	tgt.channels.resize(3);
	tgt.channels[0].name = "nx";
	tgt.channels[1].name = "ny";
	tgt.channels[2].name = "nz";
	for(unsigned int i = 0; i < 3; i++) tgt.channels[i].values.resize(tgt.points.size());
	vector<float>& nx = tgt.channels[0].values, &ny = tgt.channels[1].values, &nz = tgt.channels[2].values;
	for(unsigned int i = 0; i < N; i++)
		for(unsigned int j = 0; j < N; j++)
		{
			const unsigned int
				k0 = 0 * N * N + i * N + j,
				k1 = 1 * N * N + i * N + j,
				k2 = 2 * N * N + i * N + j;

			nx[k0] = 1; ny[k0] = 0; nz[k0] = 0;

			nx[k1] = 0; ny[k1] = 1; nz[k1] = 0;

			nx[k2] = -1; ny[k2] = 0; nz[k2] = 0;
		}
#else
	geometry_msgs::Point32 viewpoint;
	viewpoint.x = viewpoint.y = viewpoint.z = 0;
	assert(N > 5); //so there are actual neighborhoods
	rgbd::computePointCloudNormals(tgt, N, viewpoint);
#endif
//	printCloudNNormals(tgt, "tgt");
	src = tgt;
	rgbd::transform_point_cloud_in_place(xform, src, true);
//	printCloudNNormals(src, "src");
}

void runPointToPlaneTest(const Affine3f& xform)
{
	cout << "pt-2-plane, xform = " << endl << xform.matrix() << endl;
	pcl::PointCloud<rgbd::pt> src, tgt;
	createHallwayTest(src, tgt, xform);
	const Matrix<double, 6, 6> cov = registration::getPointToPlaneICPXformCovarianceXlateRPY(src, tgt);
	cout << "cov: " << endl << cov << endl << endl;
}

void runPointToPointTest(const Affine3f& xform)
{
	cout << "pt-2-pt, xform = " << endl << xform.matrix() << endl;
	pcl::PointCloud<rgbd::pt> src, tgt;
	createHallwayTest(src, tgt, xform);
	const Matrix<double, 6, 6> cov = registration::getPointToPointICPXformCovarianceXlateRPY(src, tgt);
	cout << "cov: " << endl << cov << endl << endl;
}

int main()
{
	Affine3f xform;

#define TEST(xf) \
	xform = xf;\
	runPointToPointTest(xform);
	//runPointToPlaneTest(xform);

	TEST(Translation3f(Vector3f(.1, 0, 0)))
	TEST(Translation3f(Vector3f(0, .1, 0)))
	TEST(Translation3f(Vector3f(0, 0, .1)))

	TEST(AngleAxisf(.03, Vector3f(1, 0, 0)))
	TEST(AngleAxisf(.03, Vector3f(0, 1, 0)))
	TEST(AngleAxisf(.03, Vector3f(0, 0, 1)))

	return 0;
}
