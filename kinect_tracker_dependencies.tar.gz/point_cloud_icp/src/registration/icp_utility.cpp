/*
 * icp_utility.cpp
 *
 *  Created on: Jul 7, 2009
 *      Author: peter
 */

#include <cassert>
#include <vector>
#include <string>
#include <list>
#include <sstream>
#include <algorithm> //max_element()
#include <iterator> //distance()
#include <stdexcept>
#include <boost/multi_array.hpp>
#include <boost/unordered_set.hpp>
#include <boost/iterator/counting_iterator.hpp>
#include <visualization_msgs/Marker.h>
#include "rgbd_util/timer.h"
#include "rgbd_util/mathUtils.h" //copySelected(), randomSample(), sqr()
#include "rgbd_util/eigen/Core"
#include "rgbd_util/eigen/Geometry"
#include "rgbd_util/eigen/LU"
#include "rgbd_util/eigen/QR" //SelfAdjointEigenSolver
#include "rgbd_util/primesensorUtils.h"
#include "xforms/xforms.h"
#include "pcl_rgbd/pointTypes.h"
#include "point_cloud_icp/registration/icp_utility.h"
using namespace rgbd::eigen;
using namespace std;

namespace registration
{

	void optimalClosedFormRotation(const std::vector<rgbd::eigen::Vector3f>& srcPts, const std::vector<rgbd::eigen::Vector3f>& tgtPts, std::vector<float> const& correspondence_weights, rgbd::eigen::Quaternionf &rotation)
	{
		assert(srcPts.size() == tgtPts.size());

		//get the M-matrix described in the paper
		//this is the sum of outer products of the vector pairs
		Matrix3f m = Matrix3f::Zero();
		for(unsigned int i=0; i<srcPts.size(); i++)
			m += correspondence_weights[i] * srcPts[i] * tgtPts[i].transpose();

		//get the N-matrix described in the paper
		//this is constructed from elements of the M-matrix
		//out goal is to find a quaternion q which maximizes q^t*N*q
		//when the quaternion is interpreted as a 4 element vector
		//note that the N-matrix is symmetric
		Matrix4f n = Matrix4f::Zero();
		//diagonal
		n(0,0) = m(0,0) + m(1,1) + m(2,2);
		n(1,1) = m(0,0) - m(1,1) - m(2,2);
		n(2,2) = -m(0,0) + m(1,1) - m(2,2);
		n(3,3) = -m(0,0) - m(1,1) + m(2,2);
		//non-diagonal
		n(1,0) = n(0,1) = m(1,2) - m(2,1);
		n(2,0) = n(0,2) = m(2,0) - m(0,2);
		n(3,0) = n(0,3) = m(0,1) - m(1,0);
		n(2,1) = n(1,2) = m(0,1) + m(1,0);
		n(3,1) = n(1,3) = m(2,0) + m(0,2);
		n(3,2) = n(2,3) = m(1,2) + m(2,1);

	//	cout<<"M matrix: "<<endl;
	//	cout<<m<<endl;
	//	std::cout<<"N matrix: "<<endl;
	//	std::cout<<n<<endl;

		//get the eigenvalues and eigenvectors
		SelfAdjointEigenSolver<Matrix4f> eig(n);
		const Vector4f evals = eig.eigenvalues();
		const Matrix4f evecs = eig.eigenvectors();

		//get the eigenvector for the largest eigenvalue (yes, last is largest)
		const Vector4f largestEvec = evecs.col(3);
		const float largestEval = evals[3];

		//interpret the eigenvector as a rotation
		rotation = Quaternionf(largestEvec(0),largestEvec(1),largestEvec(2),largestEvec(3));
		rotation.normalize();
	}

	/**
	 * Just a modified version of the alignment method in ICP.cpp
	 *
	 * @param correspondences
	 * @param correspondence_weights
	 * @param rotation
	 * @param translation
	 * @return
	 */
	void runClosedFormAlignment(
		deque<pair<Vector3f,Vector3f> > const& correspondences,
		vector<float> const& correspondence_weights,
		Quaternionf &rotation, Vector3f &translation)
	{
		unsigned int numPoints = correspondences.size();
		assert(numPoints >= 3);

		//find the means
		Vector3f meanToRegister= Vector3f::Zero();
		Vector3f meanCorrespondence= Vector3f::Zero();
		for(unsigned int i=0; i<numPoints; i++){
			meanToRegister += correspondences[i].first;
			meanCorrespondence += correspondences[i].second;
		}
		meanToRegister = meanToRegister / numPoints;
		meanCorrespondence = meanCorrespondence / numPoints;

		//translate the points so their centroids align
		std::vector<Vector3f> shiftedToRegister(numPoints);
		std::vector<Vector3f> shiftedCorrespondences(numPoints);
		for(unsigned int i=0; i<numPoints; i++){
			shiftedToRegister[i] = correspondences[i].first - meanToRegister;
			shiftedCorrespondences[i] = correspondences[i].second - meanCorrespondence;
		}

		//rotation component
		optimalClosedFormRotation(shiftedToRegister, shiftedCorrespondences, correspondence_weights, rotation);

		//create the translation component
		Vector3f rotatedMean = rotation*meanToRegister;
		translation =  meanCorrespondence - rotatedMean;

	}

	void getInlierCorrespondencesOld(
		std::vector<rgbd::eigen::Vector3f> const& sourcePoints,
		std::vector<rgbd::eigen::Vector3f> const& targetPoints,
		std::vector<std::pair<int, int> > const& correspondences,
		float inlierDist, rgbd::eigen::Affine3f const& transform,
		std::vector<std::pair<int, int> > & inlierCorrs)
	{
		inlierCorrs.clear();
		float squaredInlierDist = pow(inlierDist,2);
		for(unsigned int i=0; i<correspondences.size(); i++){
			rgbd::eigen::Vector3f diff = transform*sourcePoints[correspondences[i].first]-targetPoints[correspondences[i].second];
			if(diff.squaredNorm() < squaredInlierDist)
				inlierCorrs.push_back(correspondences[i]);
		}
	}

	void getInlierCorrespondencesUniform(
		std::vector<rgbd::eigen::Vector4f, rgbd::eigen::aligned_allocator<rgbd::eigen::Vector4f> > const& sourcePoints,
		std::vector<rgbd::eigen::Vector4f, rgbd::eigen::aligned_allocator<rgbd::eigen::Vector4f> > const& targetPoints,
		std::vector<std::pair<int, int> > const& correspondences,
		float inlierDist, rgbd::eigen::Affine3f const& transform,
		std::vector<std::pair<int, int> > & inlierCorrs)
	{
		inlierCorrs.clear();
		const float squaredInlierDist = pow(inlierDist,2);
		for(unsigned int i=0; i<correspondences.size(); i++){
			const rgbd::eigen::Vector4f diff = transform*sourcePoints[correspondences[i].first] - targetPoints[correspondences[i].second];
			if(diff.squaredNorm() < squaredInlierDist)
				inlierCorrs.push_back(correspondences[i]);
		}
	}

	void getInlierCorrespondencesUniformWithDepth(
		std::vector<rgbd::eigen::Vector4f, rgbd::eigen::aligned_allocator<rgbd::eigen::Vector4f> > const& sourcePoints,
		std::vector<rgbd::eigen::Vector4f, rgbd::eigen::aligned_allocator<rgbd::eigen::Vector4f> > const& targetPoints,
		std::vector<std::pair<int, int> > const& correspondences,
		float inlierDistAt1m, rgbd::eigen::Affine3f const& transform,
		std::vector<std::pair<int, int> > & inlierCorrs)
	{
		inlierCorrs.clear();
		for(unsigned int i=0; i<correspondences.size(); i++){
			const rgbd::eigen::Vector4f diff = transform*sourcePoints[correspondences[i].first] - targetPoints[correspondences[i].second];
			if(diff.squaredNorm() < sqr(inlierDistAt1m * std::max(1.0, primesensor::stereoErrorRatio(sourcePoints[correspondences[i].first].z()))))
				inlierCorrs.push_back(correspondences[i]);
		}
	}

	RansacInlierFunction getRansacInlierFunctionFromString(const std::string& s)
	{
		if (s == "RANSAC_INLIER_UNIFORM") return RANSAC_INLIER_UNIFORM;
		else if (s == "RANSAC_INLIER_UNIFORM_WITH_DEPTH") return RANSAC_INLIER_UNIFORM_WITH_DEPTH;
		else {
			assert(false && "unknown getRansacInlierFunctionFromString");
		}
	}


	bool runRANSAC(
			std::vector<rgbd::eigen::Vector3f> const& sourcePoints,
	        std::vector<rgbd::eigen::Vector3f> const& targetPoints,
	        std::vector<std::pair<int, int> > const& correspondences,
	        float inlierDist,
	        RansacInlierFunction ransac_inlier_function,
	        rgbd::eigen::Affine3f &resultTransform,
	        std::vector<std::pair<int, int> > & resultInliers,
	        unsigned int numSamples, unsigned int sampleSize,
	        float minSampleDist,
	        bool weightByInverseSquareDistance,
	        bool verbose,
	        unsigned int maxSampleAttempts)
	{
		assert(sampleSize >= 3); //needed for the model we use (3-d xforms)

		if(correspondences.size() < sampleSize) return false;

		rgbd::timer t;

		/*
		 * for getInlierCorrespondences(), so Eigen can use SSE -- this speeds up ransac by ~30% even counting the time to convert -- EVH 20100624
		 */
		vector<Vector4f, rgbd::eigen::aligned_allocator<rgbd::eigen::Vector4f> > sourcePoints4d(sourcePoints.size()), targetPoints4d(targetPoints.size());
		for(unsigned int i = 0; i < sourcePoints.size(); i++)
		{
			sourcePoints4d[i].head<3>() = sourcePoints[i];
			sourcePoints4d[i][3] = 1;
		}
		for(unsigned int i = 0; i < targetPoints.size(); i++)
		{
			targetPoints4d[i].head<3>() = targetPoints[i];
			targetPoints4d[i][3] = 1;
		}

		resultInliers.clear();

		const float minSquaredDist = pow(minSampleDist,2);

		rgbd::eigen::Quaternionf rot;
		rgbd::eigen::Vector3f trans;

		std::vector<float> weights(sampleSize,1.0);

		std::vector<std::pair<int, int> > bestInlierCorrs;
		for(unsigned int i=0; i<numSamples; i++)
		{
			//get the new sampled correspondences
			vector<unsigned int> sampleIndices(sampleSize);
			bool got_sample = sampleSpatiallyDispersedCorrespondences(
					minSquaredDist,
					maxSampleAttempts,
					verbose,
					sourcePoints,
					targetPoints,
					correspondences,
					sampleIndices);
			if (!got_sample) return false;
#if 0
			bool tooClose;
			unsigned int numTries = 0;
			do
			{
				randomSample(boost::make_counting_iterator(0u), boost::make_counting_iterator((unsigned int)correspondences.size()), sampleSize, sampleIndices.begin());

				//make sure sampled pts are far enough apart in 3-d
				tooClose = false;
				for(unsigned int j = 0; j < sampleSize - 1; j++)
				{
					for(unsigned int k = j + 1; k < sampleSize; k++)
						if((sourcePoints[correspondences[sampleIndices[j]].first] - sourcePoints[correspondences[sampleIndices[k]].first]).squaredNorm() < minSquaredDist)
						{
							tooClose = true;
							break;
						}
					if(tooClose) break;
				}

				numTries++;
			}
			while(tooClose && numTries < maxSampleAttempts);
			if(numTries == maxSampleAttempts && tooClose) {
				if(verbose) std::cout << "failed to get a spatially dispersed sample for ransac in " << maxSampleAttempts << " tries" << std::endl;
				return false;
			}
#endif


			//get the transform aligning the sampled correspondences
			std::deque<std::pair<rgbd::eigen::Vector3f,rgbd::eigen::Vector3f> > sampledCorrPts(sampleSize);
			for(unsigned int j = 0; j < sampleSize; j++)
				sampledCorrPts[j] = std::make_pair(sourcePoints[correspondences[sampleIndices[j]].first], targetPoints[correspondences[sampleIndices[j]].second]);
			runClosedFormAlignment(sampledCorrPts,weights,rot,trans);
			rgbd::eigen::Affine3f transform(rot);
			transform.pretranslate(trans);

			/*
			 * find the inlier correspondences for the transform
			 * (a subset of all corrs that doesn't necessarily include any of those that were just sampled)
			 */
			std::vector<std::pair<int, int> > inlierCorrs;

			switch(ransac_inlier_function) {
			case RANSAC_INLIER_UNIFORM:
				getInlierCorrespondencesUniform(sourcePoints4d, targetPoints4d, correspondences, inlierDist, transform, inlierCorrs);
				break;
			case RANSAC_INLIER_UNIFORM_WITH_DEPTH:
				getInlierCorrespondencesUniformWithDepth(sourcePoints4d, targetPoints4d, correspondences, inlierDist, transform, inlierCorrs);
				break;
			default:
				assert(false && "unknown ransac_inlier_function");
			}


			if(inlierCorrs.size() >= bestInlierCorrs.size()) //if we already know this hypothesis isn't good enough, save some work
			{
				/*
				 * eliminate inliers too close to each other
				 *
				 * previously we checked only for inliers with the same source or target feature index, which
				 * is not as strong a check and can lead to not having 3 unique geometric constraints, which will cause computeClosedFormRotation() to hang -- EVH
				 */
				static const float minInlierDistSqr = 1e-6;
				std::vector<std::pair<int, int> > filtered_inlier_corrs;
				for (unsigned int k = 1; k < inlierCorrs.size(); k++)
				{
					bool ok = true;
					for(unsigned int l = 0; l < filtered_inlier_corrs.size(); l++)
						if((sourcePoints[inlierCorrs[k].first] - sourcePoints[filtered_inlier_corrs[l].first]).squaredNorm() < minInlierDistSqr)
						{
							ok = false;
							break;
						}
					if(ok) filtered_inlier_corrs.push_back(inlierCorrs[k]);
				}

				if(filtered_inlier_corrs.size()>bestInlierCorrs.size())
				{
					bestInlierCorrs = filtered_inlier_corrs;
				}
			}
		}

		if(verbose) std::cout<<"--- Best transform has "<<bestInlierCorrs.size()<<" inliers out of a possible "<< correspondences.size()<<std::endl;

		resultInliers = bestInlierCorrs;

		deque<std::pair<Vector3f, Vector3f> > bestInlierCorrPts(bestInlierCorrs.size());
		for (unsigned int i = 0; i < bestInlierCorrs.size(); i++)
			bestInlierCorrPts[i] = std::make_pair(sourcePoints[bestInlierCorrs[i].first], targetPoints[bestInlierCorrs[i].second]);
		//get the transform for the largest set of inlier correspondences
		if(bestInlierCorrs.size() < 3) return false;
		if (weightByInverseSquareDistance) {
			pcl::PointCloud<rgbd::pt> source_inlier_cloud;
			source_inlier_cloud.points.resize(bestInlierCorrPts.size());
			source_inlier_cloud.width = source_inlier_cloud.points.size();
			source_inlier_cloud.height = 1;
			for (unsigned int i = 0; i < bestInlierCorrs.size(); i++) rgbd::eigen2ptX(source_inlier_cloud.points[i], bestInlierCorrPts[i].first);
			getPtWeightsByDistFromCam(source_inlier_cloud, weights);
		}
		else {
			weights.resize(bestInlierCorrs.size(),1.0);
		}
		runClosedFormAlignment(bestInlierCorrPts,weights,rot,trans);
		resultTransform = rot;
		resultTransform.pretranslate(trans);

		if(verbose)
		{
			ostringstream outstr;
			outstr << "perform RANSAC (" << numSamples << " iters)";
			t.stop(outstr.str());
		}

		return true;
	}

	bool sampleSpatiallyDispersedCorrespondences(
			float minSquaredDistance,
			unsigned int maxSampleAttempts,
			bool verbose,
			std::vector<rgbd::eigen::Vector3f> const& sourcePoints,
	        std::vector<rgbd::eigen::Vector3f> const& targetPoints,
	        std::vector<std::pair<int, int> > const& correspondences,
	        std::vector<unsigned int> & sampleIndices)
	{
		const unsigned int sampleSize = sampleIndices.size();
		bool tooClose = true;
		unsigned int numTries = 0;

		do
		{
			randomSample(boost::make_counting_iterator(0u), boost::make_counting_iterator((unsigned int)correspondences.size()), sampleSize, sampleIndices.begin());

			//make sure sampled pts are far enough apart in 3-d
			// Peter modifies: check distance of both source and target points
			tooClose = false;
			for(unsigned int j = 0; j < sampleSize - 1; j++)
			{
				for(unsigned int k = j + 1; k < sampleSize; k++) {
					if((sourcePoints[correspondences[sampleIndices[j]].first] - sourcePoints[correspondences[sampleIndices[k]].first]).squaredNorm() < minSquaredDistance) {
						tooClose = true;
						break;
					}
					if((targetPoints[correspondences[sampleIndices[j]].second] - targetPoints[correspondences[sampleIndices[k]].second]).squaredNorm() < minSquaredDistance) {
						tooClose = true;
						break;
					}
				}
				if(tooClose) break;
			}

			numTries++;
		}
		while(tooClose && numTries < maxSampleAttempts);

		if(numTries == maxSampleAttempts && tooClose) {
			if(verbose) std::cout << "failed to get a spatially dispersed sample for ransac in " << maxSampleAttempts << " tries" << std::endl;
			return false;
		}
		return true;
	}


	void downsampleFromIndices(
			const std::vector<rgbd::eigen::Vector3f> & sourcePoints,
			std::vector<rgbd::eigen::Vector3f> & targetPoints,
			const std::vector<unsigned int> & acceptedIndices)
	{
		targetPoints.resize(acceptedIndices.size());
		copySelected(sourcePoints, acceptedIndices, targetPoints.begin());
	}

	float getRotationPartialDerivative(
			rgbd::eigen::Matrix<float,7,1> const& currentTransform,
			rgbd::eigen::Vector3f const& toRegisterPoint,
			unsigned int physicalPointComponent,
			unsigned int quaternionComponent)
	{


		if((physicalPointComponent==0&&quaternionComponent==1) ||
				(physicalPointComponent==1&&quaternionComponent==2) ||
				(physicalPointComponent==2&&quaternionComponent==3))
		{
			//2xq_x+2yq_y+2zq_z
			return 2*toRegisterPoint.x()*currentTransform(1) +
				2*toRegisterPoint.y()*currentTransform(2) +
				2*toRegisterPoint.z()*currentTransform(3);
		}
		else if((physicalPointComponent==0&&quaternionComponent==0) ||
				(physicalPointComponent==1&&quaternionComponent==3) ||
				(physicalPointComponent==2&&quaternionComponent==2))
		{
			//2xq_0-2yq_z+2zq_y
			float toReturn = 2*toRegisterPoint.x()*currentTransform(0) -
				2*toRegisterPoint.y()*currentTransform(3) +
				2*toRegisterPoint.z()*currentTransform(2);
			if(physicalPointComponent == 2)
				toReturn*=-1;
			return toReturn;
		}
		else if((physicalPointComponent==0&&quaternionComponent==3) ||
				(physicalPointComponent==1&&quaternionComponent==0) ||
				(physicalPointComponent==2&&quaternionComponent==1))
		{
			//2xq_z+2yq_0-2zq_x
			float toReturn = 2*toRegisterPoint.x()*currentTransform(3) +
				2*toRegisterPoint.y()*currentTransform(0) -
				2*toRegisterPoint.z()*currentTransform(1);
			if(physicalPointComponent == 0)
				toReturn*=-1;
			return toReturn;
		}
		else if((physicalPointComponent==0&&quaternionComponent==2) ||
				(physicalPointComponent==1&&quaternionComponent==1) ||
				(physicalPointComponent==2&&quaternionComponent==0))
		{
			//-2xq_y+2yq_x+2zq_0
			float toReturn = -2*toRegisterPoint.x()*currentTransform(2) +
				2*toRegisterPoint.y()*currentTransform(1) +
				2*toRegisterPoint.z()*currentTransform(0);
			if(physicalPointComponent == 1)
				toReturn*=-1;
			return toReturn;
		}

		assert(false);
		return 0;
	}
}
