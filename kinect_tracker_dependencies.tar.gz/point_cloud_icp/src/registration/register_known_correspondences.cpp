/*
 * register_known_correspondences.cpp
 *
 *  Created on: Sep 13, 2009
 *      Author: mkrainin
 */


#include<iostream>
#include<string>
#include<deque>
#include<vector>
#include"rgbd_util/eigen/Core"
#include"rgbd_util/eigen/Geometry"
#include"rgbd_util/eigen/LU"
#include "rgbd_util/eigen/QR"
#include "point_cloud_icp/registration/icp_utility.h"
using namespace std;
using namespace rgbd::eigen;

int main(int argc, char** argv)
{

	string input;

	deque<pair<Vector3f,Vector3f> > correspondences;
	unsigned int minCorrespondences = 3;

	while(true){
		cout<<endl;
		cout<<"Enter a point? (y/n. d to delete last point in list)"<<endl;
		cin>>input;

		if(input == "n"){
			if(correspondences.size() < minCorrespondences){
				cout<<"Need more correspondences"<<endl;
				continue;
			}
			else
				break;
		}
		else if(input == "d"){
			correspondences.pop_back();
			cout<<"Dropped last correspondence"<<endl;
			continue;
		}
		else if(input != "y"){
			cout<<"Input not recognized"<<endl;
			continue;
		}

		Vector3f toRegister, target;

		//get the toRegister point
		cout<<"To Register x: ";
		cin>>toRegister.x();
		cout<<"To Register y: ";
		cin>>toRegister.y();
		cout<<"To Register z: ";
		cin>>toRegister.z();

		//get the target point
		cout<<"Target x: ";
		cin>>target.x();
		cout<<"Target y: ";
		cin>>target.y();
		cout<<"Target z: ";
		cin>>target.z();

		correspondences.push_back(pair<Vector3f,Vector3f>(toRegister,target));

		cout<<"Input taken"<<endl;
	}

//	for(unsigned int i=0; i<correspondences.size(); i++){
//		cout<<"To register point "<<i<<endl;
//		cout<<correspondences[i].first<<endl;
//
//		cout<<"Target point "<<i<<endl;
//		cout<<correspondences[i].second<<endl;
//	}

	Quaternionf rotation;
	Vector3f translation;

	registration::runClosedFormAlignment(correspondences,std::vector<float>(correspondences.size(), 1.0),rotation,translation);

	std::cout<<"Transformation : "<<std::endl;
	std::cout<<"\t Translation: "<<translation(0)<<", "<<
		translation(1)<<", "<<translation(2)<<std::endl;
	std::cout<<"\t Quaternion: "<<rotation.w()<<", "<<rotation.x()<<
		", "<<rotation.y()<<", "<<rotation.z()<<std::endl;

	cout<<"Done"<<endl;
	return 0;
}
