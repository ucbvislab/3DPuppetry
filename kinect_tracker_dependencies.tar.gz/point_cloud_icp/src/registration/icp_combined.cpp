/*
 * icp_combined.cpp
 *
 *  Created on: Jan 27, 2010
 *      Author: peter
 *
 *
 * cleaner implementation of combined icp (multiple clouds, multiple error functions, priors, and fixed correspondences)
 */

#include <cassert>
#include <cmath> //max()
#include <limits>
#include <iostream>
#include <boost/array.hpp>
#include <boost/ref.hpp>
#include "rgbd_util/timer.h"
#include "rgbd_util/parallelism.h" //partitionEvenly()
#include "rgbd_util/colorConversion.h" //rgb2hsv()
#include "xforms/xforms.h"
#include "point_cloud_icp/registration/icp_utility.h"
#include "point_cloud_icp/registration/icp_combined.h"
#include "point_cloud_icp/registration/icpPoint2Point.h"
#include "point_cloud_icp/registration/icpPoint2Plane.h"
#include "point_cloud_icp/registration/icpPlanarPatch.h"
#include "point_cloud_icp/registration/icpPoint2PointReprojection.h"
#ifdef USE_LEVMAR
#include <levmar.h>
#endif
#include <cminpack.h>
#include <functional>
using std::vector;
using std::cout;
using std::endl;
using std::deque;
using std::pair;
using rgbd::eigen::Vector3f;
using rgbd::eigen::Affine3f;
using rgbd::eigen::Quaternionf;
using rgbd::eigen::Translation3f;

//TODO should these be in eigen/preinclude.h? -- EVH 20111101
#define EIGEN_NO_STATIC_ASSERT
#define EIGEN_DONT_VECTORIZE 
#define EIGEN_DISABLE_UNALIGNED_ARRAY_ASSERT

#ifdef USE_EIGENLM
//TODO create an rgbd::eigen version for this?
#include <unsupported/Eigen/NonLinearOptimization>
#endif

namespace registration
{

/************************************************************************************************************************
 * ICPCloudPair
 */

const unsigned int ICPCloudPair::hueBinSize, ICPCloudPair::valueBinSize;
const unsigned int ICPCloudPair::numHueBins, ICPCloudPair::numValueBins;

ICPCloudPair::~ICPCloudPair()
{
}

void ICPCloudPair::setTargetIsBoundary(const std::vector<bool>& target_pt_is_boundary)
{
	m_target_is_boundary = target_pt_is_boundary;
}

void ICPCloudPair::setDefaultWeights()
{
	switch(m_params.wtType)
	{
		case ICP_WTS_SCALAR:
			setScalarWeights();
			break;
		case ICP_WTS_MATRIX:
			setMatrixWeights();
			break;
		default: assert(false);
	}
}

void ICPCloudPair::setScalarWeights(const std::vector<float>& point_weights)
{
	assert(m_params.wtType == ICP_WTS_SCALAR);
	if(point_weights.empty()) m_scalar_weights.resize(m_source_eigen_points.size(), 1);
	else
	{
		assert(point_weights.size() == m_source_eigen_points.size());
		// argument is the weights, but our optimization squares the weights
		m_scalar_weights.resize(point_weights.size());
		for (unsigned int i = 0; i < point_weights.size(); i++) m_scalar_weights[i] = sqrt(point_weights[i]);
	}
}

void ICPCloudPair::setMatrixWeights(const std::vector<rgbd::eigen::Matrix3f>& point_weights)
{
	assert(m_params.wtType == ICP_WTS_MATRIX);
	if(point_weights.empty()) m_matrix_weights.resize(m_source_eigen_points.size(), rgbd::eigen::Matrix4f::Identity());
	else
	{
		assert(point_weights.size() == m_source_eigen_points.size());
		m_matrix_weights.resize(m_source_eigen_points.size(), rgbd::eigen::Matrix4f::Zero());
		for(unsigned int i = 0; i < point_weights.size(); i++)
			m_matrix_weights[i].block<3, 3>(0, 0) = point_weights[i]; //our optimization does NOT square these weights
	}
}

/*
 * Requires cloud pair already set up
 */
void ICPCloudPair::setReprojectionError(
		boost::shared_ptr<rgbd::CameraParams> const& rgbd_camera_params_ptr,
		float stereo_baseline)
{
	// only set if not already set
	if (!m_rgbd_camera_params_ptr) {
		m_rgbd_camera_params_ptr = rgbd_camera_params_ptr;
		m_stereo_baseline = stereo_baseline;
	}
	m_params.errType = ICP_ERR_REPROJECTION;
}

void ICPCloudPair::setReprojectionCorrs(
		boost::shared_ptr<rgbd::CameraParams> const& rgbd_camera_params_ptr,
		float stereo_baseline)
{
	// only set if not already set
	if (!m_rgbd_camera_params_ptr) {
		m_rgbd_camera_params_ptr = rgbd_camera_params_ptr;
		m_stereo_baseline = stereo_baseline;
	}

	m_params.corrType = ICP_CORRS_REPROJECTION; // set this on pair creation to avoid needless kdtree creation
	// create a projected target cloud
	unsigned int point_count = m_target_eigen_points.size();
	m_target_eigen_points_projected.resize(point_count);
	std::vector<int> empty_row(m_rgbd_camera_params_ptr->yRes, -1);
	m_target_eigen_projected_points_grid.assign(m_rgbd_camera_params_ptr->xRes, empty_row);
	for (unsigned int i = 0; i < point_count; i++) {
		m_target_eigen_points_projected[i] = projectTargetPoint(m_target_eigen_points[i]);

		// should basically do nothing
		int x = round(m_target_eigen_points_projected[i][0]);
		int y = round(m_target_eigen_points_projected[i][1]);

		// debug
		//cout << "m_target_eigen_points_projected[i]: " << m_target_eigen_points_projected[i].transpose() << endl;
		//cout << "m_target_eigen_projected_points_grid[x][y]: " << m_target_eigen_projected_points_grid[x][y] << endl;

		// grid index to projected point
		assert(m_target_eigen_projected_points_grid[x][y] < 0); // since cloud is from depth map should not be dups
		m_target_eigen_projected_points_grid[x][y] = (int)i;
	}
}


ICPCloudPair::srcPtT ICPCloudPair::projectSourcePoint(const ICPCloudPair::srcPtT & p) const
{
	srcPtT result;
	float inverse_depth = 1.0 / p[2];
	result[0] = inverse_depth * m_rgbd_camera_params_ptr->focalLength * p[0] + m_rgbd_camera_params_ptr->centerX;
	result[1] = inverse_depth * m_rgbd_camera_params_ptr->focalLength * p[1] + m_rgbd_camera_params_ptr->centerY;
	result[2] = inverse_depth * m_rgbd_camera_params_ptr->focalLength * m_stereo_baseline;
	return result;
}

ICPCloudPair::tgtPtT ICPCloudPair::projectTargetPoint(const ICPCloudPair::tgtPtT & p) const
{
	tgtPtT result;
	float inverse_depth = 1.0 / p[2];
	result[0] = inverse_depth * m_rgbd_camera_params_ptr->focalLength * p[0] + m_rgbd_camera_params_ptr->centerX;
	result[1] = inverse_depth * m_rgbd_camera_params_ptr->focalLength * p[1] + m_rgbd_camera_params_ptr->centerY;
	result[2] = inverse_depth * m_rgbd_camera_params_ptr->focalLength * m_stereo_baseline;
	return result;
}


/*
 * return (whether source-cloud normals are needed, whether target-cloud normals are needed)
 *
 * pre: m_params has been set
 */
std::pair<bool, bool> ICPCloudPair::areNormalsNeeded() const
{
	bool need_source_normals = false, need_target_normals = false;
	if (!m_params.front_can_match_back) {
		need_source_normals = true;
		need_target_normals = true;
	}
	if (m_params.max_normal_angle > 0) {
		need_source_normals = true;
		need_target_normals = true;
	}
	if(m_params.errType == ICP_ERR_POINT_TO_PLANE) need_target_normals = true;
	else if(m_params.errType == ICP_ERR_PLANAR_PATCH)
	{
		need_source_normals = true;
		need_target_normals = true;
	}

	if (m_params.extract_all_normals) {
		need_source_normals = true;
		need_target_normals = true;
	}

	return std::make_pair(need_source_normals, need_target_normals);
}

void ICPCloudPair::getReprojectionCorrespondenceIndicesThreadMain(rgbd::eigen::Affine3f const& transform, std::vector<int> & correspondence_indices, std::vector<float> & correspondence_distances_squared, const unsigned int firstIndex, const unsigned int lastIndex, unsigned int& invalid_count) const
{
	float max_reprojection_distance = m_params.max_distance;
	float max_reprojection_distance_squared = max_reprojection_distance * max_reprojection_distance;

	invalid_count = 0;
	for (unsigned int i = firstIndex; i <= lastIndex; ++i)
	{
		const srcPtT transformed_source = transform * m_source_eigen_points[i];
		const srcPtT projected_transformed_source = projectSourcePoint(transformed_source);

		// get neighborhood of points to find the closest
		int best_index = -1;
		float best_error_squared = 0; // could do infinite I suppose
		for (int x = projected_transformed_source[0] - ceil(max_reprojection_distance); x < projected_transformed_source[0] + ceil(max_reprojection_distance); x++) {
			for (int y = projected_transformed_source[1] - ceil(max_reprojection_distance); y < projected_transformed_source[1] + ceil(max_reprojection_distance); y++) {
				// debug
				//cout << "x,y: " << x << "," << y << endl;

				if (x >= 0 && x < m_target_eigen_projected_points_grid.size() && y >= 0 && y < m_target_eigen_projected_points_grid[0].size()) {
					int target_point_index = m_target_eigen_projected_points_grid[x][y];
					if (target_point_index >= 0) {
						const tgtPtT & projected_target_point = m_target_eigen_points_projected[target_point_index];
						float reprojection_error_squared = (projected_target_point - projected_transformed_source).squaredNorm();

						// debug
						//cout << "projected_transformed_source: " << projected_transformed_source.transpose() << endl;
						//cout << "projected_target_point: " << projected_target_point.transpose() << endl;
						//cout << "reprojection_error_squared: " << reprojection_error_squared << endl;

						if (best_index < 0 || reprojection_error_squared < best_error_squared) {
							best_index = target_point_index;
							best_error_squared = reprojection_error_squared;
						}
					}
				}
			}
		}

		// probably duplicates work that's done later
		if (best_index >= 0 && best_error_squared <= max_reprojection_distance_squared) {
			correspondence_indices[i] = best_index;
			correspondence_distances_squared[i] = best_error_squared;
		}
		else {
			invalid_count++;
		}
	}
}

int ICPCloudPair::getReprojectionCorrespondenceIndices(rgbd::eigen::Affine3f const& transform, std::vector<int> & correspondence_indices, std::vector<float> & correspondence_distances_squared) const
{
	assert(!m_target_eigen_points_projected.empty()); //set in setReprojectionError
	assert(!m_target_eigen_projected_points_grid.empty());

	const unsigned int point_count = m_source_eigen_points.size();
	correspondence_indices.resize(point_count);
	correspondence_distances_squared.resize(point_count);

	unsigned int valid_count = point_count;
	// 1 thread per 1000 points? (instead of 10000 as elsewhere)
	//const unsigned int numThreads = (unsigned int)std::min((int)ceil(point_count / 1000.0), (int)getSuggestedThreadCount());
	const unsigned int numThreads = (m_thread_params.search_threads > 0) ? m_thread_params.search_threads : (unsigned int)std::min((int)ceil(point_count / 10000.0), (int)getSuggestedThreadCount());

	if(numThreads == 1)
	{
		unsigned int invalidCount;
		getReprojectionCorrespondenceIndicesThreadMain(transform, correspondence_indices, correspondence_distances_squared, 0, point_count - 1, invalidCount);
		valid_count -= invalidCount;
	}
	else
	{
		vector<boost::shared_ptr<rgbd::thread> > threads(numThreads);
		const vector<unsigned int>& indices = partitionEvenly(point_count, numThreads);
		vector<unsigned int> invalidCounts(numThreads);
		for(unsigned int i = 0; i < numThreads; i++)
			threads[i] = boost::shared_ptr<rgbd::thread>(new rgbd::thread(rgbd::bind(&ICPCloudPair::getReprojectionCorrespondenceIndicesThreadMain, this, rgbd::cref(transform), rgbd::ref(correspondence_indices), rgbd::ref(correspondence_distances_squared), indices[i], indices[i + 1] - 1, rgbd::ref(invalidCounts[i]))));
		for(unsigned int i = 0; i < numThreads; i++)
			threads[i]->join();
		for(unsigned int i = 0; i < numThreads; i++) {
			valid_count -= invalidCounts[i];
		}
	}

	return valid_count;
}

void ICPCloudPair::getSingleKDTreeCorrespondenceIndicesThreadMain(rgbd::eigen::Affine3f const& transform, std::vector<int> & correspondence_indices, std::vector<float> & correspondence_distances_squared, const unsigned int firstIndex, const unsigned int lastIndex, unsigned int& invalid_count) const
{
	for (unsigned int i = firstIndex; i <= lastIndex; ++i)
	{
		const srcPtT transformed_source = transform * m_source_eigen_points[i];
		const vector<float> qpt(transformed_source.data(), transformed_source.data() + 3);
		kdtree2_result_vector result;
		m_target_kdtree_ptr->n_nearest(qpt, 1, result);
		correspondence_indices[i] = result[0].idx;
		correspondence_distances_squared[i] = result[0].dis;
	}
	invalid_count = 0;
}

int ICPCloudPair::getSingleKDTreeCorrespondenceIndices(rgbd::eigen::Affine3f const& transform, std::vector<int> & correspondence_indices, std::vector<float> & correspondence_distances_squared) const
{
	const unsigned int point_count = m_source_eigen_points.size();
	correspondence_indices.resize(point_count);
	correspondence_distances_squared.resize(point_count);

//	rgbd::timer t;
	unsigned int valid_count = point_count;
	/* if clouds are small, don't thread the heck out of them */
	const unsigned int numThreads = (m_thread_params.search_threads > 0) ? m_thread_params.search_threads : (unsigned int)std::min((int)ceil(point_count / 10000.0), (int)getSuggestedThreadCount());
	//const unsigned int numThreads = (unsigned int)std::min((int)ceil(point_count / 10000.0), (int)getSuggestedThreadCount());
	if(numThreads == 1)
	{
		unsigned int invalidCount;
		getSingleKDTreeCorrespondenceIndicesThreadMain(transform, correspondence_indices, correspondence_distances_squared, 0, point_count - 1, invalidCount);
		valid_count -= invalidCount;
	}
	else
	{
		vector<boost::shared_ptr<rgbd::thread> > threads(numThreads);
		const vector<unsigned int>& indices = partitionEvenly(point_count, numThreads);
		vector<unsigned int> invalidCounts(numThreads);
		for(unsigned int i = 0; i < numThreads; i++)
			threads[i] = boost::shared_ptr<rgbd::thread>(new rgbd::thread(rgbd::bind(&ICPCloudPair::getSingleKDTreeCorrespondenceIndicesThreadMain, this, rgbd::cref(transform), rgbd::ref(correspondence_indices), rgbd::ref(correspondence_distances_squared), indices[i], indices[i + 1] - 1, rgbd::ref(invalidCounts[i]))));
		for(unsigned int i = 0; i < numThreads; i++)
			threads[i]->join();
		for(unsigned int i = 0; i < numThreads; i++) {
			valid_count -= invalidCounts[i];
		}
	}
//	t.stop("get correspondence indices");

	// debug
//	std::cout << "Corrs:" << std::endl;
//	for (unsigned int i = 0; i < correspondence_indices.size(); i++) {
//		std::cout << correspondence_indices[i] << std::endl;
//	}

	return valid_count;
}

void ICPCloudPair::getColorBinningCorrespondenceIndicesThreadMain(rgbd::eigen::Affine3f const& transform, std::vector<int> & correspondence_indices, std::vector<float> & correspondence_distances_squared, const unsigned int firstIndex, const unsigned int lastIndex, unsigned int& invalid_count) const
{
	invalid_count = 0;

	for (unsigned int i = firstIndex; i <= lastIndex; ++i)
	{
		const srcPtT transformed_source = transform * m_source_eigen_points[i];
		const boost::shared_ptr<kdtree2>& tree = targetKDTreesByColor(sourcePtKDTreeIndices[i]);
		if(tree->numPoints() > 0)
		{
			const vector<unsigned int>& subcloudIndices = targetKDTreeIndices(sourcePtKDTreeIndices[i]);
			vector<float> qpt(3);
			for(unsigned int j = 0; j < 3; j++) qpt[j] = transformed_source[j];
			kdtree2_result_vector result;
			tree->n_nearest(qpt, 1, result);
			assert(result.size() == 1); //if this fails it could be because the transform is garbage
			correspondence_indices[i] = subcloudIndices[result[0].idx];
			correspondence_distances_squared[i] = result[0].dis;
		}
		else //target cloud has no points of similar color
		{
			correspondence_indices[i] = -1;
			correspondence_distances_squared[i] = -1; // also set distance to clearly invalid value (or MAX_FLOAT?)
			invalid_count++;
		}
	}
}

int ICPCloudPair::getColorBinningCorrespondenceIndices(rgbd::eigen::Affine3f const& transform, std::vector<int> & correspondence_indices, std::vector<float> & correspondence_distances_squared) const
{
	unsigned int point_count = m_source_eigen_points.size();
	correspondence_indices.resize(point_count);
	correspondence_distances_squared.resize(point_count);

//	rgbd::timer t;
	const unsigned int numThreads = (m_thread_params.search_threads > 0) ? m_thread_params.search_threads : (unsigned int)std::min((int)ceil(point_count / 10000.0), (int)	getSuggestedThreadCount());
	//const unsigned int numThreads = std::min((int)ceil(point_count / 10000), (int) getSuggestedThreadCount());
	unsigned int valid_count = point_count;
	if(numThreads < 2)
	{
		unsigned int invalidCount;
		getColorBinningCorrespondenceIndicesThreadMain(transform, correspondence_indices, correspondence_distances_squared, 0, point_count - 1, invalidCount);
		valid_count -= invalidCount;
	}
	else
	{
		vector<boost::shared_ptr<rgbd::thread> > threads(numThreads);
		const vector<unsigned int>& indices = partitionEvenly(point_count, numThreads);
		vector<unsigned int> invalidCounts(numThreads);
		for(unsigned int i = 0; i < numThreads; i++)
			threads[i] = boost::shared_ptr<rgbd::thread>(new rgbd::thread(rgbd::bind(&ICPCloudPair::getColorBinningCorrespondenceIndicesThreadMain, this, rgbd::cref(transform), rgbd::ref(correspondence_indices), rgbd::ref(correspondence_distances_squared), indices[i], indices[i + 1] - 1, rgbd::ref(invalidCounts[i]))));
		for(unsigned int i = 0; i < numThreads; i++)
			threads[i]->join();
		for(unsigned int i = 0; i < numThreads; i++) {
			valid_count -= invalidCounts[i];
		}
	}
//	t.stop("get correspondence indices");

	return valid_count;
}

void ICPCloudPair::getColor6DSearchCorrespondenceIndicesThreadMain(
		rgbd::eigen::Affine3f const& transform,
		std::vector<int> & correspondence_indices,
		std::vector<float> & correspondence_distances_squared,
		const unsigned int firstIndex, const unsigned int lastIndex) const
{
	for (unsigned int i = firstIndex; i <= lastIndex; ++i)
	{
		const srcPtT transformed_source = transform * m_source_eigen_points[i];
		vector<float> qpt(6);
		qpt[0] = transformed_source.x();
		qpt[1] = transformed_source.y();
		qpt[2] = transformed_source.z();
		qpt[3] = m_color_dimension_scaling * m_source_colors[i][0];
		qpt[4] = m_color_dimension_scaling * m_source_colors[i][1];
		qpt[5] = m_color_dimension_scaling * m_source_colors[i][2];
		kdtree2_result_vector result;
		m_6dsearch_target_kdtree_ptr->n_nearest(qpt, 1, result);
		correspondence_indices[i] = result[0].idx;
		correspondence_distances_squared[i] = result[0].dis;
	}
}

int ICPCloudPair::getColor6DSearchCorrespondenceIndices(rgbd::eigen::Affine3f const& transform, std::vector<int> & correspondence_indices, std::vector<float> & correspondence_distances_squared) const
{
	unsigned int point_count = m_source_eigen_points.size();
	correspondence_indices.resize(point_count);
	correspondence_distances_squared.resize(point_count);

	assert(m_source_colors.size() == m_source_eigen_points.size());
	assert(m_target_colors.size() == m_target_eigen_points.size());

	rgbd::timer t;
	//const unsigned int numThreads = (unsigned int)std::min((int)ceil(point_count / 10000.0), (int)getSuggestedThreadCount());
	const unsigned int numThreads = (m_thread_params.search_threads > 0) ? m_thread_params.search_threads : (unsigned int)std::min((int)ceil(point_count / 10000.0), (int)getSuggestedThreadCount());	
	vector<boost::shared_ptr<rgbd::thread> > threads(numThreads);
	const vector<unsigned int>& indices = partitionEvenly(point_count, numThreads);
	for(unsigned int i = 0; i < numThreads; i++)
		threads[i] = boost::shared_ptr<rgbd::thread>(new rgbd::thread(rgbd::bind(&ICPCloudPair::getColor6DSearchCorrespondenceIndicesThreadMain, this, rgbd::cref(transform), rgbd::ref(correspondence_indices), rgbd::ref(correspondence_distances_squared), indices[i], indices[i + 1] - 1)));
	for(unsigned int i = 0; i < numThreads; i++)
		threads[i]->join();
	t.stop("get correspondence indices");

	return point_count;
}

void ICPCloudPair::getColor5DSearchCorrespondenceIndicesThreadMain(
		rgbd::eigen::Affine3f const& transform,
		std::vector<int> & correspondence_indices,
		std::vector<float> & correspondence_distances_squared,
		const unsigned int firstIndex, const unsigned int lastIndex) const
{
	for (unsigned int i = firstIndex; i <= lastIndex; ++i)
	{
		const srcPtT transformed_source = transform * m_source_eigen_points[i];
		vector<float> qpt(5);
		qpt[0] = transformed_source.x();
		qpt[1] = transformed_source.y();
		qpt[2] = transformed_source.z();
		boost::array<float, 3> rgb_array = {{m_source_colors[i][0], m_source_colors[i][1], m_source_colors[i][2]}};
		boost::array<float, 2> extra_dims;
		switch(m_params.corrType) {
		case ICP_CORRS_COLOR_5D_HSV_SEARCH:
			extra_dims = rgbd::rgb2huecossin(rgb_array);
			qpt[3] = m_color_dimension_scaling * extra_dims[0];
			qpt[4] = m_color_dimension_scaling * extra_dims[1];
			break;
		case ICP_CORRS_COLOR_5D_LAB_SEARCH:
			assert(false && "unimplemented");
			break;
		default:
			assert(false && "wrong corr type to be here");
			break;
		}
		kdtree2_result_vector result;
		m_5dsearch_target_kdtree_ptr->n_nearest(qpt, 1, result);
		correspondence_indices[i] = result[0].idx;
		correspondence_distances_squared[i] = result[0].dis;
	}
}

int ICPCloudPair::getColor5DSearchCorrespondenceIndices(rgbd::eigen::Affine3f const& transform, std::vector<int> & correspondence_indices, std::vector<float> & correspondence_distances_squared) const
{
	unsigned int point_count = m_source_eigen_points.size();
	correspondence_indices.resize(point_count);
	correspondence_distances_squared.resize(point_count);

	assert(m_source_colors.size() == m_source_eigen_points.size());
	assert(m_target_colors.size() == m_target_eigen_points.size());

	rgbd::timer t;
	//const unsigned int numThreads = (unsigned int)std::min((int)ceil(point_count / 10000.0), (int)getSuggestedThreadCount());
	const unsigned int numThreads = (m_thread_params.search_threads > 0) ? m_thread_params.search_threads : (unsigned int)std::min((int)ceil(point_count / 10000.0), (int)getSuggestedThreadCount());	
	vector<boost::shared_ptr<rgbd::thread> > threads(numThreads);
	const vector<unsigned int>& indices = partitionEvenly(point_count, numThreads);
	for(unsigned int i = 0; i < numThreads; i++)
		threads[i] = boost::shared_ptr<rgbd::thread>(new rgbd::thread(rgbd::bind(&ICPCloudPair::getColor5DSearchCorrespondenceIndicesThreadMain, this, rgbd::cref(transform), rgbd::ref(correspondence_indices), rgbd::ref(correspondence_distances_squared), indices[i], indices[i + 1] - 1)));
	for(unsigned int i = 0; i < numThreads; i++)
		threads[i]->join();
	t.stop("get correspondence indices");

	return point_count;
}

void ICPCloudPair::getColorCompatibilityCorrespondenceIndicesThreadMain(
		rgbd::eigen::Affine3f const& transform,
		std::vector<int> & correspondence_indices,
		std::vector<float> & correspondence_distances_squared,
		const unsigned int firstIndex, const unsigned int lastIndex, unsigned int& invalid_count) const
{
	double maxSqColorDist = pow(m_color_compatibility_max_dist,2);

	invalid_count = 0;

	for (unsigned int i = firstIndex; i <= lastIndex; ++i)
	{
		const rgbd::eigen::Vector4f transformed_source = transform * m_source_eigen_points[i];

		int bestIndex = -1;
		float bestCompatibleSqDist = 0;
		for(unsigned int j=0; j<m_target_eigen_points.size(); ++j){
			float sqSpatialDist = (transformed_source-m_target_eigen_points[j]).squaredNorm();
			float sqColorDist = (m_source_colors[i]-m_target_colors[j]).squaredNorm();

			if(sqColorDist <= maxSqColorDist && (bestIndex < 0 || sqSpatialDist < bestCompatibleSqDist)){
				bestIndex = j;
				bestCompatibleSqDist = sqSpatialDist;
			}
		}

		correspondence_indices[i] = bestIndex;
		correspondence_distances_squared[i] = bestCompatibleSqDist;

		if(bestIndex < 0)
			invalid_count++;
	}
}

int ICPCloudPair::getColorCompatibilityCorrespondenceIndices(
		rgbd::eigen::Affine3f const& transform, std::vector<int> & correspondence_indices,
		std::vector<float> & correspondence_distances_squared) const
{
	unsigned int point_count = m_source_eigen_points.size();
	correspondence_indices.resize(point_count);
	correspondence_distances_squared.resize(point_count);

	assert(m_source_colors.size() == m_source_eigen_points.size());
	assert(m_target_colors.size() == m_target_eigen_points.size());

	rgbd::timer t;
	const unsigned int numThreads = getSuggestedThreadCount();
	vector<boost::shared_ptr<rgbd::thread> > threads(numThreads);
	const vector<unsigned int>& indices = partitionEvenly(point_count, numThreads);
	vector<unsigned int> invalidCounts(numThreads);
	for(unsigned int i = 0; i < numThreads; i++)
		threads[i] = boost::shared_ptr<rgbd::thread>(new rgbd::thread(rgbd::bind(&ICPCloudPair::getColorCompatibilityCorrespondenceIndicesThreadMain, this, rgbd::cref(transform), rgbd::ref(correspondence_indices), rgbd::ref(correspondence_distances_squared), indices[i], indices[i + 1] - 1, rgbd::ref(invalidCounts[i]))));
	unsigned int valid_count = point_count;
	for(unsigned int i = 0; i < numThreads; i++)
		threads[i]->join();
	for(unsigned int i = 0; i < numThreads; i++) {
		valid_count -= invalidCounts[i];
	}
	t.stop("get correspondence indices");

	return valid_count;
}


int ICPCloudPair::getCorrespondenceIndices(rgbd::eigen::Affine3f const& transform, std::vector<int> & correspondence_indices) const
{
	unsigned int point_count = m_source_eigen_points.size();
	// if correspondence is fixed, correspondence is just index
	if (m_params.fixed_correspondence) {
		correspondence_indices.resize(point_count);
		for (unsigned int i = 0; i < point_count; ++i) {
			correspondence_indices[i] = i;
		}
		return point_count;
	}

	// these functions no longer filter by outlier distance, etc....only invalid points come from no matching color
	int valid_indices_from_search = 0; // currently ignored...filter will check for -1's
	std::vector<float> correspondence_distances_squared;
	switch(m_params.corrType)
	{
		case ICP_CORRS_SINGLE_TREE:
			valid_indices_from_search = getSingleKDTreeCorrespondenceIndices(transform, correspondence_indices, correspondence_distances_squared);
			break;
		case ICP_CORRS_COLOR_BINNING:
			valid_indices_from_search = getColorBinningCorrespondenceIndices(transform, correspondence_indices, correspondence_distances_squared);
			break;
		case ICP_CORRS_COLOR_6D_SEARCH:
			valid_indices_from_search = getColor6DSearchCorrespondenceIndices(transform, correspondence_indices, correspondence_distances_squared);
			break;
		case ICP_CORRS_COLOR_5D_LAB_SEARCH:
		case ICP_CORRS_COLOR_5D_HSV_SEARCH:
			valid_indices_from_search = getColor5DSearchCorrespondenceIndices(transform, correspondence_indices, correspondence_distances_squared);
			break;
		case ICP_CORRS_COLOR_COMPATIBILITY:
			valid_indices_from_search = getColorCompatibilityCorrespondenceIndices(transform,correspondence_indices,correspondence_distances_squared);
			break;
		case ICP_CORRS_REPROJECTION:
			valid_indices_from_search = getReprojectionCorrespondenceIndices(transform, correspondence_indices, correspondence_distances_squared);
			break;
		default: assert(false);
	}

	return filterCorrespondenceIndices(transform, correspondence_indices, correspondence_distances_squared);
}

int ICPCloudPair::filterCorrespondenceIndices(rgbd::eigen::Affine3f const& transform, std::vector<int> & correspondence_indices, const std::vector<float> & correspondence_distances_squared) const
{
	//rgbd::timer t;
	const unsigned int point_count = correspondence_indices.size();

	if(m_params.filter_on_geometric_consistency)
	{
		vector<unsigned int> validCorrIndices; //indices w/ valid correspondences
		for(unsigned int i = 0; i < point_count; i++)
			if(correspondence_indices[i] >= 0)
				validCorrIndices.push_back(i);

		const unsigned int numRANSACIters = 1000; //TODO parameterize
		const unsigned int sampleSize = 3; //TODO parameterize
		const float maxInlierDiffNorm = .005; //TODO parameterize
		vector<unsigned int> sampleIndices(sampleSize);
		Affine3f bestModel;
		vector<bool> bestInlierIndices(point_count, false); //for 30k pts, about 2.1x as fast as using set<unsigned int>
		unsigned int numBestInlierIndices = 0;
		for(unsigned int j = 0; j < numRANSACIters; j++)
		{
			randomSample(validCorrIndices.begin(), validCorrIndices.end(), sampleSize, sampleIndices.begin());

			deque<pair<Vector3f, Vector3f> > sampledCorrPts(sampleSize);
			for(unsigned int i = 0; i < sampleSize; i++)
			{
				sampledCorrPts[i].first = m_source_eigen_points[sampleIndices[i]].head<3>();
				sampledCorrPts[i].second = m_target_eigen_points[correspondence_indices[sampleIndices[i]]].head<3>();
			}
			const vector<float> corrWeights(sampleSize, 1);
			Quaternionf rot;
			Vector3f xlate;
			registration::runClosedFormAlignment(sampledCorrPts, corrWeights, rot, xlate);
			const Affine3f model = Translation3f(xlate) * rot;

			vector<bool> inlierIndices(point_count, false);
			unsigned int numInlierIndices = 0;
			for(unsigned int i = 0; i < validCorrIndices.size(); i++)
				if((model * m_source_eigen_points[validCorrIndices[i]] - m_target_eigen_points[correspondence_indices[validCorrIndices[i]]]).squaredNorm() < sqr(maxInlierDiffNorm))
				{
					inlierIndices[validCorrIndices[i]] = true;
					numInlierIndices++;
				}

			if(numInlierIndices > numBestInlierIndices)
			{
				bestModel = model;
				bestInlierIndices = inlierIndices;
				numBestInlierIndices = numInlierIndices;
			}
		}
		cout << "ransac found " << numBestInlierIndices << " inliers of " << point_count << " pts" << endl;
		/*
		 * set invalid all correspondences for pts that aren't inliers
		 */
		for(unsigned int i = 0; i < point_count; i++)
			if(!bestInlierIndices[i])
				correspondence_indices[i] = -1;
	}

	// filter out those beyond the max distance
	// invalid correspondences will be -1
	if (m_params.max_distance > 0.0) {
		const float max_distance_squared = m_params.max_distance * m_params.max_distance;
		for (unsigned int i = 0; i < point_count; ++i) {
			if (correspondence_indices[i] >= 0) {
				if (correspondence_distances_squared[i] > max_distance_squared) {
					correspondence_indices[i] = -1;
				}
			}
		}
	}

	//check for boundary matches
	if (!m_target_is_boundary.empty())
	{
		for(unsigned int i=0; i<point_count; i++)
		{
			if(correspondence_indices[i] >= 0 && m_target_is_boundary[correspondence_indices[i]])
			{
				correspondence_indices[i] = -1;
			}
		}
	}

	// separate out normal check so normals aren't always required
	if (!m_params.front_can_match_back) {
		for (unsigned int i = 0; i < point_count; ++i) {
			if (correspondence_indices[i] >= 0) {
				const normalT transformed_normal = transform * m_source_eigen_normals[i];
				const float normal_dot_product = transformed_normal.dot(m_target_eigen_normals[correspondence_indices[i]]);
				if (normal_dot_product < 0) {
					correspondence_indices[i] = -1;
				}
			}
		}
	}

	// NOTE: This is a general version of the above "front can match back"
	if (m_params.max_normal_angle > 0) {
		float min_cos_value = cos(m_params.max_normal_angle);
		for (unsigned int i = 0; i < point_count; ++i) {
			if (correspondence_indices[i] >= 0) {
				const normalT transformed_normal = transform * m_source_eigen_normals[i];
				const float normal_dot_product = transformed_normal.dot(m_target_eigen_normals[correspondence_indices[i]]);
				if (normal_dot_product < min_cos_value) {
					correspondence_indices[i] = -1;
				}
			}
		}
	}

	if (m_params.no_many_to_one_correspondences) {
		// starts at -1.
		// Set to source index of first souce point that hits it
		// If a second source point hits it, reset both correspondences and set targeted_by to -2
		// Thus subsequent source points will be set to -1 if they hit a -2
		vector<int> targeted_by(m_target_eigen_points.size(), -1);
		for (unsigned int i = 0; i < point_count; ++i) {
			if (correspondence_indices[i] >= 0) {
				int target_index = correspondence_indices[i];
				if (targeted_by[target_index] == -1) {
					targeted_by[target_index] = (int) i;
				}
				else if (targeted_by[target_index] >= 0) {
					correspondence_indices[targeted_by[target_index]] = -1;
					correspondence_indices[i] = -1;
					targeted_by[target_index] = -2;
				}
				else if (targeted_by[target_index] == -2) {
					correspondence_indices[i] = -1;
				}
				else {
					assert(false && "how did you get here?");
				}
			}
		}
	}

	// remove a percentage of the largest correspondences (includes those set to -1)
	if (m_params.outlier_percentage > 0) {
		assert(m_params.outlier_percentage < 1.0);
		// sort pairs of <distance_squared, index> to obtain indices to set to -1
		std::vector<std::pair<float, unsigned int> > distance_pairs;
		for (unsigned int i = 0; i < point_count; i++)
			if(correspondence_indices[i] == -1)
				distance_pairs.push_back(std::make_pair(std::numeric_limits<float>::max(), i));
			else
				distance_pairs.push_back(std::make_pair(correspondence_distances_squared[i], i));
		std::sort(distance_pairs.begin(), distance_pairs.end());

		// now are in increasing order, so from the cutoff index to the end are set to -1
		unsigned int cutoff_index = (1.0 - m_params.outlier_percentage) * point_count;
		for (unsigned int i = cutoff_index; i < point_count; i++) {
			unsigned int source_index_to_eliminate = distance_pairs[i].second;
			correspondence_indices[source_index_to_eliminate] = -1;
		}
	}

	//t.stop("filter correspondences");

	return getValidCorrespondenceIndexCount(correspondence_indices);
}

float ICPCloudPair::getTargetIntensity(
		rgbd::eigen::Vector2f const& projection,rgbd::eigen::Vector2f const& corrPixel) const
{
	assert(m_color_error_term_enabled);

	if(projection.x() > 0 && projection.x() < m_camera_params.xRes-1 &&
			projection.y() > 0 && projection.y() < m_camera_params.yRes-1)
	{
		//use the actual, interpolated intensity
		int x_floor = (int)projection.x();
		int y_floor = (int)projection.y();

		//between 0 and 1
		float x_resid = projection.x() - x_floor;
		float y_resid = projection.y() - y_floor;
		//C for ceiling, F for floor
		float coefCC = x_resid*y_resid;
		float coefCF = x_resid*(1-y_resid);
		float coefFC = (1-x_resid)*y_resid;
		float coefFF = (1-x_resid)*(1-y_resid);

		float result = coefFF * m_target_intensity_grid[x_floor][y_floor] +
				coefFC * m_target_intensity_grid[x_floor][y_floor+1] +
				coefCF * m_target_intensity_grid[x_floor+1][y_floor] +
				coefCC * m_target_intensity_grid[x_floor+1][y_floor+1];

		return result;
	}
	else
	{
		//use a first order, gradient-based approximation
		rgbd::eigen::Vector2f delta = projection-corrPixel;
		rgbd::eigen::Vector2f const&gradient = m_target_gradient_grid[corrPixel.x()][corrPixel.y()];

		float result = m_target_intensity_grid[corrPixel.x()][corrPixel.y()]+gradient.dot(delta);
		if(result < 0)
			result = 0;
		if(result > 1)
			result = 1;

		return result;
	}
}

void ICPCloudPair::getSourceErrorVector(rgbd::eigen::Affine3f const& transform,
	std::vector<int> const& correspondence_indices, std::vector<float> & result) const
{
	switch(m_params.errType)
	{
		case ICP_ERR_POINT_TO_POINT:
		{
			assert(m_params.wtType == ICP_WTS_SCALAR); //rest unimplemented
			icp::point2point::getSourceErrorVector(m_source_eigen_points, m_scalar_weights, transform, correspondence_indices, result);
			break;
		}
		case ICP_ERR_POINT_TO_PLANE:
		{
			switch(m_params.wtType)
			{
				case ICP_WTS_SCALAR:
					icp::point2plane::getSourceErrorVector(m_source_eigen_points, m_target_eigen_normals, m_scalar_weights, transform, correspondence_indices, result);
					break;
				case ICP_WTS_MATRIX:
					icp::point2plane::getSourceErrorVector(m_source_eigen_points,
						m_target_eigen_points, m_target_eigen_normals,
						m_matrix_weights, transform, correspondence_indices, result);
					break;
				default: assert(false);
			}
			break;
		}
		case ICP_ERR_POINT_TO_LINE:
		{
			assert(m_params.wtType == ICP_WTS_SCALAR);
			assert(false); //TODO: call to icp::point2line::getSourceErrorVector goes here
		}
		case ICP_ERR_PLANAR_PATCH:
		{
			assert(m_params.wtType == ICP_WTS_SCALAR); //rest unimplemented
			icp::planarPatch::getSourceErrorVector(m_source_eigen_points, m_source_eigen_normals, m_target_eigen_points, m_target_eigen_normals, m_scalar_weights, transform, correspondence_indices, result);
			break;
		}
		case ICP_ERR_REPROJECTION:
		{
			assert(m_params.wtType == ICP_WTS_SCALAR); //rest unimplemented
			assert(m_rgbd_camera_params_ptr); // must have been set by setReprojectionError
			icp::point2pointReprojection::getSourceErrorVector(m_rgbd_camera_params_ptr, m_stereo_baseline, m_source_eigen_points, m_scalar_weights, transform, correspondence_indices, result);
			break;
		}
		default: assert(false);
	}

	if (m_params.use_average_point_error)
	{
		float one_over_sqrt_point_count = 1.0 /
			sqrt(getValidCorrespondenceIndexCount(correspondence_indices));
		for (std::vector<float>::iterator it = result.begin(); it != result.end(); ++it) {
			*it *= one_over_sqrt_point_count;
		}
	}

	if (m_color_error_term_enabled)
	{
		uint color_match_count = 0;
		uint result_size_before = result.size();
		//estimated target intensity at the transformed source's location
		for(unsigned int i=0; i<m_source_intensities.size(); i++){
			if(correspondence_indices[i] >= 0 && m_source_intensities[i] <= m_color_matching_max_intensity){
				//get the correspondence's pixel location
				const int corrX = m_targetImgCoords[correspondence_indices[i]].first, corrY = m_targetImgCoords[correspondence_indices[i]].second;

				if(m_target_intensity_grid[corrX][corrY] > m_color_matching_max_intensity)
					continue;

				rgbd::eigen::Vector2f corrPix(corrX,corrY);

				//project the new point into the image plane
				srcPtT transformedSource = transform*m_source_eigen_points[i];
				rgbd::eigen::Vector2f projection;
				projection.x() = transformedSource.x()/transformedSource.z()*
						m_camera_params.focalLength+m_camera_params.centerX;
				projection.y() = transformedSource.y()/transformedSource.z()*
						m_camera_params.focalLength+m_camera_params.centerY;

				//store the intensity of the projection in the target image
				result.push_back(m_color_matching_weight*this->getTargetIntensity(projection,corrPix));
				color_match_count++;
			}
		}

		if (m_params.use_average_point_error) {
			float one_over_sqrt_color_match_count = 1.0 /
				sqrt(color_match_count);
			for (std::vector<float>::iterator it = result.begin()+result_size_before; it != result.end(); ++it) {
				*it *= one_over_sqrt_color_match_count;
			}
		}
	}
}

void ICPCloudPair::getTargetErrorVector(std::vector<int> const& correspondence_indices, std::vector<float> & result) const
{
	switch(m_params.errType)
	{
		case ICP_ERR_POINT_TO_POINT:
		{
			assert(m_params.wtType == ICP_WTS_SCALAR); //rest unimplemented
			icp::point2point::getTargetErrorVector(m_target_eigen_points, m_scalar_weights, correspondence_indices, result);
			break;
		}
		case ICP_ERR_POINT_TO_PLANE:
		{
			switch(m_params.wtType)
			{
				case ICP_WTS_SCALAR:
					icp::point2plane::getTargetErrorVector(m_target_eigen_points, m_target_eigen_normals, m_scalar_weights, correspondence_indices, result);
					break;
				case ICP_WTS_MATRIX:
					icp::point2plane::getTargetErrorVector(m_target_eigen_points, m_target_eigen_normals, m_matrix_weights, correspondence_indices, result);
					break;
				default: assert(false);
			}
			break;
		}
		case ICP_ERR_POINT_TO_LINE:
		{
			assert(m_params.wtType == ICP_WTS_SCALAR);
			assert(false); //TODO: call to icp::point2line::getTargetErrorVector goes here
		}
		case ICP_ERR_PLANAR_PATCH:
		{
			assert(m_params.wtType == ICP_WTS_SCALAR); //rest unimplemented
			icp::planarPatch::getTargetErrorVector(m_target_eigen_points, m_target_eigen_normals, m_scalar_weights, correspondence_indices, result);
			break;
		}
		case ICP_ERR_REPROJECTION:
		{
			assert(m_params.wtType == ICP_WTS_SCALAR); //rest unimplemented
			assert(m_rgbd_camera_params_ptr); // must have been set by setReprojectionError
			icp::point2pointReprojection::getTargetErrorVector(m_rgbd_camera_params_ptr, m_stereo_baseline, m_target_eigen_points, m_scalar_weights, correspondence_indices, result);
			break;
		}
		default: assert(false);
	}

	if (m_params.use_average_point_error)
	{
		float one_over_sqrt_point_count = 1.0 / sqrt(getValidCorrespondenceIndexCount(correspondence_indices));
		for (std::vector<float>::iterator it = result.begin(); it != result.end(); ++it) {
			*it *= one_over_sqrt_point_count;
		}
	}

	if (m_color_error_term_enabled)
	{
		uint color_match_count = 0;
		uint result_size_before = result.size();
		//backwards w.r.t. source vs target, but difference of the two turns out right
		for(unsigned int i=0; i<m_source_intensities.size(); i++){
			if(correspondence_indices[i] >= 0 && m_source_intensities[i] <= m_color_matching_max_intensity){
				const int corrX = m_targetImgCoords[correspondence_indices[i]].first, corrY = m_targetImgCoords[correspondence_indices[i]].second;

				if(m_target_intensity_grid[corrX][corrY] > m_color_matching_max_intensity)
					continue;

				result.push_back(m_color_matching_weight*m_source_intensities[i]);
				color_match_count++;
			}
		}

		if (m_params.use_average_point_error)
		{
			float one_over_sqrt_color_match_count = 1.0 /
				sqrt(color_match_count);
			for (std::vector<float>::iterator it = result.begin()+result_size_before; it != result.end(); ++it) {
				*it *= one_over_sqrt_color_match_count;
			}
		}
	}

}

float ICPCloudPair::getError(rgbd::eigen::Affine3f const& transform, std::vector<int> const& correspondence_indices) const
{
	std::vector<float> source_vector;
	getSourceErrorVector(transform, correspondence_indices, source_vector);

	std::vector<float> target_vector;
	getTargetErrorVector(correspondence_indices, target_vector);

	assert(source_vector.size() == target_vector.size());

	float result = 0.0;
	for (unsigned int i = 0; i < source_vector.size(); ++i)
	{
		float diff = source_vector[i] - target_vector[i];
		result += diff * diff;
	}
	return result;
}

void ICPCloudPair::getPoints(std::vector<rgbd::eigen::Vector3f> &source_points, std::vector<rgbd::eigen::Vector3f> &target_points)
{
	source_points.resize(m_source_eigen_points.size());
	for(unsigned int i = 0; i < source_points.size(); i++) source_points[i] = m_source_eigen_points[i].head<3>();
	target_points.resize(m_target_eigen_points.size());
	for(unsigned int i = 0; i < target_points.size(); i++) target_points[i] = m_target_eigen_points[i].head<3>();
}

ICPCloudPair::srcPtT ICPCloudPair::getSourcePoint(unsigned int i)
{
	return m_source_eigen_points.at(i);
}

ICPCloudPair::normalT ICPCloudPair::getSourceNormal(unsigned int i)
{
	return m_source_eigen_normals.at(i);
}

ICPCloudPair::tgtPtT ICPCloudPair::getTargetPoint(unsigned int i)
{
	return m_target_eigen_points.at(i);
}

ICPCloudPair::normalT ICPCloudPair::getTargetNormal(unsigned int i)
{
	return m_target_eigen_normals.at(i);
}

/*
 * throw if we aren't using scalar weights
 */
const std::vector<float>& ICPCloudPair::getPointWeights()
{
	if(m_params.wtType != ICP_WTS_SCALAR) throw std::invalid_argument("getPointWeights() only gets scalar weights");
	return m_scalar_weights;
}

int ICPCloudPair::getValidCorrespondenceIndexCount(const std::vector<int> & correspondence_indices) const
{
	int valid_count = 0;
	for (std::vector<int>::const_iterator it = correspondence_indices.begin(); it != correspondence_indices.end(); ++it) {
		if (*it >= 0) valid_count++;
	}
	if(valid_count < .01/* TODO parameterize */ * correspondence_indices.size())
	{
		cout << "WARNING in ICP: there are very few valid correspondences in a cloud pair (" << valid_count << " of " << correspondence_indices.size() << ")" << endl;
	}
	return valid_count;
}

float ICPCloudPair::getMaxDistance()
{
	return m_params.max_distance;
}

void ICPCloudPair::setMaxDistance(float new_value)
{
	m_params.max_distance = new_value;
}

void ICPCloudPair::setParams(const ICPCloudPairParams & params)
{
	m_params = params;
}

void ICPCloudPair::setThreadParams(const ICPThreadParams & thread_params)
{
	m_thread_params = thread_params;
}

/************************************************************************************************************************
 * ICPCombined
 */

ICPCombined::ICPCombined()
{
	m_initial_transform.setIdentity();
	m_use_ground_plane_coefficients = false;
}


ICPCombined::~ICPCombined() {
	// nothing yet (vectors will destroy shared pointers, which will take care of cloud pairs)
}

void
ICPCombined::setParams(ICPCombinedParams const& params)
{
	m_params = params;
}

void
ICPCombined::setCloudPairParams(unsigned int cloud_pair_index, ICPCloudPairParams const& params)
{
	m_cloud_pair_list.at(cloud_pair_index)->setParams(params);
}

void 
ICPCombined::setCloudThreadPrams(unsigned int cloud_pair_index, ICPThreadParams const& thread_params)
{
	m_cloud_pair_list.at(cloud_pair_index)->setThreadParams(thread_params);

}


void ICPCombined::addCloudPair(boost::shared_ptr<ICPCloudPair> p, float cloud_pair_weight)
{
	assert(p);
	m_cloud_pair_list.push_back(p);
	m_cloud_pair_weights.push_back(0);
	setCloudPairWeight(m_cloud_pair_weights.size() - 1, cloud_pair_weight);
}

void ICPCombined::setCloudPairWeight(unsigned int cloud_pair_index, float cloud_pair_weight)
{
	// we store the square root of the weights because LM squares them (just as with point_weights)
	float sqrt_cloud_weight = sqrt(cloud_pair_weight);
	m_cloud_pair_weights.at(cloud_pair_index) = sqrt_cloud_weight;
}

boost::shared_ptr<ICPCloudPair> ICPCombined::getCloudPair(unsigned int index)
{
	assert(index < m_cloud_pair_list.size());
	return m_cloud_pair_list[index];
}

void ICPCombined::setGroundPlaneCoefficients(
		const pcl::ModelCoefficients& curr_ground_plane_coefficients,
		const pcl::ModelCoefficients& prev_ground_plane_coefficients)
{
	m_use_ground_plane_coefficients = true;
	m_source_ground_plane_coefficients = curr_ground_plane_coefficients;
	m_target_ground_plane_coefficients = prev_ground_plane_coefficients;

}

void ICPCombined::pushErrorVecsHistory(const rgbd::eigen::Affine3f& xform)
{
	m_errorVecsHistory.resize(m_errorVecsHistory.size() + 1);
	vector<vector<float> >& errVecs = m_errorVecsHistory.back();
	errVecs.resize(m_cloud_pair_list.size());
	for(unsigned int i = 0; i < m_cloud_pair_list.size(); i++)
	{
		vector<float> srcVec, tgtVec;
		m_cloud_pair_list[i]->getSourceErrorVector(xform, m_correspondence_lists[i], srcVec);
		m_cloud_pair_list[i]->getTargetErrorVector(m_correspondence_lists[i], tgtVec);
		assert(srcVec.size() == tgtVec.size());
		for(unsigned int j = 0; j < srcVec.size(); j++)
		{
			const double err = srcVec[j] - tgtVec[j];
			srcVec[j] = err * err;
		}
		errVecs[i] = srcVec;
	}
}

float
ICPCombined::runICP2(const bool verbose) {
  return final_error = runICP(result, verbose);
}
  

float
ICPCombined::runICP(rgbd::eigen::Affine3f& result, const bool verbose) {
	if(verbose) 
 		cout << "ICP BEGIN..................." << endl;

	// reset history before each run
	m_transform_history.clear();
	m_correspondencesHistory.clear();
	m_totalErrorHistory.clear();
	m_errorVecsHistory.clear();

	rgbd::eigen::Affine3f previous_transform = m_initial_transform;
	rgbd::eigen::Affine3f new_transform = m_initial_transform;
	float previous_error = 0.0;
	float new_error = 0.0;

	m_correspondence_lists.resize(m_cloud_pair_list.size());

	int icp_iteration_count = 0;
	do {
		previous_transform = new_transform;
		previous_error = new_error;

		// update the correspondences
		int total_valid = 0;
		for (unsigned int pair_index = 0; pair_index < m_cloud_pair_list.size(); pair_index++) {
			int valid_count_for_pair = m_cloud_pair_list[pair_index]->getCorrespondenceIndices(new_transform, m_correspondence_lists[pair_index]);
			if(verbose) cout << "pair " << pair_index << ": " << valid_count_for_pair << " valid corrs" << endl;
			total_valid += valid_count_for_pair;
		}

		if(icp_iteration_count == 0) //details before any optimization
		{
			m_transform_history.push_back(new_transform);
			m_totalErrorHistory.push_back(getError(new_transform));
			m_correspondencesHistory.push_back(m_correspondence_lists);
			pushErrorVecsHistory(new_transform);
		}

		// if we do not have enough correspondences to have a reasonable optimization, return false
		if (total_valid < 3) {
			return -1;
		}

		// optimize for these correspondences
		new_transform = optimize(previous_transform);

		// getError() duplicates what LevMar is doing
		//new_error = getError(new_transform);
		// this is equivalent but gives breakdown by cloud pair
		new_error = getErrorBreakdown(new_transform, verbose);
		//if(verbose) ROS_INFO_STREAM("ICP Error:" << new_error);
		if(verbose) cout << "ICP Error: " << new_error << endl;

		m_transform_history.push_back(new_transform);
		m_totalErrorHistory.push_back(new_error);
		m_correspondencesHistory.push_back(m_correspondence_lists);
		pushErrorVecsHistory(new_transform);

		icp_iteration_count++;
	}
	while(!(m_params.max_icp_rounds > 0 && icp_iteration_count >= m_params.max_icp_rounds) &&
			shouldContinue(previous_error, new_error, previous_transform, new_transform, verbose));

	result = new_transform;

	return new_error;

	cout << "ICP END..................." << endl;
}

void
ICPCombined::setInitialTransform(rgbd::eigen::Affine3f const& t) {
	m_initial_transform = t;
}

// private:

float
ICPCombined::getError(rgbd::eigen::Affine3f const& transform) {
	// could call getError on each cloud, but we'll duplicate what levmar is doing

	std::vector<float> source_error_vector;
	getSourceErrorVector(transform, source_error_vector);

	std::vector<float> target_error_vector;
	getTargetErrorVector(target_error_vector);

	float result = 0.0;
	for (unsigned int i = 0; i < source_error_vector.size(); i++) {
		float diff = source_error_vector[i] - target_error_vector[i];
		result += diff * diff;
	}

	return result;
}

float
ICPCombined::getErrorBreakdown(rgbd::eigen::Affine3f const& transform, bool verbose) {
	if(verbose) cout << "ICP Error Breakdown:" << endl;
	float total_error = 0.0;
	for (unsigned int pair_index = 0; pair_index < m_cloud_pair_list.size(); pair_index++) {
		float pair_error = m_cloud_pair_list[pair_index]->getError(transform, m_correspondence_lists[pair_index]);
		float pair_sqrt_weight = m_cloud_pair_weights[pair_index];
		float pair_weight = pair_sqrt_weight * pair_sqrt_weight;
		float weighted_error = pair_weight * pair_error;
		total_error += weighted_error;
		if(verbose) cout << "ICP Cloud Pair: " << pair_index << " | Weight: " << pair_weight << " | Error: " << weighted_error << endl;
	}
	// Assume this will be output later:
	//ROS_INFO_STREAM("ICP Total Error: " << total_error);

	return total_error;
}


bool
ICPCombined::shouldContinue(float previous_error,
		float new_error,
		rgbd::eigen::Affine3f const& previous_transform,
		rgbd::eigen::Affine3f const& new_transform,
		bool verbose)
{
	bool any_conditions_set = false;

	if (m_params.min_error_frac_to_continue >= 0) {
		any_conditions_set = true;
		float error_ratio = fabs(new_error - previous_error) / new_error;
		if (verbose) {
			cout << "error ratio: " << error_ratio << endl;
		}
		if (error_ratio >= m_params.min_error_frac_to_continue) {
			return true;
		}
	}

	if (m_params.min_dist_to_continue >= 0) {
		any_conditions_set = true;
		float distance = (previous_transform.translation() - new_transform.translation()).norm();
		if (verbose) {
			cout << "distance: " << distance << endl;
		}
		if (distance > m_params.min_dist_to_continue) {
			return true;
		}
	}

	if (m_params.min_rot_to_continue >= 0) {
		any_conditions_set = true;
		rgbd::eigen::Quaternionf previous_rotation (previous_transform.linear());
		rgbd::eigen::Quaternionf new_rotation (new_transform.linear());
		float angle = previous_rotation.angularDistance(new_rotation);
		if (verbose) {
			cout << "angle: " << angle << endl;
		}
		if (angle > m_params.min_rot_to_continue) {
			return true;
		}
	}

	return (!any_conditions_set);
}

rgbd::eigen::Affine3f
ICPCombined::optimize(rgbd::eigen::Affine3f const& transform) {
	switch(m_params.optimizer)
	{
		case OPTIMIZER_LEVMAR:
			return optimizeLevmar(transform);
		case OPTIMIZER_CMINPACK_LM:
			return optimizeCMinpackLM(transform);
		case OPTIMIZER_EIGEN_LM:
			return optimizeEigenLM(transform);
		case OPTIMIZER_CLOSED_FORM:
			//TODO: check that all cloud pairs are point to point
			return optimizeClosedForm();
		default:
			assert(false);
			return rgbd::eigen::Affine3f();
	}
}

rgbd::eigen::Affine3f
ICPCombined::optimizeClosedForm() {

	std::deque<std::pair<rgbd::eigen::Vector3f,rgbd::eigen::Vector3f> > correspondences;
	std::vector<float> weights;

	for (unsigned int pair_index = 0; pair_index < m_cloud_pair_list.size(); pair_index++) {
//		float pair_sqrt_weight = m_cloud_pair_weights[pair_index];
//		float pair_weight = pair_sqrt_weight * pair_sqrt_weight;

		std::vector<rgbd::eigen::Vector3f> source_points,target_points;
		m_cloud_pair_list[pair_index]->getPoints(source_points,target_points);
		std::vector<float> point_weights = m_cloud_pair_list[pair_index]->getPointWeights();

		for(unsigned int corr = 0; corr < m_correspondence_lists[pair_index].size(); corr++){
			int targetIndex = m_correspondence_lists[pair_index][corr];
			if(targetIndex < 0)
				continue;
			else{
				correspondences.push_back(std::pair<rgbd::eigen::Vector3f,rgbd::eigen::Vector3f>(source_points[corr],target_points[targetIndex]));
				weights.push_back(pow(point_weights[corr],2));
			}
		}
	}

	rgbd::eigen::Quaternionf rotation;
	rgbd::eigen::Vector3f translation;
	runClosedFormAlignment(correspondences,weights,rotation,translation);
	rgbd::eigen::Affine3f transform(rotation);
	transform.pretranslate(translation);

	return transform;
}

rgbd::eigen::Affine3f
ICPCombined::optimizeLevmar(rgbd::eigen::Affine3f const& transform) {
#ifndef USE_LEVMAR
	assert(false && "USE_LEVMAR not defined during build");
#else
	// collect measurements from current correspondences
	std::vector<float> measurement_vector;
	getTargetErrorVector(measurement_vector);
//	cout << "tgtErr "; std::copy(measurement_vector.begin(), measurement_vector.end(), std::ostream_iterator<float>(cout, " ")); cout << endl;

	// prepare the state for LM
	std::vector<float> transform_as_float_vector;
	xf::convertTransformToSTDVector(transform, transform_as_float_vector);

	// debug
	error_function_call_count = 0;

	// numeric gradient
	int actual_iteration_count = slevmar_dif(optimizeLevmarErrorFunction, transform_as_float_vector.data(), measurement_vector.data(),
			transform_as_float_vector.size(), measurement_vector.size(), m_params.max_lm_rounds, NULL, NULL, NULL, NULL, (void*)this);

//	std::cout << "LevMar Iterations:" << actual_iteration_count << std::endl;
//	std::cout << "Error function call count:" << error_function_call_count << std::endl;

	// since we passed in the data() of the transform_as_float_vector, it now holds the result state
	rgbd::eigen::Affine3f result_transform;
	xf::convertSTDVectorToTransform(transform_as_float_vector, result_transform);
	return result_transform;
#endif
}

void
ICPCombined::optimizeLevmarErrorFunction(float *p, float *x, int m, int n, void *data) {
#ifndef USE_LEVMAR
	assert(false && "USE_LEVMAR not defined during build");
#else
	//p are parameters (i.e. state)
	//m is size of parameter vector
	//n is measurement vector size (i.e 3X num corr)
	//data has a pointer to "this"
	ICPCombined *icp_combined = (ICPCombined *)data;

	// assuming quaternion[4] + translation[3]
	assert(m == 7);

	const std::vector<float> transform_as_vector(p, p + 7);
	rgbd::eigen::Affine3f current_transform;
	xf::convertSTDVectorToTransform(transform_as_vector, current_transform);
//	cout << "curXform" << endl << current_transform.matrix() << endl;

	std::vector<float> x_vector;
	icp_combined->getSourceErrorVector(current_transform, x_vector);
//	cout << "srcErr "; std::copy(x_vector.begin(), x_vector.end(), std::ostream_iterator<float>(cout, " ")); cout << endl;

	// now copy from x_vector over to x[]
	assert(x_vector.size() == (unsigned int) n);
	std::copy(x_vector.begin(), x_vector.end(), x);

	// count calls to error function
	icp_combined->error_function_call_count++;
#endif
}



struct optimizeCMinpackLMParams
{
	ICPCombined* obj;
	vector<float>* tgtErrVec;
};

rgbd::eigen::Affine3f ICPCombined::optimizeCMinpackLM(rgbd::eigen::Affine3f const& transform)
{
	// collect measurements from current correspondences
	std::vector<float> measurement_vector;
	getTargetErrorVector(measurement_vector);

	// prepare the state for LM
	std::vector<float> transform_as_float_vector;
	xf::convertTransformToSTDVector(transform, transform_as_float_vector);
	vector<double> transform_as_double_vector(transform_as_float_vector.begin(), transform_as_float_vector.end());

	// debug
	error_function_call_count = 0;

	//setup inputs
	minpack_func_mn fcn = (minpack_func_mn) &ICPCombined::optimizeCMinpackLMErrorFunction;
	optimizeCMinpackLMParams p;
	p.obj = this;
	p.tgtErrVec = &measurement_vector;
	int m = measurement_vector.size();
	int n = transform_as_double_vector.size();
	double *x = transform_as_double_vector.data();
	double *fvec = new double[m];
	double tol =  sqrt (dpmpar (1)); //copied from pcl. supposedly recommended setting
	int maxfev = 2000; //max function evaluations TODO PARAM
	double epsfcn = 1e-5; //step size
	double *diag = new double[n];
	int mode = 1;
	double factor = 100.0; //recommended
	int nprint = 0;
	int nfev; //output # evaluations
	double *fjac = new double[m*n]; //output jacobian
	int *ipvt = new int[n];
	double *qtf = new double[n];
	double *wa1 = new double[n];
	double *wa2 = new double[n];
	double *wa3 = new double[n];
	double *wa4 = new double[m];

	int info = lmdif(fcn,&p,m,n,x,fvec,tol,tol,tol,maxfev,epsfcn,
			diag, mode, factor, nprint, &nfev, fjac, m, ipvt, qtf,
			wa1, wa2, wa3, wa4);
	ROS_INFO_STREAM("Cminpack returned with value "<<info);

	//delete the temporary data structures
	delete [] fvec;
	delete [] diag; delete [] fjac; delete [] ipvt; delete [] qtf;
	delete [] wa1; delete [] wa2; delete [] wa3; delete [] wa4;

	// since we passed in the data() of the transform_as_double_vector, it now holds the result state
	rgbd::eigen::Affine3f result_transform;
	std::copy(transform_as_double_vector.begin(), transform_as_double_vector.end(), transform_as_float_vector.begin());
	xf::convertSTDVectorToTransform(transform_as_float_vector, result_transform);
	return result_transform;
}

int ICPCombined::optimizeCMinpackLMErrorFunction(void* data, int funcOutputDim, int funcInputDim, const double* x, double* funcVals, int flag)
{
	optimizeCMinpackLMParams* params = (optimizeCMinpackLMParams*)data;
	ICPCombined *icp_combined = params->obj;
	const vector<float>& tgtErrVec = *params->tgtErrVec;
//	cout << "tgtErr "; std::copy(tgtErrVec.begin(), tgtErrVec.end(), std::ostream_iterator<float>(cout, " ")); cout << endl;

	// assuming quaternion[4] + translation[3]
	assert(funcInputDim == 7);
	const std::vector<float> transform_as_vector(x, x + 7);
	rgbd::eigen::Affine3f current_transform;
	xf::convertSTDVectorToTransform(transform_as_vector, current_transform);
//	cout << "curXform" << endl << current_transform.matrix() << endl;

	std::vector<float> x_vector;
	icp_combined->getSourceErrorVector(current_transform, x_vector);
//	cout << "srcErr "; std::copy(x_vector.begin(), x_vector.end(), std::ostream_iterator<float>(cout, " ")); cout << endl;
	for(unsigned int i = 0; i < x_vector.size(); i++) x_vector[i] -= tgtErrVec[i];

	assert(x_vector.size() == (unsigned int)funcOutputDim);
	std::copy(x_vector.begin(), x_vector.end(), funcVals);

	// count calls to error function
	icp_combined->error_function_call_count++;

	return flag;
}

rgbd::eigen::Affine3f
ICPCombined::optimizeEigenLM(rgbd::eigen::Affine3f const& transform) {
#ifndef USE_EIGENLM
	assert(false && "USE_EIGENLM not defined during build");
#else
	class EigenLMFunctor
	{
	public:
		// boilerplate for Eigen LM:
		typedef float Scalar;
		enum {
			InputsAtCompileTime = Eigen::Dynamic,
			ValuesAtCompileTime = Eigen::Dynamic
		};
		typedef Eigen::Matrix<Scalar,InputsAtCompileTime,1> InputType;
		typedef Eigen::Matrix<Scalar,ValuesAtCompileTime,1> ValueType;
		typedef Eigen::Matrix<Scalar,ValuesAtCompileTime,InputsAtCompileTime> JacobianType;

		// member variables
		ICPCombined* icp_combined_;
		//std::vector<float> target_error_vector_;
		ValueType target_error_eigen_;

		/*
		 * Currently assumes cloud_ptr is organized and image_for_cloud is the associated color image
		 */
		EigenLMFunctor(ICPCombined* icp_combined) : icp_combined_(icp_combined)
		{
			// collect measurements from current correspondences
			std::vector<float> target_error_vector;
			icp_combined_->getTargetErrorVector(target_error_vector);
			//target_error_eigen_.resize(target_error_vector.size());
			//std::copy(target_error_vector.begin(), target_error_vector.end(), target_error_eigen_.data());
			target_error_eigen_ = ValueType::Map(target_error_vector.data(), target_error_vector.size());
		}

		int values() const {
			return target_error_eigen_.size();
		}

		int operator() (const InputType &x, ValueType &fvec) const {
			// count calls to error function
			icp_combined_->error_function_call_count++;

			// assuming quaternion[4] + translation[3]
			assert(x.size() == 7);
			const std::vector<float> transform_as_vector(x.data(), x.data()+7);
			rgbd::eigen::Affine3f current_transform;
			xf::convertSTDVectorToTransform(transform_as_vector, current_transform);
			//	cout << "curXform" << endl << current_transform.matrix() << endl;

			std::vector<float> source_error_vector;
			icp_combined_->getSourceErrorVector(current_transform, source_error_vector);
			//	cout << "srcErr "; std::copy(x_vector.begin(), x_vector.end(), std::ostream_iterator<float>(cout, " ")); cout << endl;
			assert(source_error_vector.size() == target_error_eigen_.size());
			ValueType source_error_eigen = ValueType::Map(source_error_vector.data(), source_error_vector.size());

			// do source - target
			fvec = source_error_eigen - target_error_eigen_;

			// I think this means "ok"
			return 0;
		}
	};

	// actual function here:

	const size_t expected_transform_vector_size = 7;

	// prepare the state for LM
	std::vector<float> transform_as_float_vector;
	xf::convertTransformToSTDVector(transform, transform_as_float_vector);
	assert(transform_as_float_vector.size() == expected_transform_vector_size);
	EigenLMFunctor::InputType x = EigenLMFunctor::InputType::Map(transform_as_float_vector.data(), transform_as_float_vector.size());

	// debug
	error_function_call_count = 0;

	EigenLMFunctor functor(this);
	Eigen::NumericalDiff<EigenLMFunctor> num_diff (functor);
	Eigen::LevenbergMarquardt<Eigen::NumericalDiff<EigenLMFunctor>, float> lm (num_diff);
	int info = lm.minimize (x);

	// copy resulting values in x back into std float vector, then to transform to return
	transform_as_float_vector.assign(x.data(), x.data()+expected_transform_vector_size);
	rgbd::eigen::Affine3f result_transform;
	xf::convertSTDVectorToTransform(transform_as_float_vector, result_transform);
	return result_transform;
#endif
}


void
ICPCombined::getSourceErrorVector(rgbd::eigen::Affine3f const& transform,
		std::vector<float> & result) {
	result.clear();
	for (unsigned int pair_index = 0; pair_index < m_cloud_pair_list.size(); pair_index++) {
		std::vector<float> new_component_vector;
		m_cloud_pair_list[pair_index]->getSourceErrorVector(transform, m_correspondence_lists[pair_index], new_component_vector);
		const unsigned int new_vector_size = new_component_vector.size();
		const float cloud_weight = m_cloud_pair_weights[pair_index];
		for (unsigned int i = 0; i < new_vector_size; i++) {
			new_component_vector[i] *= cloud_weight;
		}
		result.insert(result.end(), new_component_vector.begin(), new_component_vector.end());
	}

	if (m_params.enable_alignment_with_ty_rx_rz_restrictions)
	{
		//Penalty for the Y translation

		rgbd::eigen::Vector3f translation_part = transform.translation();
		float y = translation_part.y();
		float translation_penalty = m_params.translation_penalty_weight;

#ifdef DEBUG_GROUND_PLANE
		ty_sum +=y;
		//ROS_INFO (" ****** TRANSLATION Current:%g, Accumulated:%g ***", y, ty_sum);
#endif

		result.push_back(y*translation_penalty);

		rgbd::eigen::Matrix<float,3,3> rotation_part = transform.linear();
		float rotation_penalty = m_params.rotational_penalty_weight;


		result.push_back(rotation_part.coeff(0,1)*rotation_penalty);  // (0,1) = 0
		result.push_back(rotation_part.coeff(1,0)*rotation_penalty);  // (1,0) = 0
		result.push_back(rotation_part.coeff(1,1)*rotation_penalty);  // (1,1) = 1
		result.push_back(rotation_part.coeff(1,2)*rotation_penalty);  // (1,2) = 0
		result.push_back(rotation_part.coeff(2,1)*rotation_penalty);  // (2,1) = 0
	}

	// 1) transform source plane by "transform"
	// 2) put in extra terms

	if (m_use_ground_plane_coefficients)
	{
		assert (4 == m_source_ground_plane_coefficients.values.size());  // coefficients include a,b,c & d
		assert (0 != m_source_ground_plane_coefficients.values[1]);  	 // ground plane should intersect y

		rgbd::eigen::Vector3f y_intersect(
						0.0,
						-m_source_ground_plane_coefficients.values[3]/ m_source_ground_plane_coefficients.values[1],
						0.0);

		rgbd::eigen::Vector3f point_on_transformed_plane = transform * y_intersect;  //

		rgbd::eigen::Vector3f source_plane_normal(
				m_source_ground_plane_coefficients.values[0],
				m_source_ground_plane_coefficients.values[1],
				m_source_ground_plane_coefficients.values[2]);

		rgbd::eigen::Vector3f transformed_source_plane_normal = transform.linear() * source_plane_normal;  //[a,b,c]
		assert (0 != transformed_source_plane_normal[1]);  	 // transformed ground plane should intersect y

		float transformed_y_intersect =
				(transformed_source_plane_normal[0] * point_on_transformed_plane[0] +
				 transformed_source_plane_normal[1] * point_on_transformed_plane[1] +
				 transformed_source_plane_normal[2] * point_on_transformed_plane[2] ) / transformed_source_plane_normal[1];

		float norm_alignment_penalty_weight = m_params.ground_plane_norm_alignment_penalty_weight;
		float plane_translation_penalty = m_params.ground_plane_y_intersect_alignment_penalty_weight;

		result.push_back(transformed_source_plane_normal[0] * norm_alignment_penalty_weight);  // a
		result.push_back(transformed_source_plane_normal[1] * norm_alignment_penalty_weight);  // b
		result.push_back(transformed_source_plane_normal[2] * norm_alignment_penalty_weight);  // c

		result.push_back(transformed_y_intersect * plane_translation_penalty);  // y intersect

	}


	// todo: here add prior

}


void
ICPCombined::getTargetErrorVector(std::vector<float> & result) {
	result.clear();
	for (unsigned int pair_index = 0; pair_index < m_cloud_pair_list.size(); pair_index++) {
		std::vector<float> new_component_vector;
		m_cloud_pair_list[pair_index]->getTargetErrorVector(m_correspondence_lists[pair_index], new_component_vector);
		const unsigned int new_vector_size = new_component_vector.size();
		float cloud_weight = m_cloud_pair_weights[pair_index];
		for (unsigned int i = 0; i < new_vector_size; i++) {
			new_component_vector[i] *= cloud_weight;
		}

		result.insert(result.end(), new_component_vector.begin(), new_component_vector.end());
	}

	if (m_params.enable_alignment_with_ty_rx_rz_restrictions)
	{
		//Penalty for the Y translation
		result.push_back(0);

		//Penalty for the rotation on X or Z axis
		// | cos(b)	0	- sin(b)	|
		// | 0			1 		0	|
		// | sin(b)	0		cos(b) 	|

		result.push_back(0);  // (0,1) = 0
		result.push_back(0);  // (1,0) = 0
		result.push_back(100);  // (1,1) = 1 * Penalty
		result.push_back(0);  // (1,2) = 0
		result.push_back(0);  // (2,1) = 0
	}

	if (m_use_ground_plane_coefficients)
	{
		assert (4 == m_target_ground_plane_coefficients.values.size());  // coefficients include a,b,c & d
		assert (0 != m_target_ground_plane_coefficients.values[1]);  	 // ground plane should intersect y

		result.push_back(m_target_ground_plane_coefficients.values[0]);  // a
		result.push_back(m_target_ground_plane_coefficients.values[1]);  // b
		result.push_back(m_target_ground_plane_coefficients.values[2]);  // c

		result.push_back(-m_target_ground_plane_coefficients.values[3] /  m_target_ground_plane_coefficients.values[1]);  // y intersect


	}

	// todo: here you add on the transform priors
}

#if 0
void ICPCombined::getCorrespondencesForSBA(
		const rgbd::eigen::Affine3f & transform,
		int cloud_pair,
		int max_points,
		ICPCloudPair::srcPtVecT & source_points,
		ICPCloudPair::normalVecT & source_normals,
		ICPCloudPair::tgtPtVecT & target_points,
		ICPCloudPair::normalVecT & target_normals)
{
	std::vector<unsigned int> source_indices;
	std::vector<unsigned int> target_indices;

	getCorrespondencesForSBA(transform, cloud_pair, max_points, source_indices, target_indices);

	unsigned int pair_count = source_indices.size();
	assert(target_indices.size() == pair_count);

	source_points.resize(pair_count);
	source_normals.resize(pair_count);
	target_points.resize(pair_count);
	target_normals.resize(pair_count);

	const rgbd::eigen::Affine3f rotation(transform.linear());

	for (unsigned int i = 0; i < pair_count; i++) {
		const ICPCloudPair::srcPtT & source_point = m_cloud_pair_list[cloud_pair]->getSourcePoint(source_indices[i]);
		const ICPCloudPair::normalT & source_normal = m_cloud_pair_list[cloud_pair]->getSourceNormal(source_indices[i]);
		const ICPCloudPair::tgtPtT & target_point = m_cloud_pair_list[cloud_pair]->getTargetPoint(target_indices[i]);
		const ICPCloudPair::normalT & target_normal = m_cloud_pair_list[cloud_pair]->getTargetNormal(target_indices[i]);
		source_points[i] = transform * source_point;
		source_normals[i] = rotation * source_normal;
		target_points[i] = target_point;
		target_normals[i] = target_normal;
	}
}
#endif

void ICPCombined::getCorrespondencesForSBA(
		const rgbd::eigen::Affine3f & transform,
		int cloud_pair,
		int max_points,
		std::vector<unsigned int> &source_indices,
		std::vector<unsigned int> &target_indices)
{
	assert(cloud_pair >= 0 && cloud_pair < (int)m_cloud_pair_list.size());
	std::vector<int> correspondence_indices;
	m_cloud_pair_list[cloud_pair]->getCorrespondenceIndices(transform, correspondence_indices);

	// need to rank correspondences by some metric (normal agreement, distance, etc.)
	// to start out, I'll use random rankings (except invalid will be -1)
	// can also do rankings outside of ICP
	typedef std::pair<float, unsigned int> Corr_t;
	std::vector<Corr_t> corr_ranks;
	corr_ranks.resize(correspondence_indices.size());
	for (unsigned int i = 0; i < correspondence_indices.size(); i++) {
		if (correspondence_indices[i] < 0) {
			corr_ranks[i] = Corr_t(-1, i);
		}
		else {
			corr_ranks[i] = Corr_t(rand(), i);
		}
	}
	std::sort(corr_ranks.begin(), corr_ranks.end(), std::greater<Corr_t>());

	source_indices.clear();
	target_indices.clear();
	source_indices.reserve(max_points);
	target_indices.reserve(max_points);

	//cout << "Picking at most " << max_points << " from " << corr_ranks.size() << " matches" << endl;
	for (unsigned int i = 0; i < (unsigned int) max_points && i < corr_ranks.size(); i++) {
		int source_index = corr_ranks[i].second;
		int target_index = correspondence_indices[source_index];
		if (target_index >= 0) {
			source_indices.push_back((unsigned int)source_index);
			target_indices.push_back((unsigned int)target_index);
		}
	}
	//cout << "....of which " << source_indices.size() << " were valid" << endl;
}

int ICPCombined::getMaxICPIterations()
{
	return m_params.max_icp_rounds;
}

void ICPCombined::setMaxICPIterations(int new_value)
{
	m_params.max_icp_rounds = new_value;
}


} // end namespace
