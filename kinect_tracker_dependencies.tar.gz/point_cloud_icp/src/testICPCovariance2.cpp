/*
 * testICPCovariance2: should match what's in Xiaofeng's script_icp_covariance_quicktest_euler_01_2010.m
 *
 * Evan Herbst
 * 4 / 25 / 10
 */

#include <cassert>
#include <vector>
#include <string>
#include <fstream>
#include "rgbd_util/eigen/Geometry"
#include "point_cloud_icp/icpCovariance.h"
using std::vector;
using std::string;
using std::ifstream;
using std::ofstream;
using std::cout;
using std::endl;
using rgbd::eigen::Vector3d;
using rgbd::eigen::MatrixXd;

vector<Vector3d> readVecs(const string& filepath)
{
	ifstream infile(filepath.c_str());
	assert(infile);
	vector<Vector3d> vecs;
	double x, y, z;
	while(infile >> x >> y >> z) vecs.push_back(Vector3d(x, y, z));
	return vecs;
}

void writeMATLAB(const MatrixXd& m, const string& filepath)
{
	ofstream outfile(filepath.c_str());
	assert(outfile);
	for(unsigned int i = 0; i < m.rows(); i++)
	{
		for(unsigned int j = 0; j < m.cols(); j++) outfile << m(i, j) << ' ';
		outfile << endl;
	}
}

/*
 * if using pt-2-pt, give the ptfilepath again for the normals one since they're unused
 */
int main(int argc, char* argv[])
{
	assert(argc == 4);
	vector<Vector3d> aligneePts = readVecs(argv[1]);
	vector<Vector3d> alignandPts = readVecs(argv[2]);
	vector<Vector3d> alignandNormals = readVecs(argv[3]);

	pcl::PointCloud<rgbd::pt> aligneeCloud, alignandCloud;
	aligneeCloud.points.resize(aligneePts.size());
	aligneeCloud.width = aligneeCloud.points.size();
	aligneeCloud.height = 1;
	for(unsigned int i = 0; i < aligneePts.size(); i++)
	{
		aligneeCloud.points[i].x = aligneePts[i].x();
		aligneeCloud.points[i].y = aligneePts[i].y();
		aligneeCloud.points[i].z = aligneePts[i].z();
	}
	alignandCloud.points.resize(alignandPts.size());
	alignandCloud.width = alignandCloud.points.size();
	alignandCloud.height = 1;
	for(unsigned int i = 0; i < alignandPts.size(); i++)
	{
		alignandCloud.points[i].x = alignandPts[i].x();
		alignandCloud.points[i].y = alignandPts[i].y();
		alignandCloud.points[i].z = alignandPts[i].z();
		alignandCloud.points[i].normal[0] = alignandNormals[i].x();
		alignandCloud.points[i].normal[1] = alignandNormals[i].y();
		alignandCloud.points[i].normal[2] = alignandNormals[i].z();
	}

	const rgbd::eigen::Matrix<double, 6, 6> cov = registration::getPointToPointICPXformCovarianceXlateRPY(aligneeCloud, alignandCloud);
	cout << cov << endl;
	writeMATLAB(cov, "cov.dat");

	return 0;
}
