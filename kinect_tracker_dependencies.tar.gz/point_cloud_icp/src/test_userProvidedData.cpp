/*
 * test_userProvidedData: read clouds from files as opposed to icp_combined_test, which uses random clouds
 *
 * Evan Herbst
 * 5 / 20 / 11
 */

#include <cassert>
#include <iostream>
#include <fstream>
#include <sstream>
#include <boost/lexical_cast.hpp>
#include <boost/filesystem.hpp>
#include <boost/algorithm/string/split.hpp>
#include <boost/algorithm/string/classification.hpp>
#include "rgbd_util/timer.h"
#include "pcl_rgbd/cloudSampling.h"
#include "pcl_rgbd/cloudTofroPLY.h"
#include "point_cloud_icp/registration/icp_combined.h"
using std::ifstream;
using std::istringstream;
using std::string;
using std::cout;
using std::endl;
using std::vector;
using boost::lexical_cast;
namespace fs = boost::filesystem;

void readCSVCloud(const fs::path& inpath, pcl::PointCloud<rgbd::pt>& cloud)
{
	cloud.points.clear();
	cloud.width = 0;
	cloud.height = 1;
	ifstream infile(inpath.string().c_str());
	assert(infile);
	string line;
	string tok;
	unsigned int lineNum = 0;
	while(getline(infile, line))
	{
		vector<string> tok;
		boost::algorithm::split(tok, line, boost::algorithm::is_any_of(" ,"), boost::algorithm::token_compress_on);
		if(tok[0].empty())
		{
			std::swap(tok[0], tok.back());
			tok.resize(tok.size() - 1);
		}
		assert(tok.size() >= 3);
/*		cout << "tok:";
		for(unsigned int j = 0; j < tok.size(); j++) cout << " '" << tok[j] << "'";
		cout << endl;
*/		rgbd::pt pt;
		unsigned int _ = 0;
		pt.x = lexical_cast<float>(tok[_++]);
		if(tok[_] == ",") _++;
		pt.y = lexical_cast<float>(tok[_++]);
		if(tok[_] == ",") _++;
		pt.z = lexical_cast<float>(tok[_++]);
		if(tok.size() >= 6)
		{
			/*
			 * get normals
			 */
			if(tok[_] == ",") _++;
			pt.normal[0] = lexical_cast<float>(tok[_++]);
			if(tok[_] == ",") _++;
			pt.normal[1] = lexical_cast<float>(tok[_++]);
			if(tok[_] == ",") _++;
			pt.normal[2] = lexical_cast<float>(tok[_++]);
		}
//		cout << pt.x << ' ' << pt.y << ' ' << pt.z << endl;
//		cout << pt.normal[0] << ' ' << pt.normal[1] << ' ' << pt.normal[2] << endl;
		cloud.points.push_back(pt);
		lineNum++;
//		if(lineNum > 20) break;
	}
	cloud.width = cloud.points.size();
}

/*
 * args: two input filepaths for clouds with normals
 */
int main(int argc, char* argv[])
{
	assert(argc == 3);
	const fs::path inpath1(argv[1]), inpath2(argv[2]);

	rgbd::timer t;
	pcl::PointCloud<rgbd::pt> srcCloud, tgtCloud;
	if(inpath1.extension() == ".csv")
	{
		readCSVCloud(inpath1, srcCloud);
		readCSVCloud(inpath2, tgtCloud);
	}
	else if(inpath1.extension() == ".ply")
	{
		srcCloud = *rgbd::readRGBDPLY<rgbd::pt>(inpath1);
		tgtCloud = *rgbd::readRGBDPLY<rgbd::pt>(inpath2);
	}
	else
	{
		assert(false && "unsupported format");
	}
	t.stop("get clouds");
	cout << "cloud sizes: " << srcCloud.points.size() << ' ' << tgtCloud.points.size() << endl;

	rgbd::write_ply_file(srcCloud, "src-before.ply");
	rgbd::write_ply_file(tgtCloud, "tgt-before.ply");

	/*
	 * try to match the params in libpointmatcher/Core.cpp:setDefault() pretty well so we can compare to it
	 */

	pcl::PointCloud<rgbd::pt> downsampledSrc;
	const vector<unsigned int> indices = rgbd::getRandomDownsamplingIndices(srcCloud.points.size(), .5);
	rgbd::downsampleFromIndices(srcCloud, downsampledSrc, indices);

	registration::ICPCombinedParams global_params;
	global_params.max_lm_rounds = 100;
	global_params.max_icp_rounds = 20;
	global_params.min_dist_to_continue = 1e-3;
	global_params.min_rot_to_continue = 1e-3;
	//global_params.min_error_frac_to_continue = 0.001;

	registration::ICPCombined icp_combined;
	icp_combined.setParams(global_params);

	registration::ICPCloudPairParams pair_params;
	pair_params.errType = registration::ICP_ERR_POINT_TO_PLANE;
	pair_params.corrType = registration::ICP_CORRS_SINGLE_TREE;
	pair_params.wtType = registration::ICP_WTS_SCALAR;
	pair_params.front_can_match_back = false;
	pair_params.fixed_correspondence = false;
	pair_params.use_average_point_error = true;
	pair_params.outlier_percentage = .15;
	pair_params.max_distance = -1;

	const boost::shared_ptr<registration::ICPCloudPair> cloudPair (new registration::ICPCloudPair(pair_params, downsampledSrc, tgtCloud));
	cloudPair->setScalarWeights();
	icp_combined.addCloudPair(cloudPair);

	t.restart();
	rgbd::eigen::Affine3f initialXform;
#if 0
	initialXform.setIdentity();
#else //20110522 hack for test data cloud40{0,1} in libpointmatcher
	initialXform(0, 0) = 0.01472889073; initialXform(0, 1) = 0.9773001671; initialXform(0, 2) = 0.2113373578; initialXform(0, 3) = -0.17137447;
	initialXform(1, 0) = 0.1746483743; initialXform(1, 1) = -0.210624963; initialXform(1, 2) = 0.9618365765; initialXform(1, 3) = 0.2554063797;
	initialXform(2, 0) = 0.9845209718; initialXform(2, 1) = 0.0227434244; initialXform(2, 2) = -0.1737868339; initialXform(2, 3) = 3.551202774;
	initialXform(3, 0) = 0; initialXform(3, 1) = 0; initialXform(3, 2) = 0; initialXform(3, 3) = 1;
#endif
	icp_combined.setInitialTransform(initialXform);
	rgbd::eigen::Affine3f icp_transform;
	const bool icp_success = icp_combined.runICP(icp_transform, true/* verbose */);
	t.stop("run icp");
	cout << "icp xform:" << endl << icp_transform.matrix() << endl;
	assert(icp_success);

	return 0;
}
