/*
 * icp_node.cpp
 *
 *  Created on: Jul 7, 2009
 *      Author: peter
 */

#include <ros/node_handle.h>
#include <ros/publisher.h>
#include <ros/subscriber.h>
#include <geometry_msgs/Point.h>
#include <geometry_msgs/PointStamped.h>
#include <sensor_msgs/PointCloud.h>
#include <visualization_msgs/Marker.h>
#include <visualization_msgs/MarkerArray.h>
#include "rgbd_util/eigen/Core"
#include "rgbd_util/eigen/Geometry"
#include <point_cloud_mapping/cloud_io.h>
#include <point_cloud_mapping/cloud_geometry.h>
#include <point_cloud_icp/registration/ICP.h>
//#include <point_cloud_icp/registration/icp_combined.h>
#include <point_cloud_icp/registration/icp_utility.h>
#include <point_cloud_icp/registration/feature_utility.h>
#include <point_cloud_icp/registration/FeatureExtractor.h>
#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <cv_bridge/CvBridge.h>
#include <rgbd_msgs/DepthMap.h>

#include <sensor_msgs/Image.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>

#include <tf/transform_broadcaster.h>
#include <tf_conversions/tf_eigen.h>
#include <roslib/Header.h>

#include <point_cloud_icp/registration/surfel_utility.h>

#include <rgbd_player/ReadyMessage.h>

#include <boost/filesystem.hpp>

// TORO
using std::make_pair; // suggested as a fix in sandbox/lifelong_mapping
#include <treeoptimizer3.hh>
typedef AISNavigation::TreeOptimizer3::Transformation	ToroTransformation;
typedef AISNavigation::TreeOptimizer3::Covariance 		ToroCovariance;
typedef AISNavigation::TreeOptimizer3::Information 		ToroInformation;
typedef AISNavigation::TreeOptimizer3::Translation 		ToroTranslation;
typedef AISNavigation::TreeOptimizer3::Rotation 		ToroRotation;
typedef AISNavigation::TreeOptimizer3::Pose 			ToroPose;
typedef AISNavigation::TreeOptimizer3::Vertex 			ToroVertex;
typedef AISNavigation::TreeOptimizer3::Edge 			ToroEdge;

typedef AISNavigation::TreeOptimizer3					ToroGraph;

#include <vector>
#include <algorithm>
#include <sstream>
#include <string>

using namespace Eigen;


namespace registration
{


struct KeyFrame {
	ros::Time stamp;

	std::vector<Keypoint> keypoints;
	std::vector<std::vector<float> > descriptors;
	std::vector<rgbd::eigen::Vector3f> feature_points;

	sensor_msgs::PointCloud point_cloud;
	sensor_msgs::Image image;

	int toro_id;
};

ToroTransformation convert_transformation_eigen_to_toro(Transform3f eigen_transform)
{
	Quaternionf rotation_part = Quaternionf(eigen_transform.linear());
	Vector3f translation_part = eigen_transform.translation();
	ToroRotation toro_quaternion(rotation_part.w(), rotation_part.x(), rotation_part.y(), rotation_part.z());
	ToroTranslation toro_translation(translation_part.x(), translation_part.y(), translation_part.z());
	ToroTransformation toro_transformation;
	toro_transformation.setRotation(toro_quaternion);
	toro_transformation.setTranslation(toro_translation);
	return toro_transformation;
}

Transform3f convert_transformation_toro_to_eigen(ToroTransformation toro_transform)
{
	ToroRotation toro_quaternion = toro_transform.rotation();
	ToroTranslation toro_translation = toro_transform.translation();
	Quaternionf rotation_part(toro_quaternion.w, toro_quaternion.x, toro_quaternion.y, toro_quaternion.z);
	Vector3f translation_part(toro_translation.x(), toro_translation.y(), toro_translation.z());
	Transform3f eigen_transform = Transform3f(rotation_part.normalized().toRotationMatrix());
	eigen_transform.pretranslate(translation_part);
	return eigen_transform;
}


// stolen from surfelaicp.cpp

rgbd::eigen::Vector3f getNormal(sensor_msgs::PointCloud &organizedCloud,
	unsigned int normalsChan, unsigned int x, unsigned int y, unsigned int xRes)
{
	unsigned int index = x + xRes*y;
	return rgbd::eigen::Vector3f(
		organizedCloud.channels[normalsChan].values[index],
		organizedCloud.channels[normalsChan+1].values[index],
		organizedCloud.channels[normalsChan+2].values[index]);
}

void interpolateNormals(
		sensor_msgs::PointCloud &organizedCloud,
		std::vector<std::vector<bool> >& targetValidityGrid,
		unsigned int xRes,
		unsigned int yRes,
		unsigned int normals_downsample)
{
	unsigned int inc = normals_downsample;

	if(inc == 1)
		return;

	unsigned int normalsChan = get_normal_channel_index(organizedCloud);
	for(unsigned int index = 0; index<organizedCloud.points.size(); index++){
		unsigned int x = index%xRes;
		unsigned int y = index/xRes;

		//don't bother setting a normal for a point we don't care about
		if(!targetValidityGrid[x][y])
			continue;

		unsigned int x_resid = x%inc;
		unsigned int y_resid = y%inc;

		//normal already set for these
		if(x_resid == 0 && y_resid ==0)
			continue;

		unsigned int x_floor = x - x_resid;
		unsigned int y_floor = y - y_resid;

		if(targetValidityGrid[x_floor][y_floor] &&
			targetValidityGrid[x_floor+inc][y_floor] &&
			targetValidityGrid[x_floor][y_floor+inc] &&
			targetValidityGrid[x_floor+inc][y_floor+inc])
		{
			//interpolate normal
			float x_r = ((float)x_resid)/inc;
			float y_r = ((float)y_resid)/inc;

			float coefCC = x_r*y_r;
			float coefCF = x_r*(1-y_r);
			float coefFC = (1-x_r)*y_r;
			float coefFF = (1-x_r)*(1-y_r);

			rgbd::eigen::Vector3f weightedSum =
				coefFF * getNormal(organizedCloud,normalsChan,x_floor,y_floor, xRes) +
				coefFC * getNormal(organizedCloud,normalsChan,x_floor,y_floor+inc, xRes) +
				coefCF * getNormal(organizedCloud,normalsChan,x_floor+inc,y_floor, xRes) +
				coefCC * getNormal(organizedCloud,normalsChan,x_floor+inc,y_floor+inc, xRes);
//			std::cout<<"Un-normalized: "<<std::endl;
//			std::cout<<weightedSum<<std::endl;
			weightedSum.normalize();

//			std::cout<<"Coeffs, normals"<<std::endl;
//			std::cout<<"CoeffFF: "<<coefFF<<std::endl;
//			std::cout<<this->getNormal(organizedCloud,normalsChan,x_floor,y_floor)<<std::endl;
//			std::cout<<"CoeffFC: "<<coefFC<<std::endl;
//			std::cout<<this->getNormal(organizedCloud,normalsChan,x_floor,y_floor+inc)<<std::endl;
//			std::cout<<"CoeffCF: "<<coefCF<<std::endl;
//			std::cout<<this->getNormal(organizedCloud,normalsChan,x_floor+inc,y_floor)<<std::endl;
//			std::cout<<"CoeffCC: "<<coefCC<<std::endl;
//			std::cout<<this->getNormal(organizedCloud,normalsChan,x_floor+inc,y_floor+inc)<<std::endl;
//			assert(!isnan(weightedSum.x()));
//			assert(!isnan(weightedSum.y()));
//			assert(!isnan(weightedSum.z()));
			organizedCloud.channels[normalsChan].values[index]=weightedSum.x();
			organizedCloud.channels[normalsChan+1].values[index]=weightedSum.y();
			organizedCloud.channels[normalsChan+2].values[index]=weightedSum.z();
		}
		else
		{
			//poor way to handle things, but it's easy and won't result
			//in trying to look at a value we're not sure of
			targetValidityGrid[x][y] = false;
			organizedCloud.points[index] = geometry_msgs::Point32();
		}
	}

}


void setNormals(
		sensor_msgs::PointCloud &organizedCloud,
		std::vector<std::vector<bool> >& targetValidityGrid,
		unsigned int normals_window_size,
		unsigned int normals_downsample,
		unsigned int xRes,
		unsigned int yRes,
		float normals_max_z_diff
		)
{
	std::cout<<"Computing normals"<<std::endl;
	ros::Time start = ros::Time::now();

	//organized normals
	geometry_msgs::Point32 origin;
	std::cout<<"Computing organized normals"<<std::endl;
	sensor_msgs::PointCloud withNormals;
	//XXX: make sure computeOrganizedPointCloudNormals has been modified to
	//ignore points with z <= 0. otherwise, will be a lot slower
	//also, computeOrganizedPointCloudNormals is missing a j++ and the pragma
	//line must be removed
	cloud_geometry::nearest::computeOrganizedPointCloudNormals(withNormals,
			organizedCloud,normals_window_size,normals_downsample,
			xRes,yRes,normals_max_z_diff,origin);

//	std::cout<<"WithNormals channels:"<<std::endl;
//	for(unsigned int chan = 0; chan < withNormals.channels.size(); chan++)
//		std::cout<<"Channel "<<chan<<": "<<withNormals.channels[chan].name<<
//			". Size: "<<withNormals.channels[chan].values.size()<<std::endl;

	//put the normals into organizedCloud because withNormals is the wrong dimensions
	unsigned int newXRes = lrint (ceil (xRes / (double)normals_downsample));
//	unsigned int newYRes = lrint (ceil (yRes / (double)normals_downsample));
	unsigned int origDims = organizedCloud.channels.size();
	organizedCloud.set_channels_size(origDims+3);
	organizedCloud.channels[origDims].name = "nx";
	organizedCloud.channels[origDims+1].name = "ny";
	organizedCloud.channels[origDims+2].name = "nz";
	organizedCloud.channels[origDims].set_values_size(xRes*yRes);
	organizedCloud.channels[origDims+1].set_values_size(xRes*yRes);
	organizedCloud.channels[origDims+2].set_values_size(xRes*yRes);
	for(unsigned int smIndex=0; smIndex<withNormals.points.size(); smIndex++){
		unsigned int smX = smIndex%newXRes;
		unsigned int smY = smIndex/newXRes;
		unsigned int lgX = smX*normals_downsample;
		unsigned int lgY = smY*normals_downsample;
		unsigned int lgIndex = lgX + lgY*xRes;
		if(withNormals.channels[0].values[smIndex] != 0 ||
			withNormals.channels[1].values[smIndex] != 0 ||
			withNormals.channels[2].values[smIndex] != 0)
		{
			if(targetValidityGrid[lgX][lgY]){
				organizedCloud.channels[origDims].values[lgIndex] = withNormals.channels[0].values[smIndex];
				organizedCloud.channels[origDims+1].values[lgIndex] = withNormals.channels[1].values[smIndex];
				organizedCloud.channels[origDims+2].values[lgIndex] = withNormals.channels[2].values[smIndex];

			}
			else{
				assert(false);
			}
		}
		else
		{
			if(targetValidityGrid[lgX][lgY]){
				std::cout<<"Valid point "<<lgX<<", "<<lgY<<" has no normal"<<std::endl;
			}
			organizedCloud.points[lgIndex] = geometry_msgs::Point32();
			targetValidityGrid[lgX][lgY] = false;
		}

	}


	interpolateNormals(organizedCloud, targetValidityGrid, xRes, yRes, normals_downsample);

	//regular normals
//	cloud_geometry::nearest::computePointCloudNormals(withNormals,organizedCloud,
//			40,geometry_msgs::PointStamped());

	ros::Time end = ros::Time::now();
	ros::Duration dur = end-start;
	std::cout<<"finished computing normals. took "<<dur.toSec()<<" seconds"<<std::endl;
}





class ICPNode
{
protected:
    ros::NodeHandle nh_global;
    ros::NodeHandle nh_local;

    ros::Publisher collected_cloud_publisher;
    ros::Publisher source_cloud_publisher;
    ros::Publisher source_keypoint_publisher;
    ros::Publisher target_keypoint_publisher;
    ros::Publisher visualization_marker_publisher;
    ros::Publisher feature_image_publisher;
    ros::Publisher edge_image_publisher;
    ros::Publisher edge_cloud_publisher;
    ros::Publisher collected_edge_cloud_publisher;
    ros::Publisher final_cloud_publisher;

    ros::Publisher ready_message_publisher;

    tf::TransformBroadcaster tf_broadcaster;
    //tf::TransformBroadcaster transform_publisher_every_frame;
    //tf::TransformBroadcaster transform_publisher_every_keyframe;
    //tf::TransformBroadcaster transform_publisher_loop_closure;
	std::string world_frame;
	std::string pairwise_frame;
	std::string keyframe_frame;
	std::string loop_closure_frame;

    // subscribe to a point cloud topic and stitch a global cloud
    // also subscribe to an image topic in sync
    //bool do_cloud_subscription;
	std::string cloud_subscription_topic;
	std::string image_subscription_topic;
	int subscription_frame_skip;
	int subscription_frame_counter;
	int initial_frame_skip;
	int initial_frame_counter;

	bool pause_after_alignment;
	bool pause_on_failure;
	bool pause_on_success_after_failure;
	bool pause_on_loop_closure;

	bool last_ransac_failed;
	bool collected_cloud_initialized;

	// New method:
	// Queue size controlled in constructor (used box_detector as a guide)
	static const int max_out_of_order = 100;
	message_filters::TimeSynchronizer<sensor_msgs::PointCloud, sensor_msgs::Image> sync;
	message_filters::Subscriber<sensor_msgs::PointCloud> cloud_subscription_filtered;
	message_filters::Subscriber<rgbd_msgs::DepthMap> depth_subscription_filtered;
	message_filters::Subscriber<sensor_msgs::Image> image_subscription_filtered;


	// for collecting overall cloud
	sensor_msgs::PointCloud collected_cloud;
	Transform3f last_global_transform;
	//std::deque<Transform3f, rgbd::eigen::aligned_allocator<Transform3f> > transform_history;
	//std::vector<std::pair<ros::Time, Transform3f> > pairwise_transform_history;
	//std::vector<std::pair<ros::Time, Transform3f> > keyframe_transform_history;
	//std::vector<std::pair<ros::Time, tf::Transform> > pairwise_global_transform_history; // global
	//std::vector<std::pair<ros::Time, tf::Transform> > keyframe_global_transform_history; // global

	// just keep one global transform history...toro will clear and refill on loop closure
	std::vector<std::pair<ros::Time, tf::Transform> > global_transform_history;
	std::vector<std::pair<ros::Time, tf::Transform> > ransac_relative_transform_history;
	std::vector<std::pair<ros::Time, tf::Transform> > edge_icp_relative_transform_history;
	std::vector<std::pair<ros::Time, tf::Transform> > general_icp_relative_transform_history;
	std::vector<std::pair<ros::Time, tf::Transform> > overall_relative_transform_history;
	std::vector<std::pair<ros::Time, tf::Transform> > loaded_global_transform_history;

	sensor_msgs::PointCloud collected_edge_cloud;
	sensor_msgs::PointCloud previous_edge_cloud;
	sensor_msgs::PointCloud previous_general_icp_cloud;


	sensor_msgs::Image previous_image;

	// for an overall "feature cloud"
	FeatureExtractor extractor;
	std::vector<Keypoint> collected_keypoints; //x,y info not useful, but laplacian and size is
	std::vector<std::vector<float> > collected_descriptors;
	std::vector<rgbd::eigen::Vector3f> collected_feature_points;

	// keep the keypoints and descriptors from the last n clouds
	int previous_frame_count;
	std::deque<std::vector<Keypoint> > previous_keypoints;
	std::deque<std::vector<std::vector<float> > > previous_descriptors;
	std::deque<std::vector<rgbd::eigen::Vector3f> > previous_feature_points;

	// keep keyframes for loop closure
	// so the points are relative to the camera, not to the first frame
	std::deque<KeyFrame> keyframes;
	std::deque<KeyFrame> allframes;

	std::deque<Transform3f, rgbd::eigen::aligned_allocator<Transform3f> > keyframe_global_transforms;

	// overall parameters
	bool use_ransac;
	bool use_edge_icp;
	bool use_general_icp;
	bool use_loop_closure;
	bool use_joint_icp;

	bool use_surfels;

	ICPParams general_icp_params;
	ICPParams edge_icp_params;

	// ransac parameters
	float ransacInlierDist;
    float ransacMinSampleDist;
	double hessianThreshold;
	bool use_sift;
	int min_ransac_inliers;
	int ransacNumSamples;
	bool display_only_keyframes;
	const static unsigned int ransacSampleSize = 3;
	const static unsigned int nearestNeighborThreads = 3;

	float loop_closure_prefilter_distance;
	int min_ransac_inliers_for_loop_closure;

	int min_ransac_inliers_to_skip_joint_icp;
	int min_edge_points_to_skip_general_icp;

	float ransac_icp_point_weight;
	float edge_icp_point_weight;
	float general_icp_point_weight;

	bool use_transform_priors;
	float prior_icp_component_weight;

	float toro_variance_on_ransac_failure;
	float toro_variance_on_loop_closure;

	// edge icp parameters
	double canny_threshold_1;
	double canny_threshold_2;
	int canny_aperture;
	int canny_prefilter_size;
	double edge_icp_maximum_point_distance;
	bool animate_edge_icp;

	// general icp parameters (more elsewhere)
	float general_icp_random_downsample_rate;
	int k_normal_neighbors;


	// experimenting with toro
	AISNavigation::TreeOptimizer3 toro_graph;

	// write output files
	std::string base_output_folder;
	std::string created_output_folder; // created under base output folder, not a parameter
	bool do_write_transforms_to_files;
	bool do_dump_raw_data;
	bool do_dump_sift_descriptors;

	// read input files
	bool do_read_transforms_from_file;
	bool read_transforms_are_relative;
	std::string transforms_input_filename;

	bool do_read_transforms_for_every_frame;
	std::string transforms_input_folder;

	// cloud collection behavior
	bool do_produce_collected_cloud;
	bool do_dump_all_collected_clouds;
	float cloud_initial_random_downsample_rate;
	float cloud_distance_cutoff;
	bool merge_clouds_using_density;
	double merge_density_radius;

	int frames_processed;
	float total_processing_time;

	bool callback_ever_called;

	bool ignore_prior_on_ransac_success;

	int toro_iterations;
	float toro_min_error_ratio;

	bool normalize_joint_icp_weights;


	//surfel stuff
	CameraParams camParams;
	std::vector<Surfel> surfels;
	std::vector<rgbd::eigen::Vector3f> surfelColors;
	std::vector<float> surfelMinAngleFromNormal;
	std::vector<unsigned int> surfelLastSeen;

public:

    ICPNode ()
    : nh_global(),
      nh_local("~"),
      sync(max_out_of_order),
      extractor(0)
    {
    	frames_processed = 0;
    	total_processing_time = 0.0;
    	last_ransac_failed = false;
    	collected_cloud_initialized = false;
    	callback_ever_called = false;

    	double temp_double; // used to extract float parameters
    	int temp_int; // used to extract unsigned int parameters
    	bool temp_bool; // just for uniformity...not used everywhere yet


    	camParams.xRes = 640;
    	camParams.yRes = 480;
    	camParams.centerX = 320;
    	camParams.centerY = 240;
    	camParams.focalLength = 570.34;

    	nh_local.param("use_ransac", use_ransac, true);
    	nh_local.param("use_general_icp", use_general_icp, false);
    	nh_local.param("use_edge_icp", use_edge_icp, false);
    	nh_local.param("use_loop_closure", use_loop_closure, false);
    	nh_local.param("use_joint_icp", use_joint_icp, false);

    	nh_local.param("use_surfels", use_surfels, false);

    	nh_local.param("base_output_folder", base_output_folder, std::string(""));
    	nh_local.param("do_write_transforms_to_files", do_write_transforms_to_files, false);
    	nh_local.param("do_dump_raw_data", do_dump_raw_data, false);
    	nh_local.param("do_dump_sift_descriptors", do_dump_sift_descriptors, false);

    	nh_local.param("do_read_transforms_from_file", do_read_transforms_from_file, false);
    	nh_local.param("read_transforms_are_relative", read_transforms_are_relative, false);
    	nh_local.param("transforms_input_filename", transforms_input_filename, std::string(""));

    	nh_local.param("do_read_transforms_for_every_frame", do_read_transforms_for_every_frame, false);
    	nh_local.param("transforms_input_folder", transforms_input_folder, std::string(""));
    	if (do_read_transforms_for_every_frame && !do_read_transforms_from_file) {
    		ROS_INFO("Setting do_read_transforms_from_file to true because of do_read_transforms_for_every_frame");
    		do_read_transforms_from_file = true;
    	}

    	nh_local.param("do_produce_collected_cloud", do_produce_collected_cloud, true);
    	nh_local.param("do_dump_all_collected_clouds", do_dump_all_collected_clouds, false);


		if (do_read_transforms_from_file && !do_read_transforms_for_every_frame) {
			if (read_transforms_are_relative) {
				std::vector<std::pair<ros::Time, tf::Transform> > loaded_relative_transforms;
				bool success = read_transforms_from_file(transforms_input_filename, loaded_relative_transforms);
				assert(success);
				tf::Transform last_global_transform;
				last_global_transform.setIdentity();
				loaded_global_transform_history.clear();
				for (unsigned int i = 0; i < loaded_relative_transforms.size(); i++) {
					ros::Time stamp = loaded_relative_transforms[i].first;
					tf::Transform global_to_here = last_global_transform * loaded_relative_transforms[i].second;
					loaded_global_transform_history.push_back(make_pair(stamp, global_to_here));
					last_global_transform = global_to_here;
				}
			}
			else {
				bool success = read_transforms_from_file(transforms_input_filename, loaded_global_transform_history);
				assert(success);
			}
		}


		// parameters for both icps
    	nh_local.param("max_distance", temp_double, -1.0);
    	edge_icp_params.max_distance = (float) temp_double;
    	general_icp_params.max_distance = (float) temp_double;

    	nh_local.param("max_rounds", temp_int, -1);
    	edge_icp_params.max_rounds = temp_int;
    	general_icp_params.max_rounds = temp_int;

    	nh_local.param("min_dist_to_continue", temp_double, .0001);
    	edge_icp_params.min_dist_to_continue = (float) temp_double;
    	general_icp_params.min_dist_to_continue = (float) temp_double;

    	nh_local.param("min_rot_to_continue", temp_double, .0001);
    	edge_icp_params.min_rot_to_continue = (float) temp_double;
    	general_icp_params.min_rot_to_continue = (float) temp_double;

    	nh_local.param("min_error_frac_to_continue", temp_double, .001);
    	edge_icp_params.min_error_frac_to_continue = (float) temp_double;
    	general_icp_params.min_error_frac_to_continue = (float) temp_double;

    	nh_local.param("cauchy_constant", temp_double, 1.0);
    	edge_icp_params.cauchy_constant = (float) temp_double;
    	general_icp_params.cauchy_constant = (float) temp_double;

    	nh_local.param("interleave", temp_bool, false);
    	edge_icp_params.interleave = temp_bool;
    	general_icp_params.interleave = temp_bool;

    	nh_local.param("weight_error_with_normals", temp_bool, false);
    	edge_icp_params.weight_error_with_normals = temp_bool;
    	general_icp_params.weight_error_with_normals = temp_bool;

    	nh_local.param("ransac_icp_point_weight", temp_double, 1.0);
    	ransac_icp_point_weight = (float) temp_double;
    	nh_local.param("edge_icp_point_weight", temp_double, 1.0);
    	edge_icp_point_weight = (float) temp_double;
    	nh_local.param("general_icp_point_weight", temp_double, 1.0);
    	general_icp_point_weight = (float) temp_double;

    	nh_local.param("use_transform_priors", use_transform_priors, true);
    	nh_local.param("prior_icp_component_weight", temp_double, 1.0);
    	prior_icp_component_weight = (float) temp_double;

    	nh_local.param("toro_variance_on_ransac_failure", temp_double, 1.0);
    	toro_variance_on_ransac_failure = (float) temp_double;

    	nh_local.param("toro_variance_on_loop_closure", temp_double, 1.0);
    	toro_variance_on_loop_closure = (float) temp_double;

    	nh_local.param("ignore_prior_on_ransac_success", ignore_prior_on_ransac_success, false);
    	nh_local.param("toro_iterations", toro_iterations, 1000);

    	//nh_local.param("toro_min_error_ratio", temp_double, 0.000);
    	toro_min_error_ratio = 0;

    	nh_local.param("normalize_joint_icp_weights", normalize_joint_icp_weights, false);
    	assert(!normalize_joint_icp_weights);



		// special edge_icp parameters
		nh_local.param("canny_threshold_1", canny_threshold_1, 0.0);
		nh_local.param("canny_threshold_2", canny_threshold_2, 0.0);
		nh_local.param("canny_aperture", canny_aperture, 3);
		nh_local.param("canny_prefilter_size", canny_prefilter_size, 1);
		nh_local.param("edge_icp_maximum_point_distance", edge_icp_maximum_point_distance, 0.0);
		nh_local.param("animate_edge_icp", animate_edge_icp, false);

		// special general icp parameters
		nh_local.param("general_icp_random_downsample_rate", temp_double, 0.1);
		general_icp_random_downsample_rate = (float) temp_double;
		nh_local.param("k_normal_neighbors", k_normal_neighbors, 40);


    	// error functions for both icps
    	std::string param_error_function_string;
    	nh_local.param("edge_icp_error_function", param_error_function_string, std::string("MSE"));
    	edge_icp_params.set_error_function_from_string(param_error_function_string);
    	nh_local.param("general_icp_error_function", param_error_function_string, std::string("MSE"));
    	general_icp_params.set_error_function_from_string(param_error_function_string);

    	//optimizer
    	std::string param_optimizer_string;
    	nh_local.param("edge_icp_nonlinear_optimizer", param_optimizer_string, std::string("LBFGS"));
    	edge_icp_params.set_optimizer_from_string(param_optimizer_string);
    	nh_local.param("general_icp_nonlinear_optimizer", param_optimizer_string, std::string("LBFGS"));
    	general_icp_params.set_optimizer_from_string(param_optimizer_string);

    	//downsampling (off!)
    	std::string param_downsampling_string;
    	nh_local.param("downsampling_type", param_downsampling_string, std::string("NO_DOWNSAMPLING"));
    	general_icp_params.set_downsampling_from_string(param_downsampling_string);
    	edge_icp_params.set_downsampling_from_string(param_downsampling_string);
    	assert(general_icp_params.downsampling == NO_DOWNSAMPLING);
    	assert(edge_icp_params.downsampling == NO_DOWNSAMPLING);

    	// left these here, but they aren't used
#if 0
    	nh_local.param("downsample_rate", temp_double, 0.1);
    	icp_params.downsample_rate = (float) temp_double;

    	nh_local.param("downsample_voxel_size", temp_double, 0.5);
    	icp_params.downsample_voxel_size = (float) temp_double;

    	nh_local.param("downsample_density_radius", temp_double, 0.1);
    	icp_params.downsample_density_radius = (float) temp_double;

    	nh_local.param("downsample_density_kmax", temp_int, 40);
    	icp_params.downsample_density_kmax = temp_int;

    	nh_local.param("saliency_basepoint_ratio", temp_double, 0.05);
    	icp_params.saliency_basepoint_ratio = (float) temp_double;

    	nh_local.param("saliency_binning_degrees", temp_double, 3.0);
    	icp_params.saliency_binning_degrees = (float) temp_double;

    	nh_local.param("saliency_max_radius", temp_double, 1.0);
    	icp_params.saliency_max_radius = (float) temp_double;

    	nh_local.param("saliency_radius_delta", temp_double, 0.1);
    	icp_params.saliency_radius_delta = (float) temp_double;

    	nh_local.param("saliency_max_regions", temp_int, 40);
    	icp_params.saliency_max_regions = temp_int;

    	nh_local.param("saliency_min_points", temp_int, 50);
    	icp_params.saliency_min_points = temp_int;
#endif



    	// some ransac parameters (feel free to move more out here)
    	nh_local.param("ransac_inlier_distance", temp_double, 0.02);
    	ransacInlierDist = (float) temp_double;
    	nh_local.param("ransac_min_sample_distance", temp_double, 0.05);
    	ransacMinSampleDist = (float) temp_double;
    	nh_local.param("hessian_threshold", temp_double, 300.0);
    	hessianThreshold = temp_double;
    	nh_local.param("use_sift",use_sift,false);
    	nh_local.param("min_ransac_inliers",min_ransac_inliers,25);
    	nh_local.param("ransac_iterations", ransacNumSamples, 1500);


    	nh_local.param("loop_closure_prefilter_distance",temp_double,0.0);
    	loop_closure_prefilter_distance = (float) temp_double;
    	nh_local.param("min_ransac_inliers_for_loop_closure",min_ransac_inliers_for_loop_closure,25);

    	nh_local.param("min_ransac_inliers_to_skip_joint_icp",min_ransac_inliers_to_skip_joint_icp,50);
    	nh_local.param("min_edge_points_to_skip_general_icp",min_edge_points_to_skip_general_icp,1000000); // set lower to do something


    	// cloud subscription
    	//nh_local.param("do_cloud_subscription", do_cloud_subscription, false);
    	nh_local.param("cloud_subscription_topic", cloud_subscription_topic, std::string(""));
    	nh_local.param("image_subscription_topic", image_subscription_topic, std::string(""));
    	nh_local.param("subscription_frame_skip", subscription_frame_skip, 0);
    	nh_local.param("initial_frame_skip", initial_frame_skip, 0);


    	// alignment behavior
    	nh_local.param("pause_after_alignment", pause_after_alignment, false);
    	nh_local.param("pause_on_failure", pause_on_failure, false);
    	nh_local.param("pause_on_success_after_failure", pause_on_success_after_failure, false);
    	nh_local.param("pause_on_loop_closure", pause_on_loop_closure, false);


    	nh_local.param("previous_frame_count", previous_frame_count, 1);
    	assert(previous_frame_count == 1);
    	bool consistent_seed = false;
    	nh_local.param("consistent_seed", consistent_seed, false);
    	if (consistent_seed) {
    		ROS_INFO("Using consistent random seed (may not actually work)");
    		srand(2);
    		srand48(2);
    	}


    	// cloud display behavior
    	nh_local.param("display_only_keyframes", display_only_keyframes, false);

    	nh_local.param("cloud_initial_random_downsample_rate", temp_double, 0.1);
    	cloud_initial_random_downsample_rate = (float) temp_double;

    	nh_local.param("cloud_distance_cutoff", temp_double, -1.0);
    	cloud_distance_cutoff = (float) temp_double;

    	nh_local.param("merge_clouds_using_density", merge_clouds_using_density, true);
    	nh_local.param("merge_density_radius", merge_density_radius, 0.1);

		// broadcast tf messages
    	nh_local.param("world_frame", world_frame, std::string("/world"));
    	nh_local.param("pairwise_frame", pairwise_frame, std::string("/pairwise_frame"));
    	nh_local.param("keyframe_frame", keyframe_frame, std::string("/keyframe_frame"));
    	nh_local.param("loop_closure_frame", loop_closure_frame, std::string("/loop_closure_frame"));

		// Maximum number of outgoing messages to be queued for delivery to subscribers = 1
    	collected_cloud_publisher = nh_global.advertise<sensor_msgs::PointCloud> ("collected_cloud", 1);
		source_cloud_publisher = nh_global.advertise<sensor_msgs::PointCloud> ("source_cloud_before_alignment", 1);
		source_keypoint_publisher = nh_global.advertise<sensor_msgs::PointCloud> ("source_keypoint_cloud", 1);
		target_keypoint_publisher = nh_global.advertise<sensor_msgs::PointCloud> ("target_keypoint_cloud", 1);
		visualization_marker_publisher = nh_global.advertise<visualization_msgs::Marker> ("visualization_marker", 0);
		final_cloud_publisher = nh_global.advertise<sensor_msgs::PointCloud> ("final_cloud", 1);
		feature_image_publisher = nh_global.advertise<sensor_msgs::Image> ("feature_image", 1);
		edge_image_publisher = nh_global.advertise<sensor_msgs::Image> ("edge_image", 1);
		edge_cloud_publisher = nh_global.advertise<sensor_msgs::PointCloud> ("edge_cloud", 1);
		collected_edge_cloud_publisher = nh_global.advertise<sensor_msgs::PointCloud> ("collected_edge_cloud", 1);

		ready_message_publisher = nh_global.advertise<rgbd_player::ReadyMessage>("ready_message", 1);
    }

    ~ICPNode()
    {
    }

    void visualize_keypoint_inliers(const roslib::Header& header,
    		const std::vector<rgbd::eigen::Vector3f>& source_keypoints,
    		const std::vector<rgbd::eigen::Vector3f>& target_keypoints,
    		const std::vector<std::pair<int, int> >& inlier_indices)
    {
		sensor_msgs::PointCloud source_keypoints_cloud;
		convertVectorToPointCloud(source_keypoints, source_keypoints_cloud);
		source_keypoints_cloud.header = header;
		source_keypoint_publisher.publish(source_keypoints_cloud);

		sensor_msgs::PointCloud target_keypoints_cloud;
		convertVectorToPointCloud(target_keypoints, target_keypoints_cloud);
		target_keypoints_cloud.header = header;
		target_keypoint_publisher.publish(target_keypoints_cloud);

		// and visualization messages that show linking of inliers
		visualization_msgs::Marker inlier_connection_lines;
		inlier_connection_lines.header = header;
		inlier_connection_lines.type = visualization_msgs::Marker::LINE_LIST;
		inlier_connection_lines.color.r = 1.0;
		inlier_connection_lines.color.g = 1.0;
		inlier_connection_lines.color.b = 1.0;
		inlier_connection_lines.color.a = 1.0;
		inlier_connection_lines.scale.x = 0.02;
		//inlier_connection_lines.scale.y = 1; // ignored for line lists
		//inlier_connection_lines.scale.z = 1; // ignored for line lists
		inlier_connection_lines.points.clear();
		for (unsigned int i = 0; i < inlier_indices.size(); i++) {
			int source_index = inlier_indices[i].first;
			int target_index = inlier_indices[i].second;
			// source
			geometry_msgs::Point source_point;
			source_point.x = source_keypoints.at(source_index)[0];
			source_point.y = source_keypoints.at(source_index)[1];
			source_point.z = source_keypoints.at(source_index)[2];
			inlier_connection_lines.points.push_back(source_point);
			// target
			geometry_msgs::Point target_point;
			target_point.x = target_keypoints.at(target_index)[0];
			target_point.y = target_keypoints.at(target_index)[1];
			target_point.z = target_keypoints.at(target_index)[2];
			inlier_connection_lines.points.push_back(target_point);
		}
		visualization_marker_publisher.publish(inlier_connection_lines);
    }

    bool ransac_consistent_alignment_between_keyframes(
    		const KeyFrame& source_keyframe,
    		const KeyFrame& target_keyframe,
    		int minimum_ransac_inliers,
    		Transform3f& result_transform)
    {
		std::vector<std::pair<int, int> > surfPairs = findSURFPairs(
				source_keyframe.keypoints, source_keyframe.descriptors,
				target_keyframe.keypoints, target_keyframe.descriptors,
    			nearestNeighborThreads);
		std::vector<std::pair<int, int> > ransac_inliers;
		bool ransac_success = runRANSAC(
				source_keyframe.feature_points, target_keyframe.feature_points,
				surfPairs, ransacInlierDist,
    			result_transform, ransac_inliers,
    			ransacNumSamples, ransacSampleSize, ransacMinSampleDist);
//    	ROS_INFO("CONSISTENT ALIGNMENT: Found %d inliers with last keyframe", ransac_inliers.size());
    	bool ransac_passed_threshold = ransac_success && (int)ransac_inliers.size() >= minimum_ransac_inliers;
    	return ransac_passed_threshold;
    }

    void merge_clouds(sensor_msgs::PointCloud & merge_into, sensor_msgs::PointCloud const& to_add)
    {
    	if (merge_clouds_using_density) {
    		mergeCloudsWithDensity(merge_into, to_add, merge_density_radius);
    	}
    	else {
    		mergeClouds(merge_into, to_add);
    	}
    }

    void sync_cb(
  		  const sensor_msgs::PointCloud::ConstPtr& current_cloud_ptr,
  		  const sensor_msgs::Image::ConstPtr& current_image_ptr)
    {
    	ros::Time current_frame_timestamp = current_cloud_ptr->header.stamp;
    	assert(current_frame_timestamp == current_image_ptr->header.stamp);
    	ROS_INFO ("[[[Sync callback]]]");
    	ROS_INFO ("Timestamp: %f", current_frame_timestamp.toSec());
    	callback_ever_called = true;

    	rgbd_player::ReadyMessage ready_message;
    	ready_message.name = "icp_node";
    	ready_message.stamp = current_frame_timestamp;
    	ready_message_publisher.publish(ready_message);

    	// skip frames if requested
    	// counter drops down to zero before continuing
    	if (subscription_frame_counter-- > 0) {
    		return;
    	}
    	subscription_frame_counter = subscription_frame_skip;

    	if (initial_frame_counter-- > 0) {
    		ROS_INFO("Skipping initial frame %d", initial_frame_counter);
    		return;
    	}

    	if (current_cloud_ptr->get_points_size() <= 0) {
    		ROS_INFO("Ignoring empty point cloud");
    		return;
    	}

    	// just to see how the message buffers are behaving
    	static ros::Time previous_timestamp = current_frame_timestamp;
    	if (previous_timestamp != current_frame_timestamp) {
    		ROS_INFO("Timestamp change since last processed frame:%f", (current_frame_timestamp - previous_timestamp).toSec());
    		previous_timestamp = current_frame_timestamp;
    	}
    	// end of that silliness


		if (do_read_transforms_for_every_frame) {
			std::string transform_filename = convert_timestamp_to_string(current_frame_timestamp, "-") + ".txt";
			std::string full_path_to_transform_file = transforms_input_folder + transform_filename;
			bool loaded = read_transforms_from_file(full_path_to_transform_file, loaded_global_transform_history);
			if (!loaded) {
				ROS_WARN("No transforms file found:%s", full_path_to_transform_file.c_str());
				return;
			}
		}

    	// if we are reading transforms from files, ignore frames for which we have no info
    	tf::Transform transform_from_file;
    	bool transform_found_in_file = false;
    	if (do_read_transforms_from_file) {
			for (unsigned int i = 0; i < loaded_global_transform_history.size(); i++) {
				if (loaded_global_transform_history[i].first == current_frame_timestamp) {
					transform_found_in_file = true;
					transform_from_file = loaded_global_transform_history[i].second;
					break;
				}
			}
			if (!transform_found_in_file) {
				ROS_INFO("No transform present in file attempting to process frame %d", frames_processed);
				return;
			}
    	}


    	roslib::Header output_header;
    	output_header.seq = 0;
    	output_header.stamp = current_frame_timestamp;
    	output_header.frame_id = world_frame;

    	ros::Time start = ros::Time::now();

    	if (frames_processed == 0) {
    		last_global_transform.setIdentity();
    	}

    	ROS_INFO("[[[Starting Frame %d]]]", frames_processed);

    	// to compute (and dump) sift descriptors...
		std::vector<Keypoint> keypoints,validKeypoints;
		std::vector<std::vector<float> > descriptors, validDescriptors;
		std::vector<rgbd::eigen::Vector3f> featurePoints,validPoints;
		std::vector<bool> featureValidity;
		std::vector<unsigned int> cloudIndices,validCloudIndices;

		// extract sift descriptors outside of alignment
		// Either if we're doing alignment or if we need to dump them
		if (!do_read_transforms_from_file || do_dump_sift_descriptors) {
	    	//get SURF / SIFT stuff
	    	bool extendedDescriptors = true;
			int xChan = cloud_geometry::getChannelIndex(current_cloud_ptr,"image_x");
			int yChan = cloud_geometry::getChannelIndex(current_cloud_ptr,"image_y");

			if(use_sift){
				extractor.extractSIFT(current_image_ptr,keypoints,descriptors);
			}
			else{
				extractor.extractSURF(current_image_ptr,keypoints,descriptors,hessianThreshold,extendedDescriptors);
			}
			extract3DPoints(keypoints,*current_cloud_ptr,featurePoints,featureValidity,cloudIndices,current_image_ptr->width,current_image_ptr->height,xChan,yChan);
			//extractValidPoints(keypoints,descriptors,featurePoints,featureValidity,validKeypoints,validDescriptors,validPoints);
			extractValidPointsAndIndices(keypoints,descriptors,featurePoints,cloudIndices,featureValidity,validKeypoints,validDescriptors,validPoints,validCloudIndices);
			std::cout<<"Valid keypoints: "<<validKeypoints.size()<<" out of "<<keypoints.size()<<std::endl;
		}

		// this is the cloud that will be added to the collected cloud (and stored with KeyFrames)
		sensor_msgs::PointCloud new_cloud_to_merge;
		if (do_produce_collected_cloud) {
			if (use_surfels) {
				new_cloud_to_merge = *current_cloud_ptr;
			}
			else {
				// first quickly random downsample the incoming cloud
				sensor_msgs::PointCloud random_downsampled_new_cloud;
				std::deque<unsigned int> downsample_indices;
				downsample_indices = getRandomDownsamplingIndices(*current_cloud_ptr, cloud_initial_random_downsample_rate);
				downsampleFromIndices(*current_cloud_ptr, random_downsampled_new_cloud, downsample_indices);

				// and experiment with removing points on the edge of the image
				// those points tend to be "curved" towards the camera...
				float image_radius_cutoff = 0.8;
				sensor_msgs::PointCloud radius_downsampled_new_cloud;
				downsample_indices = getImageRadiusDownsamplingIndices(
							random_downsampled_new_cloud,
							current_image_ptr->width,
							current_image_ptr->height,
							image_radius_cutoff);
				downsampleFromIndices(random_downsampled_new_cloud, radius_downsampled_new_cloud, downsample_indices);

				// finally, cut off points that are beyond a given distance
				if (cloud_distance_cutoff > 0) {
					downsample_indices = getRadiusDownsamplingIndices(radius_downsampled_new_cloud, Vector3f(0,0,0), cloud_distance_cutoff, true);
					downsampleFromIndices(radius_downsampled_new_cloud, new_cloud_to_merge, downsample_indices);
				}
				else {
					new_cloud_to_merge = radius_downsampled_new_cloud;
				}
			}

			new_cloud_to_merge.header = output_header;

			// add a channel that has the added order
			unsigned int point_count = new_cloud_to_merge.get_points_size();
			unsigned int old_channel_count = new_cloud_to_merge.get_channels_size();
			new_cloud_to_merge.channels.resize(old_channel_count + 1);
			new_cloud_to_merge.channels[old_channel_count].name = "order";
			new_cloud_to_merge.channels[old_channel_count].values.resize(point_count);
			for (unsigned int i = 0; i < point_count; i++) {
				new_cloud_to_merge.channels[old_channel_count].values[i] = (float) frames_processed;
			}

			// make sure our output channels match the input channels, but output header is different
			if (!collected_cloud_initialized) {
				copyHeaderAndChannelNames(new_cloud_to_merge, collected_cloud);
				collected_cloud.header = output_header;

				// also initialize collecte edge cloud
				// turning off collected edge cloud for now...
				/*
				copyHeaderAndChannelNames(*current_cloud_ptr, collected_edge_cloud);
				collected_edge_cloud.header = output_header;
				*/

				collected_cloud_initialized = true;
			}
		}

		Transform3f new_global_transform;
		new_global_transform.setIdentity();
		if (do_read_transforms_for_every_frame) {
			// need to add to allframes
			allframes.push_back(KeyFrame());
			KeyFrame& pairwise_keyframe = allframes.back();
			pairwise_keyframe.stamp = current_frame_timestamp;
			pairwise_keyframe.point_cloud = new_cloud_to_merge;

			// then at the end when we normally would merge into the collected cloud, we will rebuild it instead
		}
		else if (do_read_transforms_from_file) {
			// if the transform doesn't exist in the file, we should have already bailed out above
			assert (transform_found_in_file);
			Transform3f eigen_transform = convert_ros_transform_to_eigen_transform3f(transform_from_file);
			ROS_INFO("---Applying transform from file:\n%s", convert_eigen_transform_to_string(eigen_transform).c_str());

			// this should not be necessary...deserves more attention later
			rgbd::eigen::Matrix<float,7,1> v = convertTransformToVector(eigen_transform);
			eigen_transform = convertVectorToTransform(v);
			new_global_transform = eigen_transform;
		}

		else {
			// we are doing alignment
			// apply last_global_transform to the source cloud as where it started (before this round of alignment)
			bool visualize_source_cloud_before_alignment = false;
			if (visualize_source_cloud_before_alignment) {
				sensor_msgs::PointCloud source_cloud;
				transform_point_cloud(last_global_transform, new_cloud_to_merge, source_cloud);
				source_cloud.header = output_header;
				source_cloud_publisher.publish(source_cloud);
			}

			bool visualize_full_source_in_camera = false;
			if (visualize_full_source_in_camera) {
				sensor_msgs::PointCloud source_cloud = *current_cloud_ptr;
				//transform_point_cloud(last_global_transform, *current_cloud_ptr, source_cloud);
				source_cloud.header = output_header;
				source_cloud_publisher.publish(source_cloud);
			}

			// if we have a previous frame, align this to it (pairwise)
			ROS_INFO("Aligning new cloud");
			ROS_INFO("Collected cloud size:%d", collected_cloud.get_points_size());
			ROS_INFO("New (downsampled) cloud size:%d", new_cloud_to_merge.get_points_size());

			Transform3f ransac_relative_transform;
			ransac_relative_transform.setIdentity();

			// need pairs of 3d points that were inliers between the frames for combined icp
			std::vector<std::pair<Vector3f, Vector3f> > inlier_points_for_icp;

			// if we are doing ransac:
			if (use_ransac) {
				// feature extraction moved earlier in function for dumping sift descriptors

				if (previous_keypoints.size() > 0) {
					// this should be equivalent to what the elseif block does when previous_frame_count == 1
					if (previous_frame_count == 1) {
						collected_keypoints = previous_keypoints.back();
						collected_descriptors = previous_descriptors.back();
						collected_feature_points = previous_feature_points.back();
					}
					// if using only the previous n frames, set collected_* to match
					// will check when adding new points (later) that we only have n in these deques
					else if (previous_frame_count > 1) {
						//std::cout << "Creating collected features out of last " << previous_descriptors.size() << " frames."<< std::endl;

						collected_keypoints.clear();
						collected_descriptors.clear();
						collected_feature_points.clear();

						unsigned int previous_frames_available = previous_keypoints.size();
						assert (previous_frames_available == previous_descriptors.size());
						assert (previous_frames_available == previous_feature_points.size());

						for (unsigned int i = 0; i < previous_frames_available; i++) {
							// PREPEND!!
							collected_keypoints.insert(collected_keypoints.begin(),previous_keypoints.at(i).begin(), previous_keypoints.at(i).end());
							collected_descriptors.insert(collected_descriptors.begin(),previous_descriptors.at(i).begin(), previous_descriptors.at(i).end());
							collected_feature_points.insert(collected_feature_points.begin(), previous_feature_points.at(i).begin(), previous_feature_points.at(i).end());
						}
					}

					//find SURF correspondences
					std::vector<std::pair<int, int> > surfPairs;
					bool approxNearest = false;
					if(!approxNearest){
						surfPairs =	findSURFPairs(validKeypoints,validDescriptors,
								collected_keypoints,collected_descriptors,nearestNeighborThreads);
					}
					else{
						surfPairs = flannFindSURFPairs(validKeypoints,validDescriptors,
								collected_keypoints,collected_descriptors);
					}
					std::cout<<"Found "<<surfPairs.size()<<" correspondences with previous keypoints"<<std::endl;

					// need inliers for visualization
					std::vector<std::pair<int, int> > resultInliers;

					Transform3f ransac_transform;
					bool success = false;
					success = runRANSAC(validPoints,collected_feature_points,
								surfPairs,ransacInlierDist, ransac_transform, resultInliers,
								ransacNumSamples,ransacSampleSize,ransacMinSampleDist);
	#if 0
					// take this back out
					ROS_INFO("Inliers:");
					for (int i = 0; i < (int)resultInliers.size(); i++) {
						ROS_INFO("(%d,%d)", resultInliers.at(i).first, resultInliers.at(i).second);
					}
	#endif

					// publish detected and matched features in an image
					bool do_publish_feature_image = true;
					if (do_publish_feature_image) {
						std::vector<bool> source_keypoint_is_inlier(keypoints.size(), false);
						for (unsigned int i = 0; i < resultInliers.size(); i++) {
							source_keypoint_is_inlier.at(resultInliers.at(i).first) = true;
						}

						sensor_msgs::CvBridge bridge;
						IplImage *feature_image_cv = bridge.imgMsgToCv(current_image_ptr,"bgr8");
						for(unsigned int i=0; i < keypoints.size(); i++){
							registration::Keypoint pt = keypoints[i];
							//draw a circle on the image to be displayed
							CvPoint center = cvPoint((int)round(pt.x),(int)round(pt.y));
							bool only_valid_points = false;
							if (only_valid_points) {
								if (featureValidity[i]) {
									// GREEN IS VALID
									cvCircle(feature_image_cv,center,1,CV_RGB(0,255,0));
								}
							}
							else {
								if (source_keypoint_is_inlier[i]) {
									// BLUE IS MATCHED
									cvCircle(feature_image_cv,center,1,CV_RGB(0,0,255));
								}
								else if (featureValidity[i]) {
									// GREEN IS VALID
									cvCircle(feature_image_cv,center,1,CV_RGB(0,255,0));
								}
								else {
									// RED IS INVALID
									cvCircle(feature_image_cv,center,1,CV_RGB(255,0,0));
								}
							}
						}
						sensor_msgs::ImagePtr feature_image_ros = bridge.cvToImgMsg(feature_image_cv, "bgr8");
						feature_image_ros->header = current_image_ptr->header;
						feature_image_publisher.publish(feature_image_ros);
					}

					if(success && (int)resultInliers.size() >= min_ransac_inliers){
						ransac_relative_transform = ransac_transform;
						ROS_INFO("RANSAC succeeded since %d > %d", resultInliers.size(), min_ransac_inliers);
						ROS_INFO("Recovered Transformation:\n%s", getTransformString(ransac_transform).c_str());
						if (pause_on_success_after_failure && last_ransac_failed) {
							ROS_INFO("[PAUSED] (first success after failure)");
							getchar();
						}
						last_ransac_failed = false;

						if (use_joint_icp) {
							// set corresponding 3d points for combined icp
							for (unsigned int i = 0; i < resultInliers.size(); i++) {
								Vector3f source_point = validPoints[resultInliers[i].first];
								Vector3f target_point = collected_feature_points[resultInliers[i].second];
								inlier_points_for_icp.push_back(make_pair(source_point, target_point));
							}
						}
					}
					else{
						ROS_WARN("RANSAC FAILED!  (Processing frame %d)", frames_processed);
						last_ransac_failed = true;
						if (pause_on_failure) {
							ROS_INFO("[PAUSED]");
							getchar();
						}
						// at this point the relative transform is the identity
					}

					// refactored visualization of inliers
					bool source_inliers_in_original_frame = false;
					if (source_inliers_in_original_frame) {
						std::vector<rgbd::eigen::Vector3f> source_keypoints(validPoints.size());
						for (unsigned int i = 0; i < validPoints.size(); i++) {
							source_keypoints[i] = validPoints[i];
						}
						std::vector<rgbd::eigen::Vector3f> target_keypoints;
						std::vector<std::pair<int, int> > empty_inliers;
						visualize_keypoint_inliers(output_header, source_keypoints, target_keypoints, empty_inliers);
					}
					else {
						std::vector<rgbd::eigen::Vector3f> source_keypoints_transformed(validPoints.size());
						for (unsigned int i = 0; i < validPoints.size(); i++) {
							source_keypoints_transformed[i] = last_global_transform * validPoints[i];
						}
						std::vector<rgbd::eigen::Vector3f> target_keypoints;
						target_keypoints.resize(collected_feature_points.size());
						for (unsigned int i = 0; i < collected_feature_points.size(); i++) {
							target_keypoints[i] = last_global_transform * collected_feature_points[i];
						}
						visualize_keypoint_inliers(output_header, source_keypoints_transformed, target_keypoints, resultInliers);
					}
				}

				// this is for all frames including the first
				// keep updating feature points even on failure...icp will correct it
				if (true) {
					// now collect the new keypoints to match against next time (including the first cloud)
					std::vector<Keypoint> newKeypoints;
					std::vector<std::vector<float> > newDescriptors;
					std::vector<rgbd::eigen::Vector3f> newFeaturePoints;
					bool keep_all_feature_points = true;
					if (keep_all_feature_points) {
						newKeypoints = validKeypoints;
						newDescriptors = validDescriptors;
						newFeaturePoints = validPoints;
					}
					else {
						assert(false); // I'm only supporting keeping all feature points right now
		#if 0
						// add to the feature list
						// just using valid points that didn't have correspondences for now
						std::vector<bool> keepKeypoint(validPoints.size(),true);

						// note that this will cause features to "drop out" for a frame if the
						// old feature matched was in the oldest kept frame
						// Therefore, only discard matches if we're keeping more than one frame (or all frames)
						bool discard_all_matches = true;
						if (previous_frame_count != 1 && discard_all_matches) {
							for(unsigned int i=0; i<surfPairs.size(); i++){
								int index = surfPairs[i].first;
								keepKeypoint[index] = false;
							}
						}

						for(unsigned int i=0; i<validPoints.size(); i++){
							if(keepKeypoint[i]){
								newKeypoints.push_back(validKeypoints[i]);
								newDescriptors.push_back(validDescriptors[i]);
								newFeaturePoints.push_back(new_transform*validPoints[i]);
							}
						}
		#endif
					}

					// put these new keypoints in the right spot...
					// first remove the oldest frame if we're full
					if ((int)previous_keypoints.size() == previous_frame_count) {
						previous_keypoints.pop_front();
						previous_descriptors.pop_front();
						previous_feature_points.pop_front();
					}

					previous_keypoints.push_back(newKeypoints);
					previous_descriptors.push_back(newDescriptors);
					previous_feature_points.push_back(newFeaturePoints);

					std::cout<<"Added "<<newKeypoints.size()<<" keypoints in as most recent frame"<<std::endl;
				}

				tf::Transform ransac_relative_transform_ros = convert_eigen_transform3f_to_ros_transform(ransac_relative_transform);
				ransac_relative_transform_history.push_back(make_pair(current_frame_timestamp, ransac_relative_transform_ros));
			} //use_ransac


			Transform3f edge_icp_relative_transform = ransac_relative_transform;
			sensor_msgs::PointCloud edge_cloud;
			if (use_edge_icp) {
				ROS_INFO("Starting Edge ICP Section");

				sensor_msgs::ImagePtr edge_image;
				sensor_msgs::PointCloud initial_edge_cloud = *current_cloud_ptr;
				sensor_msgs::PointCloud *current_edge_cloud_ptr = &initial_edge_cloud;

				if (edge_icp_maximum_point_distance > 0.0) {
					Vector3f center(0,0,0);
					float max_radius = edge_icp_maximum_point_distance;
					std::deque<unsigned int> within_max_distance_indices = getRadiusDownsamplingIndices(*current_edge_cloud_ptr, center, max_radius, true);
					sensor_msgs::PointCloud points_within_max_radius;
					downsampleFromIndices(*current_edge_cloud_ptr, points_within_max_radius, within_max_distance_indices);
					current_edge_cloud_ptr = &points_within_max_radius;
				}

				std::deque<unsigned int> edge_indices = getEdgeDownsampleIndices(
						*current_edge_cloud_ptr,
						current_image_ptr,
						edge_image,
						canny_threshold_1,
						canny_threshold_2,
						canny_aperture,
						canny_prefilter_size);

				edge_image_publisher.publish(edge_image);

				downsampleFromIndices(*current_edge_cloud_ptr, edge_cloud, edge_indices);

				unsigned int minimum_cloud_size = 100;
				if (edge_cloud.get_points_size() > minimum_cloud_size) {
					// these normals are WRONG WRONG WRONG but not used ;)
					geometry_msgs::PointStamped pointStamped;
					pointStamped.header = current_cloud_ptr->header;
					pointStamped.point.x = pointStamped.point.y = pointStamped.point.z = 0.0;
					cloud_geometry::nearest::computePointCloudNormals(edge_cloud,k_normal_neighbors,pointStamped);

					edge_cloud.header = output_header;

					if (!animate_edge_icp) {
						edge_cloud_publisher.publish(edge_cloud);
					}
				}
				else {
					ROS_FATAL("Edge cloud has only %d points so it will be set to empty", edge_cloud.get_points_size());
					edge_cloud = sensor_msgs::PointCloud();
				}

				// with relative transforms must match against previous (untransformed) cloud
				if (!use_joint_icp && edge_cloud.get_points_size() > 0 && previous_edge_cloud.get_points_size() > 0) {
					ROS_INFO("Transform before edge icp:\n%s", getTransformString(edge_icp_relative_transform).c_str());

					ICP icp(edge_cloud, previous_edge_cloud);
					icp.setParams(edge_icp_params);
					icp.setInitialTransform(edge_icp_relative_transform);
					// set weights based on camera distance
					std::vector<float> icp_weights;
					// sqrt of weights because levmar squares the given weights
					get_sqrt_weights_based_on_distance_from_camera(edge_cloud, icp_weights);
					float sqrt_edge_icp_point_weight = sqrt(edge_icp_point_weight);
					for (std::vector<float>::iterator iter = icp_weights.begin(); iter != icp_weights.end(); ++iter) {
						*iter *= sqrt_edge_icp_point_weight;
					}
					icp.setWeights(icp_weights);

#if 0
					// here add the inlier constraints from RANSAC
					if (use_ransac && use_joint_icp && !last_ransac_failed) {
						float sqrt_ransac_icp_point_weight = sqrt(ransac_icp_point_weight);
						std::vector<float> inlier_pairs_weights(inlier_points_for_icp.size(), sqrt_ransac_icp_point_weight);
						icp.setFixedPointPairsAndWeights(inlier_points_for_icp, inlier_pairs_weights);
					}
#endif

					Transform3f icp_transform = icp.runICP();
					bool icp_success = icp.ICPSucceeded();
					ROS_INFO("ICP Result: %d", (int)icp_success);
					if (icp_success) {
						edge_icp_relative_transform = icp_transform;
					}

#if 0
					// temp code
					sensor_msgs::PointCloud pair_of_edge_clouds = previous_edge_cloud;
					sensor_msgs::PointCloud this_edge_cloud_transformed;
					transform_point_cloud(global_transform_from_edge_icp, edge_cloud, this_edge_cloud_transformed);
					merge_clouds(pair_of_edge_clouds, this_edge_cloud_transformed);
					edge_cloud_publisher.publish(pair_of_edge_clouds);
					// end temp
#endif

					if (animate_edge_icp && icp_success) {
						float sleep_frame = 0.25;
						float sleep_after = 0.0;
						std::deque<rgbd::eigen::Transform3f,rgbd::eigen::aligned_allocator<rgbd::eigen::Transform3f> > icp_transform_history = icp.getTransformHistory();
						//for (unsigned int i = 0; i < icp_transform_history.size(); i++) {
						for (int i = icp_transform_history.size() - 1; i >= 0; i--) {
							Transform3f progress_transform = icp_transform_history[i];
							sensor_msgs::PointCloud edge_icp_progress_cloud;
							transform_point_cloud(progress_transform, edge_cloud, edge_icp_progress_cloud);
							edge_cloud_publisher.publish(edge_icp_progress_cloud);
							ros::Duration(sleep_frame).sleep();
						}
						ros::Duration(sleep_after).sleep();
					}
				}

				/*
				Transform3f edge_icp_global_transform = last_global_transform * edge_icp_relative_transform;
				sensor_msgs::PointCloud edge_cloud_transformed;
				transform_point_cloud(edge_icp_global_transform, edge_cloud, edge_cloud_transformed);
				merge_clouds(collected_edge_cloud, edge_cloud_transformed);
				collected_edge_cloud_publisher.publish(collected_edge_cloud);
				*/

				if (!use_joint_icp) {
					previous_edge_cloud = edge_cloud;

					ROS_INFO("Transform after edge icp:\n%s", getTransformString(edge_icp_relative_transform).c_str());

					tf::Transform edge_icp_relative_transform_ros = convert_eigen_transform3f_to_ros_transform(edge_icp_relative_transform);
					edge_icp_relative_transform_history.push_back(make_pair(current_frame_timestamp, edge_icp_relative_transform_ros));
				}
			}


			Transform3f general_icp_relative_transform = edge_icp_relative_transform;
			sensor_msgs::PointCloud general_icp_cloud;
			if (use_general_icp) {
				ROS_INFO("Starting General ICP Section");

				// the cloud we use for ICP may be different than the cloud we merge in
				std::deque<unsigned int> downsample_indices;
				downsample_indices = getRandomDownsamplingIndices(*current_cloud_ptr, general_icp_random_downsample_rate);
				downsampleFromIndices(*current_cloud_ptr, general_icp_cloud, downsample_indices);
				general_icp_cloud.header = output_header;

				unsigned int minimum_cloud_size = 100;
				if (general_icp_cloud.get_points_size() > minimum_cloud_size) {
					// for normals
					// compute normals outside of ICP
					geometry_msgs::PointStamped pointStamped;
					pointStamped.header = current_cloud_ptr->header;
					pointStamped.point.x = pointStamped.point.y = pointStamped.point.z = 0.0;
					cloud_geometry::nearest::computePointCloudNormals(general_icp_cloud,k_normal_neighbors,pointStamped);
				}
				else {
					ROS_FATAL("General ICP cloud has only %d points so it will be set to empty", general_icp_cloud.get_points_size());
					general_icp_cloud = sensor_msgs::PointCloud();
				}

				if (!use_joint_icp && general_icp_cloud.get_points_size() > 0 && previous_general_icp_cloud.get_points_size() > 0) {
					ROS_INFO("Initial transform to general icp:\n%s", getTransformString(general_icp_relative_transform).c_str());

					ICP icp(general_icp_cloud, previous_general_icp_cloud);
					icp.setParams(general_icp_params);
					icp.setInitialTransform(general_icp_relative_transform);
					// sqrt of weights because levmar squares the given weights
					std::vector<float> icp_weights;
					get_sqrt_weights_based_on_distance_from_camera(general_icp_cloud, icp_weights);
					float sqrt_general_icp_point_weight = sqrt(general_icp_point_weight);
					for (std::vector<float>::iterator iter = icp_weights.begin(); iter != icp_weights.end(); ++iter) {
						*iter *= sqrt_general_icp_point_weight;
					}
					icp.setWeights(icp_weights);

#if 0
					// here add the inlier constraints from RANSAC
					if (use_ransac && use_joint_icp && !last_ransac_failed) {
						float sqrt_ransac_icp_point_weight = sqrt(ransac_icp_point_weight);
						std::vector<float> inlier_pairs_weights(inlier_points_for_icp.size(), sqrt_ransac_icp_point_weight);
						icp.setFixedPointPairsAndWeights(inlier_points_for_icp, inlier_pairs_weights);
					}
#endif

					// debug:
					ROS_INFO("About to run general ICP...");
					ROS_INFO("Target Cloud Size:%d", previous_general_icp_cloud.get_points_size());
					ROS_INFO("Source Cloud Size:%d", general_icp_cloud.get_points_size());

					Transform3f icp_transform = icp.runICP();
					bool icp_success = icp.ICPSucceeded();
					ROS_INFO("ICP Result: %d", (int)icp_success);
					if (icp_success) {
						general_icp_relative_transform = icp_transform;
					}

					// here could animate as in edge_icp

					ROS_INFO("Result transform from general icp:\n%s", getTransformString(general_icp_relative_transform).c_str());
				}

				if (!use_joint_icp) {
					// not applying transform...keeps it relative
					previous_general_icp_cloud = general_icp_cloud;

					tf::Transform general_icp_relative_transform_ros = convert_eigen_transform3f_to_ros_transform(general_icp_relative_transform);
					general_icp_relative_transform_history.push_back(make_pair(current_frame_timestamp, general_icp_relative_transform_ros));
				}
			} // end general icp

			Transform3f joint_icp_relative_transform = general_icp_relative_transform;
			if (use_joint_icp) {
				ROS_INFO("Starting Joint ICP Section");

				if (frames_processed > 0) {
					// not the first frame
					if (inlier_points_for_icp.size() < (unsigned int) min_ransac_inliers_to_skip_joint_icp) {
						// start with empty icp
						sensor_msgs::PointCloud empty_cloud;
						ICP icp(empty_cloud, empty_cloud);
						ICPParams joint_icp_params = general_icp_params;
						joint_icp_params.do_multiple_error_functions = true;
						assert(joint_icp_params.optimizer == LM);

						icp.setParams(joint_icp_params);
						// note this:  Should be from ransac if success, identity if failure
						Transform3f prior_transform = joint_icp_relative_transform;
						icp.setInitialTransform(prior_transform);

						if (use_edge_icp) {
							if (edge_cloud.get_points_size() > 0 && previous_edge_cloud.get_points_size() > 0) {
								// sqrt of weights because levmar squares the given weights
								std::vector<float> icp_weights;
								get_sqrt_weights_based_on_distance_from_camera(edge_cloud, icp_weights);
								float sqrt_param_weight = sqrt(edge_icp_point_weight);
								for (std::vector<float>::iterator iter = icp_weights.begin(); iter != icp_weights.end(); ++iter) {
									*iter *= sqrt_param_weight;
								}
								icp.addCloudsWithWeightsAndErrorFunction(edge_cloud, previous_edge_cloud, icp_weights, MSE_NONLINEAR);
							}
							else {
								ROS_FATAL("Either previous or current edge cloud is empty");
							}
						}

						if (use_general_icp && (!use_edge_icp || edge_cloud.get_points_size() < (unsigned int) min_edge_points_to_skip_general_icp)) {
							if (general_icp_cloud.get_points_size() > 0 && previous_general_icp_cloud.get_points_size() > 0) {
								// sqrt of weights because levmar squares the given weights
								std::vector<float> icp_weights;
								get_sqrt_weights_based_on_distance_from_camera(general_icp_cloud, icp_weights);
								float sqrt_param_weight = sqrt(general_icp_point_weight);
								for (std::vector<float>::iterator iter = icp_weights.begin(); iter != icp_weights.end(); ++iter) {
									*iter *= sqrt_param_weight;
								}
								icp.addCloudsWithWeightsAndErrorFunction(general_icp_cloud, previous_general_icp_cloud, icp_weights, POINT_TO_PLANE);
							}
							else {
								ROS_FATAL("Either previous or current general icp cloud is empty");
							}
						}
						else {
							ROS_WARN("Skipping GENERAL ICP because edge points: %d >= %d", edge_cloud.get_points_size(), min_edge_points_to_skip_general_icp);
						}

						if (use_ransac && !last_ransac_failed) {
							// here add the inlier constraints from RANSAC
							float sqrt_param_weight = sqrt(ransac_icp_point_weight);
							std::vector<float> inlier_pairs_weights(inlier_points_for_icp.size(), sqrt_param_weight);
							icp.setFixedPointPairsAndWeights(inlier_points_for_icp, inlier_pairs_weights);
						}

						if (use_transform_priors) {
							if (!ignore_prior_on_ransac_success || last_ransac_failed) {
								float sqrt_param_weight = sqrt(prior_icp_component_weight);
								rgbd::eigen::Matrix<float,7,1> prior_transform_as_vector = convertTransformToVector(prior_transform);
								icp.setSimpleTransformPriors(prior_transform_as_vector, sqrt_param_weight);
							}
						}

						Transform3f icp_transform = icp.runICP();
						bool icp_success = icp.ICPSucceeded();
						ROS_INFO("Joint ICP Result: %d", (int)icp_success);
						if (icp_success) {
							joint_icp_relative_transform = icp_transform;
						}
					}
					else {
						ROS_WARN("Skipping JOINT ICP because ransac: %d >= %d", inlier_points_for_icp.size(), min_ransac_inliers_to_skip_joint_icp);
					}
				} // end align

				// remember to update previous clouds (even on first frame)
				previous_edge_cloud = edge_cloud;
				previous_general_icp_cloud = general_icp_cloud;
			} // end joint icp


			// the overall result (before loop closure)
			Transform3f new_relative_transform = joint_icp_relative_transform;
			new_global_transform = last_global_transform * new_relative_transform;

			tf::Transform new_relative_transform_ros = convert_eigen_transform3f_to_ros_transform(new_relative_transform);
			overall_relative_transform_history.push_back(make_pair(current_frame_timestamp, new_relative_transform_ros));

			// The following happens even on the first cloud:
			// on the first cloud the relative and global transforms will be the identity

			// create toro edges for every frame
			int toro_id = frames_processed;
			if (use_loop_closure) {
				// add a toro vertex
				ToroTransformation new_toro_transform = convert_transformation_eigen_to_toro(new_global_transform);
				//ToroVertex* new_toro_vertex = toro_graph.addVertex(toro_id, new_toro_transform.toPoseType());
				toro_graph.addVertex(toro_id, new_toro_transform.toPoseType());
				// toro3d.cpp also sets new_toro_vertex->transformation...?
				// doesn't seem to matter...
				//new_toro_vertex->transformation  = new_toro_transform;

				// need to add to allframes
				allframes.push_back(KeyFrame());
				KeyFrame& pairwise_keyframe = allframes.back();
				pairwise_keyframe.stamp = current_frame_timestamp;
				pairwise_keyframe.keypoints = validKeypoints;
				pairwise_keyframe.descriptors = validDescriptors;
				pairwise_keyframe.feature_points = validPoints;
				//pairwise_keyframe.point_cloud = new_cloud_to_merge;
				//pairwise_keyframe.image = *current_image_ptr;
				pairwise_keyframe.toro_id = toro_id;

				// if not the first frame create toro constraint to previous frame
				if (toro_id > 0) {
					ToroTransformation toro_relative_transformation = convert_transformation_eigen_to_toro(new_relative_transform);

					// hardcode an information matrix
					// inverse of a made up covariance matrix?
					// first 3 are x,y,z, next 3 are roll, pitch, yaw
					double xyz_variance = 1.0;
					double rpy_variance = 1.0;
					if (last_ransac_failed) {
						bool experiment = false;
						if (experiment) {
							rgbd::eigen::Matrix<float,7,1> tv = convertTransformToVector(new_relative_transform);
							float quaternion_piece = tv[1] * tv[1] + tv[2] * tv[2] + tv[3] * tv[3];
							float translation_piece = tv[4] * tv[4] + tv[5] * tv[5] + tv[6] * tv[6];
							xyz_variance = 1 * translation_piece * toro_variance_on_ransac_failure;
							rpy_variance = 10 * quaternion_piece * toro_variance_on_ransac_failure;
							std::cout << "TORO xyz_variance:" << xyz_variance << std::endl;
							std::cout << "TORO rpy_variance:" << rpy_variance << std::endl;
						}
						else {
							xyz_variance = toro_variance_on_ransac_failure;
							rpy_variance = toro_variance_on_ransac_failure;
						}
					}
					ToroInformation toro_information_matrix = ToroInformation::I(6);
					for (int j = 0; j < 3; j++) {
						toro_information_matrix[j][j] = 1.0 / xyz_variance;
					}
					for (int j = 3; j < 6; j++) {
						toro_information_matrix[j][j] = 1.0 / rpy_variance;
					}

					// here you could not add an edge if the constraint is weak (or nonexistant)

					toro_graph.addEdge(
							toro_graph.vertex(toro_id-1),
							toro_graph.vertex(toro_id),
							toro_relative_transformation,
							toro_information_matrix);
				}
			} // end toro for every frame


			// Look at keyframes and loop closure
			bool add_as_new_keyframe = false;
			if (use_ransac && !last_ransac_failed) {
				// keyframes
				if (keyframes.empty()) {
					ROS_INFO("Adding first keyframe");
					add_as_new_keyframe = true;
				}
				else {
					// see if we can still align against the previous keyframe
					// if so, we don't need a new keyframe yet (note that this is slow ;) )
					KeyFrame new_keyframe;
					new_keyframe.keypoints = validKeypoints;
					new_keyframe.descriptors = validDescriptors;
					new_keyframe.feature_points = validPoints;
					// don't need image or pointcloud or stamp for this check (and cloud is expensive to copy) (I think...)
					KeyFrame& previous_keyframe = keyframes.back();

					Transform3f previous_keyframe_ransac_transform;
					bool ransac_success_keyframe = ransac_consistent_alignment_between_keyframes(new_keyframe, previous_keyframe, min_ransac_inliers, previous_keyframe_ransac_transform);
					add_as_new_keyframe = !ransac_success_keyframe;

					/*
					// also, regardless of the result of check, update the relative keyframe transform
					Transform3f previous_keyframe_transform = keyframe_transforms.back();
					keyframe_transforms.back() = previous_keyframe_transform * ransac_relative_transform;

					// this is a check...if we recovered a direct transform, see how it compares with the commulative transform
					if (ransac_success_keyframe) {
						ROS_INFO("Collected Keyframe Transform:\n%s", getTransformString(keyframe_transforms.back()).c_str());
						ROS_INFO("...vs direct transform      :\n%s", getTransformString(previous_keyframe_ransac_transform).c_str());
					}
					*/
				}

				if (add_as_new_keyframe) {
					ROS_INFO("Adding new keyframe");

					keyframes.push_back(KeyFrame());
					KeyFrame& new_keyframe = keyframes.back();
					new_keyframe.stamp = current_frame_timestamp;
					new_keyframe.keypoints = validKeypoints;
					new_keyframe.descriptors = validDescriptors;
					new_keyframe.feature_points = validPoints;
					new_keyframe.point_cloud = new_cloud_to_merge;
					new_keyframe.image = *current_image_ptr;
					new_keyframe.toro_id = toro_id;

					// for prefilter check
					keyframe_global_transforms.push_back(new_global_transform);

					if (use_loop_closure) {
#if 0
						// add a toro vertex
						// I THINK the pose of the vertex is in global coordinates
						ToroTransformation new_toro_transform = convert_transformation_eigen_to_toro(last_global_transform * ransac_relative_transform);
						//ToroVertex* new_toro_vertex = toro_graph.addVertex(toro_id, new_toro_transform.toPoseType());
						toro_graph.addVertex(toro_id, new_toro_transform.toPoseType());
						// toro3d.cpp also sets new_toro_vertex->transformation...?
						// doesn't seem to matter...
						//new_toro_vertex->transformation  = new_toro_transform;
#endif

						if (keyframes.size() > 1) {
							// not the first keyframe
#if 0
							Transform3f transform_to_previous_keyframe = keyframe_transforms.back();
							ToroTransformation toro_relative_transformation = convert_transformation_eigen_to_toro(transform_to_previous_keyframe);
#endif

							// hardcode an information matrix
							// inverse of a made up covariance matrix?
							// first 3 are x,y,z, next 3 are roll, pitch, yaw
							double xyz_variance = toro_variance_on_loop_closure;
							double rpy_variance = toro_variance_on_loop_closure;
							ToroInformation toro_information_matrix = ToroInformation::I(6);
							for (int j = 0; j < 3; j++) {
								toro_information_matrix[j][j] = 1.0 / xyz_variance;
							}
							for (int j = 3; j < 6; j++) {
								toro_information_matrix[j][j] = 1.0 / rpy_variance;
							}

#if 0
							toro_graph.addEdge(
									toro_graph.vertex(toro_id-1),
									toro_graph.vertex(toro_id),
									toro_relative_transformation,
									toro_information_matrix);
#endif


							// now do the slow check for loop closures...
							ROS_INFO("Testing for loop closure...");
							bool loop_closure_found = false;
							for (int i = 0; i < (int) keyframes.size() - 1; i++) {
								KeyFrame& previous_keyframe = keyframes.at(i);

								// do check to see if keyframes are within distance
								Vector3f origin_this_keyframe = new_global_transform * Vector3f(0,0,0);
								Vector3f origin_previous_keyframe = keyframe_global_transforms.at(i) * Vector3f(0,0,0);
								float origin_distance = (origin_this_keyframe-origin_previous_keyframe).norm();
								ROS_INFO("Comparing keyframe distance %f to loop closure distance %f", origin_distance, loop_closure_prefilter_distance);
								if (loop_closure_prefilter_distance > 0 && origin_distance > loop_closure_prefilter_distance) {
									ROS_INFO("Keyframe prefiltered due to distance:%f", origin_distance);
								}
								else {
									Transform3f ransac_transform;
									bool ransac_success = ransac_consistent_alignment_between_keyframes(new_keyframe, previous_keyframe, min_ransac_inliers_for_loop_closure, ransac_transform);
									if (ransac_success) {
										ROS_WARN("Closure detected with keyframe %d", i);
										loop_closure_found = true;

										ToroTransformation loop_closure_transformation = convert_transformation_eigen_to_toro(ransac_transform);
										int previous_toro_id = previous_keyframe.toro_id;

										// also reversed?
										// yes!!
										toro_graph.addEdge(
												toro_graph.vertex(previous_toro_id),
												toro_graph.vertex(toro_id),
												loop_closure_transformation,
												toro_information_matrix);

										// print out the added toro edge
										std::cout << "TORO loop closure frames: " << previous_toro_id << " " << toro_id << std::endl;
										std::cout << "TORO loop closure timestamps: " <<
												convert_timestamp_to_string(previous_keyframe.stamp, "-") << " " <<
												convert_timestamp_to_string(current_frame_timestamp, "-") << std::endl;
									}
									else {
										ROS_INFO("Closure NOT detected with keyframe %d", i);
									}
								}
							}

							if (loop_closure_found) {
								ROS_INFO("About to initialize toro graph");
								//getchar();
								toro_graph.verboseLevel=0;
								toro_graph.buildSimpleTree();
								// may want to initialize once
								ToroGraph::EdgeCompareMode compareMode = AISNavigation::EVComparator<ToroGraph::Edge*>::CompareLevel;
								toro_graph.initializeTreeParameters();
								toro_graph.initializeOptimization(compareMode);

								ROS_INFO("About to optimize toro graph");
								//getchar();
								// then optimize...
								// (from toro3d.cpp)
								//int iterations = 100;
								bool dumpError = true;
								bool corrupted = false;
								//cerr << "**** Starting optimization ****" << endl;
								ROS_INFO("Starting TORO optimization...");
								//struct timeval ts, te;
								//gettimeofday(&ts,0);
								double previous_error = 1e100;
								for (int i=0; i < toro_iterations; i++) {
									toro_graph.iterate(0,false); // false is "ignore preconditioner"
									double mte, mre, are, ate;
									double error=toro_graph.error(&mre, &mte, &are, &ate);
									if (dumpError){
										// compute the error and dump it
										//double mte, mre, are, ate;
										//double error=toro_graph.error(&mre, &mte, &are, &ate);
#if 0
										cerr 	<< "iteration " << i << " RotGain=" << pg.getRotGain() << endl
												<< "  global error = " << error << "   error/constraint = " << error/nEdges << endl;
										cerr 	<< "  mte=" << mte << "  mre=" << mre << " are=" << are << " ate=" << ate << endl;
										errorStream << i << " "
										  << pg.getRotGain() << " "
										  << error << " "
										  << error/nEdges << " "
										  << mre << " "
										  << are << " "
										  << mte << " "
										  << ate << endl;
#endif

										std::cout << "TORO Error:" << error << std::endl;
										if (mre>(M_PI/2)*(M_PI/2))
											corrupted=true;
										else
											corrupted=false;
									}
									// YEAH....YOU NEED ABS HERE, FOOL!
									double error_ratio = abs(previous_error - error) / error;
									//if (error_ratio < toro_min_error_ratio) {
									if (false) {
										std::cout << "Stopping TORO due to error ratio: " << error_ratio << std::endl;
										break;
									}
									previous_error = error;
								}
								ROS_INFO("Done with TORO optimization");

								ROS_INFO("Updating all frame positions...");

								global_transform_history.clear();

								for (ToroGraph::VertexMap::iterator it=toro_graph.vertices.begin(); it!=toro_graph.vertices.end(); it++){
									ToroVertex* v=it->second;
									v->pose=v->transformation.toPoseType();

#if 0
									std::cout << "VERTEX3 "
									   << v->id << " "
									   << v->pose.x() << " "
									   << v->pose.y() << " "
									   << v->pose.z() << " "
									   << v->pose.roll() << " "
									   << v->pose.pitch() << " "
									   << v->pose.yaw() << std::endl;
#endif

									ToroTransformation new_vertex_global_transformation(v->pose);
									Transform3f new_eigen_global_transform = convert_transformation_toro_to_eigen(new_vertex_global_transformation);

									// update collected cloud to only keyframes??
									if (do_produce_collected_cloud) {
										int keyframe_index = -1;
										for (unsigned int k = 0; k < keyframes.size(); k++) {
											if (keyframes[k].toro_id == v->id) {
												keyframe_index = k;
												break;
											}
										}
										if (keyframe_index >= 0) {
											// make a new collected cloud based on toro optimized transforms
											if (keyframe_index == 0) {
												// this clears all points and channels, leaving header and names intact
												copyHeaderAndChannelNames(collected_cloud, collected_cloud);
											}

											sensor_msgs::PointCloud transformed_keyframe_cloud;
											transform_point_cloud(new_eigen_global_transform, keyframes[keyframe_index].point_cloud, transformed_keyframe_cloud);
											merge_clouds(collected_cloud, transformed_keyframe_cloud);
										}
									}

									// update all transforms in global history to toro results
									ros::Time toro_transform_ts = allframes[v->id].stamp;
									tf::Transform ros_global_transform = convert_eigen_transform3f_to_ros_transform(new_eigen_global_transform);
									global_transform_history.push_back(std::make_pair(toro_transform_ts, ros_global_transform));

									/*
									// also publish the updated toro transforms as we go
									tf::StampedTransform stamped_transform_toro(ros_global_transform, toro_transform_ts, world_frame, loop_closure_frame);
									tf_broadcaster.sendTransform(stamped_transform_toro);
									*/
								}

								// Now toro results go in global history, so that will be written at the end of the callback
#if 0
								// save the toro "history"
								if (do_write_transforms_to_files) {
									ROS_INFO("Writing global toro transforms to file:%s", toro_global_transforms_output_filename.c_str());
									write_transforms_to_file(toro_global_transforms_output_filename, toro_global_transform_history);
									/*
									 * TODO: maintain toro relative transform history from edges
									ROS_INFO("Writing relative toro transforms to file:%s", toro_relative_transform.c_str());
									write_transforms_to_file(toro_global_transforms_output_filename, toro_transform_history);
									*/
								}
#endif

								// now need to update the current global transform based on toro result
								// I think this is accomplished by setting "last_global_transform" (global)
								// to be the optimized pose of the just added toro node
								new_global_transform = convert_transformation_toro_to_eigen(toro_graph.vertex(toro_id)->transformation);

								ROS_INFO("Finished loop closure for frame %d", frames_processed);
								if (pause_on_loop_closure) {
									ROS_INFO("[Paused]  (on loop closure)");
									getchar();
								}
								// I don't think we need this...
								//ransac_relative_transform.setIdentity();

							}// end toro optimization
						} // end keyframes not empty
					} // end loop closure

					// for any keyframe, including the first:

					// push the fresh transform for building up the transform back to this new keyframe
					//keyframe_transforms.push_back(Transform3f());
					//keyframe_transforms.back().setIdentity();

				} // end add_as_new_keyframe
			} // end if (useRansac) (for keyframes)


			tf::Transform new_global_transform_ros = convert_eigen_transform3f_to_ros_transform(new_global_transform);
			// publish the transforms via tf
			//const tf::Transform& input, const ros::Time& timestamp, const std::string & frame_id, const std::string & child_frame_id):
			// perhaps a different child frame for every frame??
			tf::StampedTransform stamped_transform_pairwise(new_global_transform_ros, current_frame_timestamp, world_frame, pairwise_frame);
			tf_broadcaster.sendTransform(stamped_transform_pairwise);

			/*
			if (add_as_new_keyframe) {
				tf::StampedTransform stamped_transform_keyframe(new_global_transform_ros, current_frame_timestamp, world_frame, keyframe_frame);
				tf_broadcaster.sendTransform(stamped_transform_keyframe);
			}
			*/

			// maintain history for file output
			// need to check if toro has already added this frame
			if (global_transform_history.empty() || global_transform_history.back().first != current_frame_timestamp) {
				global_transform_history.push_back(std::make_pair(current_frame_timestamp, new_global_transform_ros));
			}

			if (do_write_transforms_to_files) {
				std::string global_transforms_base = "global.txt";
				std::string ransac_relative_base = "ransac_relative.txt";
				std::string edge_icp_relative_base = "edge_icp_relative.txt";
				std::string general_icp_relative_base = "general_icp_relative.txt";
				std::string overall_relative_base = "relative.txt";

				// First overwrite the base files
				write_transforms_to_file(created_output_folder + global_transforms_base, global_transform_history);
				write_transforms_to_file(created_output_folder + ransac_relative_base, ransac_relative_transform_history);
				write_transforms_to_file(created_output_folder + edge_icp_relative_base, edge_icp_relative_transform_history);
				write_transforms_to_file(created_output_folder + general_icp_relative_base, general_icp_relative_transform_history);
				write_transforms_to_file(created_output_folder + overall_relative_base, overall_relative_transform_history);

				// now write the global transforms for every timestamp
				std::string timestamp_for_filename = convert_timestamp_to_string(current_frame_timestamp, "-");
				write_transforms_to_file(created_output_folder + timestamp_for_filename + ".txt", global_transform_history);
			}

			last_global_transform = new_global_transform;

		} // end alignment (including first cloud)

		// dump the images and clouds (and depthmaps?) for every aligned frame
		// maybe want option to dump when playing back transformations as well??
		std::string full_path_no_extension = created_output_folder + convert_timestamp_to_string(current_frame_timestamp, "-");
		if (do_dump_raw_data) {
			// save the image
			std::string image_filename = full_path_no_extension + ".png";
			sensor_msgs::CvBridge bridge;
			IplImage *image_cv = bridge.imgMsgToCv(current_image_ptr,"bgr8");
			cvSaveImage(image_filename.c_str(), image_cv);
			ROS_INFO("Dumped image:%s", image_filename.c_str());

			// save the cloud as ply
			std::string ply_filename = full_path_no_extension + ".ply";
			write_ply_file(*current_cloud_ptr, ply_filename);
			ROS_INFO("Dumped ply:%s", ply_filename.c_str());

			/*
			// save the cloud as pcd
			std::string pcd_filename = full_path_no_extension + ".pcd";
			cloud_io::savePCDFile(pcd_filename.c_str(), *current_cloud_ptr, true);
			ROS_INFO("Dumped pcd:%s", pcd_filename.c_str());
			*/
		}

		if (do_dump_sift_descriptors) {
			// save the sift features
			std::string sift_filename = full_path_no_extension + ".sift";
			std::vector<std::pair<int, int> > feature_image_coordinates(validKeypoints.size());
			for (unsigned int i = 0; i < validKeypoints.size(); i++) {
				feature_image_coordinates[i] = std::make_pair(validKeypoints[i].x, validKeypoints[i].y);
			}
			// need to point index of the sift descriptors
			// TODO

			write_sift_descriptors(validCloudIndices, feature_image_coordinates, validPoints, validDescriptors, sift_filename);
		}



		if (do_produce_collected_cloud) {
			if (do_read_transforms_for_every_frame) {
				copyHeaderAndChannelNames(collected_cloud, collected_cloud);
				collected_cloud.header = output_header;
				for (unsigned int i = 0; i < allframes.size(); i++) {
					Transform3f loaded_transform_for_frame;
					bool found_transform_in_history = false;
					for (unsigned int j = 0; j < loaded_global_transform_history.size(); j++) {
						if (loaded_global_transform_history[j].first == allframes[i].stamp) {
							found_transform_in_history = true;
							loaded_transform_for_frame = convert_ros_transform_to_eigen_transform3f(loaded_global_transform_history[j].second);

							// this should not be necessary...deserves more attention later
							rgbd::eigen::Matrix<float,7,1> v = convertTransformToVector(loaded_transform_for_frame);
							loaded_transform_for_frame = convertVectorToTransform(v);
						}
					}
					if (!found_transform_in_history) {
						ROS_WARN("No transform found in currently loaded file for stamp:%f", allframes[i].stamp.toSec());
						continue;
					}
					sensor_msgs::PointCloud cloud_to_update;
					transform_point_cloud(loaded_transform_for_frame, allframes[i].point_cloud, cloud_to_update);
					mergeClouds(collected_cloud, cloud_to_update);
				}
			}
			else {

				if(use_surfels){

					//float maxNormalToAdd = 60*M_PI/180;
					float maxNormalToAdd = 80*M_PI/180;
					float minNormalAgreement = 45*M_PI/180;
					float maxInterpolationDist = .04;
					//float corrDistForUpdate = .04;
					float corrDistForUpdate = .04;
					unsigned int highConfidence = 4; // if this high, see through is a false reading
					unsigned int starveConfidence = 0; // remove if not seen in 60 frames and below this confidence
					unsigned int timeDiffForRemoval = 60;


					std::vector<rgbd::eigen::Vector3f> zeros(camParams.yRes,rgbd::eigen::Vector3f::Zero());
					std::vector<bool> falses(camParams.yRes,false);

					std::vector<std::vector<rgbd::eigen::Vector3f> > pointGrid(camParams.xRes,zeros);
					std::vector<std::vector<rgbd::eigen::Vector3f> > normalGrid(camParams.xRes,zeros);
					std::vector<std::vector<bool> > validityGrid(camParams.xRes,falses);
					std::vector<std::vector<bool> > willingToAdd(camParams.xRes,falses);

					// compute slowly
//					int normalsK = 15;
//					cloud_geometry::nearest::computePointCloudNormals(new_cloud_to_merge,normalsK,geometry_msgs::PointStamped());

					// compute normals quickly (note that xChan changes after computing organized cloud)
					int xChanNew = get_channel_index(new_cloud_to_merge,"image_x");
					int yChanNew = get_channel_index(new_cloud_to_merge,"image_y");
					sensor_msgs::PointCloud organized_cloud;
					computeOrganizedPointCloud(new_cloud_to_merge, organized_cloud, validityGrid, xChanNew, yChanNew, camParams.xRes, camParams.yRes);
					unsigned int normals_window_size = 2;
					unsigned int normals_downsample = 2;
					float normals_max_z_diff = 0.03;

					setNormals(organized_cloud, validityGrid, normals_window_size, normals_downsample, camParams.xRes, camParams.yRes, normals_max_z_diff);


					int normalChan = get_normal_channel_index(organized_cloud);
					int xChanOrganized = get_channel_index(organized_cloud,"image_x");
					int yChanOrganized = get_channel_index(organized_cloud,"image_y");

					// transform before you fill in the structures
//					transform_point_cloud_in_place(new_global_transform, organized_cloud);
//					rgbd::eigen::Vector3f transformed_origin = new_global_transform * rgbd::eigen::Vector3f::Zero();

					//fill in the structures
					for(unsigned int i=0; i < organized_cloud.get_points_size(); i++)
					{
						unsigned int x = organized_cloud.channels[xChanOrganized].values[i];
						unsigned int y = organized_cloud.channels[yChanOrganized].values[i];
						pointGrid[x][y] = rgbd::eigen::Vector3f(
								organized_cloud.points[i].x,
								organized_cloud.points[i].y,
								organized_cloud.points[i].z);
						normalGrid[x][y] = rgbd::eigen::Vector3f(
								organized_cloud.channels[normalChan].values[i],
								organized_cloud.channels[normalChan+1].values[i],
								organized_cloud.channels[normalChan+2].values[i]);
						// already set by createOrganizedCloud...don't mess that up!
						//validityGrid[x][y] = true;

						float normalAngle = getAngleNormalToCamera(normalGrid[x][y],pointGrid[x][y],rgbd::eigen::Vector3f::Zero());
//						float normalAngle = getAngleNormalToCamera(normalGrid[x][y],pointGrid[x][y], transformed_origin);
						willingToAdd[x][y] = normalAngle < maxNormalToAdd;
					}

					Transform3f inverse_global_transform = invertTransform(new_global_transform);
					for(unsigned int i=0; i<surfels.size(); i++)
						transformSurfelInPlace(surfels[i],inverse_global_transform);

					std::vector<bool> okayToUpdateSurfel(surfels.size(),true);
					std::vector<unsigned int> replaced,removed;
					rgbd::eigen::Transform3f identity;
					identity.setIdentity();
					updateSurfelModel(surfels,surfelColors,surfelMinAngleFromNormal,okayToUpdateSurfel,
							surfelLastSeen,frames_processed,current_image_ptr,camParams,identity,
							pointGrid,normalGrid,validityGrid,willingToAdd,replaced,removed,
							maxInterpolationDist,corrDistForUpdate,highConfidence,starveConfidence,
							timeDiffForRemoval,maxNormalToAdd,minNormalAgreement);

					for(unsigned int i=0; i<surfels.size(); i++)
						transformSurfelInPlace(surfels[i],new_global_transform);

					convertSurfelsToPointCloud(surfels, collected_cloud);
					setSurfelCloudColors(surfelColors, collected_cloud);

				}
				else {

					transform_point_cloud_in_place(new_global_transform, new_cloud_to_merge);
					merge_clouds(collected_cloud, new_cloud_to_merge);

				}



			}
			collected_cloud_publisher.publish(collected_cloud);
			ROS_INFO("Published collected cloud of %d points", collected_cloud.get_points_size());

			if (do_dump_all_collected_clouds) {
				std::string full_ply_path = created_output_folder + convert_timestamp_to_string(current_frame_timestamp, "-") + "-collected.ply";
				try
				{
					write_ply_file(collected_cloud, full_ply_path);
					ROS_INFO("Successfully wrote:%s", full_ply_path.c_str());
				}
				catch(const std::exception& x)
				{
					ROS_WARN("Failed to write:%s", full_ply_path.c_str());
				}
			}
		}

    	ros::Time end = ros::Time::now();
    	ros::Duration dur = end-start;
    	total_processing_time += dur.toSec();

    	ROS_INFO("Frame took time:%f, mean time:%f", dur.toSec(), (total_processing_time / frames_processed));
    	ROS_INFO("[[[Frame %d Complete]]]", frames_processed);

    	frames_processed++;

    	// if we've just processed the last loaded transform, publish final cloud
    	// note that if we happen not to see the frames going with the last transform this will never occur...
		if (do_read_transforms_from_file && do_produce_collected_cloud && !do_read_transforms_for_every_frame) {
			ros::Time last_loaded_timestamp = loaded_global_transform_history.back().first;
			if (current_frame_timestamp >= last_loaded_timestamp) {
				final_cloud_publisher.publish(collected_cloud);
				ROS_INFO("Published final cloud of %d points", collected_cloud.get_points_size());

				// write the final cloud to ply
				ROS_INFO("Beginning to write final ply");
				std::string full_ply_path = created_output_folder + convert_timestamp_to_string(current_frame_timestamp, "-") + "-final.ply";
				try
				{
					write_ply_file(collected_cloud, full_ply_path);
					ROS_INFO("Successfully wrote:%s", full_ply_path.c_str());
				}
				catch(const std::exception& x)
				{
					ROS_WARN("Failed to write:%s", full_ply_path.c_str());
				}

				ROS_INFO("[PAUSED]");
				getchar();
			}
		}

    	if (pause_after_alignment) {
    		ROS_INFO("[PAUSED]");
    		getchar();
    	}
    }

    int start_cloud_subscription()
    {
    	// The old way:
    	//cloud_sub = nh_local.subscribe(cloud_subscription_topic, subscription_queue_size, sync.synchronize(&registration::ICPNode::cloud_cb, this));
    	//image_sub = nh_local.subscribe(image_subscription_topic, subscription_queue_size, sync.synchronize(&registration::ICPNode::image_cb, this));

    	// The new way with message filters
    	int queue_size = 0; // 0 means unlimited queue...or so I've heard
    	cloud_subscription_filtered.subscribe(nh_local, cloud_subscription_topic, queue_size);
    	image_subscription_filtered.subscribe(nh_local, image_subscription_topic, queue_size);
		sync.connectInput(cloud_subscription_filtered, image_subscription_filtered);
		sync.registerCallback(boost::bind(&ICPNode::sync_cb, this, _1, _2));
		// counts down to 0, then resets
		subscription_frame_counter = subscription_frame_skip;
		initial_frame_counter = initial_frame_skip;

		// create the output folder for transforms and raw data
		if (do_write_transforms_to_files) {
			std::stringstream ss;
			ros::Time folder_ts = ros::Time::now();
			//ss << folder_ts.sec << "-" << folder_ts.nsec << "/";
			ss << folder_ts.sec << "/";
			std::string folder_name = ss.str();
			created_output_folder = base_output_folder + folder_name;
			boost::filesystem::path path_to_create(created_output_folder);
			boost::filesystem::create_directory(path_to_create);

			ROS_INFO("Created output folder:%s", created_output_folder.c_str());
		}


		ROS_INFO("Waiting to send ready messages [press enter]");
		getchar();

		ros::Rate loop_rate(1.0);

		while(!callback_ever_called) {
			//ros::Duration(1.0).sleep();
			rgbd_player::ReadyMessage ready_message;
			ready_message.name = "icp_node";
			ready_message.stamp = ros::Time(0);
			ready_message_publisher.publish(ready_message);
			ROS_INFO("Just published ready message");
			ros::spinOnce();
			loop_rate.sleep();
		}

    	ros::spin();
    	return 0;
    }


};// class
} // namespace

int main (int argc, char** argv)
{
	ros::init (argc, argv, "icp_node");
	registration::ICPNode icp_node;
	return icp_node.start_cloud_subscription();
}
