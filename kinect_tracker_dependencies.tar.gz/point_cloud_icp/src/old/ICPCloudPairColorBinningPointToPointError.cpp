/*
 * ICPCloudPairColorBinningPointToPointError: point-to-point error metric disallowing matches between dissimilar colors
 *
 * Evan Herbst
 * 4 / 2 / 10
 */

#include "point_cloud_icp/registration/icpPoint2Point.h"
#include "point_cloud_icp/registration/ICPCloudPairColorBinningPointToPointError.h"

namespace registration
{

ICPCloudPairColorBinningPointToPointError::ICPCloudPairColorBinningPointToPointError(ICPCloudPairParams const& params,
		sensor_msgs::PointCloud const& source_pointcloud, sensor_msgs::PointCloud const& target_pointcloud, std::vector<float> const& point_weights)
: ICPCloudPairColorBinning(params, source_pointcloud, target_pointcloud), ICPCloudPairPointToPointError(params, source_pointcloud, target_pointcloud),
  ICPCloudPairScalarWeights(params, source_pointcloud, target_pointcloud, point_weights)
{
}

void ICPCloudPairColorBinningPointToPointError::getSourceErrorVector(rgbd::eigen::Transform3f const& transform,
		std::vector<int> const& correspondence_indices, std::vector<float> & result) const
{
	icp::point2point::getSourceErrorVector(m_source_eigen_points, m_point_weights, transform, correspondence_indices, result);
}

void ICPCloudPairColorBinningPointToPointError::getTargetErrorVector(std::vector<int> const& correspondence_indices, std::vector<float> & result) const
{
	icp::point2point::getTargetErrorVector(m_target_eigen_points, m_point_weights, correspondence_indices, result);
}

} //namespace
