/*
 * icp_sequence_reader.cpp
 *
 *  Created on: Jan 16, 2010
 *      Author: mkrainin
 */

#include <vector>
#include <algorithm>
#include <sstream>
#include <string>
#include <iostream>
#include <fstream>
#include <boost/filesystem.hpp>
#include <boost/make_shared.hpp>
#include <roslib/Header.h>
#include <ros/package.h>
#include <ros/node_handle.h>
#include <ros/publisher.h>
#include <geometry_msgs/Point.h>
#include <geometry_msgs/PointStamped.h>
#include <sensor_msgs/PointCloud2.h>
#include "rgbd_util/eigen/Core"
#include "rgbd_util/eigen/Geometry"
#include "point_cloud_icp/registration/icp_utility.h"
#include "point_cloud_icp/registration/icp_combined.h"
using namespace Eigen;

namespace registration
{


class ICPSequenceReader
{
protected:
    ros::NodeHandle nh_global;
    ros::NodeHandle nh_local;

    //for publishing
    ros::Publisher global_cloud_publisher_;
    ros::Publisher source_cloud_publisher_;

    ICPCombinedParams icp_params;
    ICPCloudPairParams pair_params;

    bool read_transforms;
    std::deque<rgbd::eigen::Transform3f,rgbd::eigen::aligned_allocator<rgbd::eigen::Transform3f> > transforms;

	float cloud_initial_random_downsample_rate;
	bool merge_clouds_using_density;

	//frame information
	std::string data_directory;
	std::string data_basename;
	unsigned int start_frame,end_frame;

public:

    ICPSequenceReader ()
    : nh_global(),
      nh_local("~")
    {
    	nh_local.param("data_directory", data_directory, std::string("data"));
    	nh_local.param("data_basename", data_basename, std::string("frame"));

    	nh_local.param("read_transforms", read_transforms, false);

    	int frames;
    	nh_local.param("start_frame", frames, 0);
    	start_frame = frames;
    	nh_local.param("end_frame", frames, 0);
    	end_frame = frames;

    	//optimizer
    	icp_params.optimizer = OPTIMIZER_LEVMAR;

    	double temp_double;

    	nh_local.param("max_distance", temp_double, -1.0);
    	pair_params.max_distance = (float) temp_double;

    	nh_local.param("max_rounds", icp_params.max_icp_rounds, -1);
    	icp_params.max_lm_rounds = 1000;

//    	nh_local.param("min_dist_to_continue", temp_double, .0001);
//    	icp_params.min_dist_to_continue = (float) temp_double;

//	   	nh_local.param("min_rot_to_continue", temp_double, .0001);
//    	icp_params.min_rot_to_continue = (float) temp_double;

    	nh_local.param("min_error_frac_to_continue", temp_double, .001);
    	icp_params.min_error_frac_to_continue = (float) temp_double;

    	nh_local.param("front_can_match_back", pair_params.front_can_match_back, false);



    	nh_local.param("cloud_initial_random_downsample_rate", temp_double, 0.1);
    	cloud_initial_random_downsample_rate = (float) temp_double;

    	nh_local.param("merge_clouds_using_density", merge_clouds_using_density, true);

		// Maximum number of outgoing messages to be queued for delivery to subscribers = 1
		global_cloud_publisher_ = nh_global.advertise<sensor_msgs::PointCloud2> ("icp_global_cloud", 1);
		source_cloud_publisher_ = nh_global.advertise<sensor_msgs::PointCloud2> ("icp_source_cloud", 1);

		pair_params.errType = ICP_ERR_POINT_TO_PLANE;
		pair_params.corrType = ICP_CORRS_SINGLE_TREE;
		pair_params.wtType = ICP_WTS_SCALAR;
    }

    ~ICPSequenceReader()
    {
    }

    void addGreyScaleChannel(sensor_msgs::PointCloud &cloud)
    {
    	unsigned int origChannelsSize = cloud.get_channels_size();
    	cloud.set_channels_size(origChannelsSize+1);
    	cloud.channels[origChannelsSize].name="intensity";
    	cloud.channels[origChannelsSize].set_values_size(cloud.get_points_size());

    	unsigned int r_channel = rgbd::get_channel_index(cloud,"r");
    	for(unsigned int i=0; i<cloud.get_points_size(); i++){
    		float r = cloud.channels[r_channel].values[i];
    		float g = cloud.channels[r_channel+1].values[i];
    		float b = cloud.channels[r_channel+2].values[i];
    		float intensity = .3*r+.59*g+.11*b;
    		cloud.channels[origChannelsSize].values[i] = intensity;
    	}
    }

    void readPointCloud(sensor_msgs::PointCloud &cloud,unsigned int frameNum)
    {
		std::string packageDir = ros::package::getPath("point_cloud_icp");
		boost::filesystem::path path(packageDir);
		path/=data_directory;
		path/=data_basename;

		std::string basePath = path.string();
		std::stringstream stream;
		stream<<basePath<<frameNum<<".ply";
		std::string filename = stream.str();

		std::cout<<"Loading point cloud: "<<filename<<std::endl;
//		cloud_io::loadPCDFile(filename.c_str(),cloud);
		read_ply_file(cloud,filename);
		cloud.header.frame_id = "base_link";
		std::cout<<"Loaded point cloud with "<<cloud.points.size()<<" points"<<std::endl;

		addGreyScaleChannel(cloud);
    }

    rgbd::eigen::Transform3f readTransform(unsigned int frameNum)
    {
		std::string packageDir = ros::package::getPath("point_cloud_icp");
		boost::filesystem::path path(packageDir);
		path/=data_directory;

		std::string basePath = path.string();
		std::stringstream stream;
		stream<<basePath<<"/transform_"<<frameNum<<".tfl";
		std::string filename = stream.str();

    	//read the transforms file
		std::ifstream reader;
		reader.open(filename.c_str(),std::ios::binary);
    	rgbd::eigen::Transform3f transform;
    	reader.read((char*)&transform,sizeof(rgbd::eigen::Transform3f));
    	reader.close();

    	return transform;
    }

    int run()
    {


    	sensor_msgs::PointCloud newCloud,combinedCloud;
    	rgbd::eigen::Transform3f lastTransform;
    	lastTransform.setIdentity();
    	for(unsigned int frameNum=start_frame; frameNum< end_frame; frameNum++){
    		std::cout<<"Frame number "<<frameNum<<std::endl;

    		this->readPointCloud(newCloud,frameNum);

    		if(!read_transforms){
				if(frameNum==start_frame){
					combinedCloud = newCloud;
				}
				else{
					//TODO: Initial downsample?

					ICPCombined icp;
					icp.setParams(icp_params);
					const boost::shared_ptr<ICPCloudPair> cloudPair = boost::make_shared
						<ICPCloudPair>(pair_params, newCloud, combinedCloud);
					cloudPair->setScalarWeights();
					icp.addCloudPair(cloudPair);
					icp.setInitialTransform(lastTransform);
					rgbd::eigen::Transform3f newTransform;
					bool success = icp.runICP(newTransform);
					transform_point_cloud_in_place(newTransform,newCloud);

					//TODO: merge with density?
					rgbd::mergeInPlace(newCloud, combinedCloud);

					lastTransform = newTransform;
				}
    		}
    		else{


    			rgbd::eigen::Transform3f transformToImageCoords = this->readTransform(frameNum);
    			rgbd::eigen::Transform3f transformToOrig;

    			sensor_msgs::PointCloud downsampledCloud;
    			std::vector<unsigned int > acceptedIndices =
    					getRandomDownsamplingIndices2(newCloud,cloud_initial_random_downsample_rate,10);
    			rgbd::downsampleFromIndices(newCloud,downsampledCloud,acceptedIndices);

    			if(frameNum == start_frame){
    				lastTransform = transformToImageCoords;
    				combinedCloud = downsampledCloud;
    			}
    			else{
    				rgbd::eigen::Transform3f prevFrameToNewFrame = transformToImageCoords*invertTransform(lastTransform);
    				transform_point_cloud_in_place(prevFrameToNewFrame,combinedCloud);
//    				transformToOrig = transformToImageCoords*invertTransform(origTransform);
//    				transform_point_cloud_in_place(transformToOrig,newCloud);
    				rgbd::mergeInPlace(downsampledCloud, combinedCloud);
    				lastTransform = transformToImageCoords;
    			}


    			usleep(100000);
    		}

    		rgbd::eigen::Transform3f translation;
    		translation.setIdentity();
    		translation.translate(rgbd::eigen::Vector3f(0,.3,0));
    		transform_point_cloud_in_place(translation,newCloud);


    		source_cloud_publisher_.publish(newCloud);
    		global_cloud_publisher_.publish(combinedCloud);

    	}

    	return 0;
    }



};// class
} // namespace

int main (int argc, char** argv)
{
	ros::init (argc, argv, "icp_sequence_reader");
	registration::ICPSequenceReader icp_node;
	return icp_node.run();
}
