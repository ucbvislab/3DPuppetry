/*
 * ICPCloudPairPointToPointError: point-to-point error metric using only 3-d position info
 *
 * Evan Herbst
 * 3 / 21 / 10
 */

#include "point_cloud_icp/registration/ICPCloudPairPointToPointError.h"
#include "point_cloud_icp/registration/icpPoint2Point.h"

namespace registration
{

ICPCloudPairPointToPointError::ICPCloudPairPointToPointError(ICPCloudPairParams const& params,
		sensor_msgs::PointCloud const& source_pointcloud,
		sensor_msgs::PointCloud const& target_pointcloud,
		std::vector<float> const& point_weights)
: ICPCloudPairSingleKDTree(params, source_pointcloud, target_pointcloud, point_weights)
{
}

ICPCloudPairPointToPointError::ICPCloudPairPointToPointError(const ICPCloudPairParams& params,
			const sensor_msgs::PointCloud& sourceCloud,
			const sensor_msgs::PointCloud& targetCloud,
			boost::shared_ptr<kdtree2> targetKDTree,
			const std::vector<float>& pointWeights)
: ICPCloudPairSingleKDTree(params, sourceCloud, targetCloud, targetKDTree, pointWeights)
{
}

void ICPCloudPairPointToPointError::getSourceErrorVector(rgbd::eigen::Transform3f const& transform,
		std::vector<int> const& correspondence_indices, std::vector<float> & result) const
{
	if (m_params.use_fastpointlib) {
		icp::point2point::getSourceErrorVectorFPL(m_source_fpl_points, m_source_fpl_points_temp, m_point_weights, transform, correspondence_indices, result);
	}
	else {
		icp::point2point::getSourceErrorVector(m_source_eigen_points, m_point_weights, transform, correspondence_indices, result);
	}
}

void ICPCloudPairPointToPointError::getTargetErrorVector(std::vector<int> const& correspondence_indices, std::vector<float> & result) const
{
	icp::point2point::getTargetErrorVector(m_target_eigen_points, m_point_weights, correspondence_indices, result);
}


} //namespace
