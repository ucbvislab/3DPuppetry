/*
 * ICP.cpp
 *
 *  Created on: Jun 26, 2009
 *      Author: mkrainin
 */

#include <point_cloud_icp/registration/ICP.h>
#include <point_cloud_mapping/geometry/nearest.h>
#include <point_cloud_mapping/geometry/point.h>
#include <point_cloud_icp/registration/icp_utility.h>
#include <geometry_msgs/PointStamped.h>
#include <assert.h>
#include "rgbd_util/eigen/QR"
#include "rgbd_util/eigen/LU"
#include <iostream>
#include <deque>
#include <list>
#include <algorithm>

#include <lm.h>


using namespace Eigen;

namespace registration{


	ICP::ICP(const sensor_msgs::PointCloud &toRegister,
			const sensor_msgs::PointCloud &target)
	:m_params(),
	 m_toRegisterTreePtr(NULL),
	 m_targetTreePtr(NULL),
	 m_targetTreePointToPointPtr(NULL),
	 m_targetTreePointToPlanePtr(NULL),
	 m_targetTreePointToPointPtrOffset(0),
	 m_targetTreePointToPlanePtrOffset(0)
	{
		m_toRegisterCloud = toRegister;
		m_targetCloud = target;

		if (m_toRegisterCloud.get_points_size() > 0) {
			m_toRegisterTreePtr = new cloud_kdtree::KdTreeANN(m_toRegisterCloud);
		}
		if (m_targetCloud.get_points_size() > 0) {
			m_targetTreePtr = new cloud_kdtree::KdTreeANN(m_targetCloud);
		}

		m_usePriors = false;
		m_useSimplePriors = false;

		m_normalsSet = false;

		m_toRegister = std::vector<Vector3f>(toRegister.points.size());
		m_toRegisterWeights = std::vector<float>(toRegister.points.size(),1.0);

		m_targetPoints = std::vector<Vector3f>(target.points.size());

		//convert toRegister points to Vector and fill in m_toRegisterIndices
		m_toRegisterIndices = std::vector<unsigned int>(m_toRegister.size());
		for(unsigned int i=0; i<toRegister.points.size(); i++){
			m_toRegister[i] = Vector3f(toRegister.points[i].x, toRegister.points[i].y,toRegister.points[i].z);
			m_toRegisterIndices[i] = i;
		}

		//convert target points to Vector
		for(unsigned int i=0; i<target.points.size(); i++){
			m_targetPoints[i] = Vector3f(target.points[i].x, target.points[i].y,target.points[i].z);
		}

		m_initialTransform.setIdentity();

		// this means that empty clouds should be passed to the constructor when using combined icp
		m_toRegisterErrorFunctions = std::vector<ErrorFunction>(m_toRegister.size(), NONE_SET);
	}

	ICP::~ICP()
	{
		delete m_toRegisterTreePtr;
		delete m_targetTreePtr;

		delete m_targetTreePointToPointPtr;
		delete m_targetTreePointToPlanePtr;
	}

	void
	ICP::addCloudsWithWeightsAndErrorFunction(
			const sensor_msgs::PointCloud &source,
			const sensor_msgs::PointCloud &target,
			const std::vector<float> &source_weights,
			ErrorFunction error_function_for_added_points)
	{
		assert(m_params.do_multiple_error_functions);

		if (error_function_for_added_points == MSE_NONLINEAR) {
			assert(m_targetTreePointToPointPtr == NULL);
			m_targetTreePointToPointPtr = new cloud_kdtree::KdTreeANN(target);
			m_targetTreePointToPointPtrOffset = m_targetPoints.size();
		}
		else if (error_function_for_added_points == POINT_TO_PLANE) {
			assert(m_targetTreePointToPlanePtr == NULL);
			m_targetTreePointToPlanePtr = new cloud_kdtree::KdTreeANN(target);
			m_targetTreePointToPlanePtrOffset = m_targetPoints.size();
		}
		else {
			assert(false);
		}

		// need these for normals, for example
		if (m_toRegisterCloud.get_points_size() == 0) {
			m_toRegisterCloud = source;
		}
		else {
			mergeClouds(m_toRegisterCloud, source);
		}
//		delete m_toRegisterTreePtr;
//		m_toRegisterTreePtr = new cloud_kdtree::KdTreeANN(m_toRegisterCloud);

		if (m_targetCloud.get_points_size() == 0) {
			m_targetCloud = target;
		}
		else {
			mergeClouds(m_targetCloud, target);
		}
//		delete m_targetTreePtr;
//		m_targetTreePtr = new cloud_kdtree::KdTreeANN(m_targetCloud);

		// expand the existing vectors to include these new points
		unsigned int old_source_size = m_toRegister.size();
		unsigned int new_source_size = old_source_size + source.get_points_size();
		m_toRegister.resize(new_source_size);
		m_toRegisterIndices.resize(new_source_size);
		m_toRegisterWeights.resize(new_source_size);
		m_toRegisterErrorFunctions.resize(new_source_size);

		for (unsigned int i = old_source_size; i < new_source_size; i++) {
			unsigned int source_index = i - old_source_size;
			m_toRegister[i] = Vector3f(
					source.points[source_index].x,
					source.points[source_index].y,
					source.points[source_index].z);
			m_toRegisterIndices[i] = i;
			m_toRegisterWeights[i] = source_weights[source_index];
			m_toRegisterErrorFunctions[i] = error_function_for_added_points;
		}

		unsigned int old_target_size = m_targetPoints.size();
		unsigned int new_target_size = old_target_size + target.get_points_size();
		m_targetPoints.resize(new_target_size);
		for(unsigned int i = old_target_size; i < new_target_size; i++){
			unsigned int target_index = i - old_target_size;
			m_targetPoints[i] = Vector3f(
					target.points[target_index].x,
					target.points[target_index].y,
					target.points[target_index].z);
		}
	}

	void
	ICP::setInitialTransform()
	{
		//get the means of the point clouds
		Vector3f meanToRegister= Vector3f::Zero();
		Vector3f meanTarget= Vector3f::Zero();
		for(unsigned int i=0; i < m_toRegister.size(); i++){
			meanToRegister+=m_toRegister[i];
		}
		for(unsigned int i=0; i < m_targetPoints.size(); i++){
			meanToRegister+=m_targetPoints[i];
		}
		meanToRegister /= m_toRegister.size();
		meanTarget /= m_targetPoints.size();

		m_initialTransform = Translation3f(meanTarget - meanToRegister);
	}

	void
	ICP::setInitialTransform(Transform3f &t)
	{
		m_initialTransform = t;
	}

	void
	ICP::setTransformPriors(
			rgbd::eigen::Matrix<float,7,1> const& transform,
			rgbd::eigen::Matrix<float,7,7> const& covariance,
			float priorStrength)
	{
		m_priorTransform = transform;
		m_priorCovarianceInverse = covariance.inverse();
		m_usePriors = true;
		m_useSimplePriors = false;
		m_priorStrength = priorStrength;

	}

	void
	ICP::setSimpleTransformPriors(
			rgbd::eigen::Matrix<float,7,1> const& transform,
			float priorStrength)
	{
		m_priorTransform = transform;
		m_priorStrength = priorStrength;
		m_useSimplePriors = true;
		m_usePriors = false;
	}


	void
	ICP::setNormals(const std::vector<rgbd::eigen::Vector3f> &toRegisterNormals,
			const std::vector<rgbd::eigen::Vector3f> &targetNormals)
	{
		m_normalsSet = true;
		m_toRegisterNormals = toRegisterNormals;
		m_targetNormals = targetNormals;
	}

	bool
	ICP::getNormals(std::vector<rgbd::eigen::Vector3f> &toRegisterNormals,
			std::vector<rgbd::eigen::Vector3f> &targetNormals)
	{
		if (!m_normalsSet) {
			return false;
		}
		toRegisterNormals = m_toRegisterNormals;
		targetNormals = m_targetNormals;
		return true;
	}

	void
	ICP::setWeights(std::vector<float> const& toRegisterWeights)
	{
		m_toRegisterWeights = toRegisterWeights;
	}

	void
	ICP::removePointsInsideRadius(geometry_msgs::Point32 center, float radius)
	{
		std::vector<int> k_indices;
		std::vector<float> k_distances;
		m_toRegisterTreePtr->radiusSearch(center,radius,k_indices,k_distances);
		std::vector<unsigned int> unsigned_k_indices(k_indices.begin(), k_indices.end());
		std::vector<unsigned int> new_indices;
		remove_indices(m_toRegister.size(), m_toRegisterIndices, unsigned_k_indices, new_indices);
		m_toRegisterIndices = new_indices;
	}

	void
	ICP::removePointsOutsideRadius(geometry_msgs::Point32 center, float radius)
	{
		std::vector<int> k_indices;
		std::vector<float> k_distances;
		m_toRegisterTreePtr->radiusSearch(center,radius,k_indices,k_distances);
		std::vector<unsigned int> unsigned_k_indices(k_indices.begin(), k_indices.end());
		std::vector<unsigned int> indices_to_remove;
		invert_indices(m_toRegister.size(), unsigned_k_indices, indices_to_remove);
		std::vector<unsigned int> new_indices;
		remove_indices(m_toRegister.size(), m_toRegisterIndices, indices_to_remove, new_indices);
		m_toRegisterIndices = new_indices;
	}

	sensor_msgs::PointCloud
	ICP::getPlanePointCloud()
	{
		return m_planeCloud;
	}

	void
	ICP::prepareForICP()
	{
		if(!m_normalsSet)
		{
			if (m_params.error_function == POINT_TO_PLANE
					|| m_params.error_function == GENERALIZED
					|| m_params.downsampling == SALIENCY)
				generateNormals();
		}

		// TODO: make generate correspondences not require normals always
		// always generate
		/*
		if (!m_normalsSet) {
			generateNormals();
		}
		*/

		performDownsampling();

		if (m_params.do_near_remove) {
			geometry_msgs::Point32 center;
			center.x = center.y = center.z = 0;
			removePointsInsideRadius(center, m_params.near_remove_radius);
		}

		if (m_params.do_far_remove) {
			geometry_msgs::Point32 center;
			center.x = center.y = center.z = 0;
			removePointsOutsideRadius(center, m_params.far_remove_radius);
		}
	}

	Transform3f
	ICP::runICP()
	{
		// debug
		std::cout << "m_toRegisterCloud.size():" << m_toRegisterCloud.get_points_size() << std::endl;
		std::cout << "m_targetCloud.size():" << m_targetCloud.get_points_size() << std::endl;

		std::cout << "m_toRegister.size():" << m_toRegister.size() << std::endl;
		std::cout << "m_targetPoints.size():" << m_targetPoints.size() << std::endl;


		// I'm not downsampling within ICP so make sure we're using all toRegister points
		assert(m_toRegisterIndices.size() == m_toRegister.size());

		ros::Time startTime = ros::Time::now();

		m_icpSuccess = true;

	    m_transformHistory.clear();
	    m_transformHistory.push_front(m_initialTransform);
		
		m_errorHistory.clear();

		Transform3f prevTransform = m_initialTransform;
		Transform3f newTransform = m_initialTransform;

		std::vector<unsigned int> correspondenceIndices;
		std::vector<bool> useCorrespondence;
		std::vector<float> correspondenceWeights;

		m_round = 1;
		std::cout<<"Starting ICP"<<std::endl;

		prepareForICP();

		if(m_params.interleave && !m_params.error_function == MSE){
			return runICPInterleaved();
		}

		//calculate the initial correspondences
		std::cout<<"Computing correspondences"<<std::endl;
		bool correspondencesFound = getCorrespondenceIndices(newTransform,correspondenceIndices,useCorrespondence,correspondenceWeights);
		if(!correspondencesFound){
			if (lm_fixed_point_pairs.size() == 0) {
				std::cout<<"Failed to find correspondences"<<std::endl;
				m_icpSuccess = false;
				return Transform3f();
			}
			else {
				std::cout << "Failed to find correspondences, but there are fixed points to align" << std::endl;
			}
		}
		else {
			std::cout << "Got correspondences" << std::endl;
		}


		float initError = getError(newTransform,correspondenceIndices,useCorrespondence,correspondenceWeights);
		std::cout<<"ICP initial error: "<<initError<<std::endl;

		do{

			//get the new transform from the new correspondences
			prevTransform = newTransform;
			//can only use closed form if we're minimizing squared errors
			if(m_params.error_function == MSE){
				newTransform = runClosedFormAlignment(correspondenceIndices,useCorrespondence,correspondenceWeights);
			}
			else if(m_params.optimizer == LBFGS){
				newTransform = runLBFGSAlignment(prevTransform,correspondenceIndices,useCorrespondence,correspondenceWeights);
			}
			else if(m_params.optimizer == LM){
				//assert(false);
				newTransform = runNewLMAlignment(prevTransform, correspondenceIndices, useCorrespondence, correspondenceWeights);
				//newTransform = runLMAlignment(prevTransform,correspondenceIndices,useCorrespondence, correspondenceWeights);
			}
			else {
				std::cerr << "Unknown optimizer" << std::endl;
				assert(false);
			}

			//calculate the new correspondences based on the new transform
			correspondencesFound = getCorrespondenceIndices(newTransform,correspondenceIndices,useCorrespondence, correspondenceWeights);
			if(!correspondencesFound){
				m_icpSuccess = false;
				return Transform3f();
			}

			//store the transform as well as the error with the _new_ correspondences
			m_transformHistory.push_front(newTransform);
			m_errorHistory.push_front(getError(newTransform,correspondenceIndices,useCorrespondence,correspondenceWeights));


			//try to extrapolate toward the error minimum
			//see A Method for Registration of 3-D Shapes by Besl & McKay
			if (m_params.use_accelerated && m_transformHistory.size() >= 3){

				//move to 7-space to check angular consistency and extrapolate
				//linearly or quadratically
				Matrix<float,7,1> q3 = convertTransformToVector(m_transformHistory[0]);
				Matrix<float,7,1> q2 = convertTransformToVector(m_transformHistory[1]);
				Matrix<float,7,1> q1 = convertTransformToVector(m_transformHistory[2]);
				Matrix<float,7,1> q0 = convertTransformToVector(m_transformHistory[3]);
				//the changes in transformation
				Matrix<float,7,1> deltaQ3 = q3-q2;
				Matrix<float,7,1> deltaQ2 = q2-q1;
				Matrix<float,7,1> deltaQ1 = q1-q0;
				//the angles between changes in transformations
				double theta3 = acos(deltaQ3.dot(deltaQ2)
									 /(deltaQ3.norm()*deltaQ2.norm()));
				double theta2 = acos(deltaQ2.dot(deltaQ1)
									 /(deltaQ2.norm()*deltaQ1.norm()));

				//check to see if the angles are small enough to proceed with
				//extrapolation
//				std::cout<<"theta2: " << theta2<<", theta3: "<<theta3<<", max: "
//					<<maxAccelAngle<<std::endl;
				if(theta3 < m_params.max_accel_angle && theta2 < m_params.max_accel_angle){
					//error histories
					float d3 = m_errorHistory[0];
					float d2 = m_errorHistory[1];
					float d1 = m_errorHistory[2];

					//calculate extrapolations, which are functions d(v)
					double v3 = 0;
					double v2 = -1*deltaQ3.norm();
					double v1 = -1*deltaQ2.norm() + v2;
					//quadratic fit constants for d2(v) = a2v^2+b2v+c2
					double a2 = (((d3-d2)*(v2-v1)-(d2-d1))
							   /((v3*v3-v2*v2)-(v2*v2-v1*v1)*(d3-d2)));
					double b2 = ((d2-d1)-a2*(v2*v2-v1*v1))/(v2-v1);
					//double c2 = d3-a2*v3*v3-b2*v3;
					//linear fit constants for d1(v) = a1v+b1
					double a1 = (d3-d2)/(v3-v2);
					double b1 = d3-a1*v3;

					//find the bottom-point of the parabola and the crossing
					//point of the line
					double parabolaUpdate = -b2/(2*a2);
					double linearUpdate = -b1/a1;
					double maximumUpdate = m_params.max_accel_ratio*deltaQ3.norm();

					double updateFactor = 0;

					//perform the appropriate update (if either parabolic or
					//linear gives a positive update)
					if(parabolaUpdate <= linearUpdate
					 && parabolaUpdate <= maximumUpdate && parabolaUpdate > 0)
						updateFactor=parabolaUpdate;
					else if((linearUpdate <= parabolaUpdate || parabolaUpdate < 0)
						  && linearUpdate > 0 && linearUpdate < maximumUpdate)
						updateFactor=linearUpdate;
					else if(linearUpdate > maximumUpdate
						  && parabolaUpdate > maximumUpdate)
						updateFactor=maximumUpdate;

					//don't bother with the rest unless there's an update to try
//					std::cout<<"update factor: " <<updateFactor<<std::endl;
					if(updateFactor > 0){
						q3+=updateFactor*deltaQ3/deltaQ3.norm();

						//try out the transform to make sure it actually does better
						Transform3f tempTransform = convertVectorToTransform(q3);
						std::vector<unsigned int> tempCorrIndices;
						std::vector<bool> tempUseCorrs;
						correspondencesFound = getCorrespondenceIndices(tempTransform,tempCorrIndices,tempUseCorrs,correspondenceWeights);
						if(!correspondencesFound){
							m_icpSuccess = false;
							return Transform3f();
						}
						double tempError = getError(tempTransform,tempCorrIndices,tempUseCorrs,correspondenceWeights);


						//if the accelerated is an improvement (i.e. we didn't
						//overshoot), then set the transform and error
//						std::cout<<"old error: "<<m_errorHistory[0]<<", new error: "<<
//							tempError<<std::endl;
						if(tempError < m_errorHistory[0]){
							std::cout<<"Using accelerated transform with "<<
									"update factor "<<updateFactor<<std::endl;
							newTransform = tempTransform;
							m_transformHistory[0] = newTransform;
							m_errorHistory[0] = tempError;
							correspondenceIndices = tempCorrIndices;
							useCorrespondence = tempUseCorrs;
						}
					}
				}//end if angles less than max angle
			}//end if useAccelerated

			std::cout<<"***** Error for round "<<m_round<<" is "<<m_errorHistory[0]
			         <<" *****"<<std::endl;
			m_round++;

		}while(shouldContinue(prevTransform,newTransform,
				correspondenceIndices,useCorrespondence,correspondenceWeights));

		ros::Time endTime = ros::Time::now();
		ros::Duration dur = endTime-startTime;
		std::cout<<"ICP completed in "<<dur.toSec()<<" seconds"<<std::endl;

		return newTransform;
	}

	Transform3f
	ICP::runICPInterleaved()
	{
	    int hessianSteps = 5;
	    float derivativeStepSize = 1E-3;

	    unsigned int maxRounds = m_params.max_rounds;

	    unsigned int dimensions = 7;
	    lbfgsstate state;
	    lbfgsreport rep;

		std::vector<unsigned int> correspondenceIndices;
		std::vector<bool> useCorrespondence;
		std::vector<float> correspondenceWeights;

	    ap::real_1d_array startState = TransformToLBFGSArray(m_initialTransform);
	    minlbfgs(dimensions, hessianSteps, startState, 0.0, 0.0, 0.0, maxRounds, 0, state);

	    unsigned int round = 1;
	    while(minlbfgsiteration(state))
	    {
//	    	std::cout << "LBFGS loop..." << std::endl;

	    	Transform3f currentTransform = LBFGSArrayToTransform(state.x);
	    	m_transformHistory.push_front(currentTransform);

	    	//the interleaving part: get the correspondences
	    	getCorrespondenceIndices(currentTransform,correspondenceIndices,useCorrespondence,correspondenceWeights);

	    	//set the value at the currentTransform
	        state.f = getError(currentTransform,correspondenceIndices,useCorrespondence,correspondenceWeights);

	        //set the partial derivatives at the currentTransform
	        for(unsigned int i=0; i<dimensions; i++){
	        	ap::real_1d_array tmpArray = state.x;

	        	tmpArray(i) += derivativeStepSize;
	        	Transform3f plusTransform = LBFGSArrayToTransform(tmpArray);
		    	//get the correspondences
		    	getCorrespondenceIndices(plusTransform,correspondenceIndices,useCorrespondence,correspondenceWeights);
	        	float plusError = getError(plusTransform,
	        			correspondenceIndices,useCorrespondence,correspondenceWeights);

	        	tmpArray(i) -= 2*derivativeStepSize;
	        	Transform3f minusTransform = LBFGSArrayToTransform(tmpArray);
		    	//get the correspondences
		    	getCorrespondenceIndices(minusTransform,correspondenceIndices,useCorrespondence,correspondenceWeights);
	        	float minusError = getError(minusTransform,
	        			correspondenceIndices,useCorrespondence,correspondenceWeights);

	        	//the ith partial derivative
	        	state.g(i) = (plusError - minusError)/(2*derivativeStepSize);
	        }

	        std::cout << "Completed Round "<<round<<" of interleaved ICP "<<std::endl;
			std::cout << "New Transform Translation:\n" << Vector3f(currentTransform.translation())
				<<"\nRotation angle:\n "<<AngleAxisf(currentTransform.linear()).angle()<<std::endl;
			round++;
	    }
	    //retreive the results
	    ap::real_1d_array result;
	    minlbfgsresults(state, result, rep);

	    Transform3f toReturn = LBFGSArrayToTransform(result);
	    m_transformHistory.push_front(toReturn);

	    return toReturn;
	}

	sensor_msgs::PointCloud
	ICP::getDownsampledCloud()
	{
		sensor_msgs::PointCloud downsampledCloud;
		std::vector<rgbd::eigen::Vector3f> downsampledPoints =
			std::vector<rgbd::eigen::Vector3f>(m_toRegisterIndices.size());
		for(unsigned int i=0; i<m_toRegisterIndices.size(); i++){
			downsampledPoints[i] = m_toRegister[m_toRegisterIndices[i]];
		}
		convertVectorToPointCloud(downsampledPoints, downsampledCloud);
		return downsampledCloud;
	}

	void
	ICP::generateNormals()
	{
		m_normalsSet = true;
		int k=40;

		m_toRegisterNormals = std::vector<Vector3f>(m_toRegister.size());
		m_targetNormals = std::vector<Vector3f>(m_targetPoints.size());

		geometry_msgs::PointStamped pointStamped;
		pointStamped.header.frame_id = "frame";
		// Set the viewpoint in the laser coordinate system to 0, 0, 0
		pointStamped.point.x = pointStamped.point.y = pointStamped.point.z = 0.0;

		// if the point cloud already has normals, don't regenerate them
		bool to_register_has_normals = pointCloudNormalsToEigenNormals(m_toRegisterCloud, m_toRegisterNormals);
		if (!to_register_has_normals) {
			int origDimsToRegister = m_toRegisterCloud.channels.size();
			cloud_geometry::nearest::computePointCloudNormals(m_toRegisterCloud,k,pointStamped);
			//convert toRegister points to Vector
			for(unsigned int i=0; i<m_toRegister.size(); i++){
				m_toRegisterNormals[i] = Vector3f(
						m_toRegisterCloud.channels[origDimsToRegister+0].values[i],
						m_toRegisterCloud.channels[origDimsToRegister+1].values[i],
						m_toRegisterCloud.channels[origDimsToRegister+2].values[i]);
			}
		}
		else {
			std::cout << "Normals already existed" << std::endl;
		}

		bool target_has_normals = pointCloudNormalsToEigenNormals(m_targetCloud, m_targetNormals);
		if (!target_has_normals) {
			int origDimsTarget = m_targetCloud.channels.size();
			cloud_geometry::nearest::computePointCloudNormals(m_targetCloud,k,pointStamped);
			//convert target points to Vector
			for(unsigned int i=0; i<m_targetPoints.size(); i++){
				m_targetNormals[i] = Vector3f(
						m_targetCloud.channels[origDimsTarget+0].values[i],
						m_targetCloud.channels[origDimsTarget+1].values[i],
						m_targetCloud.channels[origDimsTarget+2].values[i]);
			}
		}
		else {
			std::cout << "Normals already existed" << std::endl;
		}

	}

	bool
	ICP::getCorrespondenceIndices(
			Transform3f const& currentRegistrationTransform,
			std::vector<unsigned int> &correspondenceIndices,
			std::vector<bool> &useCorrespondence,
			std::vector<float> & correspondenceWeights)
	{
		correspondenceIndices.resize(m_toRegisterIndices.size());
		useCorrespondence.resize(m_toRegisterIndices.size());
		correspondenceWeights.resize(m_toRegisterIndices.size());
		std::vector<float> distanceOfCorrespondence = std::vector<float>(m_toRegisterIndices.size());

		Quaternionf rotationPart(currentRegistrationTransform.linear());

		// first get the euclidean distances for all correspondences
		for(unsigned int i=0; i<m_toRegisterIndices.size(); i++) {
			//get the transformed point
			Vector3f transformed = currentRegistrationTransform *
				m_toRegister[m_toRegisterIndices[i]];

			float ptWeight = m_toRegisterWeights[m_toRegisterIndices[i]];

			Vector3f transformedNormal;
			if (m_params.weight_error_with_normals && m_normalsSet) {
				transformedNormal = rotationPart*m_toRegisterNormals[i];
				transformedNormal.normalize();
			}

			//convert to Point32 format
			geometry_msgs::Point32 pt;
			pt.x = transformed.x();
			pt.y = transformed.y();
			pt.z = transformed.z();

			//get the k=1 nearest neighbors
			std::vector<int> k_indices;
			std::vector<float> k_distances;
			if (m_params.do_multiple_error_functions) {
				if (m_toRegisterErrorFunctions[i] == MSE_NONLINEAR) {
					// use the point-to-point tree
					m_targetTreePointToPointPtr->nearestKSearch(pt,1,k_indices,k_distances);
					correspondenceIndices[i] = k_indices[0] + m_targetTreePointToPointPtrOffset;
					// DEBUG
					//std::cout << "Edge corr:" << correspondenceIndices[i] << std::endl;
				}
				else if (m_toRegisterErrorFunctions[i] == POINT_TO_PLANE) {
					// use the point-to-plane tree
					m_targetTreePointToPlanePtr->nearestKSearch(pt,1,k_indices,k_distances);
					correspondenceIndices[i] = k_indices[0] + m_targetTreePointToPlanePtrOffset;
					// DEBUG
					//std::cout << "General corr:" << correspondenceIndices[i] << std::endl;
				}
				else {
					assert(false);
				}
				assert(correspondenceIndices[i] < m_targetPoints.size());
			}
			else {
				m_targetTreePtr->nearestKSearch(pt,1,k_indices,k_distances);
				correspondenceIndices[i] = k_indices[0];
			}

			distanceOfCorrespondence[i] = sqrt(k_distances[0]);

			if (m_params.weight_error_with_normals && m_normalsSet) {
				correspondenceWeights[i] = ptWeight*getCorrespondenceWeight(transformedNormal,
					m_targetNormals[correspondenceIndices[i]]);
			}
			else {
				correspondenceWeights[i] = ptWeight;
			}
		}
		std::vector<float> distance_vector = distanceOfCorrespondence;
		std::sort(distance_vector.begin(), distance_vector.end());
//		float median_distance = distance_vector[distance_vector.size() / 2];

		// DEBUG
		bool print_distances = false;
		if (print_distances) {
			for (unsigned int i = 0; i < distance_vector.size(); i++) {
				std::cout << distance_vector[i] << ", ";
			}
			std::cout << std::endl;
		}


		unsigned int numValid = 0;
		// now go through and only keep correspondences meeting conditions
		for(unsigned int i=0; i<m_toRegisterIndices.size(); i++){
			//TODO: other conditions
			if((distanceOfCorrespondence[i] > m_params.max_distance && m_params.max_distance > 0) ||
					correspondenceWeights[i] == 0)
			{
				useCorrespondence[i] = false;
			}
			else
			{
				useCorrespondence[i] = true;
				numValid++;
			}
		}

		//make sure we have enough points to work with
		return (numValid >= 3);
	}

	float
	ICP::getCorrespondenceWeight(
			rgbd::eigen::Vector3f const& toRegisterNormal,
			rgbd::eigen::Vector3f const& targetNormal)
	{
		float exponent = 10;

		float dot = toRegisterNormal.dot(targetNormal);
		if(dot < 0){
			if(m_params.front_can_match_back)
				dot*=-1;
			else
				return 0;
		}

		return pow(dot,exponent);
	}

	float
	ICP::getError(
			rgbd::eigen::Transform3f const& transform,
			std::vector<unsigned int> const& correspondenceIndices,
			std::vector<bool> const& useCorrespondence,
			std::vector<float> const& correspondenceWeights)
	{
		if (m_params.do_multiple_error_functions) {
			float point_to_point_error = 0.0;
			float point_to_plane_error = 0.0;
			float fixed_point_error = 0.0;
			float prior_error = 0.0;
			for(unsigned int i=0; i < m_toRegisterIndices.size(); i++){
				if (useCorrespondence[i]) {
					//find the difference between the two points
					Vector3f diff = transform * m_toRegister[i] - m_targetPoints[correspondenceIndices[i]];

					if (m_toRegisterErrorFunctions[i] == MSE_NONLINEAR) {
						// point-to-point
						float weighted_error = m_toRegisterWeights[i] * diff.norm();
						point_to_point_error += weighted_error * weighted_error;
					}
					else if (m_toRegisterErrorFunctions[i] == POINT_TO_PLANE) {
						// point-to-plane
						float weighted_error = m_toRegisterWeights[i] * diff.dot(m_targetNormals[correspondenceIndices[i]]);
						point_to_plane_error += weighted_error * weighted_error;
					}
					else {
						std::cerr << "Unsupported multiple error function" << std::endl;
						assert(false);
					}
				}
			}

			for (unsigned int i = 0; i < lm_fixed_point_pairs.size(); i++) {
				Vector3f diff = transform * lm_fixed_point_pairs[i].first - lm_fixed_point_pairs[i].second;
				float weighted_error = lm_fixed_point_weights[i] * diff.norm();
				fixed_point_error += weighted_error * weighted_error;
			}

			if (m_useSimplePriors) {
				rgbd::eigen::Matrix<float,7,1> diff = convertTransformToVector(transform)-m_priorTransform;
				float weighted_error = m_priorStrength * diff.norm();
				prior_error += weighted_error * weighted_error;
				//float exponent = m_priorStrength*(diff.transpose()*m_priorCovarianceInverse*diff)(0,0);
				//error*=exp(exponent);
			}


			float total_error = point_to_point_error + point_to_plane_error + fixed_point_error + prior_error;
			std::cout << "[Error Breakdown]" << std::endl;
			std::cout << "Point-to-point :" << point_to_point_error << std::endl;
			std::cout << "Point-to-plane :" << point_to_plane_error << std::endl;
			std::cout << "Fixed-point    :" << fixed_point_error << std::endl;
			std::cout << "Prior          :" << prior_error << std::endl;
			std::cout << "Total----------:" << total_error << std::endl;

			return total_error;
		}
		else {
			float error = 0;
			int count = 0;

			for(unsigned int i=0; i < m_toRegisterIndices.size(); i++){
				if(useCorrespondence[i]){
					error += correspondenceWeights[i]*pow(getComponentError(transform,correspondenceIndices,
							useCorrespondence,i),2);
					count++;
				}
			}

			if(m_usePriors){
				//diff = angles-mean
				rgbd::eigen::Matrix<float,7,1> diff = convertTransformToVector(transform)-m_priorTransform;
				float exponent = m_priorStrength*(diff.transpose()*m_priorCovarianceInverse*diff)(0,0);
				error*=exp(exponent);
			}

			return error;
		}
	}

	float
	ICP::getComponentError(rgbd::eigen::Transform3f const& transform,
			std::vector<unsigned int> const& correspondenceIndices,
			std::vector<bool> const& useCorrespondence,
			unsigned int component)
	{
		if (m_params.do_multiple_error_functions) {
			std::cerr << "NOT IMPLEMENTED" << std::endl;
			assert(false);
		}

		//no contribution from components not in use
		if(!useCorrespondence[component])
			return 0;

		//find the difference between the two points
		Vector3f diff = transform * m_toRegister[m_toRegisterIndices[component]] -
			m_targetPoints[correspondenceIndices[component]];

		//find the error for this term for each of the possible error functions
		//note that the returned quantity will be squared to get the value to
		//add to the overall function
		if(m_params.error_function == MSE || m_params.error_function == MSE_NONLINEAR){
			return diff.norm();
		}
		else if(m_params.error_function == POINT_TO_PLANE)
		{
			Vector3f targetNormal = m_targetNormals[correspondenceIndices[component]];
			return diff.dot(targetNormal);
		}
		else if(m_params.error_function == GENERALIZED){
			Vector3f toRegisterNormal = m_toRegisterNormals[m_toRegisterIndices[component]];
			Vector3f targetNormal = m_targetNormals[correspondenceIndices[component]];

			Matrix3f CA = getGeneralizedICPCovarianceMatrix(toRegisterNormal);
			Matrix3f CB = getGeneralizedICPCovarianceMatrix(targetNormal);

			Matrix3f T = transform.linear();

			float squaredError = ((diff.transpose())*
					((CB + T*CA*(T.transpose())).inverse())*diff)(0,0);

			return sqrt(squaredError);
		}
		else if(m_params.error_function == CAUCHY){

			float cauchyScale = m_params.cauchy_constant;
			float squaredDist = diff.squaredNorm();
			return sqrt(squaredDist/(squaredDist+cauchyScale));
		}
		else if(m_params.error_function == LORENTZIAN){
			float lorentzianScale = 1;
			return log(1+diff.squaredNorm()/lorentzianScale);
		}

		assert(false);
		return 0;
	}

	rgbd::eigen::Matrix<float,7,1>
	ICP::getErrorGradient(rgbd::eigen::Transform3f const& transform,
			std::vector<unsigned int> const& correspondenceIndices,
			std::vector<bool> const& useCorrespondence,
			std::vector<float> const& correspondenceWeights)
	{
	    if(m_params.error_function == MSE || m_params.error_function == MSE_NONLINEAR ||
	    		m_params.error_function == POINT_TO_PLANE)
	    	return this->getErrorGradientAnalytic(transform,correspondenceIndices,useCorrespondence,correspondenceWeights);

		rgbd::eigen::Matrix<float,7,1> gradient;
	    float derivativeStepSize = 1E-3;

        //set the partial derivatives at the currentTransform
        for(unsigned int i=0; i<7; i++){
        	rgbd::eigen::Matrix<float,7,1> tmpArray = convertTransformToVector(transform);
        	tmpArray(i) += derivativeStepSize;
        	Transform3f plusTransform = convertVectorToTransform(tmpArray);
        	float plusError = getError(plusTransform,
        			correspondenceIndices,useCorrespondence,correspondenceWeights);
        	tmpArray(i) -= 2*derivativeStepSize;
        	Transform3f minusTransform = convertVectorToTransform(tmpArray);
        	float minusError = getError(minusTransform,
        			correspondenceIndices,useCorrespondence,correspondenceWeights);

        	//the ith partial derivative
        	gradient(i) = (plusError - minusError)/(2*derivativeStepSize);
        }

		return gradient;
	}

	rgbd::eigen::Matrix<float,7,1>
	ICP::getErrorGradientAnalytic(rgbd::eigen::Transform3f const& transform,
			std::vector<unsigned int> const& correspondenceIndices,
			std::vector<bool> const& useCorrespondence,
			std::vector<float> const& correspondenceWeights)
	{
		rgbd::eigen::Matrix<float,7,1> gradient;
		rgbd::eigen::Matrix<float,7,1> transformAsVector = convertTransformToVector(transform);

		std::vector<rgbd::eigen::Vector3f> correspondenceDiffs(m_toRegisterIndices.size());
		for(unsigned int i=0; i<m_toRegisterIndices.size(); i++){
			if(!useCorrespondence[i])
				continue;
			unsigned int ptIndex = m_toRegisterIndices[i];

			correspondenceDiffs[i] = transform*m_toRegister[ptIndex]-
					m_targetPoints[correspondenceIndices[i]];
		}

		//TODO: replace with analytic gradient for other error functions
		if(m_params.error_function == MSE || m_params.error_function == MSE_NONLINEAR){
			//rotation part of the gradient
			for(unsigned int quaternionIndex=0; quaternionIndex<4; quaternionIndex++){
				float derivSum=0;

				//for each point to register
				for(unsigned int i=0; i<m_toRegisterIndices.size(); i++){
					if(!useCorrespondence[i])
						continue;
					unsigned int ptIndex = m_toRegisterIndices[i];

					//for each of the 3 physical dimensions
					for(unsigned int j=0; j<3; j++){
						derivSum+=2*correspondenceWeights[i]*correspondenceDiffs[i](j)*getRotationPartialDerivative(
								transformAsVector,m_toRegister[ptIndex],j,quaternionIndex);
					}
				}


				gradient(quaternionIndex) = derivSum;
			}

			//translation part of the gradient
			rgbd::eigen::Vector3f derivSumVector = rgbd::eigen::Vector3f::Zero();
			//for each point to register
			for(unsigned int i=0; i<m_toRegisterIndices.size(); i++){
				if(!useCorrespondence[i])
					continue;
				derivSumVector+=2*correspondenceWeights[i]*correspondenceDiffs[i];
			}

			for(unsigned int translationIndex=0; translationIndex<3; translationIndex++){
				gradient(translationIndex+4) = derivSumVector(translationIndex);
			}
		} //end MSE, MSE_NONLINEAR case
		else if(m_params.error_function == POINT_TO_PLANE){
			std::vector<float> dotProducts(m_toRegisterIndices.size());
			for(unsigned int i=0; i<m_toRegisterIndices.size(); i++){
				if(!useCorrespondence[i])
					continue;
				Vector3f targetNormal = m_targetNormals[correspondenceIndices[i]];
				dotProducts[i] = correspondenceDiffs[i].dot(targetNormal);
			}

			//rotation part of the gradient
			for(unsigned int quaternionIndex=0; quaternionIndex<4; quaternionIndex++){
				float derivSum=0;

				//for each point to register
				for(unsigned int i=0; i<m_toRegisterIndices.size(); i++){
					if(!useCorrespondence[i])
						continue;
					unsigned int ptIndex = m_toRegisterIndices[i];

					Vector3f targetNormal = m_targetNormals[correspondenceIndices[i]];

					//for each of the 3 physical dimensions
					for(unsigned int j=0; j<3; j++){
						derivSum+=2*correspondenceWeights[i]*dotProducts[i]*targetNormal(j)*getRotationPartialDerivative(
								transformAsVector,m_toRegister[ptIndex],j,quaternionIndex);
					}
				}


				gradient(quaternionIndex) = derivSum;
			}

			//translation part of the gradient
			rgbd::eigen::Vector3f derivSumVector = rgbd::eigen::Vector3f::Zero();
			//for each point to register
			for(unsigned int i=0; i<m_toRegisterIndices.size(); i++){
				if(!useCorrespondence[i])
					continue;
				derivSumVector+=2*correspondenceWeights[i]*dotProducts[i]*m_targetNormals[correspondenceIndices[i]];
			}

			for(unsigned int translationIndex=0; translationIndex<3; translationIndex++){
				gradient(translationIndex+4) = derivSumVector(translationIndex);
			}
		} //end point to plane case


		if(m_usePriors){

			//diff = angles-mean
			rgbd::eigen::Matrix<float,7,1> diff = convertTransformToVector(transform)-m_priorTransform;
			float exponent = m_priorStrength*(diff.transpose()*m_priorCovarianceInverse*diff)(0,0);
			float penalty=exp(exponent);

			//TODO: make a bit more efficient maybe
			float error = this->getError(transform,correspondenceIndices,useCorrespondence,correspondenceWeights);

			rgbd::eigen::Matrix<float,7,1> penaltyGradient = rgbd::eigen::Matrix<float,7,1>::Zero();
			for(unsigned int i=0; i<7; i++){
				for(unsigned int j=0; j<7;j++){
					penaltyGradient(i)+=2*m_priorStrength*m_priorCovarianceInverse(i,j)*diff(j);
				}
			}
			penaltyGradient*=penalty;


			gradient = penalty*gradient + penaltyGradient*error;
		}

		return gradient;

	}

	rgbd::eigen::Matrix3f
	ICP::getGeneralizedICPCovarianceMatrix(rgbd::eigen::Vector3f & normal)
	{
		normal.normalize(); //should already be the case, but just to be sure

		//rotation matrix sending (1,0,0) to the normal vector
		Matrix3f rotation;
		rotation.col(0) = normal;

		//now we need to find two unit vectors perpendicular to the normal
		Vector3f unitx = Vector3f::UnitX();
		Vector3f unity = Vector3f::UnitY();

		//at least one of the two has a component not in line with the normal
		float xprojection = unitx.dot(normal);

		Vector3f nonparallelVector;
		if(xprojection < 1 && xprojection > -1)
			nonparallelVector = unitx;
		else
			nonparallelVector = unity;

		//cross products give vectors perpendicular to both arguments
		//and nonzero as long as the vectors are not in line
		Vector3f col1 = nonparallelVector.cross(normal).normalized();
		Vector3f col2 = col1.cross(normal).normalized();

		rotation.col(1) = col1;
		rotation.col(2) = col2;

		//make sure there is no reflection (not sure if this matters)
		if(rotation.determinant() < 0){
			rotation.col(1) = col2;
			rotation.col(2) = col1;
		}

		//now apply this rotation to the matrix as it would be for a unit x normal
		Matrix3f matrixForXNormal = Matrix3f::Identity();
		float epsilon = 0.02;
		matrixForXNormal(0,0) = epsilon;

		return rotation*matrixForXNormal*(rotation.transpose());
	}

	void
	ICP::performDownsampling()
	{
		if(m_params.downsampling == RANDOM){
			performDownsamplingRandom();
		}
		else if(m_params.downsampling == UNIFORM){
			performDownsamplingWithVoxels();
		}
		else if(m_params.downsampling == DENSITY){
			performDownsamplingUsingDensity();
		}
		else if(m_params.downsampling == SALIENCY){
			performDownsamplingUsingSaliency();
		}
	}

	void
	ICP::performDownsamplingRandom()
	{
		float rate = m_params.downsample_rate;

		std::cout<<"Downsampling to "<<rate*100<<"% of "<<
			m_toRegisterIndices.size()<<" points"<<std::endl;

		//fill in the possible indices
		std::vector<unsigned int> possibleIndices;
		possibleIndices = m_toRegisterIndices;
//		for(unsigned int i=0; i<m_toRegister.size(); i++)
//			possibleIndices[i] = i;

		//shuffle the std::vector of indices
//		srand ( unsigned ( time (NULL) ) );
		random_shuffle(possibleIndices.begin(),possibleIndices.end());

		//use the indices at the start of possibleIndices
		unsigned int numToSelect = rate*m_toRegister.size();
		assert(numToSelect >= 3);

		m_toRegisterIndices = std::vector<unsigned int>(numToSelect);
		for(unsigned int i=0; i<numToSelect; i++){
			m_toRegisterIndices[i] = possibleIndices[i];
		}
	}

	void
	ICP::performDownsamplingWithVoxels()
	{
		float leaf_size = m_params.downsample_voxel_size;

		//get the centroids of points within voxels
		sensor_msgs::PointCloud downsampled_cloud;
		geometry_msgs::Point leaf_size_point;
		leaf_size_point.x = leaf_size_point.y = leaf_size_point.z = leaf_size;
		cloud_geometry::downsamplePointCloud(m_toRegisterCloud, downsampled_cloud, leaf_size_point);
		std::vector<rgbd::eigen::Vector3f> downsampledPoints;
		convertPointCloudToVector(downsampled_cloud, downsampledPoints);

		//unfortunately these aren't points in the original set, so we
		//would lose normals and possibly other information. we'll instead use
		//the closest points to these
		m_toRegisterIndices = std::vector<unsigned int>(downsampledPoints.size());
		for(unsigned int i=0; i<downsampledPoints.size(); i++){
			geometry_msgs::Point32 pt;
			pt.x = downsampledPoints[i].x();
			pt.y = downsampledPoints[i].y();
			pt.z = downsampledPoints[i].z();

			//get the k=1 nearest neighbors
			std::vector<int> k_indices;
			std::vector<float> k_distances;
			m_toRegisterTreePtr->nearestKSearch(pt,1,k_indices,k_distances);
			m_toRegisterIndices[i] = k_indices[0];
		}


		ROS_INFO ("Voxel resulting size: %d out of %d", (int) downsampledPoints.size(), (int) m_toRegister.size());
	}

	void
	ICP::performDownsamplingUsingDensity()
	{
		performDownsamplingRandom();

		cloud_kdtree::KdTreeANN downsampledKDTree(getDownsampledCloud());

		int maxWithinRadius = m_params.downsample_density_kmax;
		float radius = m_params.downsample_density_radius;

		//randomize the indices so we don't bias the point removal
		std::vector<unsigned int> possibleIndices;
		possibleIndices = m_toRegisterIndices;
//		for(unsigned int i=0; i<m_toRegister.size(); i++)
//			possibleIndices[i] = i;
//		srand ( unsigned ( time (NULL) ) );
		random_shuffle(possibleIndices.begin(),possibleIndices.end());

		//sort out points into accepted or rejected based on number of so far non-rejected
		//points within the specified radius
		std::vector<bool> toRegisterIndexRejected =
			std::vector<bool>(m_toRegister.size(),true);
		std::deque<unsigned int> acceptedIndices;
		for(unsigned int i=0; i<possibleIndices.size(); i++){
			unsigned int pointIndex = possibleIndices[i];
			Vector3f vec = m_toRegister[pointIndex];

			geometry_msgs::Point32 pt;
			pt.x = vec.x();
			pt.y = vec.y();
			pt.z = vec.z();

			//do a radius search
			std::vector<int> k_indices;
			std::vector<float> k_distances;
			downsampledKDTree.radiusSearch(pt,radius,k_indices,k_distances);
			//count the number of non-rejected indices in k_indices
			int nonRejectedCount = 0;
			for(unsigned int j=0; j<k_indices.size(); j++){
				unsigned int neighborIndex = m_toRegisterIndices[k_indices[j]];
				if(!toRegisterIndexRejected[neighborIndex]){
					nonRejectedCount++;
				}
			}
			//throw out the point if count is too large
			if(nonRejectedCount <= maxWithinRadius){
				toRegisterIndexRejected[pointIndex] = false;
				acceptedIndices.push_back(pointIndex);
			}
		}

		m_toRegisterIndices = std::vector<unsigned int>(acceptedIndices.begin(),
				acceptedIndices.end());

		std::cout<<"Downsampled "<<m_toRegister.size()<<" points to "<<
			m_toRegisterIndices.size()<<" points by performing a random downsample to "
			<< (m_params.downsample_rate * 100)<<"% and then limiting to points "
			"with initially less than "<<maxWithinRadius
			<<" points within "<<radius<<" meters"<<std::endl;
	}

	bool compare_pairs (std::pair<unsigned int, float> first,
			std::pair<unsigned int,float> second)
	{
		return first.second < second.second;
	}

	void
	ICP::performDownsamplingUsingSaliency()
	{
		performDownsamplingUsingDensity();

		cloud_kdtree::KdTreeANN downsampledKDTree(getDownsampledCloud());

		unsigned int numBasePoints =
			m_params.saliency_basepoint_ratio * m_toRegisterIndices.size();
		unsigned int maxSalientRegions = m_params.saliency_max_regions;
		float maxSphereRadius = m_params.saliency_max_radius;
		float radiusDelta = m_params.saliency_radius_delta;
		float binningDegrees = m_params.saliency_binning_degrees;
		unsigned int minPointsInRegion = m_params.saliency_min_points;

		unsigned int azimuthBins = ceil(360/binningDegrees);
		unsigned int inclineBins = ceil(180/binningDegrees);


		//select some basepoints
		std::vector<unsigned int> basepointIndices =
			std::vector<unsigned int>(numBasePoints);
		std::vector<unsigned int> possibleIndices;
		possibleIndices = m_toRegisterIndices;
//		srand ( unsigned ( time (NULL) ) );
		random_shuffle(possibleIndices.begin(),possibleIndices.end());
		for(unsigned int i=0; i<numBasePoints; i++){
			basepointIndices[i] = possibleIndices[i];
		}

		//compute saliency of basepoints
		std::list<std::pair<unsigned int, float> > saliencies; //saliency for each basepoint
		float bestRadii[numBasePoints]; //radius for each basepoint
		bool hasRegion[numBasePoints];

		for(unsigned int basePoint=0; basePoint<numBasePoints; basePoint++){
			hasRegion[basePoint] = false;

			unsigned int index = basepointIndices[basePoint];
			Vector3f vec = m_toRegister[index];
			geometry_msgs::Point32 pt;
			pt.x = vec.x();
			pt.y = vec.y();
			pt.z = vec.z();

			//stores the previous radius histogram for gradient calculation
			unsigned int prevNormalCounts[inclineBins][azimuthBins];
			for(unsigned int incline = 0; incline < inclineBins; incline++){
				for(unsigned int azimuth = 0; azimuth < azimuthBins; azimuth++){
					prevNormalCounts[incline][azimuth] = 0;
				}
			}

			float maxSaliency = 0;

			//loop over the different radii
			for(unsigned int p=1; p*radiusDelta <= maxSphereRadius; p++){
				float radius = p*radiusDelta;
				//do a radius search
				std::vector<int> k_indices;
				std::vector<float> k_distances;
				downsampledKDTree.radiusSearch(pt,radius,k_indices,k_distances);

				//angular distribution of normals
				unsigned int normalCounts[inclineBins][azimuthBins];
				//initialize to 0
				for(unsigned int incline = 0; incline < inclineBins; incline++){
					for(unsigned int azimuth = 0; azimuth < azimuthBins; azimuth++){
						normalCounts[incline][azimuth] = 0;
					}
				}
				//loop through the points returned by the radius search
				for(unsigned int i=0; i<k_indices.size(); i++){
					unsigned int tmpIndex = m_toRegisterIndices[k_indices[i]];

					Vector3f normal = m_toRegisterNormals[tmpIndex];
					double incline = acos(normal.z());
					double azimuth = atan2(normal.y(),normal.x());
					normalCounts[(unsigned int)(incline/binningDegrees)]
					             [(unsigned int)(azimuth/binningDegrees)]++;
				}

				//compute the terms for the saliency
				float hTerm = 0;
				float wTerm = 0;
				for(unsigned int incline = 0; incline < inclineBins; incline++){
					for(unsigned int azimuth = 0; azimuth < azimuthBins; azimuth++){
						unsigned int count = normalCounts[incline][azimuth];
						unsigned int prevCount = prevNormalCounts[incline][azimuth];
						if(count > 0)
							hTerm-= (float)count * log2((double)count);

						float gradient = (count - prevCount)/radiusDelta;
						if(gradient < 0)
							gradient*=0;
						wTerm+=gradient;
					}
				}
				wTerm*=radius;

				//saliency for this radius and basepoint
				float saliency = hTerm * wTerm;
				//don't start looking for maxSaliency until the second radius
				//because we need the gradient
				if((!hasRegion[basePoint] || saliency > maxSaliency)
						&& k_indices.size() >= minPointsInRegion){
					maxSaliency = saliency;
					bestRadii[basePoint] = radius;
					hasRegion[basePoint] = true;
				}
			}//end for each radius

			saliencies.push_back(std::pair<unsigned int,float>(basePoint,maxSaliency));
		}//end for each base point

		//now decide which regions to use
		std::vector<bool> pointInUse(m_toRegister.size(),false);
		saliencies.sort(compare_pairs);
		unsigned int numUsed = 0;
		while(numUsed < maxSalientRegions && !saliencies.empty()){
			unsigned int basepointNum = saliencies.back().first;
			unsigned int index = basepointIndices[basepointNum];
			if(!pointInUse[index] && hasRegion[basepointNum]){
				float radius = bestRadii[basepointNum];
				Vector3f vec = m_toRegister[index];
				geometry_msgs::Point32 pt;
				pt.x = vec.x();
				pt.y = vec.y();
				pt.z = vec.z();
				std::vector<int> k_indices;
				std::vector<float> k_distances;
				downsampledKDTree.radiusSearch(pt,radius,k_indices,k_distances);

				std::cout<<"Found a salient region with radius "<<radius<<
						" containing " <<k_indices.size()<<" points"<<std::endl;

				//mark all points within the radius as in use
				pointInUse[index] = true;
				for(unsigned int i=0; i<k_indices.size(); i++){
					pointInUse[m_toRegisterIndices[k_indices[i]]] = true;
				}

				numUsed++;
			}
			saliencies.pop_back();
		}

		//make a new m_toRegisterIndices
		std::deque<unsigned int> acceptedIndices;
		for(unsigned int i=0; i<m_toRegister.size(); i++){
			if(pointInUse[i])
				acceptedIndices.push_back(i);
		}

		m_toRegisterIndices = std::vector<unsigned int>(acceptedIndices.begin(),
				acceptedIndices.end());

		std::cout<<"Further downsampled to "<<m_toRegisterIndices.size()<<" points"
				" using "<<numUsed<<" salient regions"<<std::endl;

	}

	Transform3f
	ICP::runClosedFormAlignment(
			std::vector<unsigned int> &correspondenceIndices,
			std::vector<bool> &useCorrespondence,
			std::vector<float> const& correspondenceWeights)
	{
		std::vector<Vector3f> shiftedToRegister;
		std::vector<Vector3f> shiftedCorrespondences;

		//find the means
		Vector3f meanToRegister= Vector3f::Zero();
		Vector3f meanCorrespondence= Vector3f::Zero();
		int numCorrespondences = 0;
		for(unsigned int i=0; i < m_toRegisterIndices.size(); i++){
			if(useCorrespondence[i]){
				meanToRegister += m_toRegister[m_toRegisterIndices[i]];
				meanCorrespondence += m_targetPoints[correspondenceIndices[i]];
				numCorrespondences++;
			}
		}

		//if we don't have at least 3 correspondences to work with, something
		//is seriously wrong
		assert(numCorrespondences >= 3);

		meanToRegister = meanToRegister / numCorrespondences;
		meanCorrespondence = meanCorrespondence / numCorrespondences;

		//std::cout << "meanToRegister:\n" << meanToRegister << std::endl;
		//std::cout << "meanCorrespondence:\n" << meanCorrespondence << std::endl;

		//translate the points so their centroids align
		for(unsigned int i=0; i < m_toRegisterIndices.size(); i++){
//			if(useCorrespondence[i]){
				shiftedToRegister.push_back(
						m_toRegister[m_toRegisterIndices[i]] - meanToRegister);
				shiftedCorrespondences.push_back(
					m_targetPoints[correspondenceIndices[i]] - meanCorrespondence);
//			}
		}

		//get the M-matrix described in the paper
		//this is the sum of outer products of the vector pairs
		Matrix3f m = Matrix3f::Zero();
		for(unsigned int i=0; i<shiftedToRegister.size(); i++){
			m += correspondenceWeights[i] * shiftedToRegister[i] * shiftedCorrespondences[i].transpose();
		}

		//get the N-matrix described in the paper
		//this is constructed from elements of the M-matrix
		//out goal is to find a quaternion q which maximizes q^t*N*q
		//when the quaternion is interpreted as a 4 element vector
		//note that the N-matrix is symmetric
		Matrix4f n = Matrix4f::Zero();
		//diagonal
		n(0,0) = m(0,0) + m(1,1) + m(2,2);
		n(1,1) = m(0,0) - m(1,1) - m(2,2);
		n(2,2) = -m(0,0) + m(1,1) - m(2,2);
		n(3,3) = -m(0,0) - m(1,1) + m(2,2);
		//non-diagonal
		n(1,0) = n(0,1) = m(1,2) - m(2,1);
		n(2,0) = n(0,2) = m(2,0) - m(0,2);
		n(3,0) = n(0,3) = m(0,1) - m(1,0);
		n(2,1) = n(1,2) = m(0,1) + m(1,0);
		n(3,1) = n(1,3) = m(2,0) + m(0,2);
		n(3,2) = n(2,3) = m(1,2) + m(2,1);

		//get the eigenvalues and eigenvectors
		SelfAdjointEigenSolver<Matrix4f> eig(n);
		Vector4f evals = eig.eigenvalues();
		Matrix4f evecs = eig.eigenvectors();

		//get the largest of the eigenvectors
		Vector4f largestEvec;
		float largestEval = 0;
		for(unsigned int i=0; i<4; i++){
			if(i==0 || evals(i) > largestEval){
				largestEvec = evecs.col(i);
				largestEval = evals(i);
			}
		}

		//interpret the eigenvector as a rotation
		Quaternionf rotation(largestEvec(0),largestEvec(1),largestEvec(2),largestEvec(3));
		//create the translation component
		Vector3f rotatedMean = rotation*meanToRegister;
		Translation3f translation(meanCorrespondence - rotatedMean);

		//std::cout << "Internal translation:\n" <<
		//(meanCorrespondence - rotatedMean) << std::endl;

		//the final transform is the rotation then the translation
		//return rotation*translation;
		return translation * rotation;

	}

	rgbd::eigen::Transform3f
	ICP::runLBFGSAlignment(
			rgbd::eigen::Transform3f &prevTransform,
			std::vector<unsigned int> &correspondenceIndices,
			std::vector<bool> &useCorrespondence,
			std::vector<float> const& correspondenceWeights)
	{
	    int hessianSteps = 5;
		unsigned int maxIterations = 1000;

	    unsigned int dimensions = 7;
	    lbfgsstate state;
	    lbfgsreport rep;

	    ap::real_1d_array startState = TransformToLBFGSArray(prevTransform);
	    minlbfgs(dimensions, hessianSteps, startState, 0.0, 0.0, 0.0, maxIterations, 0, state);
	    while(minlbfgsiteration(state))
	    {
//	    	std::cout << "LBFGS loop..." << std::endl;

	    	Transform3f currentTransform = LBFGSArrayToTransform(state.x);
	    	//set the value at the currentTransform
	        state.f = getError(currentTransform,correspondenceIndices,useCorrespondence,correspondenceWeights);

	        rgbd::eigen::Matrix<float,7,1> gradient = this->getErrorGradient(
	        		currentTransform,correspondenceIndices,useCorrespondence,correspondenceWeights);

	        for(unsigned int i=0; i<dimensions; i++){
	        	state.g(i)= gradient(i);
	        }
	    }
	    //retreive the results
	    ap::real_1d_array result;
	    minlbfgsresults(state, result, rep);

	    return LBFGSArrayToTransform(result);
	}

#if 0
	rgbd::eigen::Transform3f
	ICP::runLMAlignment(
			rgbd::eigen::Transform3f &prevTransform,
			std::vector<unsigned int> &correspondenceIndices,
			std::vector<bool> &useCorrespondence,
			std::vector<float> const& correspondenceWeights)
	{
		std::cerr << "What the hell are you doing here?" << std::endl;
		assert(false);

		unsigned int maxIterations = 50;
	    float derivativeStepSize = 1E-3;

	    unsigned int dimensions = 7;
	    //maybe change this to count the number of true's in useCorrespondence
	    //this would require changing how we look up the component functions though
	    unsigned int numFunctions = m_toRegisterIndices.size();
	    lmstate state;
	    lmreport rep;

	    std::cout<<"Running LM Optimization"<<std::endl;

	    ap::real_1d_array startState = TransformToLBFGSArray(prevTransform);
//	    minlmfgj(dimensions, numFunctions, startState, 0.0, 0.0, maxIterations, state);
	    minlmfj(dimensions, numFunctions, startState, 0.0, 0.0, maxIterations, state);
	    while(minlmiteration(state))
	    {
//	    	std::cout << "LM loop..." << std::endl;

	    	Transform3f currentTransform = LBFGSArrayToTransform(state.x);
	    	//set the value at the currentTransform
	        state.f = getError(currentTransform,correspondenceIndices,useCorrespondence,correspondenceWeights);

	        //compute the gradient
            if( state.needfg)
            {
    	        //set the partial derivatives at the currentTransform
    	        for(unsigned int i=0; i<dimensions; i++){
    	        	ap::real_1d_array tmpArray = state.x;
    	        	tmpArray(i) += derivativeStepSize;
    	        	Transform3f plusTransform = LBFGSArrayToTransform(tmpArray);
    	        	float plusError = getError(plusTransform,
    	        			correspondenceIndices,useCorrespondence,correspondenceWeights);
    	        	tmpArray(i) -= 2*derivativeStepSize;
    	        	Transform3f minusTransform = LBFGSArrayToTransform(tmpArray);
    	        	float minusError = getError(minusTransform,
    	        			correspondenceIndices,useCorrespondence,correspondenceWeights);

    	        	//the ith partial derivative
    	        	state.g(i) = (plusError - minusError)/(2*derivativeStepSize);
    	        }
            }
            //compute the component functions and the jacobian
            if( state.needfij )
            {
            	//compute the component errors
            	for(unsigned int i=0; i<dimensions; i++){
            		state.fi(i) = getComponentError(currentTransform,
            				correspondenceIndices,useCorrespondence,i);
            	}
    	        //compute the jacobian
				for(unsigned int dim=0; dim<dimensions; dim++){
					ap::real_1d_array plusArray = state.x;
					plusArray(dim) += derivativeStepSize;
					Transform3f plusTransform = LBFGSArrayToTransform(plusArray);
					ap::real_1d_array minusArray = state.x;
					minusArray(dim) -= derivativeStepSize;
					Transform3f minusTransform = LBFGSArrayToTransform(minusArray);

					for(unsigned int func=0; func<numFunctions; func++){
						float plusError = getComponentError(plusTransform,
								correspondenceIndices,useCorrespondence,func);
						float minusError = getComponentError(minusTransform,
								correspondenceIndices,useCorrespondence,func);

						//the ith partial derivative
						state.j(func,dim) = (plusError - minusError)/(2*derivativeStepSize);
					}
				}
            }

	    }
	    //retreive the results
	    ap::real_1d_array result;
	    minlmresults(state, result, rep);

	    std::cout<<"LM termination code: " <<rep.terminationtype<<std::endl;

	    return LBFGSArrayToTransform(result);
	}
#endif

	/*
	 * This runs the levmar lm code...
	 * It sets some member variables so that the function pointer can get what it needs
	 */
	rgbd::eigen::Transform3f ICP::runNewLMAlignment(
			rgbd::eigen::Transform3f &prevTransform,
			std::vector<unsigned int> &correspondenceIndices,
			std::vector<bool> &useCorrespondence,
			std::vector<float> const &correspondenceWeights)
	{
		// used run LMAlignment from SurfelAICP as a guide
		//unsigned int maxRounds = m_params.max_lm_rounds;
		//bool useAnalyticJacobian = false;

		// one measurement for each component of each point.
		// these are the target points...
#if 0
		std::vector<float> measurement;
		for(unsigned int i=0; i<m_currentCorrPoints.size(); i++){
			if(m_currentCorrWeights[i] > 0){
				for(unsigned int j=0; j<3; j++){
					measurement.push_back(m_currentCorrWeights[i]*m_currentCorrNormals[i][j]*m_currentCorrPoints[i][j]);
				}
			}
		}
#endif

		// for now...
		assert(m_params.do_multiple_error_functions);

		// first set the hacky member variables
		lm_correspondence_indices = correspondenceIndices;
		lm_correspondence_weights = correspondenceWeights;
		lm_use_correspondence = useCorrespondence;

		// I then refer to the hacky variables for clarity
		// first the non-fixed points, which SHOULD use the param specified error function (i.e., point-to-plane)
		std::vector<float> measurement;
		for(unsigned int i=0; i < lm_correspondence_indices.size(); i++){
			if (lm_use_correspondence[i]) {
				if (m_toRegisterErrorFunctions[i] == POINT_TO_PLANE) {
					float dot_component = 0.0;
					for(unsigned int j=0; j<3; j++) {
						dot_component += lm_correspondence_weights[i] *
								m_targetPoints[lm_correspondence_indices[i]][j] *
								m_targetNormals[lm_correspondence_indices[i]][j];
					}
					measurement.push_back(dot_component);
				}
				else if (m_toRegisterErrorFunctions[i] == MSE_NONLINEAR) {
					for(unsigned int j=0; j<3; j++) {
						measurement.push_back(lm_correspondence_weights[i] * m_targetPoints[lm_correspondence_indices[i]][j]);
					}
				}
				else {
					std::cerr << "Unsupported error function for levmar" << std::endl;
					assert(false);
				}
			}
		}

		// then tack on the fixed correpondences, which ALWAYS use point-to-point
		for (unsigned int i = 0; i < lm_fixed_point_pairs.size(); i++) {
			for (unsigned int j = 0; j < 3; j++) {
				// always use point-to-point (mse_nonlinear) for fixed corrs
				measurement.push_back(lm_fixed_point_weights[i] * lm_fixed_point_pairs[i].second[j]);
			}
		}

		if (m_useSimplePriors) {
			// and now 7 priors on the transformation
			for (unsigned int i = 0; i < 7; i++) {
				//rgbd::eigen::Matrix<float,7,1> diff = convertTransformToVector(transform)-m_priorTransform;
				measurement.push_back(m_priorStrength * m_priorTransform[i]);
			}
		}


		// start with prevTransform as an LM state vector
		std::vector<float> transform_as_float_vector;
		convertTransformToSTDVector(prevTransform, transform_as_float_vector);
		float* state = transform_as_float_vector.data();

		// numeric gradient
		slevmar_dif(newErrorFunction, state, measurement.data(),
				transform_as_float_vector.size(), measurement.size(), m_params.max_lm_rounds, NULL, NULL, NULL, NULL, (void*)this);

		// since we passed in the data() of the transform_as_float_vector, it now holds the result state
		Transform3f result_transform;
		convertSTDVectorToTransform(transform_as_float_vector, result_transform);
		return result_transform;

	}

	void
	ICP::newErrorFunction(float *p, float *x, int m, int n, void *data)
	{
		//p are parameters (i.e. state)
		//m is size of parameter vector
		//n is measurement vector size (i.e 3X num corr)
		//data has a pointer to "this"
		ICP *icp = (ICP *)data;

		// assuming quaternion[4] + translation[3]
		assert(m == 7);

		//std::vector<float> state = icp->LMStateToICPState(p);
		//std::vector<rgbd::eigen::Vector3f> newPoints = icp->getSurfelLocations(state,true);

		// Get the locations of source points under the current state "p"
		//void convertTransformToSTDVector(rgbd::eigen::Transform3f const& t, std::vector<float>& v);
		//void convertSTDVectorToTransform(std::vector<float> const& v, rgbd::eigen::Transform3f& t);

		std::vector<float> transform_as_vector(7);
		for (unsigned int i = 0; i < 7; i++) {
			transform_as_vector[i] = p[i];
		}
		rgbd::eigen::Transform3f current_transform;
		convertSTDVectorToTransform(transform_as_vector, current_transform);

		// the variable points
		unsigned int used_positions = 0;
		for(unsigned int i=0; i < icp->m_toRegister.size(); i++) {
			if (icp->lm_use_correspondence[i]) {
				rgbd::eigen::Vector3f transformed_source_point = current_transform*icp->m_toRegister[i];
				if (icp->m_toRegisterErrorFunctions[i] == POINT_TO_PLANE) {
					float dot_component = 0.0;
					for (unsigned int j = 0; j < 3; j++) {
						dot_component += icp->lm_correspondence_weights[i] *
								transformed_source_point[j] *
								icp->m_targetNormals[icp->lm_correspondence_indices[i]][j];
					}
					x[used_positions] = dot_component;
					used_positions++;
				}
				else if (icp->m_toRegisterErrorFunctions[i] == MSE_NONLINEAR) {
					for (unsigned int j = 0; j < 3; j++) {
						x[used_positions + j] =  icp->lm_correspondence_weights[i] * transformed_source_point[j];
					}
					used_positions += 3;
				}
				else {
					std::cerr << "Unsupported error function for levmar new error function" << std::endl;
					assert(false);
				}
			}
		}

		for (unsigned int i = 0; i < icp->lm_fixed_point_pairs.size(); i++) {
			rgbd::eigen::Vector3f transformed_source_point = current_transform*icp->lm_fixed_point_pairs[i].first;
			for (unsigned int j = 0; j < 3; j++) {
				x[used_positions + j] = icp->lm_fixed_point_weights[i] * transformed_source_point[j];
			}
			used_positions += 3;
		}

		// and priors
		if (icp->m_useSimplePriors) {
			for (unsigned int i = 0; i < 7; i++) {
				x[used_positions] = (icp->m_priorStrength * transform_as_vector[i]);
				used_positions++;
			}
		}

		//std::cout << "Used_positions:" << used_positions << std::endl;
		//std::cout << "n             :" << n << std::endl;
		// could make assertions about used_points here...but I'll just see if it works ;)
	}

	void ICP::setFixedPointPairsAndWeights(
			std::vector<std::pair<rgbd::eigen::Vector3f, rgbd::eigen::Vector3f> > const& fixed_point_pairs,
			std::vector<float> const& fixed_point_weights)
	{
		assert(fixed_point_pairs.size() == fixed_point_weights.size());
		lm_fixed_point_pairs = fixed_point_pairs;
		lm_fixed_point_weights = fixed_point_weights;
	}

	bool
	ICP::shouldContinue(
			rgbd::eigen::Transform3f &prevTransform,
			rgbd::eigen::Transform3f & newTransform,
			std::vector<unsigned int> &correspondenceIndices,
			std::vector<bool> &useCorrespondence,
			std::vector<float> const& correspondenceWeights)
	{
		int max_rounds = m_params.max_rounds;
		float minTranslation = m_params.min_dist_to_continue;
		float minRotation = m_params.min_rot_to_continue;
		float minErrorFraction = m_params.min_error_frac_to_continue;

		//check round limit
		if(max_rounds > 0 && m_round > max_rounds)
			return false;

		//difference in translation
		Vector3f translateDiff = newTransform.translation() - prevTransform.translation();
		float translationLength = sqrt(translateDiff.dot(translateDiff));
		//difference in rotation
		Matrix3f rotationDiff = newTransform.linear() * prevTransform.linear().transpose();
		float rotationAmt = AngleAxisf(rotationDiff).angle();
		//difference in error given the _current_ correspondences
		float previous_error = getError(prevTransform,correspondenceIndices,useCorrespondence,correspondenceWeights);
		float current_error = getError(newTransform,correspondenceIndices,useCorrespondence,correspondenceWeights);
		float error_diff = -(current_error - previous_error);
		float error_diff_fraction = error_diff / current_error;

//		std::cout << "New Transform Translation:\n" << Vector3f(newTransform.translation())
//			<<"\nRotation angle:\n "<<AngleAxisf(newTransform.linear()).angle()<<std::endl;
//		std::cout<<"Translation diff: "<<translationLength<<", rotation diff: "
//			<<rotationAmt<<", Error diff: "<<error_diff<<
//			", Error diff fraction:" << error_diff_fraction << std::endl;

		//TODO: other considerations (e.g. time)
		if(translationLength > minTranslation || rotationAmt > minRotation ||
				error_diff_fraction > minErrorFraction)
			return true;
		else
			return false;
	}

	ap::real_1d_array
	ICP::TransformToLBFGSArray(rgbd::eigen::Transform3f const& t)
	{
		Matrix<float,7,1> m = convertTransformToVector(t);

		ap::real_1d_array x;
		x.setbounds(0, 6);
	    x(0) = m[0];
	    x(1) = m[1];
	    x(2) = m[2];
	    x(3) = m[3];
	    x(4) = m[4];
	    x(5) = m[5];
	    x(6) = m[6];

	    return x;
	}

	rgbd::eigen::Transform3f
	ICP::LBFGSArrayToTransform(ap::real_1d_array const& a)
	{
		Matrix<float,7,1> m;
		m[0] = a(0);
		m[1] = a(1);
		m[2] = a(2);
		m[3] = a(3);
		m[4] = a(4);
		m[5] = a(5);
		m[6] = a(6);
		return convertVectorToTransform(m);
	}

	std::vector<unsigned int>& ICP::getSourceIndices()
	{
		return m_toRegisterIndices;
	}

	std::vector<unsigned int>& ICP::getTargetIndices()
	{
		ROS_INFO ("Not implemented");
		assert (false);
	}
}


