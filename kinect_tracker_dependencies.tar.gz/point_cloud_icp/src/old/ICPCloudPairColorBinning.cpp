/*
 * ICPCloudPairPointsOnly: cloud pairs for ICPCombined that only use 3-d position info
 *
 * Evan Herbst
 * 3 / 21 / 10
 */

#include <cassert>
#include <cmath> //min()
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <boost/ref.hpp>
#include <boost/bind.hpp>
#include <boost/make_shared.hpp>
#include <boost/thread.hpp>
#include "rgbd_util/timer.h"
#include "rgbd_util/parallelism.h" //partitionEvenly()
#include "point_clouds/cloudUtils.h"
#ifdef DEBUG_COLOR_BINNING
#include "point_clouds/cloudTofroPLY.h"
#endif
#include "point_cloud_icp/registration/icp_utility.h" //createKDTree()
#include "point_cloud_icp/registration/ICPCloudPairColorBinning.h"
using std::vector;
using std::cout;
using std::endl;
using std::ostringstream;
using std::runtime_error;
using sensor_msgs::PointCloud;

namespace registration
{

//from http://www.cs.rit.edu/~ncs/color/t_convert.html
// r,g,b values are from 0 to 1
// h = [0,360], s = [0,1], v = [0,1]
//		if s == 0, then h = -1 (undefined)
boost::array<unsigned char, 3> rgb2hsv(const boost::array<unsigned char, 3>& rgb)
{
	boost::array<unsigned char, 3> hsv;
	const double r = rgb[0] / 255.0, g = rgb[1] / 255.0, b = rgb[2] / 255.0;
	double h, s, v;

	double min, max;
	min = r; if(g < min) min = g; if(b < min) min = b;
	max = r; if(g > max) max = g; if(b > max) max = b;
	v = max;				// v

	const double delta = max - min;

	if( max > 0 )
	{
		s = delta / max;		// s

		if( r == max )
			h = ( g - b ) / delta;		// between yellow & magenta
		else if( g == max )
			h = 2 + ( b - r ) / delta;	// between cyan & yellow
		else
			h = 4 + ( r - g ) / delta;	// between magenta & cyan

		h *= 60;				// degrees
		if( h < 0 )
			h += 360;
	}
	else {
		// r = g = b = 0		// s = 0, v is undefined
		s = 0;
		h = 1; //so I can return legal char values -- EVH
		v = 1;
	}

	hsv[0] = h * 255 / 360;
	hsv[1] = s * 255;
	hsv[2] = v * 255;
	return hsv;
}

ICPCloudPairColorBinning::ICPCloudPairColorBinning(ICPCloudPairParams const& params,
		sensor_msgs::PointCloud const& source_pointcloud,
		sensor_msgs::PointCloud const& target_pointcloud)
: ICPCloudPair(params, source_pointcloud, target_pointcloud)
{
	initialize(source_pointcloud, target_pointcloud);

	/*
	 * create 2n - 1 bins in each dim, n - 1 of which halfway overlap the "base" bins
	 * (create extra overlapping bins to reduce quantization effects)
	 *
	 * TODO allow to cache trees for another CloudPair
	 */
#ifdef DEBUG_COLOR_BINNING
	rgbd::write_ply_file(target_pointcloud, "full.ply");
#endif
	const unsigned int hueBinSize = 64, valueBinSize = 64; //must be powers of 2
	const unsigned int numHueBins = 2 * (256 / hueBinSize) - 1, numValueBins = 2 * (256 / valueBinSize) - 1;
	targetKDTreesByColor.resize(boost::extents[numHueBins][numValueBins]);
	targetKDTreeIndices.resize(boost::extents[numHueBins][numValueBins]);
	const boost::function<boost::array<unsigned char, 3> (const sensor_msgs::PointCloud& cloud, const unsigned int ptIndex)> getTgtRGB = rgbd::getRGBExtractor(target_pointcloud);
	for(unsigned int i = 0; i < numHueBins; i++)
		for(unsigned int j = 0; j < numValueBins; j++)
		{
			PointCloud subcloud;
			vector<unsigned int>& indices = targetKDTreeIndices[i][j];
			for(unsigned int k = 0; k < target_pointcloud.points.size(); k++)
			{
				const boost::array<unsigned char, 3> hsv = rgb2hsv(getTgtRGB(target_pointcloud, k));
				const unsigned int hueBaseIndex = 2 * (hsv[0] / hueBinSize), valueBaseIndex = 2 * (hsv[2] / valueBinSize); //base (non-overlapping) bin indices
				if(abs((signed)hueBaseIndex - (signed)i) <= 1 && abs((signed)valueBaseIndex - (signed)j) <= 1)
				{
					subcloud.points.push_back(target_pointcloud.points[k]);
					indices.push_back(k);
				}
			}
//			if(subcloud.points.empty()) throw runtime_error("empty subcloud! k-nn will break depending on query data");       instead we'll handle this case later

#ifdef DEBUG_COLOR_BINNING
			subcloud.channels.resize(1);
			subcloud.channels[0].name = "rgb";
			subcloud.channels[0].values.resize(subcloud.points.size(), 0);
			ostringstream outstr;
			outstr << "sub_" << i << "_" << j << ".ply";
			rgbd::write_ply_file(subcloud, outstr.str());
#endif

			targetKDTreesByColor[i][j] = rgbd::createKDTree2(subcloud);
		}

	/*
	 * set which k-d tree each source point will use for lookup
	 */
	sourcePtKDTreeIndices.resize(source_pointcloud.points.size());
	const boost::function<boost::array<unsigned char, 3> (const sensor_msgs::PointCloud& cloud, const unsigned int ptIndex)> getSrcRGB = rgbd::getRGBExtractor(source_pointcloud);
	for(unsigned int i = 0; i < source_pointcloud.points.size(); i++)
	{
		const boost::array<unsigned char, 3> hsv = rgb2hsv(getSrcRGB(source_pointcloud, i));
		const unsigned int hueIndex = std::max(0, std::min((signed)numHueBins - 1, ((signed)hsv[0] - (signed)hueBinSize / 4) / ((signed)hueBinSize / 2))),
			valueIndex = std::max(0, std::min((signed)numValueBins - 1, ((signed)hsv[2] - (signed)valueBinSize / 4) / ((signed)valueBinSize / 2)));
		sourcePtKDTreeIndices[i][0] = hueIndex;
		sourcePtKDTreeIndices[i][1] = valueIndex;
	}
}

/*
 * common ctor code
 *
 * pre: m_params has been set
 */
void ICPCloudPairColorBinning::initialize(const sensor_msgs::PointCloud& source_pointcloud, const sensor_msgs::PointCloud& target_pointcloud)
{
	convertPointCloudToVector(source_pointcloud, m_source_eigen_points);
	convertPointCloudToVector(target_pointcloud, m_target_eigen_points);
}

void ICPCloudPairColorBinning::getCorrespondenceIndicesThreadMain(rgbd::eigen::Transform3f const& transform, std::vector<int> & correspondence_indices, const unsigned int firstIndex, const unsigned int lastIndex, unsigned int& invalid_count) const
{
	invalid_count = 0;

	std::vector<float> correspondence_distances_squared(lastIndex - firstIndex + 1);
	for (unsigned int i = firstIndex, i0 = 0; i <= lastIndex; ++i, i0++)
	{
		const rgbd::eigen::Vector3f transformed_source = transform * m_source_eigen_points[i];
		const boost::shared_ptr<kdtree2>& tree = targetKDTreesByColor(sourcePtKDTreeIndices[i]);
		if(tree->numPoints() > 0)
		{
			const vector<unsigned int>& subcloudIndices = targetKDTreeIndices(sourcePtKDTreeIndices[i]);
			vector<float> qpt(3);
			for(unsigned int j = 0; j < 3; j++) qpt[j] = transformed_source[j];
			kdtree2_result_vector result;
			tree->n_nearest(qpt, 1, result);
			correspondence_indices[i] = subcloudIndices[result[0].idx];
			correspondence_distances_squared[i0] = result[0].dis;
		}
		else //target cloud has no points of similar color
		{
			correspondence_indices[i] = -1;
			invalid_count++;
		}
	}

	// now filter out those beyond the max distance
	// invalid correspondences will be -1
	if (m_params.max_distance > 0.0) {
		const float max_distance_squared = m_params.max_distance * m_params.max_distance;
		for (unsigned int i = firstIndex, i0 = 0; i <= lastIndex; ++i, i0++)
			if (correspondence_indices[i] >= 0) {
				if (correspondence_distances_squared[i0] > max_distance_squared) {
					correspondence_indices[i] = -1;
					invalid_count++;
				}
			}
	}

	// separate out normal check so normals aren't always required
	if (!m_params.front_can_match_back) {
		for (unsigned int i = firstIndex; i <= lastIndex; ++i) {
			if (correspondence_indices[i] >= 0) {
				const rgbd::eigen::Vector3f transformed_normal = transform.linear() * m_source_eigen_normals[i];
				const float normal_dot_product = transformed_normal.dot(m_target_eigen_normals[correspondence_indices[i]]);
				if (normal_dot_product < 0) {
					correspondence_indices[i] = -1;
					invalid_count++;
				}
			}
		}
	}
}

int ICPCloudPairColorBinning::getCorrespondenceIndices(rgbd::eigen::Transform3f const& transform, std::vector<int> & correspondence_indices) const
{
	unsigned int point_count = m_source_eigen_points.size();
	correspondence_indices.resize(point_count);

	// if correspondence is fixed, correspondence is just index
	if (m_params.fixed_correspondence) {
		for (unsigned int i = 0; i < point_count; ++i) {
			correspondence_indices[i] = i;
		}
		return point_count;
	}

	// otherwise, find the nearest point in target points
	rgbd::timer t;
	const unsigned int numThreads = std::max(2, (int)boost::thread::hardware_concurrency() - 4);
	vector<boost::shared_ptr<boost::thread> > threads(numThreads);
	const vector<unsigned int>& indices = partitionEvenly(point_count, numThreads);
	vector<unsigned int> invalidCounts(numThreads);
	for(unsigned int i = 0; i < numThreads; i++)
		threads[i] = boost::make_shared<boost::thread>(boost::bind(&ICPCloudPairColorBinning::getCorrespondenceIndicesThreadMain, this, boost::cref(transform), boost::ref(correspondence_indices), indices[i], indices[i + 1] - 1, boost::ref(invalidCounts[i])));
	unsigned int valid_count = point_count;
	for(unsigned int i = 0; i < numThreads; i++)
	{
		threads[i]->join();
		valid_count -= invalidCounts[i];
	}
	t.stop("get correspondence indices");

	return valid_count;
}

void ICPCloudPairColorBinning::getPoints(std::vector<rgbd::eigen::Vector3f> &source_points, std::vector<rgbd::eigen::Vector3f> &target_points)
{
	source_points = m_source_eigen_points;
	target_points = m_target_eigen_points;
}

} //namespace
