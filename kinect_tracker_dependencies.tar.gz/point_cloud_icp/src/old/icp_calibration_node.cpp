/*
 * icp_calibration_node.cpp
 *
 *  Created on: Aug 28, 2009
 *      Author: mkrainin
 */

#include <ros/node_handle.h>
#include <ros/publisher.h>
#include <ros/subscriber.h>
#include <point_cloud_mapping/cloud_io.h>
#include <sensor_msgs/PointCloud.h>
#include <pr_msgs/WAMJointState.h>
#include <pr_msgs/BHState.h>
#include <point_cloud_icp/openrave_interface.h>
#include <point_cloud_icp/registration/ICP.h>
#include <point_cloud_icp/registration/JointAngleKalmanFilter.h>
#include <point_cloud_icp/registration/icp_utility.h>
#include "rgbd_util/eigen/Core"
#include "rgbd_util/eigen/LU"

#include <string>
#include <sstream>
#include <iomanip>

using namespace std;

namespace registration{

class ICPCalibrationNode{

public:
	ICPCalibrationNode(ros::NodeHandle& node)
	: m_node (node), m_tf_frame("base_link")
	{

		//load the robot
		std::string dataPath,file;
		m_node.param("~openrave_data_path", dataPath, OpenRAVEInterface::readOpenRAVEDataPath());
		m_node.param("~robot_file", file, (string)"/robots/barrettwam.robot.xml");
		bool loaded = m_inter.loadRobot(dataPath,file);

		assert(loaded);

		//set the camera params
		float pKK[4];
		double pKK0,pKK1,pKK2,pKK3;
		int xres,yres;
		m_node.param("~camera_x_res", xres, 1000);
		m_node.param("~camera_y_res", yres, 800);
		m_node.param("~camera_intrinsic_0", pKK0, 800.0);
		m_node.param("~camera_intrinsic_1", pKK1, 800.0);
		m_node.param("~camera_intrinsic_2", pKK2, xres/2.0);
		m_node.param("~camera_intrinsic_3", pKK3, yres/2.0);
		pKK[0] = pKK0;
		pKK[1] = pKK1;
		pKK[2] = pKK2;
		pKK[3] = pKK3;
		m_inter.setCameraParams(xres,yres,pKK);

		//set the camera transform
		double xloc,yloc,zloc;
		double axisx,axisy,axisz,angle;
		m_node.param("~camera_loc_x", xloc, -.01);
		m_node.param("~camera_loc_y", yloc, 0.26);
		m_node.param("~camera_loc_z", zloc, 0.47);
		m_node.param("~camera_axis_x", axisx, 0.282147);
		m_node.param("~camera_axis_y", axisy, -0.433866);
		m_node.param("~camera_axis_z", axisz, -0.855660);
		m_node.param("~camera_angle", angle, 2.044096);
		rgbd::eigen::Vector3f translation(xloc,yloc,zloc);
		rgbd::eigen::AngleAxisf angleAxis(angle,rgbd::eigen::Vector3f(axisx,axisy,axisz));
		rgbd::eigen::Transform3f transform(angleAxis);
		transform.pretranslate(translation);
		m_inter.setCameraTransform(transform);
	}

	int start()
	{
		m_reportedStateHistory.clear();
		m_reportedStateHistory.push_front(std::vector<float>(m_inter.getNumDOF()));

		m_handStateReady = false;
		m_wamStateReady = false;
		m_framesSeen = 0;

		ros::Subscriber handSubscriber = m_node.subscribe<pr_msgs::BHState>("/handstate",0,&registration::ICPCalibrationNode::processHandState,this);
		ros::Subscriber wamSubscriber = m_node.subscribe<pr_msgs::WAMJointState>("/owd/jointstate",0,&registration::ICPCalibrationNode::processWAMState,this);
		ros::Subscriber cloudSubscriber = m_node.subscribe<sensor_msgs::PointCloud>("/wide_stereo/cloud",0,&registration::ICPCalibrationNode::processCloud,this);

		std::cout<<"Calibration node started. Waiting for data sequence . . ."<<std::endl;

		ros::spin();

		return 0;
	}

private:
	ros::NodeHandle& m_node;

	//topics to listen to
	string m_handStateTopic;
	string m_wamStateTopic;
	string m_stereoCloudTopic;

	//point cloud frame
	string m_tf_frame;

	std::deque<std::vector<float> > m_reportedStateHistory;
	OpenRAVEInterface m_inter;
	std::deque<std::pair<sensor_msgs::PointCloud,std::vector<float> > > m_cloudConfigurationPairs;

	//flags to tell what's been done
	bool m_handStateReady;
	bool m_wamStateReady;

	unsigned int m_framesSeen;

	void performCalibration()
	{
		//angle uncertainties are quaternion components
		float initTranslationUncertainty = 0.4;
		float initAngleUncertainty = 0.6;
		float icpTranslationUncertainty = 0.2;
		float icpAngleUncertainty = 0.2;
		float maxStandardDeviations = 5.0;
		unsigned int pixelIncrement = 2;
		bool cameraToSimulated = true;
		bool useRejection = true;

		ICPParams icp_params;
		icp_params.max_distance = 0.07;
		icp_params.use_accelerated = false;
		icp_params.max_rounds = 20;
		icp_params.error_function = GENERALIZED;
		icp_params.downsampling = RANDOM;
		icp_params.downsample_rate = 0.2;
		icp_params.do_far_remove = true;
		icp_params.far_remove_radius = 1.2;


		//set the initial state for the filter
		rgbd::eigen::Transform3f initTransform;
		initTransform.setIdentity();
		rgbd::eigen::Matrix<float,7,1> initState = transformToStateVector(initTransform);
//		initState(0) = 0;
//		initState(1) = .02;
//		initState(2) = .01;
//		initState(3) = 0.9955;
//		initState(4) = -0.02702;
//		initState(5) = -0.08438;
//		initState(6) = -0.03346;

		if(!cameraToSimulated){
			initState = getInverseState(initState);
		}


		rgbd::eigen::Matrix<float,7,7> initCovariance = rgbd::eigen::Matrix<float,7,7>::Identity();
		for(unsigned int i=0; i<7; i++){
			if(i<3)
				initCovariance(i,i) = pow(initTranslationUncertainty,2);
			else
				initCovariance(i,i) = pow(initAngleUncertainty,2);
		}


		//construct the measurement covariance, which we will consider
		//to be just a constant matrix
		rgbd::eigen::Matrix<float,7,7> Q = rgbd::eigen::Matrix<float,7,7>::Identity();
		for(unsigned int i=0; i<7; i++){
			if(i<3)
				Q(i,i) = pow(icpTranslationUncertainty,2);
			else
				Q(i,i) = pow(icpAngleUncertainty,2);
		}


		rgbd::eigen::Matrix<float,7,1> filterMean = initState;
		rgbd::eigen::Matrix<float,7,7> filterCovariance = initCovariance;

		std::cout<<"Start state vector: "<<std::endl;
		std::cout<<filterMean<<std::endl;

		unsigned int numRejected = 0;
		unsigned int numFailed = 0;

		unsigned int frame = 0;
		unsigned int totalFrames = m_cloudConfigurationPairs.size();

		while(!m_cloudConfigurationPairs.empty()){
			//capture the ray-traced scan from the reported angles
			sensor_msgs::PointCloud simulatedCloud;
			m_inter.setJointAngles(m_cloudConfigurationPairs.front().second);
			m_inter.generatePointCloud(simulatedCloud,true,pixelIncrement);

			//run icp
			rgbd::eigen::Transform3f icpStartState = stateVectorToTransform(filterMean);
			rgbd::eigen::Transform3f icpResult;
			bool icpSuccess;
			if(cameraToSimulated){
				ICP icp(m_cloudConfigurationPairs.front().first,simulatedCloud);
				icp.setParams(icp_params);
				icp.setInitialTransform(icpStartState);
				rgbd::eigen::Matrix<float,7,1> stateVector = convertTransformToVector(icpStartState);
				icp.setTransformPriors(stateVector,filterCovariance);
				icpResult = icp.runICP();
				icpSuccess = icp.ICPSucceeded();
			}
			else{
				ICP icp(simulatedCloud,m_cloudConfigurationPairs.front().first);
				icp.setParams(icp_params);
				icp.setInitialTransform(icpStartState);
				icpResult = icp.runICP();
				icpSuccess = icp.ICPSucceeded();
			}

			if(!icpSuccess)
			{
				std::cout<<"ICP failed for frame "<<frame<<std::endl;
				numFailed++;
				frame++;
				continue;
			}

			rgbd::eigen::Matrix<float,7,1> measuredState = transformToStateVector(icpResult);
			rgbd::eigen::Matrix<float,7,1> stateDiff = measuredState-filterMean;

			//make sure that the icp result seems reasonable before incorporating it
			float stDevs = sqrt((stateDiff.transpose()*filterCovariance.inverse()*stateDiff)(0,0));
			if(stDevs > maxStandardDeviations && useRejection){
				std::cout<<"Rejecting ICP result for frame "<<frame<<std::endl;
				std::cout<<"Num standard devs: "<<stDevs<<std::endl;

				std::cout<<"Rejected state vector: "<<std::endl;
				std::cout<<measuredState<<std::endl;
				numRejected++;
				frame++;
				continue;
			}

//			std::cout<<"Filter covariance: "<<std::endl;
//			std::cout<<filterCovariance<<std::endl;
//			std::cout<<"Q: "<<std::endl;
//			std::cout<<Q<<std::endl;
//			std::cout<<"Filter covariance + Q inverse: "<<std::endl;
//			std::cout<<(filterCovariance+Q).inverse()<<std::endl;

			rgbd::eigen::Matrix<float,7,7> K = filterCovariance * (filterCovariance + Q).inverse();
			filterMean = filterMean + K*stateDiff;
			filterCovariance = (rgbd::eigen::Matrix<float,7,7>::Identity() - K)*filterCovariance;

			std::cout<<"New state vector: "<<std::endl;
			std::cout<<filterMean<<std::endl;

			rgbd::eigen::Matrix<float,7,1> camToSim;
			if(cameraToSimulated){
				camToSim = filterMean;
			}
			else{
				camToSim = getInverseState(filterMean);
			}
			std::cout<<"Filter mean (camera to simulated) for frame "<<frame<<std::endl;
			std::cout<<"\t Translation: "<<camToSim(0)<<", "<<camToSim(1)<<", "<<camToSim(2)<<std::endl;
			std::cout<<"\t Quaternion: "<<camToSim(3)<<", "<<camToSim(4)<<", "<<camToSim(5)<<", "<<camToSim(6)<<std::endl;

			m_cloudConfigurationPairs.pop_front();
			frame++;
		}

		rgbd::eigen::Matrix<float,7,1> camToSim;
		if(cameraToSimulated){
			camToSim = filterMean;
		}
		else{
			camToSim = getInverseState(filterMean);
		}
		std::cout<<"Final Result (camera to simulated): "<<std::endl;
		std::cout<<"\t Translation: "<<camToSim(0)<<", "<<camToSim(1)<<", "<<camToSim(2)<<std::endl;
		std::cout<<"\t Quaternion: "<<camToSim(3)<<", "<<camToSim(4)<<", "<<camToSim(5)<<", "<<camToSim(6)<<std::endl;
		std::cout<<"Rejected "<<numRejected<<" ICP results, and "<<numFailed<<" ICP failures out of "<<totalFrames<<std::endl;

		rgbd::eigen::Transform3f totalTransform = stateVectorToTransform(camToSim)*(m_inter.getCameraTransform());
		rgbd::eigen::AngleAxisf aa(totalTransform.linear());
		rgbd::eigen::Vector3f trans = totalTransform.translation();

		std::cout<<"Combined transform: "<<std::endl;
		std::cout<<"Angle: "<<aa.angle()<<std::endl;
		std::cout<<"Axis: "<<aa.axis()<<std::endl;
		std::cout<<"Translation: "<<trans<<std::endl;
	}


	rgbd::eigen::Matrix<float,7,1> getInverseState(rgbd::eigen::Matrix<float,7,1> const& state){
		rgbd::eigen::Transform3f transform = stateVectorToTransform(state);

		rgbd::eigen::Translation3f t(transform.translation());
		rgbd::eigen::Quaternionf q(transform.linear());

		rgbd::eigen::Transform3f inverse(q.inverse());
		inverse.translate(t.inverse().vector());

		return transformToStateVector(inverse);
	}

	rgbd::eigen::Matrix<float,7,1> transformToStateVector(rgbd::eigen::Transform3f const& transform){
		rgbd::eigen::Matrix<float,7,1> toReturn;

		rgbd::eigen::Vector3f t(transform.translation());
		rgbd::eigen::Quaternionf q(transform.linear());
		q.normalize();

		for(unsigned int i=0; i<3; i++)
			toReturn(i) = t(i);
		toReturn(3) = q.w();
		toReturn(4) = q.x();
		toReturn(5) = q.y();
		toReturn(6) = q.z();

		return toReturn;
	}

	rgbd::eigen::Transform3f stateVectorToTransform(rgbd::eigen::Matrix<float,7,1> const& vector){
		rgbd::eigen::Vector3f t(vector(0),vector(1),vector(2));
		rgbd::eigen::Quaternionf q(vector(3),vector(4),vector(5),vector(6));

		rgbd::eigen::Transform3f toReturn(q);
		toReturn.pretranslate(t);

		return toReturn;
	}



	void processHandState(const pr_msgs::BHState::ConstPtr &handState)
	{
		std::cout<<"Updating hand state"<<std::endl;

		for(unsigned int i=0; i<4; i++){
			m_reportedStateHistory.front()[i+7] = handState.get()->positions[i];
		}

		m_handStateReady = true;

		if(m_wamStateReady)
			m_reportedStateHistory.push_front(std::vector<float>(m_reportedStateHistory.front()));
	}

	void processWAMState(const pr_msgs::WAMJointState::ConstPtr &wamState)
	{
		std::cout<<"Updating wam state"<<std::endl;

		for(unsigned int i=0; i<7; i++){
			m_reportedStateHistory.front()[i] = wamState.get()->positions[i];
		}

		m_reportedStateHistory.front()[6] -= M_PI_2;

		m_wamStateReady = true;

		if(m_handStateReady)
			m_reportedStateHistory.push_front(std::vector<float>(m_reportedStateHistory.front()));
	}

	void processCloud(const sensor_msgs::PointCloud::ConstPtr &cloud)
	{
		//make sure these numbers multiply to less than the total number of frames in the sequence
		unsigned int maxFrames = 30;
		unsigned int skipRate = 1; //lots of identical frames. this should help prevent overconfidence from identical views

		//hack to get things roughly syncronized. stereo processing takes
		//some time, so they come in at some delay relative to the joint angles
		unsigned int numBackFromLastReported = 0;

		//front is never ready, so size needs to be at least 2 + numBack
		if(m_reportedStateHistory.size() < (numBackFromLastReported + 2))
			return;

		std::vector<float> reported = m_reportedStateHistory[1+numBackFromLastReported];

		m_framesSeen++;

//		float timeStamp = ros::Time::now().toSec();
//
//		if(!m_initialStateSet){
//			m_firstTimeStamp = timeStamp;
//			m_initialStateSet = true;
//
//		}
//
//		float diff = timeStamp - m_firstTimeStamp;
//		std::cout<<diff<<" seconds into the sequence on pair "<<(m_cloudConfigurationPairs.size()+1)<<std::endl;

		if(m_cloudConfigurationPairs.size() == maxFrames){
			std::cout<<"Done reading in clouds"<<std::endl;
			std::cout<<"Read in "<<m_cloudConfigurationPairs.size()<<" pairs"<<std::endl;
			this->performCalibration();
			ros::shutdown();
		}
		else if(m_framesSeen % skipRate == 0)
		{
			std::cout<<"Storing cloud, configuration pair"<<std::endl;

			//radius remove
			std::deque<unsigned int > indices =
					getRadiusDownsamplingIndices(*cloud.get(),rgbd::eigen::Vector3f::Zero(),1.2,true);
			sensor_msgs::PointCloud downsampledCloud;
			downsampleFromIndices(*cloud.get(),downsampledCloud,indices);

			sensor_msgs::PointCloud realCloud = m_inter.convertCameraToGlobalCoords(downsampledCloud);
			realCloud.header.stamp = ros::Time::now();
			realCloud.header.frame_id = m_tf_frame;

			m_cloudConfigurationPairs.push_back(
					std::pair<sensor_msgs::PointCloud,std::vector<float> >(realCloud,reported));
		}

	}


	static void setPointCloudColor(sensor_msgs::PointCloud &cloud, rgbd::eigen::Vector3f color)
	{
		unsigned int startChannel = 0;
		for(unsigned int i=0; i<cloud.points.size(); i++){
			cloud.channels[startChannel].values[i] = color.x();
			cloud.channels[startChannel+1].values[i] = color.y();
			cloud.channels[startChannel+2].values[i] = color.z();
		}
	}


};
}


int main(int argc, char** argv)
{

	ros::init (argc, argv,"icp_calibration_node");
	ros::NodeHandle ros_node;
	ROS_INFO ("Starting main...");

	registration::ICPCalibrationNode node(ros_node);
	return (node.start());
}

