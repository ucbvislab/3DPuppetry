std::deque<unsigned int> getDensityDownsamplingIndices(
			sensor_msgs::PointCloud const& cloud,
			float radius, int maxWithinRadius)
	{

		ros::Time startTime = ros::Time::now();

		cloud_kdtree::KdTreeANN cloudTree(cloud);

		unsigned int initNumPts = cloud.points.size();

		//randomize the indices so we don't bias the point removal
		std::vector<unsigned int> possibleIndices(initNumPts);
		for(unsigned int i=0; i<initNumPts; i++)
			possibleIndices[i] = i;
//		srand ( unsigned ( time (NULL) ) );
		random_shuffle(possibleIndices.begin(),possibleIndices.end());

		//sort out points into accepted or rejected based on number of so far non-rejected
		//points within the specified radius
		std::vector<bool> toRegisterIndexRejected =
			std::vector<bool>(initNumPts,true);
		std::deque<unsigned int> acceptedIndices;
		for(unsigned int i=0; i<possibleIndices.size(); i++){
			unsigned int pointIndex = possibleIndices[i];

			//do a radius search
			std::vector<int> k_indices;
			std::vector<float> k_distances;
			cloudTree.radiusSearch(cloud.points[pointIndex],radius,k_indices,k_distances);
			//count the number of non-rejected indices in k_indices
			int nonRejectedCount = 0;
			for(unsigned int j=0; j<k_indices.size(); j++){
				unsigned int neighborIndex = k_indices[j];
				if(!toRegisterIndexRejected[neighborIndex]){
					nonRejectedCount++;
				}
			}
			//throw out the point if count is too large
			if(nonRejectedCount <= maxWithinRadius){
				toRegisterIndexRejected[pointIndex] = false;
				acceptedIndices.push_back(pointIndex);
			}
		}

		unsigned int finalNumPts = acceptedIndices.size();
		std::cout<<"Downsampled "<<initNumPts<<" points to "<<finalNumPts<<
			" points by limiting to points  with initially less than "<<maxWithinRadius
			<<" points within "<<radius<<" meters"<<std::endl;

		ros::Time endTime = ros::Time::now();
		ros::Duration dur = endTime-startTime;
		std::cout<<"Density downsampling selection took "<<dur.toSec()<<" seconds"<<std::endl;

		return acceptedIndices;
	}

void mergeCloudsWithDensity(sensor_msgs::PointCloud &toMergeInto,
			sensor_msgs::PointCloud const& toAdd, float densityRadius)
	{
		if (toMergeInto.points.size() == 0 && toAdd.points.size() == 0) {
			return;
		}
		else if (toMergeInto.points.size() == 0) {
#if 0
			// simply way...
			// merge just points and channels to keep header of merge into
			toMergeInto.points = toAdd.points;
			toMergeInto.channels = toAdd.channels;
			return;
#endif
			// density downsample toAdd into toMergeInto
			// then density downsample the result

			int density_count = 0;
			std::deque<unsigned int> downsample_indices = getDensityDownsamplingIndices(toAdd, densityRadius, density_count);
			downsampleFromIndices(toAdd, toMergeInto, downsample_indices);
			toMergeInto.header = toAdd.header;
			return;
		}

		std::vector<unsigned int> indicesToUse;
		float squaredRadius = pow(densityRadius,2);

		cloud_kdtree::KdTreeANN cloudTree(toMergeInto);

		std::vector<int> k_indices;
		std::vector<float> k_distances;
		for(unsigned int i=0; i<toAdd.points.size(); i++){
			cloudTree.nearestKSearch(toAdd,i,1,k_indices,k_distances);
			if(k_distances[0] > squaredRadius){
				indicesToUse.push_back(i);
			}
		}

		unsigned int origPoints = toMergeInto.points.size();
		unsigned int toAddPoints = indicesToUse.size();
		unsigned int newPoints = origPoints + toAddPoints;

		rgbd::setPointCount(toMergeInto, newPoints);

		for(unsigned int i=0; i<toAddPoints; i++){
			toMergeInto.points[origPoints+i] = toAdd.points[indicesToUse[i]];
			for(unsigned int chan=0; chan<toMergeInto.channels.size(); chan++){
				toMergeInto.channels[chan].values[origPoints+i] =
						toAdd.channels[chan].values[indicesToUse[i]];
			}
		}
	}

void add_indices(int total_indices, const std::vector<unsigned int>& indices_before,
			const std::vector<unsigned int>& indices_to_add, std::vector<unsigned int>& result)
	{
    	std::vector<bool> use_index(total_indices, false);
		for (unsigned int i = 0; i < indices_before.size(); i++) {
			use_index[indices_before[i]] = true;
		}
		for (unsigned int i = 0; i < indices_to_add.size(); i++) {
			use_index[indices_to_add[i]] = true;
		}
		result.clear();
		for (unsigned int i = 0; i < use_index.size(); i++) {
			if (use_index[i])
				result.push_back(i);
		}
	}

	void remove_indices(int total_indices, const std::vector<unsigned int>& indices_before, const std::vector<unsigned int>& indices_to_remove, std::vector<unsigned int>& result)
	{
    	std::vector<bool> use_index(total_indices, false);
		for (unsigned int i = 0; i < indices_before.size(); i++) {
			use_index[indices_before[i]] = true;
		}
		for (unsigned int i = 0; i < indices_to_remove.size(); i++) {
			use_index[indices_to_remove[i]] = false;
		}
		result.clear();
		for (unsigned int i = 0; i < use_index.size(); i++) {
			if (use_index[i])
				result.push_back(i);
		}
	}

	void invert_indices(int total_indices, const std::vector<unsigned int>& indices_before, std::vector<unsigned int>& result)
	{
		std::vector<bool> use_index(total_indices, true);
		for (unsigned int i = 0; i < indices_before.size(); i++) {
			use_index[indices_before[i]] = false;
		}
		result.clear();
		for (unsigned int i = 0; i < use_index.size(); i++) {
			if (use_index[i])
				result.push_back(i);
		}
	}

	float getMedianSSE(
		deque<pair<Vector3f,Vector3f> > const& correspondences,
		rgbd::eigen::Transform3f const& transform)
	{
		vector<float> errors;
		for(unsigned int i=0; i<correspondences.size(); i++){
			Vector3f diff = transform*correspondences[i].first-correspondences[i].second;
			errors.push_back(diff.dot(diff));
		}

		sort(errors.begin(),errors.end());
		return errors[errors.size()/2];
	}

	bool write_sift_descriptors(std::vector<unsigned int> const& cloud_indices,
			std::vector<std::pair<int, int> > const& image_points,
			std::vector<rgbd::eigen::Vector3f> const& depth_points,
			std::vector<std::vector<float> > const& descriptors,
			std::string filename)
	 {
		unsigned int point_count = image_points.size();

		assert(depth_points.size() == point_count);
		assert(descriptors.size() == point_count);

		std::ofstream ofs(filename.c_str());
		if (!ofs.is_open()) {
			std::cerr << "Failed to open file:" << filename << std::endl;
			return false;
		}

		for (unsigned int i = 0; i < point_count; i++) {
			// cloud index (then " : ")
			ofs << cloud_indices[i] << " : ";
			// image location
			ofs << image_points[i].first << " " << image_points[i].second << " : ";
			// 3d location
			ofs << depth_points[i].x() << " " << depth_points[i].y() << " " << depth_points[i].z() << " : ";
			// finally, the descriptor
			for (unsigned int j = 0; j < descriptors[i].size(); j++) {
				ofs.precision(10);
				ofs << descriptors[i][j] << " ";
			}
			ofs << "\n";
		}
		ofs.close();
		return true;
	 }
