void test_descriptor_3d(const sensor_msgs::PointCloudConstPtr& point_cloud) {
		// from the examples directory of descriptors_3d
    	ROS_INFO("Beginning feature computation");
    	ros::Time start_time = ros::Time::now ();

		// ----------------------------------------------
		// Read point cloud data and create Kd-tree that represents points.
		// We will compute features for all points in the point cloud.
		sensor_msgs::PointCloud data;

		// use the full cloud (copy)
		data = (*point_cloud);

		// or a downsampled cloud
		//randomDownsamplePointCloud((*point_cloud), data, 0.1);

		cloud_kdtree::KdTreeANN data_kdtree(data);
		cv::Vector<const geometry_msgs::Point32*> interest_pts(
				data.points.size());
		for (size_t i = 0; i < data.points.size(); i++) {
			interest_pts[i] = &(data.points[i]);
		}

		ros::Time setup_end_time = ros::Time::now();
		ROS_INFO("Setup time for features:%f", (setup_end_time - start_time).toSec());

		float normal_neighborhood = 20.0; // depends on scale (2 cm)


		// ----------------------------------------------
		// SpectralAnalysis is not a descriptor, it is a class that holds
		// intermediate data to be used/shared by different descriptors.
		// It performs eigen-analyis of local neighborhoods and extracts
		// eigenvectors and values.  Here, we set it to look at neighborhoods
		// within a radius of 5.0 around each interest point.
		SpectralAnalysis sa(normal_neighborhood);

		// ----------------------------------------------
		// Examines the eigenvalues for a local neighborhood scatter matrix
		// to give features that represent the local shape (how flat, how linear,
		// how scattered) of the neighborhood.
		// This descriptor uses information from spectral analysis.
		ShapeSpectral shape_spectral(sa);

		// ----------------------------------------------
		// Compute a spin image centered at each interest point.
		// The spin axis here is the +z direction (0,0,1).
		// The spin image resolution has 1.0 square cells.
		// Note that the number of rows in the spin image MUST be odd
		// (see documentation).
		// The last argument is used when computing spin image for
		// regions of points, since we are computing a descriptor
		// for single points it should be false.

		// Peter: dependence on z (relative to camera) probably not good
		//SpinImageCustom spin_image1(0, 0, 1, 1.0, 1.0, 5, 4, false);

		// ----------------------------------------------
		// Compute another spin image centered at each interest point.
		// The spin axis here is about each interest points' estimated normal.
		// We can either recompute the normals using a different radius than
		// used with spectral_shape (by instantiating another SpectralAnalysis),
		// or we can use the same normals computed from shape_spectral.
		float bin_resolution = 10.0; // 1 cm per bin
		SpinImageNormal spin_image2(bin_resolution, bin_resolution, 5, 4, false, sa);

		// ----------------------------------------------
		// Compares the locally estimated normal and tangent vectors around
		// each interest point against the specified reference direction (+z).
		// The feature value is cos(theta), where theta is the angle between
		// the normal/tangent and the reference direction
		//OrientationNormal o_normal(0, 0, 1, sa);
		//OrientationTangent o_tangent(0, 0, 1, sa);

		// ----------------------------------------------
		// The feature is simply the z coordinate for each interest point
		//Position position;

		// ----------------------------------------------
		// Computes the bounding box in the principle component space
		// of all points within radius 6.0.  That is, feature values
		// are the lengths of the box along the 3 component directions.
		//BoundingBoxSpectral bbox_spectral(6.0, sa);

		// ----------------------------------------------
		// Put all descriptors into a vector
		std::vector<Descriptor3D*> descriptors_3d;
		descriptors_3d.push_back(&shape_spectral);
		//descriptors_3d.push_back(&spin_image1);
		descriptors_3d.push_back(&spin_image2);
		//descriptors_3d.push_back(&o_normal);
		//descriptors_3d.push_back(&o_tangent);
		//descriptors_3d.push_back(&position);
		//descriptors_3d.push_back(&bbox_spectral);

		// ----------------------------------------------
		// Iterate over each descriptor and compute features for each point in the point cloud.
		// The compute() populates a vector of vector of floats, i.e. a feature vector for each
		// interest point.  If the features couldn't be computed successfully for an interest point,
		// its feature vector has size 0
		unsigned int nbr_descriptors = descriptors_3d.size();
		std::vector<cv::Vector<cv::Vector<float> > > all_descriptor_results(
				nbr_descriptors);
		for (unsigned int i = 0; i < nbr_descriptors; i++) {
			descriptors_3d[i]->compute(data, data_kdtree, interest_pts,
					all_descriptor_results[i]);
		}

		ros::Time end_time = ros::Time::now();
		ROS_INFO ("Done computing features in time:%f", (end_time - start_time).toSec());

		// the spin images for the first n points
		size_t n_print = 10;
		for (size_t p = 0; p < n_print; p++) {
			const cv::Vector<float>& spin_image_feature = all_descriptor_results[1][p];
			std::stringstream feature_string;
			for (size_t i = 0; i < spin_image_feature.size(); i++) {
				feature_string << spin_image_feature[i] << " ";
			}
			ROS_INFO("Spin image:%s", feature_string.str().c_str());
		}

#if 0
		// ----------------------------------------------
		// Print out the bounding box dimension features for the first point 0
		cv::Vector<float>& pt0_bbox_features = all_descriptor_results[6][0];
		std::cout << "Bounding box features:";
		for (size_t i = 0; i < pt0_bbox_features.size(); i++) {
			std::cout << " " << pt0_bbox_features[i];
		}
		std::cout << std::endl;
#endif
	}







/****
 *
 * Various things from surfel_node that got abandoned
 *
 */

std::vector<float> getSquaredDistancesToLinks(
		SurfelAICP &icp, unsigned int surfelNum, std::vector<bool> const& dontUseSurfel,
		std::vector<std::vector<unsigned int> > const& nearbySurfels,
		std::vector<std::pair<float,float> > const& projections)
{
	unsigned int pixelWindow = m_linkPixelWindow;

	unsigned int numLinks = m_inter.getLinks().size();
	rgbd::eigen::Vector3f ptLocation = m_surfels[surfelNum].location;

	//initialize closest distances with the link centers
	std::vector<float> closestSqDist(numLinks+1);
	for(unsigned int i=0; i<numLinks; i++){
		closestSqDist[i] = (ptLocation-getLinkLocation(icp,i)).squaredNorm();
	}
	closestSqDist[numLinks] = (ptLocation - getEndEffectorLocation(icp)).squaredNorm();

	//look at all surfels in a pixel window
	//might just be worthwhile to have kd-trees
	int x = round(projections[surfelNum].first);
	int y = round(projections[surfelNum].second);
	for(int u = x-(int)pixelWindow; u<=x+(int)pixelWindow; u++){
		if(u < 0)
			continue;
		if(u >= (int)m_camParams.xRes)
			break;
		for(int v = y-(int)pixelWindow; v<=y+(int)pixelWindow; v++){
			if(v < 0)
				continue;
			if(v >= (int)m_camParams.yRes)
				break;

			std::vector<unsigned int> surfelIndices = nearbySurfels[u + v*m_camParams.xRes];
			for(unsigned int i=0; i<surfelIndices.size(); i++){
				unsigned int index = surfelIndices[i];

				if(index==surfelNum || dontUseSurfel[index])
					continue;

				unsigned int linkNum = numLinks;
				if(!m_surfelIsOnObject[index])
					linkNum = m_surfelLinks[index]->GetIndex();

				float sqDist = (m_surfels[index].location-ptLocation).squaredNorm();
				if(sqDist < closestSqDist[linkNum]){
					closestSqDist[linkNum] = sqDist;
				}
			}
		}
	}

	return closestSqDist;
}

std::vector<std::vector<float> > getSquaredDistancesToLinks(
		SurfelAICP &icp, std::vector<unsigned int> const& surfelIndices,
		std::vector<bool> const& dontUseSurfel,
		std::vector<std::vector<unsigned int> > const& nearbySurfels,
		std::vector<std::pair<float,float> > const& projections)
{
	std::vector<std::vector<float> > toReturn;
	for(unsigned int i=0; i<surfelIndices.size(); i++){
		toReturn.push_back(getSquaredDistancesToLinks(icp,surfelIndices[i],
				dontUseSurfel,nearbySurfels,projections));
	}
	return toReturn;
}

std::vector<float> getMinSquaredDistancesToLinks(
	SurfelAICP &icp, std::vector<unsigned int> const& surfelIndices,
	std::vector<bool> const& dontUseSurfel,
	std::vector<std::vector<unsigned int> > const& nearbySurfels,
	std::vector<std::pair<float,float> > const& projections)
{
	unsigned int numLinks = m_inter.getLinks().size();
	std::vector<float> toReturn(numLinks+1);
	for(unsigned int i=0; i<surfelIndices.size(); i++)
	{
		std::vector<float> currentDists = getSquaredDistancesToLinks(
			icp,surfelIndices[i],dontUseSurfel,nearbySurfels,projections);
		if(i==0)
			toReturn = currentDists;
		else{
			for(unsigned int j=0; j<currentDists.size(); j++){
				if(currentDists[j] < toReturn[j])
					toReturn[j] = currentDists[j];
			}
		}
	}
	return toReturn;
}

std::vector<float> getMinSquaredDistancesToLinks(
	std::vector<unsigned int> const& cluster,
	std::vector<unsigned int> const& surfelIndices,
	std::vector<std::vector<float> > const& squaredDistances)
{
	//cluster and surfelIndices index into m_surfels
	//squaredDistances is indexed into the same way as surfelIndices

	//identify which surfels are in the cluster
	std::vector<bool> inCluster(m_surfels.size(), false);
	for(unsigned int i=0; i<cluster.size(); i++){
		inCluster[cluster[i]] = true;
	}

	//do the minimization
	std::vector<float> toReturn;
	bool toReturnSet = false;
	for(unsigned int i=0; i<surfelIndices.size(); i++){
		unsigned int index = surfelIndices[i];
		if(inCluster[index]){
			if(!toReturnSet){
				toReturn = squaredDistances[i];
				toReturnSet = true;
			}
			else{
				for(unsigned int j=0; j<squaredDistances[i].size(); j++){
					if(squaredDistances[i][j] < toReturn[j])
						toReturn[j] = squaredDistances[i][j];
				}
			}
		}
	}

	return toReturn;
}

void chooseLinkForSurfel(
		SurfelAICP &icp, unsigned int surfelNum, std::vector<bool> & shouldRemove,
		std::vector<std::vector<unsigned int> > const& nearbySurfels,
		std::vector<std::pair<float,float> > const& projections)
{

	float distForSpecialConsideration = m_linkSpecialDist;
	float minDistFromOther = m_linkDistFromSecond;
	float maxDistFromClosest = m_linkDistFromClosest;

	unsigned int numLinks = m_inter.getLinks().size();
	OpenRAVE::KinBody::LinkPtr objLink = m_inter.getLinks()[7];
	rgbd::eigen::Vector3f ptLocation = m_surfels[surfelNum].location;

	std::vector<float> closestSqDist = this->getSquaredDistancesToLinks(
			icp,surfelNum,shouldRemove,nearbySurfels,projections);
	bool specialObjectConsideration = closestSqDist[numLinks] < pow(distForSpecialConsideration,2);

	unsigned int index1=0,index2=0;
	float sqDist1=0,sqDist2=0;
	for(unsigned int i=0; i<=numLinks; i++){
		float sqDist = closestSqDist[i];

		if(i == 0 || sqDist < sqDist1){
			index2 = index1;
			sqDist2 = sqDist1;
			index1 = i;
			sqDist1 = sqDist;
		}
		else if(i == 1 || sqDist < sqDist2){
			index2 = i;
			sqDist2 = sqDist;
		}
	}

	if(closestSqDist[index1] > pow(maxDistFromClosest,2)){
		//nothing near the point to compare to
		//throw away the point
		shouldRemove[surfelNum] = true;
		return;
	}

	//if near the object seed, take object unless another link is
	//really close
	if(specialObjectConsideration){
//    		std::cout<<"special consideration case"<<std::endl;
		unsigned int closestNonObject = index1;
		if(closestNonObject == numLinks){
			closestNonObject = index2;
		}

		if(closestSqDist[closestNonObject] > pow(minDistFromOther,2)){
//    			std::cout<<"chose object"<<std::endl;
			m_surfelLinks[surfelNum] = objLink;
			m_surfelIsOnObject[surfelNum] = true;
			return;
		}
	}

	//pick the closest
	if(index1 == numLinks){
//    		std::cout<<"chose object"<<std::endl;
		m_surfelLinks[surfelNum] = objLink;
		m_surfelIsOnObject[surfelNum] = true;
	}
	else{
//    		std::cout<<"chose link "<<index1<<std::endl;
		m_surfelLinks[surfelNum] = m_inter.getLinks()[index1];
		m_surfelIsOnObject[surfelNum] = false;
	}

	//decide whether we are confident in the assignemnt
	//i.e. whether the second closest is "far away"
	bool secondClosestFarAway =  closestSqDist[index2] > pow(minDistFromOther,2);
	if(!secondClosestFarAway){
		shouldRemove[surfelNum] = true;
	}
}

std::vector<std::vector<unsigned int> > clusterSurfels(std::vector<unsigned int> surfelIndices,
		std::vector<bool> const& useInClusters)
{
	//cluster the points (using k-means)
	std::cout<<"Performing clustering"<<std::endl;
	unsigned int k = 20;

	if(surfelIndices.size() < k)
		k = surfelIndices.size();
	std::vector<rgbd::eigen::Vector3f> clusterSeeds(k);
	std::vector<std::vector<unsigned int> > clusters(k); //lists contain indices into m_surfels
	std::vector<unsigned int> prevClusterAssignments(surfelIndices.size(),0);
	std::vector<unsigned int> clusterAssignments(surfelIndices.size(),0);
	//initialize cluster seeds to random indices
	std::vector<unsigned int> seedIndices = surfelIndices;
	std::random_shuffle(seedIndices.begin(),seedIndices.end());
	for(unsigned int i=0; i<k; i++)
		clusterSeeds[i] = m_surfels[seedIndices[i]].location;
	//perform the clustering
	bool cont = true;
	int iter = 1;
	while(cont){
//			std::cout<<"Clustering iteration "<<iter<<std::endl;
		cont = false;
		clusters.clear();
		clusters.resize(k);
		//select the closest seed for each point
		for(unsigned int i=0; i<surfelIndices.size(); i++){
			if(!useInClusters[i])
				continue;

			unsigned int closestSeed = 0;
			float closestSqDist = 0;
			//pick the closest seed
			for(unsigned int j=0; j<clusterSeeds.size(); j++){
				float sqDist = (m_surfels[surfelIndices[i]].location -
						clusterSeeds[j]).squaredNorm();
				if(j==0 || sqDist < closestSqDist)
				{
					closestSeed = j;
					closestSqDist = sqDist;
				}
			}
			clusterAssignments[i] = closestSeed;
			clusters[closestSeed].push_back(surfelIndices[i]);
			//see if the cluster assignment has changed
			if(closestSeed != prevClusterAssignments[i])
				cont = true;
		}
		//move the seeds
		for(unsigned int j=0; j<clusterSeeds.size(); j++){
			if(!clusters[j].empty()){
				rgbd::eigen::Vector3f mean = rgbd::eigen::Vector3f::Zero();
				for(unsigned int k=0; k<clusters[j].size(); k++){
					mean+=m_surfels[clusters[j][k]].location;
				}
				clusterSeeds[j] = mean/clusters[j].size();
			}
		}
		prevClusterAssignments = clusterAssignments;
		iter++;
	}

	return clusters;
}

void chooseLinksForNewSurfels(
		SurfelAICP &icp, std::vector<unsigned int> const& newIndices,
		std::vector<bool> & shouldRemove,
		std::vector<std::vector<unsigned int> > const& nearbySurfels,
		std::vector<std::pair<float,float> > const& projections)
{
	if(newIndices.empty())
		return;

	float distForSpecialConsideration = m_linkSpecialDist;
//    	float minDistFromOther = m_linkDistFromSecond;
	float maxDistFromClosest = m_linkDistFromClosest;

	unsigned int numLinks = m_inter.getLinks().size();
	OpenRAVE::KinBody::LinkPtr objLink = m_inter.getLinks()[7];


	std::vector<bool> useInClusters(newIndices.size(),true);
	std::vector<bool> dontUseSurfel = shouldRemove; //surfels not to compare against
	for(unsigned int i=0; i<newIndices.size(); i++)
		dontUseSurfel[newIndices[i]] = true;

	std::vector<std::vector<float> > sqDistsToLinks = this->getSquaredDistancesToLinks(
			icp,newIndices,dontUseSurfel,nearbySurfels,projections);

	//hand removal stage
	if(!m_allowHandUpdate){
		float handRemovalDist = .01;
		for(unsigned int i=0; i<newIndices.size(); i++){
			for(unsigned int j=8; j<numLinks; j++){
				if(sqDistsToLinks[i][j] < handRemovalDist){
					shouldRemove[newIndices[i]] = true;
					useInClusters[i] = false;
					break;
				}
			}
		}
	}

	std::vector<std::vector<unsigned int> > clusters = clusterSurfels(newIndices,useInClusters);

	//perform the assignments
	for(unsigned int i=0; i<clusters.size(); i++){
//    		std::cout<<"Performing assignment for cluster "<<i<<std::endl;
		if(clusters[i].empty())
			continue;

		std::vector<float> closestSqDist = getMinSquaredDistancesToLinks(clusters[i],newIndices,sqDistsToLinks);

		bool specialObjectConsideration = closestSqDist[numLinks] < pow(distForSpecialConsideration,2);


		unsigned int index1=0,index2=0;
//        	std::cout<<"Choosing best 2"<<std::endl;
		float sqDist1=0,sqDist2=0;
		for(unsigned int j=0; j<=numLinks; j++){
			float sqDist = closestSqDist[j];

			if(j == 0 || sqDist < sqDist1){
				index2 = index1;
				sqDist2 = sqDist1;
				index1 = j;
				sqDist1 = sqDist;
			}
			else if(j == 1 || sqDist < sqDist2){
				index2 = j;
				sqDist2 = sqDist;
			}
		}

		//select what to do with the cluster
		bool remove = false;
		unsigned int chosenLink = 0;
		if(closestSqDist[index1] > pow(maxDistFromClosest,2)){
			remove = true;
		}
		else if(specialObjectConsideration){
//        		unsigned int closestNonObject = index1;
//        		if(closestNonObject == numLinks){
//    				closestNonObject = index2;
//        		}
//        		if(closestSqDist[closestNonObject] > pow(minDistFromOther,2))
				chosenLink = numLinks;
//        		else
//        			chosenLink = index1;
		}
		else{
			//pick the closest
			chosenLink = index1;
		}

		//do the assignment
//        	std::cout<<"Performing actual assignment"<<std::endl;
		for(unsigned int j=0; j<clusters[i].size(); j++)
		{
			unsigned int surfelNum = clusters[i][j];
			if(remove){
				shouldRemove[surfelNum] = true;
			}
			else{
				if(chosenLink == numLinks){
					m_surfelLinks[surfelNum] = objLink;
					m_surfelIsOnObject[surfelNum] = true;
				}
				else{
					m_surfelLinks[surfelNum] = m_inter.getLinks()[chosenLink];
					m_surfelIsOnObject[surfelNum] = false;
				}

				//surfel is fine to compare against now
				dontUseSurfel[surfelNum] = false;
			}
		}

	}//end for each cluster


}

void updateSurfels(SurfelAICP &icp,
		std::vector<std::vector<unsigned int> > & nearbySurfels,
		std::vector<std::pair<float,float> > const& projections,
		std::vector<unsigned int> &replaced,
		std::vector<bool> &shouldRemove,
		unsigned int start = 0)
{
	float maxNormalAngle = m_maxNormalAngleForUpdate;
	float corrDistForUpdate = m_surfelUpdateDist;
	unsigned int highConfidence = m_highSurfelConfidence;

	replaced.clear();

	std::vector<std::vector<rgbd::eigen::Vector3f> > pointGrid;
	std::vector<std::vector<rgbd::eigen::Vector3f> > normalGrid;
	std::vector<std::vector<bool> > validityGrid;
	icp.getTargetData(pointGrid,normalGrid,validityGrid);

	std::vector<std::vector<rgbd::eigen::Vector3f> > undownsampledPoints;
	icp.getOrigPointGrid(undownsampledPoints);

	rgbd::eigen::Vector3f viewedFrom = rgbd::eigen::Vector3f::Zero();
	rgbd::eigen::Vector3f lookDir = rgbd::eigen::Vector3f::UnitZ();

	std::cout<<(m_surfels.size()-start)<<" surfels to update"<<std::endl;

	unsigned int hasProjection = 0;
	unsigned int withinDistOfCorr = 0;
	unsigned int observationAdded = 0;
	for(unsigned int i=start; i<m_surfels.size(); i++){
		//skip hand updates
		if(!m_allowHandUpdate && !m_surfelIsOnObject[i] && m_surfelLinks[i]->GetIndex() >= 7)
			continue;

		//skip if it's already scheduled to be removed
		if(shouldRemove[i])
			continue;

		//if the normal is tilted too far away, don't update
		float normalAngle = getAngleNormalToCamera(m_surfels[i],viewedFrom);

		std::pair<float,float> pixel = projections[i];
		rgbd::eigen::Vector3f corrPoint,corrNormal;
		performInterpolation(pixel,pointGrid,normalGrid,validityGrid,corrPoint,corrNormal);
		int x = round(pixel.first);
		int y = round(pixel.second);

		//undo the radius remove that icp used
		bool radiusRemoved = false;
		if(x >= 0 && x <(int)m_camParams.xRes && y >= 0 && y < (int)m_camParams.yRes
				&& corrPoint.z() == 0)
		{
			if(undownsampledPoints[x][y].norm() > m_icpParams.max_radius){
				corrPoint = undownsampledPoints[x][y];
				radiusRemoved = true;
			}
		}

		//make sure there is something to project to
		if(corrPoint.z() > 0){
			rgbd::eigen::Vector3f pixelColor = m_pixelColors[x][y];

			hasProjection++;
			//check its distance to correspondence
			float depthDiff = m_surfels[i].location.z()-corrPoint.z();
			if(fabs(depthDiff) <= corrDistForUpdate){
				withinDistOfCorr++;
				if(normalAngle > maxNormalAngle || radiusRemoved)
					continue;
				//perform the update
				observationAdded++;
				addObservation(m_surfels[i],corrPoint,corrNormal,viewedFrom,lookDir,m_camParams.focalLength);
				addToNearbySurfelMap(m_surfels[i],i,m_camParams,nearbySurfels);

				//update color

				//best viewpoint color update rule
				float newAngle = getAngleNormalToCamera(m_surfels[i],viewedFrom);
				if(newAngle < m_surfelMinAngleFromNormal[i] - 10*M_PI/180){
					m_surfelColors[i] = pixelColor;
					m_surfelMinAngleFromNormal[i] = newAngle;
				}

				//color averaging update rule
//					m_surfelColors[i] = ((m_surfels[i].total_views-1)*m_surfelColors[i]+pixelColor)/m_surfels[i].total_views;


				m_surfelLastSeen[i] = m_processedClouds;
			}
			else if(depthDiff < -1*corrDistForUpdate){
				//saw through the surfel
				//if surfel confidence is low, replace it
				if(m_surfels[i].visibility_confidence < highConfidence){
					if(!radiusRemoved){
						m_surfels[i] = createSurfel(corrPoint,corrNormal,viewedFrom,lookDir,m_camParams.focalLength);
						addToNearbySurfelMap(m_surfels[i],i,m_camParams,nearbySurfels);
						m_surfelColors[i] = pixelColor;
						m_surfelMinAngleFromNormal[i] = getAngleNormalToCamera(m_surfels[i],viewedFrom);
						m_surfelLastSeen[i] = m_processedClouds;
						replaced.push_back(i);
					}
					else{
						shouldRemove[i] = true;
					}
				}
				//else do nothing
			}
			else{
				if(normalAngle > maxNormalAngle || radiusRemoved)
					continue;
				//input scan in front of surfel
				//check for self-occlusion
				bool foundOcclusion = false;
				unsigned int occludingIndex = 0;
				rgbd::eigen::Vector3f intersection;
				if(x >= 0 && x <(int)m_camParams.xRes && y >= 0 && y < (int)m_camParams.yRes){
					int pixelIndex = x + y*m_camParams.xRes;
					for(unsigned int j=0; j<nearbySurfels[pixelIndex].size(); j++){
						//check for occlusion by the nearby surfel
						unsigned int surfelNum = nearbySurfels[pixelIndex][j];
						if(surfelNum==i)
							continue;
						bool occlusion = segmentIntersectsSurfel(rgbd::eigen::Vector3f::Zero(),m_surfels[i].location,
							m_surfels[surfelNum],intersection);
						if(occlusion && fabs(intersection.z()-corrPoint.z()) < corrDistForUpdate){
							foundOcclusion = true;
							occludingIndex = surfelNum;
							break;
						}

					}
				}

				if(foundOcclusion){
					//if histogram says we shoud see the surfel and it's low confidence
					//and the occluding surfel is high confidence, then remove it
					std::pair<unsigned int, unsigned int> histogramIndices =
							getDirectionIndices(m_surfels[i],viewedFrom);
					bool shouldSee = m_surfels[i].
						observed_directions[histogramIndices.first][histogramIndices.second];

					if(shouldSee && m_surfels[i].visibility_confidence < highConfidence
						&& m_surfels[occludingIndex].visibility_confidence >= highConfidence)
					{
						shouldRemove[i] = true;
					}
				}
				else{
					//if no self-occlusion and surfel is low confidence, replace it
					// do we really want this?
//						if(m_surfels[i].visibility_confidence < highConfidence){
//							m_surfels[i] = createSurfel(corrPoint,corrNormal,
//									viewedFrom,lookDir,m_focalLength);
//							m_surfelLastSeen[i] = m_processedClouds;
//							replaced.push_back(i);
//						}
				} //end no occlusion case
			} //end scan in front of surfel case
		} //end correspondence has z > 0
	}

//		std::cout<<hasProjection<<" had a valid projection"<<std::endl;
//		std::cout<<withinDistOfCorr<<" were within acceptable distance of the projection"<<std::endl;
//		std::cout<<observationAdded<<" had an observation added"<<std::endl;
//		std::cout<<replaced.size()<<" were replaced"<<std::endl;

}


void removeSurfels(std::vector<bool> const& shouldRemove,
		unsigned int start = 0)
{
	unsigned int removalTime = m_surfelRemovalTime;
	unsigned int highConfidence = m_highSurfelConfidence;

	//remove any surfel that has not been seen in a while
	//or was marked for removal
	unsigned int totalSurfels = m_surfels.size();
	unsigned int numRemoved = 0;
	for(unsigned int origIndex=start; origIndex<totalSurfels; origIndex++){
		unsigned int newIndex = origIndex-numRemoved;

		bool timeRemove = (m_processedClouds - m_surfelLastSeen[newIndex] > removalTime)
				&& (m_surfels[newIndex].visibility_confidence < highConfidence);
		if(shouldRemove[origIndex] || timeRemove){
			m_surfels.erase(m_surfels.begin()+newIndex);
			m_surfelLinks.erase(m_surfelLinks.begin()+newIndex);
			m_surfelIsOnObject.erase(m_surfelIsOnObject.begin()+newIndex);
			m_surfelLastSeen.erase(m_surfelLastSeen.begin()+newIndex);
			m_surfelColors.erase(m_surfelColors.begin()+newIndex);
			m_surfelMinAngleFromNormal.erase(m_surfelMinAngleFromNormal.begin()+newIndex);
			numRemoved++;
		}
	}
	std::cout<<"Removed "<<numRemoved<<" surfels"<<std::endl;
}


void updateSurfelModel(SurfelAICP &icp){
	std::cout<<"Starting model update"<<std::endl;
	ros::Time start = ros::Time::now();

	//get the new surfels
	std::vector<rgbd::eigen::Vector3f> corrPoints,corrNormals;
	std::vector<float> corrWeights;
	icp.getICPResults(m_surfels,corrPoints,corrNormals,corrWeights);

	rgbd::eigen::Vector3f viewedFrom = rgbd::eigen::Vector3f::Zero();
	rgbd::eigen::Vector3f lookDir = rgbd::eigen::Vector3f::UnitZ();

	//data structures we'll need
	std::vector<std::vector<unsigned int> > nearbySurfels;
	getNearbySurfelMap(m_surfels,m_camParams,nearbySurfels);
	std::vector<rgbd::eigen::Vector3f> surfelLocations(m_surfels.size());
	for(unsigned int i=0; i<m_surfels.size(); i++)
		surfelLocations[i] = m_surfels[i].location;
	std::vector<std::pair<float,float> > projections;
	projectSurfelLocations(surfelLocations,m_camParams,projections);


	//update existing surfels
	std::vector<unsigned int> newIndices;
	std::vector<bool> shouldRemove(m_surfels.size(),false);
	this->updateSurfels(icp,nearbySurfels,projections,newIndices,shouldRemove);



	//add new surfels
	std::vector<std::vector<rgbd::eigen::Vector3f> > pointGrid;
	std::vector<std::vector<rgbd::eigen::Vector3f> > normalGrid;
	std::vector<std::vector<bool> > validityGrid;
	icp.getTargetData(pointGrid,normalGrid,validityGrid);
	unsigned int numAdded = 0;
	for(unsigned int x = 0; x<m_camParams.xRes; x++){
		for(unsigned int y=0; y<m_camParams.yRes; y++){
			if(validityGrid[x][y] && nearbySurfels[x+m_camParams.xRes*y].empty()){
				unsigned int newSurfelNum = m_surfels.size();
				m_surfels.push_back(createSurfel(pointGrid[x][y],
						normalGrid[x][y],viewedFrom,lookDir,m_camParams.focalLength));
				m_surfelColors.push_back(m_pixelColors[x][y]);
				m_surfelMinAngleFromNormal.push_back(getAngleNormalToCamera(m_surfels[newSurfelNum],viewedFrom));
				m_surfelLinks.resize(m_surfelLinks.size()+1);
				m_surfelIsOnObject.resize(m_surfelIsOnObject.size()+1);
				m_surfelLastSeen.push_back(m_processedClouds);
				shouldRemove.push_back(false);
				projections.push_back(std::pair<float,float>(x,y));
				nearbySurfels[x + y*m_camParams.xRes].push_back(newSurfelNum);
				//mark as needing link selected
				newIndices.push_back(newSurfelNum);
				numAdded++;
			}
		}
	}

	//assign links to surfels
	this->chooseLinksForNewSurfels(icp,newIndices,shouldRemove,nearbySurfels,projections);


	//remove surfels marked as shouldRemove or that are too old
	this->removeSurfels(shouldRemove);



//		std::cout<<"transforming updated surfels back to acquisition angles"<<std::endl;
	icp.transformFromFinalToAcquisitionAngles(m_surfels,m_surfelLinks,m_surfelIsOnObject);

	ros::Time end = ros::Time::now();
	ros::Duration dur = end-start;
	std::cout<<"Update took "<<dur.toSec()<<" seconds"<<std::endl;
}



//rgbd::eigen::Vector3f
//OpenRAVEInterface::getNewPointLocation(
//		rgbd::eigen::Vector3f &originalPoint,
//		OpenRAVE::KinBody::LinkPtrparentLink,
//		std::vector<float> &originalAngles,
//		std::vector<float> &newAngles)
//{
//	std::vector<float> cachedAngles = this->getJointAngles();
//
//	this->setJointAngles(originalAngles);
//	RaveTransform<float> oldLinkTransform = parentLink->GetTransform();
//
//	this->setJointAngles(newAngles);
//	RaveTransform<float> newLinkTransform = parentLink->GetTransform();
//
//	//put the joints back where they belong
//	this->setJointAngles(cachedAngles);
//
//	return this->getTransformedPoint(originalPoint,oldLinkTransform,newLinkTransform);
//}

void
OpenRAVEInterface::getNewPointLocations(
		std::vector<std::vector<rgbd::eigen::Vector3f> > const &originalPoints,
		std::vector<std::vector<OpenRAVE::KinBody::LinkPtr> > const &parentLinks,
		std::vector<std::vector<bool> > const &validityMap,
		std::vector<float> const &originalAngles,
		std::vector<float> const &newAngles,
		std::vector<std::vector<rgbd::eigen::Vector3f> > &newPoints,
		bool fromGlobalCoords, bool toGlobalCoords)
{
	std::vector<OpenRAVE::RaveTransform<float> > oldTransformInverses = this->getInverseLinkRaveTransforms(originalAngles);
	std::vector<OpenRAVE::RaveTransform<float> > newTransforms = this->getLinkRaveTransforms(newAngles);

	newPoints.resize(m_camWidth);
	for(int i=0; i<m_camWidth; i++){
		newPoints[i].resize(m_camHeight);
	}

	for(int i=0; i<m_camWidth; i++)
	{
		for(int j=0; j<m_camHeight; j++){
			if(validityMap[i][j])
				newPoints[i][j] = this->getTransformedPoint(originalPoints[i][j],
						oldTransformInverses[parentLinks[i][j]->GetIndex()],
						newTransforms[parentLinks[i][j]->GetIndex()],
						fromGlobalCoords,toGlobalCoords);
		}
	}

}

void
OpenRAVEInterface::getNewPointLocations(
		std::vector<rgbd::eigen::Vector3f> const &validOriginalPoints,
		std::vector<OpenRAVE::KinBody::LinkPtr> const &parentLinks,
		std::vector<float> const &originalAngles,
		std::vector<float> const &newAngles,
		std::vector<rgbd::eigen::Vector3f> &newPoints,
		bool fromGlobalCoords, bool toGlobalCoords)
{
	vector<OpenRAVE::RaveTransform<float> > oldTransformInverses = this->getInverseLinkRaveTransforms(originalAngles);
	vector<OpenRAVE::RaveTransform<float> > newTransforms = this->getLinkRaveTransforms(newAngles);

	newPoints.resize(validOriginalPoints.size());

	//get the new points
	for(unsigned int i=0; i<validOriginalPoints.size(); i++)
	{
		newPoints[i] = this->getTransformedPoint(validOriginalPoints[i],
				oldTransformInverses[parentLinks[i]->GetIndex()],
				newTransforms[parentLinks[i]->GetIndex()],
				fromGlobalCoords,toGlobalCoords);
	}
}

void
OpenRAVEInterface::getNewPointLocations(
		std::vector<rgbd::eigen::Vector3f> const& validOriginalPoints,
		std::vector<unsigned int> const& relevantIndices,
		std::vector<bool> const& transformAtIndex,
		std::vector<OpenRAVE::KinBody::LinkPtr> const &parentLinks,
		std::vector<float> const &originalAngles,
		std::vector<float> const &newAngles,
		std::vector<rgbd::eigen::Vector3f> &newPoints,
		bool fromGlobalCoords, bool toGlobalCoords)
{
	vector<OpenRAVE::RaveTransform<float> > oldTransformInverses = this->getInverseLinkRaveTransforms(originalAngles);
	vector<OpenRAVE::RaveTransform<float> > newTransforms = this->getLinkRaveTransforms(newAngles);

	newPoints.resize(validOriginalPoints.size());

	//get the new points
	for(unsigned int i=0; i<relevantIndices.size(); i++)
	{
		if(!transformAtIndex[i])
			continue;

		unsigned int index = relevantIndices[i];

		if(index < validOriginalPoints.size())
			newPoints[index] = this->getTransformedPoint(validOriginalPoints[index],
					oldTransformInverses[parentLinks[index]->GetIndex()],
					newTransforms[parentLinks[index]->GetIndex()],
					fromGlobalCoords,toGlobalCoords);
	}
}

void
OpenRAVEInterface::getNewNormals(
		std::vector<rgbd::eigen::Vector3f> const &validOriginalNormals,
		std::vector<OpenRAVE::KinBody::LinkPtr> const &parentLinks,
		std::vector<float> const &originalAngles,
		std::vector<float> const &newAngles,
		std::vector<rgbd::eigen::Vector3f> &newNormals,
		bool fromGlobalCoords, bool toGlobalCoords)
{
	vector<OpenRAVE::RaveTransform<float> > oldTransformInverses = this->getInverseLinkRaveTransforms(originalAngles);
	vector<OpenRAVE::RaveTransform<float> > newTransforms = this->getLinkRaveTransforms(newAngles);

	newNormals.resize(validOriginalNormals.size());

	//get the new points
	for(unsigned int i=0; i<validOriginalNormals.size(); i++)
	{
		newNormals[i] = this->getTransformedNormal(validOriginalNormals[i],
				oldTransformInverses[parentLinks[i]->GetIndex()],
				newTransforms[parentLinks[i]->GetIndex()],
				fromGlobalCoords,toGlobalCoords);
	}
}

void
OpenRAVEInterface::getNewNormals(
		std::vector<rgbd::eigen::Vector3f> const &validOriginalNormals,
		std::vector<unsigned int> const& relevantIndices,
		std::vector<bool> const& transformAtIndex,
		std::vector<OpenRAVE::KinBody::LinkPtr> const &parentLinks,
		std::vector<float> const &originalAngles,
		std::vector<float> const &newAngles,
		std::vector<rgbd::eigen::Vector3f> &newNormals,
		bool fromGlobalCoords, bool toGlobalCoords)
{
	vector<OpenRAVE::RaveTransform<float> > oldTransformInverses = this->getInverseLinkRaveTransforms(originalAngles);
	vector<OpenRAVE::RaveTransform<float> > newTransforms = this->getLinkRaveTransforms(newAngles);

	newNormals.resize(validOriginalNormals.size());

	//get the new points
	for(unsigned int i=0; i<relevantIndices.size(); i++)
	{
		if(!transformAtIndex[i])
			continue;

		unsigned int index = relevantIndices[i];

		if(index < validOriginalNormals.size())
			newNormals[index] = this->getTransformedNormal(validOriginalNormals[index],
					oldTransformInverses[parentLinks[index]->GetIndex()],
					newTransforms[parentLinks[index]->GetIndex()],
					fromGlobalCoords,toGlobalCoords);
	}
}

//public:
//	/**
//	 * Returns a 3x9 matrix such that a vectorized 3x3 matrix vec(P) has that
//	 * P*x = Equiv(x)*vec(p). This assumes a column-major order
//	 *
//	 * @param vec
//	 * @return
//	 */
//	rgbd::eigen::Matrix<float,3,9> getEquivalentMatrix(rgbd::eigen::Vector3f &vec){
//		rgbd::eigen::Matrix<float,3,9> toReturn;
//		toReturn<<vec.x(),0,0,vec.y(),0,0,vec.z(),0,0,
//					0,vec.x(),0,0,vec.y(),0,0,vec.z(),0,
//					0,0,vec.x(),0,0,vec.y(),0,0,vec.z();
//		return toReturn;
//	}
//
//	rgbd::eigen::Matrix<float,3,12> getEquivalentMatrix(rgbd::eigen::Vector4f &vec){
//		rgbd::eigen::Matrix<float,3,12> toReturn;
//		toReturn<<vec(0),0,0,vec(1),0,0,vec(2),0,0,vec(3),0,0,
//					0,vec(0),0,0,vec(1),0,0,vec(2),0,0,vec(3),0,
//					0,0,vec(0),0,0,vec(1),0,0,vec(2),0,0,vec(3);
//		return toReturn;
//	}
//
//	/**
//	 * Get a matrix for a vector x such that cross(x,y) = skewSymm(x)*y
//	 *
//	 * @param vec
//	 * @return
//	 */
//	rgbd::eigen::Matrix3f getSkewSymmetric(rgbd::eigen::Vector3f &vec){
//		rgbd::eigen::Matrix3f toReturn;
//		toReturn<<0,-vec.z(),vec.y(),
//					vec.z(),0,-vec.x(),
//					-vec.y(),vec.x(),0;
//		return toReturn;
//	}

//public:
//	void testRayTrace(){
//		OpenRAVE::RaveVector<float> base(0,0,0);
//		OpenRAVE::RaveVector<float> dir(1,0,0);
//		OpenRAVE::RAY ray(base,dir);
//		OpenRAVE::COLLISIONREPORT *rep = new OpenRAVE::COLLISIONREPORT();
//		boost::shared_ptr< OpenRAVE::COLLISIONREPORT > report(rep);
//		m_env->CheckCollision(ray,m_robot,report);
//	}

void
OpenRAVEInterface::transformCloudGlobalToCameraFrame(sensor_msgs::PointCloud &cloud)
{
	RaveTransform<float> cameraTransform = m_env->GetCameraTransform();
	RaveTransform<float> inverse = cameraTransform.inverse();
	for(unsigned int i=0; i<cloud.points.size(); i++){
		RaveVector<float> pt(cloud.points[i].x,cloud.points[i].y,cloud.points[i].z);
		RaveVector<float> newPoint = inverse * pt;
		cloud.points[i].x = newPoint.x;
		cloud.points[i].y = newPoint.y;
		cloud.points[i].z = newPoint.z;
	}
}

void
OpenRAVEInterface::transformGlobalToLinkFrame(sensor_msgs::PointCloud &cloud,
		std::vector<float> const& acquisitionAngles,
		OpenRAVE::KinBody::LinkPtr link)
{
	std::vector<float> cachedAngles = this->getJointAngles();
	this->setJointAngles(acquisitionAngles);
	RaveTransform<float> linkTransform = link->GetTransform();
	this->setJointAngles(cachedAngles);

	RaveTransform<float> inverse = linkTransform.inverse();
	for(unsigned int i=0; i<cloud.points.size(); i++){
		RaveVector<float> pt(cloud.points[i].x,cloud.points[i].y,cloud.points[i].z);
		RaveVector<float> newPoint = inverse * pt;
		cloud.points[i].x = newPoint.x;
		cloud.points[i].y = newPoint.y;
		cloud.points[i].z = newPoint.z;
	}
}

void
OpenRAVEInterface::transformLinkFrameToGlobal(
		std::vector<float> const& jointAngles,
		OpenRAVE::KinBody::LinkPtr link,
		std::vector<rgbd::eigen::Vector3f> const& localPoints,
		std::vector<rgbd::eigen::Vector3f> const& localNormals,
		std::vector<rgbd::eigen::Vector3f> &globalPoints,
		std::vector<rgbd::eigen::Vector3f> &globalNormals)
{


	OpenRAVE::RaveTransform<float> oldTransformInverse,newTransform;
	oldTransformInverse.identity();
	newTransform = this->getLinkRaveTransforms(jointAngles)[link->GetIndex()];

	//resize the data structures
	globalPoints.resize(localPoints.size());
	globalNormals.resize(localNormals.size());

	for(unsigned int i=0; i<localPoints.size(); i++)
	{
		globalPoints[i] = this->getTransformedPoint(localPoints[i],
				oldTransformInverse,newTransform,true,true);
		globalNormals[i] = this->getTransformedNormal(localNormals[i],
				oldTransformInverse,newTransform,true,true);
	}

}

//bool
//OpenRAVEInterface::writeCameraImage(string &baseName, string &extension)
//{
//	string fileName = baseName + "." + extension;
//	return m_env->WriteCameraImage(m_camWidth,m_camHeight,
//			RaveTransform<float>(),m_camIntrinsic,fileName.c_str(),extension.c_str());
//}


/**
 * Helper function which finds the new location of a point given
 * the previous transformation (pose) of the OpenRAVE::KinBody::Link on
 * which it lies and the new one
 *
 * @param oldPointLocation
 * @param oldLinkTransform
 * @param newLinkTransform
 * @param fromGlobalCoords whether the point is in global coordinates (as opposed to camera)
 * @param toGlobalCoords
 * @return newPointLocation
 */
rgbd::eigen::Vector3f getTransformedPoint(rgbd::eigen::Vector3f const &oldPointLocation,
		OpenRAVE::RaveTransform<float> const &inverseOldLinkTransform,
		OpenRAVE::RaveTransform<float> const &newLinkTransform,
		bool fromGlobalCoords, bool toGlobalCoords)
{

	OpenRAVE::RaveVector<float> transformedPoint(oldPointLocation.x(),
			oldPointLocation.y(),oldPointLocation.z());

	if(!fromGlobalCoords){
		transformedPoint = m_rotAdjCamTrans * transformedPoint;
	}

	transformedPoint = newLinkTransform*inverseOldLinkTransform*transformedPoint;

	if(!toGlobalCoords){
		transformedPoint = m_rotAdjCamTransInv * transformedPoint;
	}

	return rgbd::eigen::Vector3f(transformedPoint.x,transformedPoint.y,transformedPoint.z);

}

/**
 * Helper function which finds the new normal of a point given
 * the previous transformation (pose) of the OpenRAVE::KinBody::Link on
 * which it lies and the new one
 *
 * Assumes the transforms passed in are just the rotation parts
 *
 * @param oldNormal
 * @param oldLinkTransform
 * @param newLinkTransform
 * @param fromGlobalCoords
 * @param newGlobalCoords
 * @return newNormal
 */
rgbd::eigen::Vector3f getTransformedNormal(rgbd::eigen::Vector3f const &oldNormal,
		OpenRAVE::RaveTransform<float> const &inverseOldLinkTransform,
		OpenRAVE::RaveTransform<float> const &newLinkTransform,
		bool fromGlobalCoords, bool toGlobalCoords)
{
	OpenRAVE::RaveVector<float> transformedNormal(oldNormal.x(),
			oldNormal.y(),oldNormal.z());

	if(!fromGlobalCoords){
		transformedNormal = m_rotAdjCamTrans.rotate(transformedNormal);
	}

	transformedNormal = newLinkTransform.rotate(inverseOldLinkTransform.rotate(transformedNormal));

	if(!toGlobalCoords){
		transformedNormal = m_rotAdjCamTransInv.rotate(transformedNormal);
	}

	return rgbd::eigen::Vector3f(transformedNormal.x,transformedNormal.y,transformedNormal.z);

}

void
OpenRAVEInterface::generatePointCloud(sensor_msgs::PointCloud &cloud,
			std::vector<rgbd::eigen::Vector3f> &points,
			std::vector<rgbd::eigen::Vector3f> &colors,
			std::vector<rgbd::eigen::Vector3f> &normals)
{
	cloud.header.stamp = ros::Time::now ();
	cloud.header.frame_id = "base_link";
	unsigned int numValid = points.size();

	//set the sizes
	cloud.set_points_size(numValid);
	cloud.set_channels_size(6);

	cloud.channels[0].name = "r";
	cloud.channels[1].name = "g";
	cloud.channels[2].name = "b";
	cloud.channels[3].name = "n_x";
	cloud.channels[4].name = "n_y";
	cloud.channels[5].name = "n_z";

	for(unsigned int i=0; i<6; i++)
		cloud.channels[i].set_values_size(numValid);

	//fill in the points
	for(unsigned int i=0; i<numValid; i++){
		//collision point
		geometry_msgs::Point32 pt;
		pt.x = points[i].x();
		pt.y = points[i].y();
		pt.z = points[i].z();
		cloud.points[i] = pt;

		//color
		cloud.channels[0].values[i] = colors[i].x();
		cloud.channels[1].values[i] = colors[i].y();
		cloud.channels[2].values[i] = colors[i].z();

		//normal
		cloud.channels[3].values[i] = normals[i].x();
		cloud.channels[4].values[i] = normals[i].y();
		cloud.channels[5].values[i] = normals[i].z();
	}
}

vector<OpenRAVE::RaveTransform<float> >
OpenRAVEInterface::getLinkRaveTransforms(
		std::vector<float> const& angles)
{
	unsigned int numLinks = m_robot->GetLinks().size();
	vector<OpenRAVE::RaveTransform<float> > toReturn(numLinks);

	std::vector<float> cachedAngles = this->getJointAngles();
	this->setJointAngles(angles);

	for(unsigned int i=0; i<numLinks; i++)
		toReturn[i] = this->getLinks()[i]->GetTransform();

	//reset the angles
	this->setJointAngles(cachedAngles);

	return toReturn;
}

vector<OpenRAVE::RaveTransform<float> >
OpenRAVEInterface::getInverseLinkRaveTransforms(
		std::vector<float> const& angles)
{
	unsigned int numLinks = m_robot->GetLinks().size();
	vector<OpenRAVE::RaveTransform<float> > toReturn(numLinks);

	std::vector<float> cachedAngles = this->getJointAngles();
	this->setJointAngles(angles);

	for(unsigned int i=0; i<numLinks; i++)
		toReturn[i] = this->getLinks()[i]->GetTransform().inverse();

	//reset the angles
	this->setJointAngles(cachedAngles);

	return toReturn;
}
