/*
 * viewICPLocalizationOutputViewer: display a map and a sequence of query-frame-plus-transform pairs aligned to it
 *
 * Evan Herbst
 * 3 / 1 / 10
 */

#include <unordered_map>
#include <iostream>
#include <boost/filesystem/path.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/format.hpp>
#include <QtGui/QApplication>
#include "point_cloud_icp/xforms.h"
#include "point_cloud_icp/mapping/mathUtils.h" //MAX()
#include "rgbd_datatypes/cloudTofroPLY.h"
#include "point_cloud_icp/mapping/cloudViewingUtils.h" //box3d, centroid()
#include "point_cloud_icp/mapping/icpLocalizationOutputViewer.h"
using std::vector;
using std::unordered_map;
using std::string;
using std::cout;
using std::endl;
using boost::lexical_cast;
namespace fs = boost::filesystem;
using namespace Eigen;

class ptcloudReader
{
	public:

		ptcloudReader(const boost::format& filepaths) : filepathFmt(filepaths)
		{}

		void operator () (const unsigned int queryID, PointCloud& cloud)
		{
			const string filepath = (filepathFmt % queryID).str();
			rgbd::read_ply_file(cloud, filepath);
		}

	private:

		boost::format filepathFmt;
};

template <typename T>
class mapIndexFunctor
{
	public:

		mapIndexFunctor(unordered_map<unsigned int, T>& m) : v(m)
		{}

		T operator () (const unsigned int queryID) {return v[queryID];}

	private:

		unordered_map<unsigned int, T>& v;
};

/*
 * arguments: map PLY filepath, query PLY filepath boost.format str (params: id), min query id, max query id, query xform-list filepath
 */
int main(int argc, char* argv[])
{
	assert(argc == 6);
	unsigned int _ = 1; //index argv
	const fs::path mapPLYFilepath(argv[_++]);
	boost::format queryPLYFilepaths(argv[_++]);
	const unsigned int minQueryID = lexical_cast<unsigned int>(argv[_++]), maxQueryID = lexical_cast<unsigned int>(argv[_++]);
	const fs::path queryXformlistFilepath(argv[_++]);

	PointCloud mapCloud;
	rgbd::read_ply_file(mapCloud, mapPLYFilepath.string());
	Transform3f mapXform; mapXform.setIdentity();

	unordered_map<unsigned int, Transform3f> queryXformMap; //index them on query id
	const vector<std::pair<ros::Time, geometry_msgs::Transform>> queryXforms = std::move(xf::readTransformsFromFile(queryXformlistFilepath.string()));
	for(auto i = queryXforms.begin(); i != queryXforms.end(); i++) cout << (*i).first << ' ' << (*i).second << endl;
	for(unsigned int i = minQueryID, i0 = 0; i <= maxQueryID; i++, i0++)
	{
		Transform3f tf;
		xf::convert_geometry_msg_to_eigen_transform(queryXforms[i0].second, tf);
		queryXformMap[i] = tf;
	}

	QApplication app(argc, argv);
	icpLocalizationOutputViewer gui(NULL, mapCloud, mapXform, ptcloudReader(queryPLYFilepaths), mapIndexFunctor<Transform3f>(queryXformMap), minQueryID, maxQueryID);
	const box3d mapBbox = bounds(mapCloud);
	const vec3d lookat = centroid(mapCloud), eye = lookat + vec3d(0, 0, MAX(MAX(mapBbox.range(0), mapBbox.range(1)), mapBbox.range(2))), up(0, 1, 0);
	gui.setLookAt(eye, lookat, up);

	gui.show();
	app.exec();
	return 0;
}
