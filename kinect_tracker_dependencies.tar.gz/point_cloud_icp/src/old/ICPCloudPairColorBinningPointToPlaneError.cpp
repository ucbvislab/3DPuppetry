/*
 * ICPCloudPairColorBinningPointToPlaneError: point-to-plane error metric disallowing matches between dissimilar colors
 *
 * Evan Herbst
 * 3 / 23 / 10
 */

#include "point_cloud_icp/registration/icpPoint2Plane.h"
#include "point_cloud_icp/registration/ICPCloudPairColorBinningPointToPlaneError.h"

namespace registration
{

ICPCloudPairColorBinningPointToPlaneError::ICPCloudPairColorBinningPointToPlaneError(ICPCloudPairParams const& params,
		sensor_msgs::PointCloud const& source_pointcloud, sensor_msgs::PointCloud const& target_pointcloud, std::vector<float> const& point_weights)
: ICPCloudPairColorBinning(params, source_pointcloud, target_pointcloud), ICPCloudPairPointToPlaneError(params, source_pointcloud, target_pointcloud),
  ICPCloudPairScalarWeights(params, source_pointcloud, target_pointcloud, point_weights)
{
}

boost::tuple<bool, bool> ICPCloudPairColorBinningPointToPlaneError::getNeedSourceTargetNormals() const
{
	boost::tuple<bool, bool> nn = ICPCloudPairColorBinning::getNeedSourceTargetNormals();
	boost::get<1>(nn) = true;
	return nn;
}

void ICPCloudPairColorBinningPointToPlaneError::getSourceErrorVector(rgbd::eigen::Transform3f const& transform,
		std::vector<int> const& correspondence_indices, std::vector<float> & result) const
{
	icp::point2plane::getSourceErrorVector(m_source_eigen_points, m_target_eigen_normals, m_point_weights, transform, correspondence_indices, result);
}

void ICPCloudPairColorBinningPointToPlaneError::getTargetErrorVector(std::vector<int> const& correspondence_indices, std::vector<float> & result) const
{
	icp::point2plane::getTargetErrorVector(m_target_eigen_points, m_target_eigen_normals, m_point_weights, correspondence_indices, result);
}

} //namespace
