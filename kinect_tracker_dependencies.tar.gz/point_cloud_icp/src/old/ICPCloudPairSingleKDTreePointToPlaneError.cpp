/*
 * ICPCloudPairPointToPlaneError: point-to-plane error metric using only 3-d position info
 *
 * Evan Herbst
 * 3 / 21 / 10
 */

#include "point_cloud_icp/registration/icpPoint2Plane.h"
#include "point_cloud_icp/registration/ICPCloudPairPointToPlaneError.h"

namespace registration
{

ICPCloudPairPointToPlaneError::ICPCloudPairPointToPlaneError(ICPCloudPairParams const& params,
		sensor_msgs::PointCloud const& source_pointcloud,
		sensor_msgs::PointCloud const& target_pointcloud,
		std::vector<float> const& point_weights,
		const bool xyzWeights)
: ICPCloudPairSingleKDTree(params, source_pointcloud, target_pointcloud, point_weights), separateXYZWeights(xyzWeights)
{
}

ICPCloudPairPointToPlaneError::ICPCloudPairPointToPlaneError(const ICPCloudPairParams& params,
			const sensor_msgs::PointCloud& sourceCloud,
			const sensor_msgs::PointCloud& targetCloud,
			boost::shared_ptr<kdtree2> targetKDTree,
			const std::vector<float>& pointWeights,
			const bool xyzWeights)
: ICPCloudPairSingleKDTree(params, sourceCloud, targetCloud, targetKDTree, pointWeights), separateXYZWeights(xyzWeights)
{
}

boost::tuple<bool, bool> ICPCloudPairPointToPlaneError::getNeedSourceTargetNormals() const
{
	boost::tuple<bool, bool> nn = ICPCloudPairPointsOnly::getNeedSourceTargetNormals();
	boost::get<1>(nn) = true;
	return nn;
}

void ICPCloudPairPointToPlaneError::getSourceErrorVector(rgbd::eigen::Transform3f const& transform, std::vector<int> const& correspondence_indices, std::vector<float> & result) const
{
	if(separateXYZWeights)
		icp::point2plane::getSourceErrorVector(m_source_eigen_points, m_target_eigen_normals, m_xyz_weights, transform, correspondence_indices, result);
	else
	{
		if (m_params.use_fastpointlib) {
			icp::point2plane::getSourceErrorVectorFPL(m_source_fpl_points, m_source_fpl_points_temp, m_target_eigen_normals, m_point_weights, transform, correspondence_indices, result);
		}
		else {
			icp::point2plane::getSourceErrorVector(m_source_eigen_points, m_target_eigen_normals, m_point_weights, transform, correspondence_indices, result);
		}
	}
}

void ICPCloudPairPointToPlaneError::getTargetErrorVector(std::vector<int> const& correspondence_indices, std::vector<float> & result) const
{
	if(separateXYZWeights)
		icp::point2plane::getTargetErrorVector(m_target_eigen_points, m_target_eigen_normals, m_xyz_weights, correspondence_indices, result);
	else
		icp::point2plane::getTargetErrorVector(m_target_eigen_points, m_target_eigen_normals, m_point_weights, correspondence_indices, result);
}

} //namespace
