/*
 * JointAngleICP.cpp
 *
 *  Created on: Jul 29, 2009
 *      Author: mkrainin
 */

#include <point_cloud_icp/registration/JointAngleICP.h>
//#include <point_cloud_icp/lm/minlm.h>
#include <point_cloud_mapping/geometry/nearest.h>
#include <point_cloud_icp/registration/icp_utility.h>
#include "geometry_msgs/PointStamped.h"
#include "rgbd_util/eigen/LU"
#include "rgbd_util/eigen/QR"
#include <float.h>
using namespace Eigen;

#include <opencv/cv.h>
#include <opencv/highgui.h>

//#include <lm.h>

namespace registration{

	JointAngleICP::JointAngleICP(
			OpenRAVEInterface *interface,
			const sensor_msgs::PointCloud &targetCloud,
			bool globalCoords)
	:m_targetTree(targetCloud)
	{
		//TODO: fix issues with non-global coords
		assert(globalCoords);

		m_interface = interface;
		m_targetCloud = targetCloud;
		m_useGlobalCoords = globalCoords;

		this->initializeVariables();
	}

	JointAngleICP::~JointAngleICP()
	{
		delete m_targetTreeExtended;
	}

	void JointAngleICP::initializeVariables()
	{
		m_numAngles = m_interface->getJointAngles().size();
		m_initialAngles = std::vector<float>(m_numAngles,0);
		m_currentDOF = s_jointHierarchyBreakpoints[0]+1;
		m_currentDOFStage = 0;
		m_lastDOFIncrease = 1;

		m_targetNormalsSet = false;

		m_objectPointsSet = false;
		m_fixedCorrsSet = false;

		m_usePriors = false;
		m_allowCalibAdjustment = false;
		m_allowObjectAdjustment = false;

		rgbd::eigen::Transform3f identity;
		identity.setIdentity();
		m_calibAdjustment = convertTransformToVector(identity);
		m_objectAdjustment = convertTransformToVector(identity);


		m_targetPoints = std::vector<Vector3f>(m_targetCloud.points.size());
		for(unsigned int i=0; i<m_targetCloud.points.size(); i++){
			m_targetPoints[i] = Vector3f(m_targetCloud.points[i].x,
					m_targetCloud.points[i].y,m_targetCloud.points[i].z);
		}

		m_toRegisterLoaded = false;

		//assume all links exist initially unless the setter is used
		m_linkExistsInTarget = std::vector<bool>(16,true);


		//create the extended tree; x,y,z,nx,ny,nz
		this->generateNormals();
		unsigned int length = 6;
		cv::Mat targetMat(m_targetPoints.size(), length, CV_32F);
		float* targetPtr = targetMat.ptr<float>(0);
	    for(unsigned int i = 0; i < m_targetPoints.size(); i++ )
	    {
	    	float extendedPt[length];
	    	extendedPt[0] = m_targetPoints[i].x();
	    	extendedPt[1] = m_targetPoints[i].y();
	    	extendedPt[2] = m_targetPoints[i].z();
	    	extendedPt[3] = m_params.normals_weight*m_targetNormals[i].x();
	    	extendedPt[4] = m_params.normals_weight*m_targetNormals[i].y();
	    	extendedPt[5] = m_params.normals_weight*m_targetNormals[i].z();
	        memcpy(targetPtr, extendedPt, length*sizeof(float));
	        targetPtr += length;
	    }
	    m_targetTreeExtended =  new cv::flann::Index(targetMat, cv::flann::AutotunedIndexParams(-1));//KDTreeIndexParams(4));

	}

	void JointAngleICP::reset()
	{
		m_currentDOF = s_jointHierarchyBreakpoints[0]+1;
		m_currentDOFStage = 0;
		m_lastDOFIncrease = 1;
	}

//	rgbd::eigen::MatrixXf
//	JointAngleICP::getCovarianceMatrix(std::vector<float> angles)
//	{
//		std::vector<unsigned int> correspondenceIndices; //ordered by m_toRegisterIndices
//		std::vector<bool> useCorrespondence;
//		this->getCorrespondenceIndices(angles,correspondenceIndices,useCorrespondence);
//		float SSE = this->getError(angles,correspondenceIndices,useCorrespondence);
//
//		//anything false in useCorrespondence
//		float scaleFactor = SSE/(m_toRegisterIndices.size()-angles.size());
//
//		rgbd::eigen::MatrixXf jacobian = this->getJacobianMatrix(angles);
//
//		return scaleFactor * (jacobian.transpose() * jacobian).inverse();
//	}

	std::vector<float>
	JointAngleICP::getInitialAngles(){
		return m_initialAngles;
	}

	void
	JointAngleICP::getPointsToRegister(std::vector<rgbd::eigen::Vector3f> &toRegister,
			std::vector<OpenRAVE::KinBody::LinkPtr > &links,
			std::vector<rgbd::eigen::Vector3f> &normals,
			std::vector<float> &acquisitionAngles)
	{
		acquisitionAngles = m_acquisitionAngles;

		unsigned int numToRegister = m_toRegisterIndices.size();
		toRegister.resize(numToRegister);
		links.resize(numToRegister);
		normals.resize(numToRegister);

		for(unsigned int i=0; i<numToRegister; i++){
			toRegister[i] = m_toRegister[m_toRegisterIndices[i]];
			links[i] = m_links[m_toRegisterIndices[i]];
			normals[i] = m_toRegisterNormals[m_toRegisterIndices[i]];
		}
	}

	void
	JointAngleICP::setJointAnglePriors(
			rgbd::eigen::VectorXf const& angles,
			rgbd::eigen::MatrixXf const& covariance,
			float priorStrength)
	{
		m_anglePriorMean = angles;
		m_anglePriorCovarianceInverse = covariance.inverse();
		m_usePriors = true;
		m_priorStrength = priorStrength;
	}

	void
	JointAngleICP::setInitialAngles(const std::vector<float> &angles)
	{
		m_initialAngles = angles;
	}

	void
	JointAngleICP::setRayTracedScan(const std::vector<rgbd::eigen::Vector3f> &toRegister,
			const std::vector<OpenRAVE::KinBody::LinkPtr > &links,
			const std::vector<rgbd::eigen::Vector3f> &normals,
			const std::vector<float> &acquisitionAngles)
	{
		m_toRegister = toRegister;
		m_links = links;
		m_toRegisterNormals = normals;
		m_acquisitionAngles = acquisitionAngles;

		//set m_toRegisterIndices
		m_toRegisterIndices.resize(m_toRegister.size());
		for(unsigned int i=0; i<m_toRegister.size(); i++){
			m_toRegisterIndices[i] = i;
		}

		m_toRegisterLoaded = true;
	}

	void
	JointAngleICP::
	setFixedCorrespondences(
			std::vector<rgbd::eigen::Vector3f> const& modelPoints,
			std::vector<rgbd::eigen::Vector3f> const& modelNormals,
			std::vector<OpenRAVE::KinBody::LinkPtr> const& links,
			std::vector<bool> const& linkIsObject,
			std::vector<rgbd::eigen::Vector3f> const& targetPoints,
			std::vector<rgbd::eigen::Vector3f> const& targetNormals)
	{
		assert(m_toRegisterLoaded && !m_fixedCorrsSet);

		if(!m_targetNormalsSet)
			this->generateNormals();

		m_fixedPtLocalCoords = modelPoints;
		m_fixedPtLocalNormals = modelNormals;
		m_fixedPtIsObject = linkIsObject;

		unsigned int origPtsSize = m_toRegister.size();
		unsigned int origTargetPtsSize = m_targetPoints.size();
		unsigned int origIndicesSize = m_toRegisterIndices.size();
		unsigned int numToAdd = modelPoints.size();

		m_fixedCorrsSet = true;
		m_fixedPointsStart = origPtsSize;
		m_fixedPointsEnd = origPtsSize+numToAdd;

		m_toRegister.resize(origPtsSize+numToAdd);
		m_toRegisterNormals.resize(origPtsSize+numToAdd);
		m_toRegisterIndices.resize(origIndicesSize+numToAdd);
		m_links.resize(origPtsSize+numToAdd);
		m_targetPoints.resize(origTargetPtsSize+numToAdd);
		m_targetNormals.resize(origTargetPtsSize+numToAdd);
		m_fixedCorrs.resize(numToAdd);

		std::deque<rgbd::eigen::Transform3f,rgbd::eigen::aligned_allocator<rgbd::eigen::Transform3f> >
			linkTransforms = m_interface->getLinkTransforms(m_acquisitionAngles);

		OpenRAVE::KinBody::LinkPtr palmLink = m_interface->getLinks()[7];

		//add into the dataset for the model
		for(unsigned int i=0; i<numToAdd; i++){
			rgbd::eigen::Transform3f toApply;
			if(linkIsObject[i]){
				toApply = linkTransforms[7];
				m_links[i+origPtsSize] = palmLink;
			}
			else{
				toApply = linkTransforms[links[i]->GetIndex()];
				m_links[i+origPtsSize] = links[i];
			}

			m_toRegister[i+origPtsSize] = toApply * modelPoints[i];
			m_toRegisterNormals[i+origPtsSize] = toApply.linear() * modelNormals[i];
			m_toRegisterIndices[i+origIndicesSize] = i+origPtsSize;

			//add new target points. note that these are not added to the
			//cloud or the kd-tree, so they won't be otherwise matched against
			m_targetPoints[i+origTargetPtsSize] = targetPoints[i];
			m_targetNormals[i+origTargetPtsSize] = targetNormals[i];

			//add the correspondences
			m_fixedCorrs[i] = i+origTargetPtsSize;
		}
	}

	void
	JointAngleICP::
	setGraspedObjectToRegister(
			sensor_msgs::PointCloud const& objectCloud,
			std::vector<rgbd::eigen::Vector3f> const& objectNormals)
	{
		assert(m_toRegisterLoaded && !m_objectPointsSet);

		m_objectCloud = objectCloud;
		m_objectNormals = objectNormals;

		//all object points are assumed rigidly attached to wam7
		OpenRAVE::KinBody::LinkPtr link = m_interface->getLinks()[7];

		unsigned int objectPtsSize = m_objectCloud.points.size();
		unsigned int origPtsSize = m_toRegister.size();
		unsigned int origIndicesSize = m_toRegisterIndices.size();
		unsigned int numToAdd = objectPtsSize;

		m_objectPointsSet = true;
		m_objectPointsStart = origPtsSize;
		m_objectPointsEnd = origPtsSize+numToAdd;

		m_toRegister.resize(origPtsSize+numToAdd);
		m_toRegisterNormals.resize(origPtsSize+numToAdd);
		m_toRegisterIndices.resize(origIndicesSize+numToAdd);
		m_links.resize(origPtsSize+numToAdd,link);

		//extract points
		std::vector<rgbd::eigen::Vector3f> localPoints(numToAdd);
		for(unsigned int i=0; i<numToAdd; i++){
			localPoints[i] = Vector3f(m_objectCloud.points[i].x,
					m_objectCloud.points[i].y,m_objectCloud.points[i].z);
		}
		m_objectPoints = localPoints;

		//transform to the acquisition coordinates
		std::vector<rgbd::eigen::Vector3f> globalPoints(objectPtsSize);
		std::vector<rgbd::eigen::Vector3f> globalNormals(objectPtsSize);
		m_interface->transformLinkFrameToGlobal(m_acquisitionAngles,link,
				localPoints,objectNormals,globalPoints,globalNormals);

		//add into the dataset
		for(unsigned int i=0; i<objectPtsSize; i++){
			m_toRegister[i+origPtsSize] = globalPoints[i];
			m_toRegisterNormals[i+origPtsSize] = globalNormals[i];
			m_toRegisterIndices[i+origIndicesSize] = i+origPtsSize;
		}
	}

	void JointAngleICP::setObjectAdjustmentDisabled()
	{
		m_allowObjectAdjustment = false;
	}

	void JointAngleICP::setObjectAdjustmentEnabled(
			rgbd::eigen::Transform3f const& correctionTransform,
			rgbd::eigen::Matrix<float,7,7> correctionCovariance)
	{
		assert(m_usePriors);

		m_allowObjectAdjustment = true;
		m_objectAdjustment = convertTransformToVector(correctionTransform);
		m_objectCovarianceInverse = correctionCovariance.inverse();
	}

	std::vector<float>
	JointAngleICP::runICP()
	{
		float interpolationRate = m_params.interpolation_rate;

		ros::Time startTime = ros::Time::now();

		//make sure we have points to register
		if(!m_toRegisterLoaded)
			this->captureRayTracedScan(m_initialAngles);

		if(!m_targetNormalsSet)
			this->generateNormals();

		std::vector<float> initState = constructStateFromVectors(m_initialAngles,
				m_calibAdjustment,m_objectAdjustment);

	    m_stateHistory.clear();
	    m_stateHistory.push_front(initState);
		std::deque<float> errorHistory;

		std::vector<float> prevState = initState;
		std::vector<float> newState = initState;
		m_initialState = initState;

		std::vector<unsigned int> correspondenceIndices; //ordered by m_toRegisterIndices
		std::vector<bool> useCorrespondence;
		std::vector<float> correspondenceWeights;

		m_round = 1;
		std::cout<<"Starting Articulated ICP"<<std::endl;

		//calculate the initial correspondences
		getCorrespondenceIndices(newState,correspondenceIndices,
				useCorrespondence,correspondenceWeights);

		bool cont;
		unsigned int prevDOF;

		do{
//			rgbd::eigen::VectorXf numericGradient = this->getErrorGradientNumeric(prevState,
//					correspondenceIndices,useCorrespondence,correspondenceWeights);
//			rgbd::eigen::VectorXf analyticGradient = this->getErrorGradient(prevState,
//					correspondenceIndices,useCorrespondence,correspondenceWeights);
//			std::cout<<"Numeric Gradient, Analytic Gradient"<<std::endl;
//			for(unsigned int i=0; i<numericGradient.size(); i++){
//				std::cout<<numericGradient(i)<<", "<<analyticGradient(i)<<std::endl;
//			}

			std::vector<float> icpState;

			//get the new angles via non-linear optimizer
			icpState = runLBFGSAlignment(prevState,correspondenceIndices,
					useCorrespondence,correspondenceWeights);

			for(unsigned int angle=0; angle<icpState.size(); angle++){
				newState[angle] = interpolationRate*icpState[angle] +
						(1.0-interpolationRate)*prevState[angle];
			}

			//calculate the new correspondences based on the new transform
			getCorrespondenceIndices(newState,correspondenceIndices,
					useCorrespondence,correspondenceWeights);

			//store the transform as well as the error with the _new_ correspondences
			m_stateHistory.push_front(newState);
			errorHistory.push_front(getError(newState,correspondenceIndices,
					useCorrespondence,correspondenceWeights));

			std::cout<<"***** Error for round "<<m_round<<" is "<<errorHistory[0]
			         <<" *****"<<std::endl;
			m_round++;

			cont = shouldContinue(prevState,newState,
					correspondenceIndices,useCorrespondence,correspondenceWeights);

			prevDOF = m_currentDOF;
			prevState = newState;

		}while(cont || prevDOF != getCurrentAdjustableDOF(newState,!cont));

		ros::Time endTime = ros::Time::now();
		ros::Duration dur = endTime-startTime;
		std::cout<<"Articulated ICP completed in "<<dur.toSec()<<" seconds"<<std::endl;

		return newState;
	}

	void
	JointAngleICP::captureRayTracedScan(std::vector<float> &jointAngles)
	{
		std::cout<<"Capturing Ray-Traced Scan from within ICP"<<std::endl;
		unsigned int pixelIncrement = m_params.ray_tracing_pixel_increment;

		m_interface->setJointAngles(jointAngles);
		m_acquisitionAngles = jointAngles;

		//get a point cloud
		std::vector<std::vector<rgbd::eigen::Vector3f> > points;
		std::vector<std::vector<rgbd::eigen::Vector3f> > colors;
		std::vector<std::vector<OpenRAVE::KinBody::LinkPtr > > links;
		std::vector<std::vector<bool> > validity;
		std::vector<std::vector<rgbd::eigen::Vector3f> > normals;
		m_interface->sample3dPoints(points,colors,links,normals,validity,
				m_useGlobalCoords,pixelIncrement);

		//convert to 1D structures rather than sparse 2D
		std::vector<rgbd::eigen::Vector3f> validColors;
		m_interface->convertTo1DVectors(points,m_toRegister,colors,validColors,
				normals,m_toRegisterNormals,links,m_links,validity);

		//set m_toRegisterIndices
		m_toRegisterIndices.resize(m_toRegister.size());
		for(unsigned int i=0; i<m_toRegister.size(); i++){
			m_toRegisterIndices[i] = i;
		}

		m_toRegisterLoaded = true;
	}

	void
	JointAngleICP::checkForFingers(std::vector<float> const &state)
	{
		float minRatioInRange = m_params.min_finger_point_ratio;
		float maxRange = m_params.max_finger_point_dist;

		//TODO: parameters
		bool allowSingleLinkDisabling = true;
		bool allowSingleLinkEnabling = true;

		//set up counters to track how many finger points have good
		//correspondences
		unsigned int inRangeCount[8];
		unsigned int outOfRangeCount[8];
		for(unsigned int i=0; i<8; i++){
			inRangeCount[i] = 0;
			outOfRangeCount[i] = 0;
		}

		std::vector<rgbd::eigen::Vector3f> newPoints;
		this->getNewPointLocations(state,newPoints);

		for(unsigned int i=0; i<m_toRegisterIndices.size(); i++){
			//get the transformed point
			unsigned int index = m_toRegisterIndices[i];
			int linkIndex = m_links[index]->GetIndex();

			//we only care about points on the hand
			if(linkIndex<8){
				continue;
			}

			Vector3f vec = newPoints[index];

			//convert to Point32 format
			geometry_msgs::Point32 pt;
			pt.x = vec.x();
			pt.y = vec.y();
			pt.z = vec.z();

			//get the k=1 nearest neighbors
			std::vector<int> k_indices;
			std::vector<float> k_distances;
			m_targetTree.nearestKSearch(pt,1,k_indices,k_distances);
			float dist = sqrt(k_distances[0]);

			//see if the correspondence is within acceptable range
			if(dist <= maxRange){
				inRangeCount[linkIndex-8]++;
			}
			else{
				outOfRangeCount[linkIndex-8]++;
			}
		}


		//check each finger
		for(unsigned int angle=7; angle<10; angle++){
			unsigned int inRange=0;
			unsigned int outOfRange=0;

			//add in totals for each link pertaining to the finger
			for(unsigned int link=0; link<8; link++){
				if(m_interface->isAffected(link+8,angle)){
					inRange+=inRangeCount[link];
					outOfRange+=outOfRangeCount[link];
				}
			}

			bool useFinger = (inRange > 0 && ((double)inRange/(inRange+outOfRange) >= minRatioInRange));

			std::cout<<"Point in range "<<maxRange<<" for angle "<<angle<<": "<<inRange<<std::endl;
			std::cout<<"Point out of range "<<maxRange<<" for angle "<<angle<<": "<<outOfRange<<std::endl;

			//disable the use of all links in the finger
			if(!useFinger){
				std::cout<<"Disabling finger "<<angle<<std::endl;
				for(unsigned int link=0; link<8; link++){
					if(m_interface->isAffected(link+8,angle)){
						m_linkExistsInTarget[link+8] = false;
					}
				}
			}
		}


		if(allowSingleLinkDisabling || allowSingleLinkEnabling){
			//compare inRange,outofRange to minRatio. set flags appropriately
			for(unsigned int i=0; i<8; i++){
				//ignore any link for which the ray traced scan has no points
				if(inRangeCount[i] == 0 && outOfRangeCount[i] == 0){
					if(allowSingleLinkDisabling)
						m_linkExistsInTarget[i+8] = false;
				}
				else{
					bool enoughPoints = ((double)inRangeCount[i]/(inRangeCount[i]+outOfRangeCount[i]) >= minRatioInRange);

					if(!enoughPoints && allowSingleLinkDisabling)
						m_linkExistsInTarget[i+8] = false;
					if(enoughPoints && allowSingleLinkEnabling)
						m_linkExistsInTarget[i+8] = true;
				}
			}
		}
	}

	void
	JointAngleICP::generateNormals()
	{
		m_targetNormals = std::vector<Vector3f>(m_targetPoints.size());

		bool hasNormals = pointCloudNormalsToEigenNormals(m_targetCloud,m_targetNormals);

		if(!hasNormals){
			int k=m_params.normals_k;
			geometry_msgs::PointStamped pointStamped;
			pointStamped.header.frame_id = "frame";
			// Set the viewpoint in the laser coordinate system to 0, 0, 0
			pointStamped.point.x = pointStamped.point.y = pointStamped.point.z = 0.0;
			int origDimsTarget = m_targetCloud.channels.size();
			cloud_geometry::nearest::computePointCloudNormals(m_targetCloud,k,pointStamped);

			//convert target points to Vector
			for(unsigned int i=0; i<m_targetPoints.size(); i++){
				m_targetNormals[i] = Vector3f(
						m_targetCloud.channels[origDimsTarget+0].values[i],
						m_targetCloud.channels[origDimsTarget+1].values[i],
						m_targetCloud.channels[origDimsTarget+2].values[i]);
			}
		}
		else{
			std::cout<<"Normals already existed"<<std::endl;
		}

		m_targetNormalsSet = true;
	}

	std::vector<bool>
	JointAngleICP::getAnglesRegistered()
	{
		std::vector<bool> anglesRegistered(11,false);
		for(unsigned int i=0; i<this->getCurrentAdjustableDOF(m_initialAngles); i++){
			int angle = s_jointHierarchyOrder[i];

			//if the angle was adjustable, the it was set as long as it had
			//a link below it that was considered valid
			anglesRegistered[angle] = false;
			for(unsigned int linkIndex = 0; linkIndex < 16; linkIndex++){
				if(m_interface->isAffected(linkIndex,angle) && m_linkExistsInTarget[linkIndex]){
					anglesRegistered[angle] = true;
					break;
				}
			}

//			std::cout<<"Angle "<<angle<<" registered? "<<anglesRegistered[angle]<<std::endl;
		}
		return anglesRegistered;
	}

	void
	JointAngleICP::getCorrespondenceIndices(
			std::vector<float> const& state,
			std::vector<unsigned int> &correspondenceIndices,
			std::vector<bool> &useCorrespondence,
			std::vector<float> & correspondenceWeights)
	{
		double max_distance = m_params.max_distance;

		bool useExtendedTree = (m_params.normals_weight > 0);


		//TODO: use normals like in surfel icp to decide whether to find
		//correspondences for the point. (i.e. if the normal is pointing away,
		//the camera won't have a corresponding point for it)


//		//TODO: parameter
//		if(m_round == 1){
//			max_distance = .04;
//		}

		std::vector<rgbd::eigen::Vector3f> newPoints,newNormals;
		this->getNewPointLocations(state,newPoints);
		this->getNewNormals(state,newNormals);

		correspondenceIndices.resize(m_toRegisterIndices.size());
		useCorrespondence.resize(m_toRegisterIndices.size());
		correspondenceWeights.resize(m_toRegisterIndices.size());

		std::vector<float> distanceOfCorrespondence(m_toRegisterIndices.size());

		if(!useExtendedTree){
			for(unsigned int i=0; i<m_toRegisterIndices.size(); i++){
				//get the transformed point
				unsigned int index = m_toRegisterIndices[i];

				//check if it has a preset correspondence
				if(m_fixedCorrsSet && (index >= m_fixedPointsStart) &&
						(index < m_fixedPointsEnd ))
				{
					distanceOfCorrespondence[i] = 0;
					correspondenceIndices[i] = m_fixedCorrs[index-m_fixedPointsStart];
					correspondenceWeights[i] = m_params.fixed_corr_weight;
				}
				//if not, find the closest point
				else{
					Vector3f vec = newPoints[index];

					//convert to Point32 format
					geometry_msgs::Point32 pt;
					pt.x = vec.x();
					pt.y = vec.y();
					pt.z = vec.z();

					//get the k=1 nearest neighbors
					std::vector<int> k_indices;
					std::vector<float> k_distances;
					m_targetTree.nearestKSearch(pt,1,k_indices,k_distances);
					correspondenceIndices[i] = k_indices[0];
					distanceOfCorrespondence[i] = sqrt(k_distances[0]);

					OpenRAVE::KinBody::LinkPtr link = m_links[index];
					correspondenceWeights[i] = this->getCorrespondenceWeight(link->GetIndex(),
							newNormals[index],m_targetNormals[correspondenceIndices[i]]);
				}
			}
		}
		else{
			unsigned int length = 6;
		    cv::Mat sourceMat(m_toRegisterIndices.size(), length, CV_32F);

			float* sourcePtr = sourceMat.ptr<float>(0);
		    for(unsigned int i = 0; i < m_toRegisterIndices.size(); i++ )
		    {
		    	unsigned int index = m_toRegisterIndices[i];
				float extendedPt[length];
				extendedPt[0] = newPoints[index].x();
				extendedPt[1] = newPoints[index].y();
				extendedPt[2] = newPoints[index].z();
				extendedPt[3] = m_params.normals_weight*newNormals[index].x();
				extendedPt[4] = m_params.normals_weight*newNormals[index].y();
				extendedPt[5] = m_params.normals_weight*newNormals[index].z();
				memcpy(sourcePtr, extendedPt, length*sizeof(float));
				sourcePtr += length;
		    }

		    // find nearest neighbors using FLANN
		    cv::Mat indicesMat(m_toRegisterIndices.size(), 1, CV_32S);
		    cv::Mat distsMat(m_toRegisterIndices.size(), 1, CV_32F);

//		    std::cout<<"Extended tree length: "<<m_targetTreeExtended->size()<<std::endl;
//		    std::cout<<"Entry length: "<<m_targetTreeExtended->veclen()<<std::endl;

		    m_targetTreeExtended->knnSearch(sourceMat, indicesMat,
		    		distsMat, 1, cv::flann::SearchParams(150) ); // maximum number of leafs checked

		    // check the distance ratio
		    int* indices_ptr = indicesMat.ptr<int>(0);
		    for (unsigned int i=0;i<m_toRegisterIndices.size();i++) {
				unsigned int index = m_toRegisterIndices[i];

				//check if it has a preset correspondence
				if(m_fixedCorrsSet && (index >= m_fixedPointsStart) &&
						(index < m_fixedPointsEnd ))
				{
					distanceOfCorrespondence[i] = 0;
					correspondenceIndices[i] = m_fixedCorrs[index-m_fixedPointsStart];
					correspondenceWeights[i] = m_params.fixed_corr_weight;
				}
				else{
					int corrIndex = indices_ptr[i];
					correspondenceIndices[i] = corrIndex;
					distanceOfCorrespondence[i] = (m_targetPoints[corrIndex]-newPoints[index]).norm();

					OpenRAVE::KinBody::LinkPtr link = m_links[index];
					correspondenceWeights[i] = this->getCorrespondenceWeight(link->GetIndex(),
							newNormals[index],m_targetNormals[corrIndex]);
				}
		    }
		}

		//use distance threshold to determine validity of correspondence
		unsigned int numValid = 0;
		for(unsigned int i=0; i<m_toRegisterIndices.size(); i++){
			if((distanceOfCorrespondence[i] > max_distance && max_distance > 0)
					|| correspondenceWeights[i] == 0)
			{
				useCorrespondence[i] = false;
			}
			else
			{
				useCorrespondence[i] = true;
				numValid++;
			}
		}
	}

	float
	JointAngleICP::getFixedCorrError(std::vector<float> const &state,
			std::vector<float> const& correspondenceWeights)
	{
		if(!m_fixedCorrsSet)
			return 0;

		std::vector<unsigned int> corrIndices(m_toRegisterIndices.size());
		std::vector<bool> useCorr(m_toRegisterIndices.size(),false);

		for(unsigned int i=0; i<m_toRegisterIndices.size(); i++){
			unsigned int index = m_toRegisterIndices[i];
			if(index >= m_fixedPointsStart && index < m_fixedPointsEnd){
				corrIndices[i] = m_fixedCorrs[index-m_fixedPointsStart];
				useCorr[i] = true;
			}
		}

		return this->getError(state,corrIndices,useCorr,correspondenceWeights);

	}

	float
	JointAngleICP::getError(std::vector<float> const &state,
			std::vector<unsigned int> const &correspondenceIndices,
			std::vector<bool> const &useCorrespondence,
			std::vector<float> const& correspondenceWeights)
	{
		std::vector<rgbd::eigen::Vector3f> newPoints,newNormals;
		this->getNewPointLocations(state,useCorrespondence,newPoints);
		this->getNewNormals(state,useCorrespondence,newNormals);

		float error = 0;
		int count = 0;

		for(unsigned int i=0; i < m_toRegisterIndices.size(); i++){
			if(useCorrespondence[i]){
				unsigned int index = m_toRegisterIndices[i];
				rgbd::eigen::Vector3f diff = newPoints[index] -
					m_targetPoints[correspondenceIndices[i]];
				float weight = correspondenceWeights[i];
				//fixed correspondences should not use point to plane
				if(m_fixedCorrsSet && index >= m_fixedPointsStart && index < m_fixedPointsEnd){
					error += weight*diff.squaredNorm();
				}
				else{
					error+=weight*pow(diff.dot(newNormals[index]),2);
				}
				count++;
			}
		}

		if(m_usePriors){
			rgbd::eigen::VectorXf stateDiff;
			rgbd::eigen::MatrixXf inverseCovariance;
			this->getStateDiffAndInverseCovariance(state,stateDiff,inverseCovariance);
			float exponent = m_priorStrength*(stateDiff.transpose()*inverseCovariance*stateDiff)(0,0);
			//XXX: a bit of a hack to prevent exceeding maximum float
			if(exponent > 10)
				exponent = 10;
			error*=exp(exponent);
		}

		assert(!isnan(error));
		assert(!isinf(error));
		assert(error>=0);

		return error;
	}

	rgbd::eigen::VectorXf
	JointAngleICP::getErrorGradient(std::vector<float> const &state,
			std::vector<unsigned int> const &correspondenceIndices,
			std::vector<bool> const &useCorrespondence,
			std::vector<float> const& correspondenceWeights)
	{
		//get the full list of adjustable state components
		std::deque<unsigned int> stateIndices = this->getLBFGSStateIndices(state);
		rgbd::eigen::VectorXf gradient(stateIndices.size());

		std::vector<float> jointAngles;
		rgbd::eigen::Transform3f calibAdj,objectAdj;
		rgbd::eigen::Matrix<float,7,1> calibAdjVec,objectAdjVec;
		separateOutStateToVectors(state,jointAngles,calibAdjVec,objectAdjVec);
		calibAdj = convertVectorToTransform(calibAdjVec);
		objectAdj = convertVectorToTransform(objectAdjVec);


		//get the number of joint angles
		unsigned int numDOF = this->getCurrentAdjustableDOF(state);

		std::vector<rgbd::eigen::Vector3f> newPoints,newNormals;
		this->getNewPointLocations(state,useCorrespondence,newPoints);
		this->getNewNormals(state,useCorrespondence,newNormals);

		std::vector<rgbd::eigen::Vector3f> correspondenceDiffs(m_toRegisterIndices.size());
		for(unsigned int i=0; i<correspondenceDiffs.size(); i++){
			unsigned int ptIndex = m_toRegisterIndices[i];
			if(useCorrespondence[i] || !(m_fixedCorrsSet &&
					ptIndex >= m_fixedPointsStart && ptIndex < m_fixedPointsEnd)){
				correspondenceDiffs[i] = newPoints[m_toRegisterIndices[i]]-
					m_targetPoints[correspondenceIndices[i]];
			}
		}

		//for the calibration adjustment, to make the derivatives easier, we consider
		//the target points as being adjusted by the calibration adjustment
		std::vector<rgbd::eigen::Vector3f> targetAlteredCorrDiffs(m_toRegisterIndices.size());
		std::vector<rgbd::eigen::Vector3f> calibAdjustedNormals(m_toRegisterIndices.size());
		if(this->adjustCalibration(state)){
			rgbd::eigen::Quaternionf rotationPart = getQuaternionPart(calibAdjVec);
			for(unsigned int i=0; i<calibAdjustedNormals.size(); i++){
				unsigned int ptIndex = m_toRegisterIndices[i];
				if(useCorrespondence[i] || !(m_fixedCorrsSet &&
						ptIndex >= m_fixedPointsStart && ptIndex < m_fixedPointsEnd)){
					//note: preserves length but not direction
					targetAlteredCorrDiffs[i] = rotationPart*correspondenceDiffs[i];
					calibAdjustedNormals[i] = rotationPart*newNormals[ptIndex];
				}
			}
		}


		std::vector<float> dotProducts(m_toRegisterIndices.size());
		for(unsigned int i=0; i<m_toRegisterIndices.size(); i++){
			unsigned int ptIndex = m_toRegisterIndices[i];
			if(!useCorrespondence[i] || (m_fixedCorrsSet &&
					ptIndex >= m_fixedPointsStart && ptIndex < m_fixedPointsEnd))
				continue;
			dotProducts[i] = correspondenceDiffs[i].dot(newNormals[ptIndex]);
		}


		//joint angle part
		for(unsigned int jointIndex=0; jointIndex<numDOF; jointIndex++){
			unsigned int joint = s_jointHierarchyOrder[jointIndex];
			float derivSum=0;

			rgbd::eigen::Vector3f jointBase,jointAxis;
			this->getJointKinematics(joint,state,jointBase,jointAxis);

			//for each point to register
			for(unsigned int i=0; i<m_toRegisterIndices.size(); i++){
				unsigned int ptIndex = m_toRegisterIndices[i];

				if(!useCorrespondence[i] || (m_fixedCorrsSet &&
						ptIndex >= m_fixedPointsStart && ptIndex < m_fixedPointsEnd))
					continue;


				OpenRAVE::KinBody::LinkPtr link = m_links[ptIndex];

				char effect = m_interface->isAffected(link->GetIndex(),joint);
				if(effect == 0)
					continue;

				rgbd::eigen::Vector3f dSdTheta = jointAxis.cross(newPoints[ptIndex]-jointBase);
				rgbd::eigen::Vector3f dNdTheta = jointAxis.cross(newNormals[ptIndex]);
				if(effect < 0){
					dSdTheta *= -1;
					dNdTheta *= -1;
				}

				//for each of the 3 physical dimensions
				for(unsigned int j=0; j<3; j++){
					derivSum+=2*correspondenceWeights[i]*dotProducts[i]*
							(newNormals[ptIndex](j)*dSdTheta(j) + dNdTheta(j)*correspondenceDiffs[i](j));
				}
			}
//				std::cout<<"deriv sum for index "<<jointIndex<<": "<<derivSum<<std::endl;
			gradient(jointIndex) = derivSum;
		} //end joint angle part

		unsigned int gradientStartIndex=numDOF;
		if(this->adjustCalibration(state))
		{
//				std::cout<<"adjusting calibration"<<std::endl;
			//rotation part of calibration gradient
			for(unsigned int quaternionIndex=0; quaternionIndex<4; quaternionIndex++){
				float derivSum=0;

				//for each point to register
				for(unsigned int i=0; i<m_toRegisterIndices.size(); i++){
					unsigned int ptIndex = m_toRegisterIndices[i];

					if(!useCorrespondence[i] || (m_fixedCorrsSet &&
							ptIndex >= m_fixedPointsStart && ptIndex < m_fixedPointsEnd))
						continue;

					//for each of the 3 physical dimensions
					for(unsigned int j=0; j<3; j++){
						derivSum+=2*correspondenceWeights[i]*dotProducts[i]*
							(getRotationPartialDerivative(calibAdjVec,newNormals[m_toRegisterIndices[i]],
									j,quaternionIndex)*targetAlteredCorrDiffs[i](j) -
							getRotationPartialDerivative(calibAdjVec,m_targetPoints[correspondenceIndices[i]],
									j,quaternionIndex)*calibAdjustedNormals[i](j));
					}
				}
				gradient(gradientStartIndex+quaternionIndex) = derivSum;
			}

			//translation part of calibration gradient
			rgbd::eigen::Vector3f derivSumVector = rgbd::eigen::Vector3f::Zero();
			//for each point to register
			for(unsigned int i=0; i<m_toRegisterIndices.size(); i++){
				unsigned int ptIndex = m_toRegisterIndices[i];

				if(!useCorrespondence[i] || (m_fixedCorrsSet &&
						ptIndex >= m_fixedPointsStart && ptIndex < m_fixedPointsEnd))
					continue;

				derivSumVector+=(-2)*correspondenceWeights[i]*dotProducts[i]*calibAdjustedNormals[i];
			}

			for(unsigned int translationIndex=0; translationIndex<3; translationIndex++){
				gradient(gradientStartIndex+translationIndex+4) = derivSumVector(translationIndex);
			}

			gradientStartIndex+=7;
		}
		if(this->adjustObject(state))
		{
//				std::cout<<"adjusting object"<<std::endl;

			rgbd::eigen::Transform3f palmToWorld = invertTransform(calibAdj)*
					m_interface->getLinkTransform(jointAngles,7);

			//rotation part of object gradient
			for(unsigned int quaternionIndex=0; quaternionIndex<4; quaternionIndex++){
				float derivSum=0;

				//for each point to register
				for(unsigned int i=0; i<m_toRegisterIndices.size(); i++){
					unsigned int ptIndex = m_toRegisterIndices[i];

					if(!useCorrespondence[i] || (m_fixedCorrsSet &&
							ptIndex >= m_fixedPointsStart && ptIndex < m_fixedPointsEnd))
						continue;

					rgbd::eigen::Vector3f point,normal;
					//object point from the object list
					if(m_objectPointsSet &&
						ptIndex >= m_objectPointsStart && ptIndex < m_objectPointsEnd)
					{
						point = m_objectPoints[ptIndex-m_objectPointsStart];
						normal = m_objectNormals[ptIndex-m_objectPointsStart];
					}
					//object point from the fixed points list
					else if(m_fixedCorrsSet &&
						ptIndex >= m_fixedPointsStart && ptIndex < m_fixedPointsEnd
						&& m_fixedPtIsObject[ptIndex-m_fixedPointsStart])
					{
						point = m_fixedPtLocalCoords[ptIndex-m_fixedPointsStart];
						normal = m_fixedPtLocalNormals[ptIndex-m_fixedPointsStart];
					}
					//unaffected by object adjustment
					else{
						continue;
					}

					//determine how the quaternion component makes the
					//object move within the palm frame
					rgbd::eigen::Vector3f dSdQ_current;
					rgbd::eigen::Vector3f dNdQ_current;
					for(unsigned int j=0; j<3; j++){
						dSdQ_current[j] = getRotationPartialDerivative(objectAdjVec,
								point,j,quaternionIndex);
						dNdQ_current[j] = getRotationPartialDerivative(objectAdjVec,
								normal,j,quaternionIndex);
					}
					//transform the derivative vector to the world frame
					dSdQ_current = palmToWorld.linear()*dSdQ_current;
					dNdQ_current = palmToWorld.linear()*dNdQ_current;

					//for each of the 3 physical dimensions
					for(unsigned int j=0; j<3; j++){
						derivSum+=2*correspondenceWeights[i]*dotProducts[i]*
								(correspondenceDiffs[i](j)*dNdQ_current(j) +
								newNormals[ptIndex](j)*dSdQ_current(j));
					}

					gradient(gradientStartIndex+quaternionIndex) = derivSum;
				}//end for each point
			}//end for each quaternion component

			//translation part of object gradient
			rgbd::eigen::Vector3f derivSumVector = rgbd::eigen::Vector3f::Zero();
			rgbd::eigen::Matrix3f palmToWorldRotation = palmToWorld.linear();
			//for each point to register
			for(unsigned int i=0; i<m_toRegisterIndices.size(); i++){
				if(!useCorrespondence[i]||m_toRegisterIndices[i]<m_objectPointsStart||
						m_toRegisterIndices[i] >= m_objectPointsEnd)
					continue;
				for(unsigned int derivComponent=0; derivComponent<3; derivComponent++){
					for(unsigned int j=0; j<3; j++){
						derivSumVector(derivComponent)+=2*correspondenceWeights[i]*
							dotProducts[i]*newNormals[m_toRegisterIndices[i]](j)*palmToWorldRotation(j,derivComponent);
					}
				}
			}

			for(unsigned int translationIndex=0; translationIndex<3; translationIndex++){
				gradient(gradientStartIndex+translationIndex+4) = derivSumVector(translationIndex);
			}

		}//end if adjust object

		if(m_usePriors){
//			std::cout<<"applying priors"<<std::endl;

			rgbd::eigen::VectorXf stateDiff;
			rgbd::eigen::MatrixXf inverseCovariance;
			this->getStateDiffAndInverseCovariance(state,stateDiff,inverseCovariance);
			float exponent = m_priorStrength*(stateDiff.transpose()*inverseCovariance*stateDiff)(0,0);
			//XXX: a bit of a hack to prevent exceeding maximum float
			if(exponent > 10)
				exponent = 10;
			float penalty = exp(exponent);

			float error = this->getError(state,correspondenceIndices,useCorrespondence,correspondenceWeights);
//			std::cout<<"error is "<<error<<std::endl;

			rgbd::eigen::VectorXf penaltyGradient = rgbd::eigen::VectorXf::Zero(stateIndices.size());
			for(unsigned int i=0; i<stateIndices.size(); i++){
				unsigned int stateIndex = stateIndices[i];
				for(int j=0; j<inverseCovariance.rows();j++){
					penaltyGradient(i)+=2*m_priorStrength*inverseCovariance(stateIndex,j)*stateDiff(j);
				}
			}
			penaltyGradient*=penalty;
			gradient = penalty*gradient + penaltyGradient*error;
		}

		if(m_fixedCorrsSet){
			gradient+=getFixedCorrGradient(state,correspondenceWeights);
		}

		for(int i=0; i<gradient.size(); i++){
//			std::cout<<"gradient("<<i<<") = "<<gradient(i)<<std::endl;
			assert(!isnan(gradient(i)));
			assert(!isinf(gradient(i)));
		}

		return gradient;
	}

	void
	JointAngleICP::setCalibAdjustmentDisabled()
	{
		m_allowCalibAdjustment = false;
	}

	void
	JointAngleICP::setCalibAdjustmentEnabled(
			rgbd::eigen::Transform3f const& calibrationCorrection,
			rgbd::eigen::Matrix<float,7,7> const& adjustmentCovariance)
	{
		assert(m_usePriors);

		m_allowCalibAdjustment = true;
		m_calibAdjustment = convertTransformToVector(calibrationCorrection);
		m_calibCovarianceInverse = adjustmentCovariance.inverse();
	}

	rgbd::eigen::VectorXf
	JointAngleICP::getFixedCorrGradient(
			std::vector<float> const &state,
			std::vector<float> const& correspondenceWeights)
	{
		std::deque<unsigned int> stateIndices = this->getLBFGSStateIndices(state);
		rgbd::eigen::VectorXf gradient(stateIndices.size());

		float angleStepSize = 5*FLT_EPSILON;
		float nonAngleStepSize = 1E-3;

		std::vector<float> tmpState = state;
		for(unsigned int i=0; i<stateIndices.size(); i++){
			unsigned int stateIndex = stateIndices[i];

			float stepSize = (stateIndex < 11) ? angleStepSize : nonAngleStepSize;

			tmpState[stateIndex] += stepSize;
			float plusError = getFixedCorrError(tmpState,correspondenceWeights);
			tmpState[stateIndex] -= 2*stepSize;
			float minusError = getFixedCorrError(tmpState,correspondenceWeights);

			//the ith partial derivative
			gradient(i) = (plusError - minusError)/(2*stepSize);
		}

		return gradient;
	}

	rgbd::eigen::VectorXf
	JointAngleICP::getErrorGradientNumeric(std::vector<float> const &state,
			std::vector<unsigned int> const &correspondenceIndices,
			std::vector<bool> const &useCorrespondence,
			std::vector<float> const& correspondenceWeights)
	{
		std::deque<unsigned int> stateIndices = this->getLBFGSStateIndices(state);
		rgbd::eigen::VectorXf gradient(stateIndices.size());

		float angleStepSize = 5*FLT_EPSILON;
		float nonAngleStepSize = 1E-3;

		std::vector<float> tmpState = state;
		for(unsigned int i=0; i<stateIndices.size(); i++){
			unsigned int stateIndex = stateIndices[i];

			float stepSize = (stateIndex < 11) ? angleStepSize : nonAngleStepSize;

			tmpState[stateIndex] += stepSize;
			float plusError = getError(tmpState,correspondenceIndices,useCorrespondence,correspondenceWeights);
			tmpState[stateIndex] -= 2*stepSize;
			float minusError = getError(tmpState,correspondenceIndices,useCorrespondence,correspondenceWeights);

			//the ith partial derivative
			gradient(i) = (plusError - minusError)/(2*stepSize);
		}

		return gradient;
	}

	void
	JointAngleICP::getNewPointLocations(std::vector<float> const& state,
			std::vector<rgbd::eigen::Vector3f> &newPoints)
	{
		std::vector<bool> useCorrespondences(m_toRegisterIndices.size(),true);
		return this->getNewPointLocations(state,useCorrespondences,newPoints);
	}

	void
	JointAngleICP::getNewPointLocations(std::vector<float> const& state,
			std::vector<bool> const& useCorrespondences,
			std::vector<rgbd::eigen::Vector3f> &newPoints)
	{
		rgbd::eigen::Transform3f calibAdjustment,objectAdjustment;
		std::vector<float> angles;
		separateOutState(state,angles,calibAdjustment,objectAdjustment);

		m_interface->getNewPointLocations(m_toRegister,m_toRegisterIndices,useCorrespondences,m_links,
				m_acquisitionAngles,angles,newPoints,m_useGlobalCoords,m_useGlobalCoords);

		//there may be points that transform with the object instead
		if((m_objectPointsSet || m_fixedCorrsSet)&&m_allowObjectAdjustment){

			rgbd::eigen::Transform3f linkTransform = m_interface->getLinkTransform(angles,7);

			if(m_objectPointsSet){
				for(unsigned int i=0; i<m_objectPoints.size(); i++){
					newPoints[m_objectPointsStart + i] =
							linkTransform*objectAdjustment*m_objectPoints[i];
				}
			}
			if(m_fixedCorrsSet){
				for(unsigned int i=0; i<m_fixedCorrs.size(); i++){
					if(m_fixedPtIsObject[i]){
						newPoints[m_fixedPointsStart + i] =
							linkTransform*objectAdjustment*m_fixedPtLocalCoords[i];
					}
				}
			}
		}

		//apply the calibration adjustment
		if(m_allowCalibAdjustment){
			//camera transform gives transformation for camframe -> globalframe
			//newPoints are globalPoints, so we need to use the inverse
			rgbd::eigen::Transform3f inverseAdjustment = invertTransform(calibAdjustment);
			for(unsigned int i=0; i<m_toRegisterIndices.size(); i++){
				if(useCorrespondences[i]){
					unsigned int index = m_toRegisterIndices[i];
					newPoints[index] = inverseAdjustment*newPoints[index];
				}
			}
		}
	}

	void
	JointAngleICP::getNewNormals(std::vector<float> const& state,
			std::vector<rgbd::eigen::Vector3f> &newNormals)
	{

		std::vector<bool> useCorrespondences(m_toRegisterIndices.size(),true);
		return this->getNewPointLocations(state,useCorrespondences,newNormals);
	}

	void
	JointAngleICP::getNewNormals(std::vector<float> const& state,
			std::vector<bool> const& useCorrespondences,
			std::vector<rgbd::eigen::Vector3f> &newNormals)
	{
		rgbd::eigen::Transform3f calibAdjustment,objectAdjustment;
		std::vector<float> angles;
		separateOutState(state,angles,calibAdjustment,objectAdjustment);
		calibAdjustment = rgbd::eigen::Transform3f(calibAdjustment.linear());
		objectAdjustment = rgbd::eigen::Transform3f(objectAdjustment.linear());

		m_interface->getNewNormals(m_toRegisterNormals,m_toRegisterIndices,useCorrespondences,m_links,
				m_acquisitionAngles,angles,newNormals,m_useGlobalCoords,m_useGlobalCoords);

		//there may be points that transform with the object instead
		if((m_objectPointsSet || m_fixedCorrsSet)&&m_allowObjectAdjustment){

			rgbd::eigen::Transform3f linkTransform(m_interface->getLinkTransform(angles,7).linear());

			if(m_objectPointsSet){
				for(unsigned int i=0; i<m_objectPoints.size(); i++){
					newNormals[m_objectPointsStart + i] =
							linkTransform*objectAdjustment*m_objectNormals[i];
				}
			}
			if(m_fixedCorrsSet){
				for(unsigned int i=0; i<m_fixedCorrs.size(); i++){
					if(m_fixedPtIsObject[i]){
						newNormals[m_fixedPointsStart + i] =
							linkTransform*objectAdjustment*m_fixedPtLocalNormals[i];
					}
				}
			}
		}

		//apply the calibration adjustment
		if(m_allowCalibAdjustment){
			//camera transform gives transformation for camframe -> globalframe
			//newPoints are globalPoints, so we need to use the inverse
			rgbd::eigen::Transform3f inverseAdjustment = invertTransform(calibAdjustment);
			inverseAdjustment = rgbd::eigen::Transform3f(inverseAdjustment.linear());
			for(unsigned int i=0; i<m_toRegisterIndices.size(); i++){
				if(useCorrespondences[i]){
					unsigned int index = m_toRegisterIndices[i];
					newNormals[index] = inverseAdjustment*newNormals[index];
				}
			}
		}
	}


	unsigned int
	JointAngleICP::getCurrentAdjustableDOF(std::vector<float> const& state,bool forceIncrease)
	{
		if(forceIncrease)
			std::cout<<"Force increase in round "<<m_round<<std::endl;

		bool useHierarchy = m_params.use_joint_hierarchy;
		unsigned int stages = m_params.joint_hierarchy_steps;
		unsigned int totalStages = 5;

		if(!useHierarchy || m_params.max_rounds == (int)m_round)
			m_currentDOF = m_numAngles;


		if(m_currentDOF == m_numAngles)
			return m_currentDOF;
		else if(m_params.max_rounds == 1){
			m_currentDOFStage = stages-1;
			m_currentDOF = m_numAngles;
			return m_currentDOF;
		}

		unsigned int roundsToIncrease = (m_params.max_rounds)/(stages+1);
		unsigned int increaseAmount = 1;
		if(roundsToIncrease == 0){
			roundsToIncrease = 1;
			increaseAmount = ceil((double)(stages+1)/(m_params.max_rounds));
		}

		if(ceil((double)(totalStages-1)/stages) > increaseAmount)
			increaseAmount = ceil((double)(totalStages-1)/stages);

		bool increase = forceIncrease || ((m_round-m_lastDOFIncrease)>=roundsToIncrease);

		if(!increase)
			return m_currentDOF;

		m_currentDOFStage+=increaseAmount;
		if(m_currentDOFStage >= (totalStages-1))
			m_currentDOFStage = totalStages-1;
		m_currentDOF = s_jointHierarchyBreakpoints[m_currentDOFStage] + 1;
		m_lastDOFIncrease = m_round;

		//if we just added in the fingers, make sure they seem valid
		if(m_currentDOF == m_numAngles){
			std::cout<<"Current round "<<m_round<<std::endl;
			std::cout<<"Max rounds "<<m_params.max_rounds<<std::endl;
			this->checkForFingers(state);
		}

		return m_currentDOF;

	}

	void
	JointAngleICP::getJointKinematics(unsigned int joint,
			std::vector<float> const& state,
			rgbd::eigen::Vector3f & jointBase,
			rgbd::eigen::Vector3f & jointAxis)
	{
		//separate the state
		std::vector<float> angles;
		rgbd::eigen::Transform3f calibT,objectT;
		separateOutState(state,angles,calibT,objectT);

		m_interface->getJointKinematics(joint,m_useGlobalCoords,angles,jointBase,jointAxis);

		//all points to register get transformed by the inverse calibration transform
		rgbd::eigen::Transform3f inverseAdjustment = invertTransform(calibT);
		jointBase = inverseAdjustment*jointBase;
		jointAxis = inverseAdjustment.linear()*jointAxis;
	}

	bool
	JointAngleICP::adjustCalibration(std::vector<float> const& state)
	{
		unsigned int adjustableDOF = getCurrentAdjustableDOF(state);
		return m_allowCalibAdjustment && adjustableDOF == m_numAngles;
	}

	bool
	JointAngleICP::adjustObject(std::vector<float> const& state)
	{
		unsigned int adjustableDOF = getCurrentAdjustableDOF(state);
		return m_allowObjectAdjustment && adjustableDOF == m_numAngles;
	}

	float
	JointAngleICP::getCorrespondenceWeight(
			unsigned int linkIndex,
			rgbd::eigen::Vector3f const& toRegisterNormal,
			rgbd::eigen::Vector3f const& targetNormal)
	{
		//dot product gives cos(theta). raising it to a power greater than 1
		//makes it fall off faster, giving agreement of normals more importance
		//a power less than 1 makes it fall off slower, making the normals of
		//less importance

		//TODO: parameter
		float exponent = 1.0;

		float dot = toRegisterNormal.dot(targetNormal);
		if(dot < 0)
			dot*=-1;

		float normalsFactor = pow(dot,exponent);

		return normalsFactor*getCurrentLinkWeight(linkIndex);
	}

	float
	JointAngleICP::getCurrentLinkWeight(unsigned int linkIndex)
	{
//		unsigned int numDOF = this->getCurrentAdjustableDOF();
		bool useWeights = true;

		if(!m_linkExistsInTarget[linkIndex])
			return 0.0;

		if(!useWeights)
			return 1.0;

		//upper arm
		if(linkIndex < 4){
			return m_params.upper_arm_weight;
		}
		//lower arm + wrist
		else if(linkIndex < 8){
			return m_params.lower_arm_weight;
		}
		//hand
		else{
			return m_params.hand_weight;
		}
	}


//	rgbd::eigen::Transform3f
//	JointAngleICP::getXAxisAligningTransform(
//			std::vector<float> const& state,
//			unsigned int jointIndex)
//	{
//		rgbd::eigen::Vector3f jointBase,jointAxis;
//		m_interface->getJointKinematics(jointIndex,m_useGlobalCoords,currentAngles,jointBase,jointAxis);
//
//		rgbd::eigen::Translation3f translation(jointBase);
//
//		rgbd::eigen::Vector3f nonParallelVector;
//		if(rgbd::eigen::Vector3f::UnitX().dot(jointAxis) < .9)
//			nonParallelVector = rgbd::eigen::Vector3f::UnitX();
//		else
//			nonParallelVector = rgbd::eigen::Vector3f::UnitY();
//
//		rgbd::eigen::Vector3f perpVec1 = (nonParallelVector - nonParallelVector.dot(jointAxis)*jointAxis).normalized();
//		rgbd::eigen::Vector3f perpVec2 = jointAxis.cross(perpVec1).normalized();
//
//		rgbd::eigen::Matrix3f rotTranspose;
//		rotTranspose.col(0) = jointAxis; //unit-x maps to jointAxis
//		rotTranspose.col(1) = perpVec1; //unit-y maps to perpVec1
//		rotTranspose.col(2) = perpVec2; //unit-z maps to perpVec2
//
//		//make sure it's just rotation and not reflection as well
//		if(rotTranspose.determinant() < 0)
//			rotTranspose.col(2) *= -1;
//
//		rgbd::eigen::Transform3f toReturn = rotTranspose.transpose()*translation.inverse();
//
//		return toReturn;
//
//	}

//	rgbd::eigen::Transform3f
//	JointAngleICP::getYawPitchRollAxesTransform(
//			std::vector<float> const& currentAngles,
//			unsigned int startIndex)
//	{
//		rgbd::eigen::Vector3f jointBase,yawAxis,pitchAxis,rollAxis;
//		m_interface->getJointKinematics(startIndex,m_useGlobalCoords,currentAngles,jointBase,yawAxis);
//		m_interface->getJointKinematics(startIndex+1,m_useGlobalCoords,currentAngles,jointBase,pitchAxis);
//		m_interface->getJointKinematics(startIndex+2,m_useGlobalCoords,currentAngles,jointBase,rollAxis);
//
//		rgbd::eigen::Translation3f translation(jointBase);
//		rgbd::eigen::Matrix3f rotTranspose;
//		rotTranspose.col(0) = rollAxis; //unit-x maps to jointAxis
//		rotTranspose.col(1) = pitchAxis; //unit-y maps to perpVec1
//		rotTranspose.col(2) = yawAxis; //unit-z maps to perpVec2
//
//		rgbd::eigen::Transform3f toReturn = rotTranspose.transpose()*translation.inverse();
//		return toReturn;
//	}

	std::vector<float>
	JointAngleICP::runLBFGSAlignment(
			std::vector<float> &prevState,
			std::vector<unsigned int> &correspondenceIndices,
			std::vector<bool> &useCorrespondence,
			std::vector<float> const& correspondenceWeights)
	{
	    unsigned int hessianSteps = 6;
		unsigned int maxIterations = m_params.max_optimizer_iterations;

		bool numericGradient = m_params.numeric_gradient;

	    unsigned int dimensions = this->getLBFGSStateIndices(prevState).size();

	    if(hessianSteps > dimensions)
	    	hessianSteps = dimensions;

	    lbfgsstate state;
	    lbfgsreport rep;

	    std::cout<<"Optimizing over "<<dimensions<<" parameters"<<std::endl;

	    ap::real_1d_array startState = convertStateToLBFGSArray(prevState);
	    minlbfgs(dimensions, hessianSteps, startState, 0.0, 0.0, 0.0, maxIterations, 0, state);
	    while(minlbfgsiteration(state))
	    {
//	    	std::cout << "LBFGS loop..." << std::endl;

	    	std::vector<float> currentState = convertLBFGSArrayToState(state.x);
	    	//set the value at the currentTransform
	        state.f = getError(currentState,correspondenceIndices,useCorrespondence,correspondenceWeights);

	        //set the partial derivatives at the currentTransform
	        rgbd::eigen::VectorXf gradient;
	        if(numericGradient)
	        	gradient = this->getErrorGradientNumeric(currentState,correspondenceIndices,useCorrespondence,correspondenceWeights);
	        else
	        	gradient = this->getErrorGradient(currentState,correspondenceIndices,useCorrespondence,correspondenceWeights);
	        for(unsigned int i=0; i<dimensions; i++){
	        	state.g(i) = gradient(i);
	        }
	    }
	    //retreive the results
	    ap::real_1d_array result;
	    minlbfgsresults(state, result, rep);

	    std::vector<float> toReturn =  convertLBFGSArrayToState(result);

	    return toReturn;
	}

//	void
//	pointToPointFunc(float *p, float *x, int m, int n, void *data)
//	{
//		//p are parameters (i.e. state)
//		//m is size of parameter vector
//		//n is measurement vector size (i.e 3X num corr)
//		//data has anything needed (indices,usecorr,corrweights)
//		void **dataArray = (void**)data;
//		JointAngleICP *icp = (JointAngleICP*) dataArray[0];
//		std::vector<unsigned int> *correspondenceIndices = (std::vector<unsigned int> *)dataArray[1];
//		std::vector<bool> *useCorrespondence = (std::vector<bool> *)dataArray[2];
//		std::vector<float> *correspondenceWeights = (std::vector<float> *)dataArray[3];
//
//		std::vector<float> state(m);
//		for(unsigned int i=0; i<m; i++)
//			state[i] = p[i];
//
//		std::vector<rgbd::eigen::Vector3f> newPoints;
//		icp->getNewPointLocations(state,*useCorrespondence,newPoints);
//
//		unsigned int numValid = 0;
//		for(unsigned int i=0; i<icp->m_toRegisterIndices.size(); i++){
//			if((*useCorrespondence)[i]){
//				float sqrtWt = sqrt((*correspondenceWeights)[i]);
//				for(unsigned int j=0; j<3; j++){
//					x[3*numValid+j] = sqrtWt*newPoints[i];
//				}
//				numValid++;
//			}
//		}
//	}
//
//
//
//	std::vector<float>
//	JointAngleICP::runLMAlignment(
//			std::vector<float> &prevState,
//			std::vector<unsigned int> &correspondenceIndices,
//			std::vector<bool> &useCorrespondence,
//			std::vector<float> const& correspondenceWeights)
//	{
//		void *data[4];
//		data[0] = (void*)this;
//		data[1] = (void*)&correspondenceIndices;
//		data[2] = (void*)&useCorrespondence;
//		data[3] = (void*)&correspondenceWeights;
//
//		unsigned int numValid = 0;
//		std::vector<float> measurement;
//		for(unsigned int i=0; i<icp->m_toRegisterIndices.size(); i++){
//			if(useCorrespondence[i]){
//				float sqrtWt = sqrt(correspondenceWeights[i]);
//				unsigned int corrIndex = correspondenceIndices[i];
//				for(unsigned int j=0; j<3; j++){
//					measurement.push_back(sqrtWt*m_targetPoints[corrIndex][j]);
//				}
//				numValid++;
//			}
//		}
//
//		float state[prevState.size()];
//		state = prevState.data();
//
//		int ret = slevmar_dif(pointToPointFunc,state,measurement.data(),
//			prevState.size(),measurement.size(),1000,NULL,NULL,NULL,NULL,(void*)data);
//
//		std::vector<float> toReturn(prevState.size());
//		for(unsigned int i=0; i<prevState.size(); i++)
//			toReturn[i] = state[i];
//		return toReturn;
//	}

	bool
	JointAngleICP::shouldContinue(
			std::vector<float> &prevState,
			std::vector<float> &newState,
			std::vector<unsigned int> &correspondenceIndices,
			std::vector<bool> &useCorrespondence,
			std::vector<float> const& correspondenceWeights)
	{
//		std::cout<<"Current round "<<m_round<<", max rounds "<<m_params.max_rounds<<std::endl;
		if((int)m_round > m_params.max_rounds)
			return false;


		float min_angle_diff = m_params.min_angle_diff;
		float min_error_diff_fraction = m_params.min_error_diff_fraction;

		//difference in error given the _current_ correspondences
		float previous_error = getError(prevState,correspondenceIndices,useCorrespondence,correspondenceWeights);
		float current_error = getError(newState,correspondenceIndices,useCorrespondence,correspondenceWeights);
		float error_diff = -(current_error - previous_error);
		float error_diff_fraction = error_diff / current_error;

		//angular difference (possibly some translations and quaternion components as well)
		float greatestAngleDiff = 0;
		for(unsigned int i=0; i<prevState.size(); i++){
			float angleDiff = newState[i]-prevState[i];
			if(angleDiff < 0)
				angleDiff*=-1;
			if(angleDiff > greatestAngleDiff)
				greatestAngleDiff = angleDiff;
		}

//		std::cout<<"Error diff fraction: "<<error_diff_fraction<<
//			", where min is: "<<min_error_diff_fraction<<std::endl;
//		std::cout<<"Largest angle diff: "<<greatestAngleDiff<<
//			", where min is: "<<min_angle_diff<<std::endl;

		if(error_diff_fraction < min_error_diff_fraction &&
				greatestAngleDiff < min_angle_diff)
			return false;
		return true;
	}

	std::deque<unsigned int>
	JointAngleICP::getLBFGSStateIndices(std::vector<float> const& state)
	{
		std::deque<unsigned int > stateIndices;
		unsigned int adjustableDOF = getCurrentAdjustableDOF(state);
		for(unsigned int i=0; i<adjustableDOF; i++){
			unsigned int angleIndex = s_jointHierarchyOrder[i];
			stateIndices.push_back(angleIndex);
		}
		if(this->adjustCalibration(state)){
			for(unsigned int i=0; i<7; i++){
				stateIndices.push_back(m_numAngles+i);
			}
		}
		if(this->adjustObject(state)){
			for(unsigned int i=0; i<7; i++){
				stateIndices.push_back(m_numAngles+7+i);
			}
		}

		return stateIndices;
	}

	void
	JointAngleICP::getStateDiffAndInverseCovariance(
			std::vector<float> const& state,
			rgbd::eigen::VectorXf & stateDiff,
			rgbd::eigen::MatrixXf & inverseCovariance)
	{
		int dimensions = m_numAngles + 14;

		//find the difference in state
		stateDiff = rgbd::eigen::VectorXf(dimensions);
		for(unsigned int i=0; i<m_numAngles; i++){
			stateDiff(i) = state[i]-m_anglePriorMean(i);
		}
		for(unsigned int i=0; i<7; i++){
			stateDiff(m_numAngles+i) = state[m_numAngles+i] - m_calibAdjustment(i);
			stateDiff(m_numAngles+7+i) = state[m_numAngles+7+i] - m_objectAdjustment(i);
		}

		//construct the (block diagonal) combined inverse covariance matrix
		inverseCovariance = rgbd::eigen::MatrixXf::Zero(dimensions,dimensions);
		inverseCovariance.block(0,0,m_numAngles,m_numAngles) = m_anglePriorCovarianceInverse;
		if(this->adjustCalibration(state)){
			inverseCovariance.block(m_numAngles,m_numAngles,7,7) = m_calibCovarianceInverse;
		}
		if(this->adjustObject(state)){
			inverseCovariance.block(m_numAngles+7,m_numAngles+7,7,7) = m_objectCovarianceInverse;
		}
	}


	ap::real_1d_array
	JointAngleICP::convertStateToLBFGSArray(std::vector<float> const& state)
	{
		ap::real_1d_array x;
		std::deque<unsigned int> stateIndices = this->getLBFGSStateIndices(state);

		x.setbounds(0, stateIndices.size()-1);
		for(unsigned int i=0; i<stateIndices.size(); i++){
			unsigned int stateIndex = stateIndices[i];
			x(i) = state[stateIndex];
		}

	    return x;
	}

	std::vector<float>
	JointAngleICP::convertLBFGSArrayToState(ap::real_1d_array const& array)
	{
		std::deque<unsigned int> stateIndices = this->getLBFGSStateIndices(m_initialState);

		//set to the initial state because components not specified in array
		//must still be at their start values
		std::vector<float> state(m_initialState);

		for(unsigned int i=0; i<stateIndices.size(); i++){
			unsigned int stateIndex = stateIndices[i];
			assert(!isnan(array(i)));
			state[stateIndex] = array(i);
		}

		return state;
	}

}
