/*
 * ICPCloudPairSingleKDTree: cloud pairs for ICPCombined that use a single k-d tree for the whole cloud
 *
 * Evan Herbst
 * 3 / 21 / 10
 */

#include <cmath> //max()
#include <iostream>
#include <boost/ref.hpp>
#include <boost/bind.hpp>
#include <boost/make_shared.hpp>
#include <boost/thread.hpp>
#include "rgbd_util/timer.h"
#include "rgbd_util/parallelism.h" //partitionEvenly()
#include "point_cloud_icp/registration/icp_utility.h" //createKDTree()
#include "point_cloud_icp/registration/ICPCloudPairSingleKDTree.h"
using std::vector;
using std::endl;

namespace registration
{

ICPCloudPairSingleKDTree::ICPCloudPairSingleKDTree(ICPCloudPairParams const& params,
		sensor_msgs::PointCloud const& source_pointcloud,
		sensor_msgs::PointCloud const& target_pointcloud)
: ICPCloudPair(params, source_pointcloud, target_pointcloud)
{
	m_target_kdtree_ptr = rgbd::createKDTree2(target_pointcloud);
	initialize(source_pointcloud, target_pointcloud);
}

ICPCloudPairSingleKDTree::ICPCloudPairSingleKDTree(const ICPCloudPairParams& params,
			const sensor_msgs::PointCloud& sourceCloud,
			const sensor_msgs::PointCloud& targetCloud,
			boost::shared_ptr<kdtree2> targetKDTree)
: ICPCloudPair(params, sourceCloud, targetCloud), m_target_kdtree_ptr(targetKDTree)
{
	initialize(sourceCloud, targetCloud);
}

ICPCloudPairSingleKDTree::~ICPCloudPairSingleKDTree()
{
	// this assumes that these have been correctly allocated...
	fastpointlib::pointarray_free(&m_source_fpl_points);
	fastpointlib::pointarray_free(&m_source_fpl_points_temp);
}

/*
 * common ctor code
 *
 * pre: m_params has been set
 */
void ICPCloudPairSingleKDTree::initialize(const sensor_msgs::PointCloud& source_pointcloud, const sensor_msgs::PointCloud& target_pointcloud)
{
	// create eigen version of both point clouds
	convertPointCloudToVector(source_pointcloud, m_source_eigen_points);
	convertPointCloudToVector(target_pointcloud, m_target_eigen_points);

	// also create a fastpointlib version of the source cloud and an equally sized temp structure
	unsigned int source_point_count = source_pointcloud.get_points_size();
	m_source_fpl_points = fastpointlib::pointarray_alloc(source_point_count);
	fastpointlib::conv_ros_cloud_to_points(source_pointcloud, m_source_fpl_points);
	m_source_fpl_points_temp = fastpointlib::pointarray_alloc(source_point_count);
}

void ICPCloudPairSingleKDTree::getCorrespondenceIndicesThreadMain(rgbd::eigen::Transform3f const& transform, std::vector<int> & correspondence_indices, const unsigned int firstIndex, const unsigned int lastIndex, unsigned int& invalid_count) const
{
	std::vector<float> correspondence_distances_squared(lastIndex - firstIndex + 1);
	for (unsigned int i = firstIndex, i0 = 0; i <= lastIndex; ++i, i0++)
	{
		const rgbd::eigen::Vector3f transformed_source = transform * m_source_eigen_points[i];
		vector<float> qpt(3);
		for(unsigned int j = 0; j < 3; j++) qpt[j] = transformed_source[j];
		kdtree2_result_vector result;
		m_target_kdtree_ptr->n_nearest(qpt, 1, result);
		correspondence_indices[i] = result[0].idx;
		correspondence_distances_squared[i0] = result[0].dis;
	}
	invalid_count = 0;

	// now filter out those beyond the max distance
	// invalid correspondences will be -1
	if (m_params.max_distance > 0.0) {
		const float max_distance_squared = m_params.max_distance * m_params.max_distance;
		for (unsigned int i = firstIndex, i0 = 0; i <= lastIndex; ++i, i0++)
			if (correspondence_distances_squared[i0] > max_distance_squared) {
				correspondence_indices[i] = -1;
				invalid_count++;
			}
	}

	// separate out normal check so normals aren't always required
	if (!m_params.front_can_match_back) {
		for (unsigned int i = firstIndex; i <= lastIndex; ++i) {
			if (correspondence_indices[i] >= 0) {
				const rgbd::eigen::Vector3f transformed_normal = transform.linear() * m_source_eigen_normals[i];
				const float normal_dot_product = transformed_normal.dot(m_target_eigen_normals[correspondence_indices[i]]);
				if (normal_dot_product < 0) {
					correspondence_indices[i] = -1;
					invalid_count++;
				}
			}
		}
	}
}

int ICPCloudPairSingleKDTree::getCorrespondenceIndices(rgbd::eigen::Transform3f const& transform, std::vector<int> & correspondence_indices) const
{
	const unsigned int point_count = m_source_eigen_points.size();
	correspondence_indices.resize(point_count);

	// if correspondence is fixed, correspondence is just index
	if (m_params.fixed_correspondence) {
		for (unsigned int i = 0; i < point_count; ++i) {
			correspondence_indices[i] = i;
		}
		return point_count;
	}

	// otherwise, find the nearest point in target points
	rgbd::timer t;
	const unsigned int numThreads = (unsigned int) std::max(2, (int) boost::thread::hardware_concurrency() - 4);
	vector<boost::shared_ptr<boost::thread> > threads(numThreads);
	const vector<unsigned int>& indices = partitionEvenly(point_count, numThreads);
	vector<unsigned int> invalidCounts(numThreads);
	for(unsigned int i = 0; i < numThreads; i++)
		threads[i] = boost::make_shared<boost::thread>(boost::bind(&ICPCloudPairPointsOnly::getCorrespondenceIndicesThreadMain, this, boost::cref(transform), boost::ref(correspondence_indices), indices[i], indices[i + 1] - 1, boost::ref(invalidCounts[i])));
	unsigned int valid_count = point_count;
	for(unsigned int i = 0; i < numThreads; i++)
	{
		threads[i]->join();
		valid_count -= invalidCounts[i];
	}
	t.stop("get correspondence indices");

	// debug
//	std::cout << "Corrs:" << std::endl;
//	for (unsigned int i = 0; i < correspondence_indices.size(); i++) {
//		std::cout << correspondence_indices[i] << std::endl;
//	}

	return valid_count;
}

void ICPCloudPairSingleKDTree::getPoints(std::vector<rgbd::eigen::Vector3f> &source_points, std::vector<rgbd::eigen::Vector3f> &target_points)
{
	source_points = m_source_eigen_points;
	target_points = m_target_eigen_points;
}

} //namespace
