/*
 * JointAngleKalmanFilter.cpp
 *
 *  Created on: Aug 5, 2009
 *      Author: mkrainin
 */

#include <point_cloud_icp/registration/JointAngleKalmanFilter.h>
#include <point_cloud_icp/registration/PointCloudSegmenter.h>
#include <point_cloud_icp/registration/ICP.h>
#include <point_cloud_icp/registration/icp_utility.h>
#include <point_cloud_icp/registration/feature_utility.h>
#include <point_cloud_mapping/geometry/nearest.h>
#include <point_cloud_mapping/geometry/point.h>
#include "geometry_msgs/PointStamped.h"
#include "rgbd_util/eigen/LU"
#include <float.h>

namespace registration{

JointAngleKalmanFilter::
JointAngleKalmanFilter(OpenRAVEInterface *interface)
: m_extractor(-1)
{
	m_inter = interface;
	m_haveObjectCloud = false;

	//TODO: params
	m_xChannel = 1;
	m_yChannel = 2;
	unsigned int xRes = 640;
	unsigned int yRes = 480;
	m_segmenter.setResolution(xRes,yRes);
	m_segmenter.setPixelChannels(m_xChannel,m_yChannel);

}

JointAngleKalmanFilter::
~JointAngleKalmanFilter()
{
}

std::vector<float>
JointAngleKalmanFilter::getLastICPResult()
{
	return m_lastICPAngles;
}

void
JointAngleKalmanFilter::getLastPointsToRegister(
		std::vector<rgbd::eigen::Vector3f> &toRegister,
		std::vector<OpenRAVE::KinBody::LinkPtr > &links,
		std::vector<rgbd::eigen::Vector3f> &normals,
		std::vector<float> &acquisitionAngles)
{
	toRegister = m_lastICPToRegister;
	links = m_lastICPLinks;
	normals = m_lastICPNormals;
	acquisitionAngles = m_lastICPAcquisitionAngles;
}

void
JointAngleKalmanFilter::getLastICPCorrespondences(
		std::vector<unsigned int> &correspondenceIndices,
		std::vector<bool> &useCorrespondence,
		std::vector<float> &correspondenceWeights)
{
	correspondenceIndices = m_lastICPCorrespondences;
	useCorrespondence = m_lastICPUseCorrespondences;
	correspondenceWeights = m_lastICPWeights;
}

sensor_msgs::PointCloud
JointAngleKalmanFilter::getObjectCloud()
{
	return m_objectCloud;
}

sensor_msgs::PointCloud
JointAngleKalmanFilter::getDownsampledObjectCloud()
{
	return m_downsampledObjectCloud;
}

sensor_msgs::PointCloud
JointAngleKalmanFilter::getLastTargetCloud()
{
	return m_lastTargetCloud;
}

sensor_msgs::PointCloud
JointAngleKalmanFilter::getLastObjectCloud()
{
	return m_lastObjectCloudUpdate;
}

sensor_msgs::PointCloud
JointAngleKalmanFilter::getColorizedCloud()
{
	return m_colorizedCloud;
}

//rgbd::eigen::MatrixXf
//JointAngleKalmanFilter::getLastICPCovariance()
//{
//	return m_lastICPCovariance;
//}

void
JointAngleKalmanFilter::getState(
		std::vector<float> &meanState,
		rgbd::eigen::MatrixXf &covariance)
{
	meanState = m_currentMean;
	covariance = m_currentCovariance;
}

void
JointAngleKalmanFilter::performUpdate(
		const std::vector<float> &reportedAngles,
		const sensor_msgs::PointCloud &observation,
		bool globalCoords,sensor_msgs::ImageConstPtr const imagePtr)
{

	bool retrieveCorrespondences = true;
	float randomDownsampleRate = m_params.target_downsample_rate;
	bool downsampleTarget = (randomDownsampleRate > 0 && randomDownsampleRate < 1);

	rgbd::eigen::Vector3f radiusDownsampleCenter = rgbd::eigen::Vector3f::Zero();
	float radiusDownsampleRadius = m_params.radius_downsample_radius;

	//image/feature parameters
	float ransacInlierDist = .005;
    unsigned int ransacNumSamples = 200;
    unsigned int ransacSampleSize = 3;
    float ransacMinSampleDist = .1;
	double hessianThreshold = 300;
	bool extendedDescriptors = true;
	bool approxNearest = false;
	bool matchKeypoints = m_params.detect_object_in_hand && m_haveObjectCloud &&
			imagePtr.get() != NULL;
	bool useSift = false;
	unsigned int minRansacMatches = 5;
	unsigned int numThreads = 1;


	bool setJointPriors = (m_params.icp_prior_strength > 0);

	rgbd::eigen::VectorXf reportedChange(m_numAngles);
	rgbd::eigen::VectorXf predictedMean = stdToEigen(m_currentMean);
	for(unsigned int i=0; i<m_numAngles; i++){
		reportedChange(i) = reportedAngles[i] - m_lastReportedAngles[i];
		predictedMean(i) = m_currentMean[i] + reportedChange(i);
	}
	m_lastReportedAngles = reportedAngles;

	//state transition covariance
	rgbd::eigen::MatrixXf R = this->getMotionUpdateCovariance(reportedChange);
	rgbd::eigen::MatrixXf sigma_bar = m_currentCovariance + R;

	//run icp to get the measurement
	sensor_msgs::PointCloud	target,radiusRemoved;

	//radius remove
	std::deque<unsigned int> acceptedIndices = getRadiusDownsamplingIndices(
			observation,radiusDownsampleCenter,radiusDownsampleRadius,true);
	downsampleFromIndices(observation,radiusRemoved,acceptedIndices);

	if(downsampleTarget){
		//random downsample
		acceptedIndices = getRandomDownsamplingIndices(
			radiusRemoved,randomDownsampleRate);
		downsampleFromIndices(radiusRemoved,target,acceptedIndices);
	}
	else{
		target = radiusRemoved;
	}

	std::vector<float> predictedAngles;
	rgbd::eigen::Transform3f predictedCalibAdj,predictedObjAdj;
	separateOutState(eigenToStd(predictedMean),predictedAngles,predictedCalibAdj,predictedObjAdj);

	//compute normals
	geometry_msgs::PointStamped pointStamped;
	pointStamped.header.frame_id = "frame";
	pointStamped.point.x = pointStamped.point.y = pointStamped.point.z = 0.0;
	cloud_geometry::nearest::computePointCloudNormals(target,m_params.icp_params.normals_k,pointStamped);

	registration::JointAngleICP icp(m_inter,target,globalCoords);
	icp.setParams(m_params.icp_params);

	//split up sigma_bar and pass in the blocks separately
	rgbd::eigen::MatrixXf sigma_bar_angles = sigma_bar.block(0,0,m_numAngles,m_numAngles);
	rgbd::eigen::MatrixXf sigma_bar_calib = sigma_bar.block(m_numAngles,m_numAngles,7,7);
	rgbd::eigen::MatrixXf sigma_bar_object = sigma_bar.block(m_numAngles+7,m_numAngles+7,7,7);

	//set angles
	icp.setInitialAngles(predictedAngles);
	if(setJointPriors){
		icp.setJointAnglePriors(stdToEigen(predictedAngles),sigma_bar_angles,m_params.icp_prior_strength);
	}

	//set points to register
	this->setRayTracedScan(icp);
	if(m_params.detect_object_in_hand && m_haveObjectCloud){
		//TODO: put back in. maybe allow optional (object adjust as well)
//		icp.setGraspedObjectToRegister(m_downsampledObjectCloud,m_downsampledObjectNormals);
		if(m_params.allow_object_adjustment)
			icp.setObjectAdjustmentEnabled(predictedObjAdj,sigma_bar_object);
	}

	//set whether calibration is allowed
	if(m_params.allow_calibration_adjustment){
		icp.setCalibAdjustmentEnabled(predictedCalibAdj,sigma_bar_calib);
	}

	// set initial valid links (e.g. ignore upper arm)
	//TODO: use occlusion information (particularly important for fingers)
	std::vector<bool> linkInCamera(16,true);
	for(int link=0; link<m_params.first_link_in_camera; link++){
		linkInCamera[link] = false;
	}
	icp.setInitialTargetLinkExistence(linkInCamera);

	//SURF stuff
	std::vector<Keypoint> validKeypoints;
	std::vector<std::vector<float> > validDescriptors;
	std::vector<rgbd::eigen::Vector3f> validPoints,validNormals;
	std::vector<std::pair<int, int> > surfPairs;

	if(imagePtr.get() != NULL){
		//temporary structures
		std::vector<Keypoint> keypoints;
		std::vector<std::vector<float> > descriptors;
		std::vector<rgbd::eigen::Vector3f> featurePoints;
		std::vector<bool> featureValidity;
		std::vector<unsigned int> cloudIndices;

		if(useSift){
			m_extractor.extractSIFT(imagePtr,keypoints,descriptors);
		}
		else{
			m_extractor.extractSURF(imagePtr,keypoints,descriptors,hessianThreshold,extendedDescriptors);
		}
		//extract3DPoints(keypoints,radiusRemoved,featurePoints,featureValidity,m_xChannel,m_yChannel);
		unsigned int xRes = 640;
		unsigned int yRes = 480;
		extract3DPoints(keypoints,radiusRemoved,featurePoints,featureValidity,cloudIndices,xRes,yRes,m_xChannel,m_yChannel);
		extractValidPoints(keypoints,descriptors,featurePoints,featureValidity,
				validKeypoints,validDescriptors,validPoints);
		extractValidNormals(keypoints,radiusRemoved,validNormals,m_xChannel,m_yChannel);
		std::cout<<"Valid keypoints: "<<validKeypoints.size()<<" out of "<<keypoints.size()<<std::endl;

		if(matchKeypoints){
			//find SURF correspondences
			//Note: looking up pairs in reverse order of the way we'll use them
			if(!approxNearest){
				surfPairs =	findSURFPairs(validKeypoints,validDescriptors,
						m_objectKeypoints,m_objectDescriptors,numThreads);
			}
			else{
				surfPairs = flannFindSURFPairs(validKeypoints,validDescriptors,
						m_objectKeypoints,m_objectDescriptors);
			}
			std::cout<<"Found "<<surfPairs.size()<<" correspondences with previous keypoints"<<std::endl;

			rgbd::eigen::Transform3f ransac_transform;
			std::vector<std::pair<int, int> > ransac_inliers; // not used
			bool ransacSuccess = runRANSAC(validPoints,m_objectFeaturePoints,
					surfPairs,ransacInlierDist, ransac_transform, ransac_inliers,
					ransacNumSamples,ransacSampleSize,ransacMinSampleDist);
			if(ransacSuccess && ransac_inliers.size() >= minRansacMatches){
				std::vector<std::pair<int, int> > inlierPairs;
				getInlierCorrespondences(validPoints,m_objectFeaturePoints,
					surfPairs,ransacInlierDist,ransac_transform,inlierPairs);

				//construct the inputs for icp
				std::vector<rgbd::eigen::Vector3f> modelPoints(inlierPairs.size());
				std::vector<rgbd::eigen::Vector3f> modelNormals(inlierPairs.size());
				std::vector<rgbd::eigen::Vector3f> targetPoints(inlierPairs.size());
				std::vector<rgbd::eigen::Vector3f> targetNormals(inlierPairs.size());
				std::vector<OpenRAVE::KinBody::LinkPtr> links(inlierPairs.size());
				std::vector<bool> linkIsObject(inlierPairs.size(),true);

				for(unsigned int i=0; i<inlierPairs.size(); i++){
					modelPoints[i] = m_objectFeaturePoints[inlierPairs[i].second];
					modelNormals[i] = m_objectFeatureNormals[inlierPairs[i].second];
					targetPoints[i] = validPoints[inlierPairs[i].first];
					targetNormals[i] = validNormals[inlierPairs[i].first];
				}

				icp.setFixedCorrespondences(modelPoints,modelNormals,links,
						linkIsObject,targetPoints,targetNormals);
			}
		}
	}

	std::vector<float> icpResult = icp.runICP();
	std::vector<float> icpAngles;
	rgbd::eigen::Transform3f icpCalibVec,icpObjVec;
	separateOutState(icpResult,icpAngles,icpCalibVec,icpObjVec);

	//store some parts of the icp results for visualization and such
	m_lastICPAngles = icpAngles;
	icp.getPointsToRegister(m_lastICPToRegister,m_lastICPLinks,
			m_lastICPNormals,m_lastICPAcquisitionAngles);
	if(retrieveCorrespondences){
		icp.getCorrespondenceIndices(icpResult,m_lastICPCorrespondences
				,m_lastICPUseCorrespondences,m_lastICPWeights);
	}
	m_lastTargetCloud = target;
	m_lastICPTargetPts = icp.getTargetPoints();
	icp.getFixedPointRange(m_lastFixedPointStart,m_lastFixedPointEnd);

	//measurement uncertainty
	rgbd::eigen::MatrixXf Q = this->getICPCovariance();

	//throw out outliers
	std::vector<bool> anglesRegistered = icp.getAnglesRegistered();
	std::vector<unsigned int> validMeasurements =
		this->getDimensionsToUse(predictedMean,sigma_bar,stdToEigen(icpResult),anglesRegistered);
	unsigned int sub_size = validMeasurements.size();

	std::cout<<"num valid measurements: "<<sub_size<<std::endl;

	//incorporate the measurement if any components are valid
	if(sub_size > 0){

		//get the non-outlier submatrices of sigma_bar and Q
		rgbd::eigen::MatrixXf sub_sigma_bar = this->reduceMatrixDimensions(sigma_bar,validMeasurements);
		rgbd::eigen::MatrixXf sub_Q = this->reduceMatrixDimensions(Q,validMeasurements);

		//get the subvectors of icp result and predicted mean
		rgbd::eigen::VectorXf sub_icp_result = this->reduceVectorDimensions(stdToEigen(icpResult),validMeasurements);
		rgbd::eigen::VectorXf sub_predicted_mean = this->reduceVectorDimensions(predictedMean,validMeasurements);

		//perform the state update
		rgbd::eigen::MatrixXf sub_K = sub_sigma_bar * (sub_sigma_bar + sub_Q).inverse();
		rgbd::eigen::VectorXf sub_new_mean = sub_predicted_mean + sub_K*(sub_icp_result - sub_predicted_mean);
		rgbd::eigen::MatrixXf sub_new_covariance = (rgbd::eigen::MatrixXf::Identity(sub_size,sub_size) - sub_K)*sub_sigma_bar;

		//fill in the full newMean
		//use predicted mean for anything we don't have valid measurement for
		m_currentMean = eigenToStd(predictedMean);
		for(unsigned int i=0; i<sub_size; i++){
			m_currentMean[validMeasurements[i]] = sub_new_mean(i);
		}

		//fill in the new covariance
		//use sigma_bar (predicted covariance) for anything we don't have valid covariance for
		m_currentCovariance = sigma_bar;
		for(unsigned int i=0; i<sub_size; i++){
			for(unsigned int j=0; j<sub_size; j++){
				m_currentCovariance(validMeasurements[i],validMeasurements[j]) =
					sub_new_covariance(i,j);
			}
		}


	} //end if sub_size > 0
	else{
		m_currentMean = eigenToStd(predictedMean);
		m_currentCovariance = sigma_bar;
	}

//	std::cout<<"New covariance matrix: "<<std::endl;
//	std::cout<<m_currentCovariance<<std::endl;

	std::cout<<"Kalman Updated. Results: predicted mean, icp result, new mean "<<std::endl;
	for(unsigned int i=0; i<icpResult.size(); i++)
		std::cout<<predictedMean(i)<<", "<<icpResult[i]<<", "<<m_currentMean[i]<<std::endl;


	//update object model if any
	if(m_params.detect_object_in_hand){
		bool detected = this->updateObjectModel(radiusRemoved,icpResult);

		if(detected && imagePtr.get() != NULL){
			this->updateObjectFeatures(icpResult,validKeypoints,
					validDescriptors,validPoints,validNormals,surfPairs);
		}


		if(detected){
			m_haveObjectCloud = true;
		}
	}
	else{
		//it's a lot faster when we're not doing object stuff
		//to even it out, do a sleep
		float secSleep = m_params.no_detection_sleep;
		usleep(secSleep*1E6);
		m_haveObjectCloud = false;
	}
}

void
JointAngleKalmanFilter::setInitialState(
		std::vector<float> &meanAngles,
		rgbd::eigen::MatrixXf &covariance)
{
	m_numAngles = m_inter->getNumDOF();
	m_lastReportedAngles = meanAngles;
	rgbd::eigen::Transform3f identity;
	identity.setIdentity();
	m_currentMean = constructState(meanAngles,identity,identity);
	m_currentCovariance = covariance;
}

std::vector<unsigned int>
JointAngleKalmanFilter::getDimensionsToUse(
			const rgbd::eigen::VectorXf & predictedState,
			const rgbd::eigen::MatrixXf & predictedCovariance,
			const rgbd::eigen::VectorXf & measuredState,
			const std::vector<bool> & anglesRegistered)
{
	float maxStandardDevs = m_params.outlier_standard_deviations;
	bool throwOutOutliers = false;

	rgbd::eigen::VectorXf stateDiff = measuredState-predictedState;

	//for now, reject everything or nothing
	float stDevs = sqrt((stateDiff.transpose()*predictedCovariance.inverse()*stateDiff)(0,0));

	if(stDevs >= maxStandardDevs && throwOutOutliers){
		return std::vector<unsigned int>(0);
	}

	//fill in the list of valid indices
	std::vector<unsigned int> validIndices;
	for(int i=0; i<predictedState.size(); i++){
		if(anglesRegistered[i]){
			validIndices.push_back((unsigned int) i);
		}
	}

	if(m_params.allow_calibration_adjustment){
		for(unsigned int i=0; i<7; i++){
			validIndices.push_back(m_numAngles+i);
		}
	}
	if(m_params.allow_object_adjustment && m_haveObjectCloud){
		for(unsigned int i=0; i<7; i++){
			validIndices.push_back(m_numAngles+7+i);
		}
	}

	return validIndices;
}

rgbd::eigen::MatrixXf
JointAngleKalmanFilter::getInitialCovariance()
{
	unsigned int dimensions = m_inter->getNumDOF()+14;
	rgbd::eigen::MatrixXf initCovariance = rgbd::eigen::MatrixXf::Zero((int)dimensions,(int)dimensions);

	for(unsigned int i=0; i<dimensions; i++){
		float uncertainty;
		if(i<m_numAngles)
			uncertainty = m_params.init_joint_uncertainty;
		else if(i<m_numAngles+4)
			uncertainty = m_params.init_camera_quaternion_uncertainty;
		else if(i<m_numAngles+7)
			uncertainty = m_params.init_camera_trans_uncertainty;
		else if(i<m_numAngles+11)
			uncertainty = m_params.init_object_quaternion_uncertainty;
		else
			uncertainty = m_params.init_object_trans_uncertainty;

		initCovariance(i,i) = pow(uncertainty,2);
	}

	return initCovariance;
}

rgbd::eigen::MatrixXf
JointAngleKalmanFilter::getMotionUpdateCovariance(
		rgbd::eigen::VectorXf const& reportedChange)
{
	float motionUncertaintyRatio = m_params.motion_uncertainty_ratio;
	float minAngleUncertainty = m_params.min_motion_uncertainty;

	rgbd::eigen::MatrixXf toReturn = rgbd::eigen::MatrixXf::Zero((int)m_numAngles+14,(int)m_numAngles+14);

	//motion only affects joint angle estimates, not camera calibration or
	//object/hand relation. if we want to model possible camera motion or
	//possible object shifting, we can add in terms for that
	for(unsigned int i=0; i<m_numAngles; i++){
		float motionUncertainty = motionUncertaintyRatio * reportedChange[i];
		if(motionUncertainty < minAngleUncertainty)
			motionUncertainty = minAngleUncertainty;
		toReturn(i,i) = pow(motionUncertainty,2);
	}

	return toReturn;
}

rgbd::eigen::MatrixXf
JointAngleKalmanFilter::getICPCovariance()
{
	unsigned int dimensions = m_numAngles+14;

	rgbd::eigen::MatrixXf toReturn = rgbd::eigen::MatrixXf::Zero((int)dimensions,(int)dimensions);
	for(unsigned int i=0; i<dimensions; i++){
		float uncertainty;
		if(i<4)
			uncertainty = m_params.icp_arm_uncertainty;
		else if(i<7)
			uncertainty = m_params.icp_wrist_uncertainty;
		else if(i<m_numAngles)
			uncertainty = m_params.icp_finger_uncertainty;
		else if(i<m_numAngles+4)
			uncertainty = m_params.icp_camera_quaternion_uncertainty;
		else if(i<m_numAngles+7)
			uncertainty = m_params.icp_camera_trans_uncertainty;
		else if(i<m_numAngles+11)
			uncertainty = m_params.icp_object_quaternion_uncertainty;
		else
			uncertainty = m_params.icp_object_trans_uncertainty;

		toReturn(i,i) = pow(uncertainty,2);
	}

	return toReturn;
}


void JointAngleKalmanFilter::getCurrentRayTracedScan(
		std::vector<rgbd::eigen::Vector3f> &points,
		std::vector<OpenRAVE::KinBody::LinkPtr > &links,
		std::vector<float> &acquisitionAngles)
{
	points = m_points;
	links = m_links;
	acquisitionAngles = m_acquisitionAngles;
}

rgbd::eigen::MatrixXf
JointAngleKalmanFilter::reduceMatrixDimensions(
		const rgbd::eigen::MatrixXf & matrix,
		const std::vector<unsigned int> & dimensions)
{
	rgbd::eigen::MatrixXf toReturn((int)dimensions.size(),(int)dimensions.size());
	for(unsigned int i=0; i<dimensions.size(); i++)
	{
		for(unsigned int j=0; j<dimensions.size(); j++)
		{
			toReturn(i,j) = matrix(dimensions[i],dimensions[j]);
		}
	}
	return toReturn;
}

rgbd::eigen::VectorXf
JointAngleKalmanFilter::reduceVectorDimensions(
		const rgbd::eigen::VectorXf & vector,
		const std::vector<unsigned int> & dimensions)
{
	rgbd::eigen::VectorXf toReturn((int)dimensions.size());
	for(unsigned int i=0; i<dimensions.size(); i++)
	{
		toReturn(i) = vector(dimensions[i]);
	}
	return toReturn;
}

void JointAngleKalmanFilter::setRayTracedScan(registration::JointAngleICP &icp)
{
	bool alwaysGetScan = false;
	unsigned int pixelIncrement = m_params.ray_tracing_pixel_increment;
	float maxAngleDiff = m_params.ray_tracing_max_angle_diff;


	bool getNewScan = false;
	//see if we've acquired a scan at all
	if(m_points.empty() || alwaysGetScan){
		getNewScan = true;
	}
	//if so, see if it's "recent" enough
	else{
		std::vector<float> icpAngles = icp.getInitialAngles();
		for(unsigned int i=0; i<icpAngles.size(); i++){
			float diff = icpAngles[i] - m_acquisitionAngles[i];
			if(diff < 0)
				diff *= -1;
			if(diff > maxAngleDiff){
//				std::cout<<"Angle "<<i<<" outside of acceptable ray-traced scan range"<<std::endl;
//				std::cout<<"Start state: "<<icpAngles[i]<<", acquisition: "<<m_acquisitionAngles[i]<<
//					", diff: "<<diff<<", max allowed: "<<maxAngleDiff<<std::endl;
				getNewScan = true;
			}
		}
	}

	//get the new scan if necessary
	if(getNewScan){

		std::cout<<"Updating Kalman Filter's Ray-Traced Scan"<<std::endl;

		std::vector<float> angles;
		rgbd::eigen::Matrix<float,7,1> calibAdj,objectAdj;
		separateOutStateToVectors(m_currentMean,angles,calibAdj,objectAdj);

		m_inter->setJointAngles(angles);
		m_acquisitionAngles = angles;

		//get a point cloud
		std::vector<std::vector<rgbd::eigen::Vector3f> > points;
		std::vector<std::vector<rgbd::eigen::Vector3f> > colors;
		std::vector<std::vector<rgbd::eigen::Vector3f> > normals;
		std::vector<std::vector<OpenRAVE::KinBody::LinkPtr > > links;
		std::vector<std::vector<bool> > validity;
		m_inter->sample3dPoints(points,colors,links,normals,validity,icp.usesGlobalCoords(),pixelIncrement);

		//convert to 1D structures rather than sparse 2D
		std::vector<rgbd::eigen::Vector3f> validColors;
		m_inter->convertTo1DVectors(points,m_points,colors,validColors,normals,m_normals,links,m_links,validity);
	}

	//set whatever is the current scan
	icp.setRayTracedScan(m_points,m_links,m_normals,m_acquisitionAngles);
}

bool
JointAngleKalmanFilter::updateObjectModel(sensor_msgs::PointCloud const& newCloud,
		std::vector<float> const& icpResult)
{
	//note that newCloud is in the global coordinates from the initial
	//calibration (i.e. newCloud = origCalib * cameraCloud)
	//need to use calib = calibAdj * origCalib

	float maxEdgeDist = m_params.object_segmentation_max_edge_dist;
	unsigned int minResultPoints = m_params.object_segmentation_min_points;
	float handRemovalDist= m_params.object_segmentation_min_hand_dist;
	float proximityForAdding = m_params.object_segmentation_proximity;
	float minDistAlongWrist = m_params.object_segmentation_min_wrist_dist;

	bool densityDownsample = true;
	float radius = m_params.object_density_downsample_radius; //1cm across circle
	unsigned int maxPtsInRadius = 1;

	std::cout<<"Updating object model"<<std::endl;

	//separate out joint angles
	std::vector<float> estimatedJointAngles;
	rgbd::eigen::Transform3f calibAdj,objectAdj;
	separateOutState(icpResult,estimatedJointAngles,calibAdj,objectAdj);

	sensor_msgs::PointCloud globalCloud;
	transform_point_cloud(calibAdj,newCloud,globalCloud);
	sensor_msgs::PointCloud segmentedCloud = m_segmenter.segmentUsingHandInformation(
			globalCloud,estimatedJointAngles,m_colorizedCloud,m_inter,
			maxEdgeDist,minResultPoints,handRemovalDist,proximityForAdding,
			minDistAlongWrist,m_params.object_segmentation_grid_increment);

	rgbd::eigen::Transform3f globalToCurrentPalm = m_inter->getInverseLinkTransforms(estimatedJointAngles)[7];
	rgbd::eigen::Transform3f globalToOrigPalm = invertTransform(objectAdj)*globalToCurrentPalm;

	sensor_msgs::PointCloud segmentInOrigPalm;
	transform_point_cloud(globalToOrigPalm,segmentedCloud,segmentInOrigPalm);

	m_lastObjectCloudUpdate = segmentInOrigPalm;
	bool merged = this->mergeCloudWithModel(segmentInOrigPalm);

	if(!merged)
		return false;

	if(densityDownsample){
		sensor_msgs::PointCloud downsampledCloud;
		std::vector<rgbd::eigen::Vector3f> downsampledNormals;
		std::deque<unsigned int> acceptedIndices = getDensityDownsamplingIndices(
			m_downsampledObjectCloud,radius,maxPtsInRadius);
		downsampleFromIndices(m_downsampledObjectCloud,downsampledCloud,acceptedIndices);
		downsampleFromIndices(m_downsampledObjectNormals,downsampledNormals,acceptedIndices);
		m_downsampledObjectCloud = downsampledCloud;
		m_downsampledObjectNormals = downsampledNormals;
	}

	std::cout<<"Object model update complete"<<std::endl;

	return true;
}

bool
JointAngleKalmanFilter::mergeCloudWithModel(sensor_msgs::PointCloud const& cloud)
{
	//note that at this point, the cloud has been transformed to the hand
	//coordinate system

	//make sure we don't random downsample too much
	//when in doubt, let the density downsample do it instead
	float downsampleRate = m_params.object_downsample_rate;
	unsigned int minPoints = m_params.object_segmentation_min_points/2;
	if(cloud.points.size() < minPoints)
		return false;

	//downsample
	sensor_msgs::PointCloud downsampledCloud;
	std::deque<unsigned int> acceptedIndices =
			getRandomDownsamplingIndices(cloud,downsampleRate,minPoints);
	downsampleFromIndices(cloud,downsampledCloud,acceptedIndices);
	unsigned int downsampledPoints = downsampledCloud.points.size();

	//get normals of the downsampled, incoming cloud
	//not that normals are computed on a per-incoming-cloud basis in case of slight misregistrations
	//it is also done after downsampling simply for purposes of speed
	std::vector<rgbd::eigen::Vector3f> newCloudNormals(downsampledCloud.points.size());
	bool hasNormals = pointCloudNormalsToEigenNormals(downsampledCloud,newCloudNormals);

	if(!hasNormals){
		int normalsK=m_params.icp_params.normals_k;
		if(normalsK >= (int)downsampledPoints)
			normalsK = downsampledPoints - 1;

		geometry_msgs::PointStamped pointStamped;
		pointStamped.header.frame_id = "frame";
		pointStamped.point.x = pointStamped.point.y = pointStamped.point.z = 0.0;
		cloud_geometry::nearest::computePointCloudNormals(downsampledCloud,normalsK,pointStamped);

		pointCloudNormalsToEigenNormals(downsampledCloud,newCloudNormals);
	}


	if(!m_haveObjectCloud){
		m_objectCloud = cloud;
		m_downsampledObjectCloud = downsampledCloud;
		m_downsampledObjectNormals = newCloudNormals;
		return true;
	}

	unsigned int origObjPts = m_objectCloud.points.size();
	unsigned int cloudPts = cloud.points.size();
	unsigned int newObjPts = origObjPts+cloudPts;

	unsigned int origDownsampledPts = m_downsampledObjectCloud.points.size();
	unsigned int incomingDownsampledPts = downsampledPoints;
	unsigned int newDownsampledPts = origDownsampledPts + incomingDownsampledPts;

	//resize the clouds
	m_objectCloud.set_points_size(newObjPts);
	m_downsampledObjectCloud.set_points_size(newDownsampledPts);
	m_downsampledObjectNormals.resize(newDownsampledPts);
	for(unsigned int chan=0; chan<m_objectCloud.get_channels_size(); chan++){
		m_objectCloud.channels[chan].set_values_size(newObjPts);
	}
	for(unsigned int chan=0; chan<m_downsampledObjectCloud.get_channels_size(); chan++){
		m_downsampledObjectCloud.channels[chan].set_values_size(newDownsampledPts);
	}

	//add in the new points
	for(unsigned int i=0; i<cloudPts; i++){
		m_objectCloud.points[origObjPts+i] = cloud.points[i];
		for(unsigned int chan=0; chan<m_objectCloud.get_channels_size(); chan++){
			m_objectCloud.channels[chan].values[origObjPts+i] =
					cloud.channels[chan].values[i];
		}
	}
	//same for downsampled stuff
	for(unsigned int i=0; i<incomingDownsampledPts; i++){
		m_downsampledObjectCloud.points[origDownsampledPts+i] = downsampledCloud.points[i];
		m_downsampledObjectNormals[origDownsampledPts+i] = newCloudNormals[i];

		for(unsigned int chan=0; chan<m_downsampledObjectCloud.get_channels_size(); chan++){
			m_downsampledObjectCloud.channels[chan].values[origDownsampledPts+i] =
					downsampledCloud.channels[chan].values[i];
		}
	}

	return true;

}

void
JointAngleKalmanFilter::
updateObjectFeatures(std::vector<float> const& icpResult,
		std::vector<Keypoint> const& validKeypoints,
		std::vector<std::vector<float> > const& validDescriptors,
		std::vector<rgbd::eigen::Vector3f> const& validPoints,
		std::vector<rgbd::eigen::Vector3f> const& validNormals,
		std::vector<std::pair<int, int> > const& surfPairs)
{
	//separate out joint angles. get transformation info
	std::vector<float> estimatedJointAngles;
	rgbd::eigen::Transform3f calibAdj,objectAdj;
	separateOutState(icpResult,estimatedJointAngles,calibAdj,objectAdj);
	rgbd::eigen::Transform3f globalToCurrentPalm = m_inter->getInverseLinkTransforms(estimatedJointAngles)[7];
	rgbd::eigen::Transform3f globalToOrigPalm = invertTransform(objectAdj)*globalToCurrentPalm;
	rgbd::eigen::Transform3f totalTransform = globalToOrigPalm*calibAdj;

	std::vector<std::vector<bool> > segmentationMap;
	m_segmenter.getSegmentationMap(segmentationMap);

	std::vector<bool> keepKeypoint(validPoints.size(),true);
	//discard features that had correspondences
	for(unsigned int i=0; i<surfPairs.size(); i++){
		int index = surfPairs[i].first;
		keepKeypoint[index] = false;
	}
	//discard features not on the object
    for(unsigned int i = 0; i < validKeypoints.size(); i++)
    {
        int x = round(validKeypoints[i].x);
        int y = round(validKeypoints[i].y);
        if(!segmentationMap[x][y])
        	keepKeypoint[i] = false;
    }

    //downsample to just the ones we want
	std::vector<Keypoint> newKeypoints;
	std::vector<std::vector<float> > newDescriptors;
	std::vector<rgbd::eigen::Vector3f> newFeaturePoints;
	std::vector<rgbd::eigen::Vector3f> newFeatureNormals;
	for(unsigned int i=0; i<validPoints.size(); i++){
		if(keepKeypoint[i]){
			newKeypoints.push_back(validKeypoints[i]);
			newDescriptors.push_back(validDescriptors[i]);
			newFeaturePoints.push_back(totalTransform*validPoints[i]);
			newFeatureNormals.push_back(totalTransform.linear()*validNormals[i]);
		}
	}

	if(!m_haveObjectCloud){
		m_objectKeypoints = newKeypoints;
		m_objectDescriptors = newDescriptors;
		m_objectFeaturePoints = newFeaturePoints;
		m_objectFeatureNormals = newFeatureNormals;
	}
	else{
		m_objectKeypoints.insert(m_objectKeypoints.begin(),
				newKeypoints.begin(),newKeypoints.end());
		m_objectDescriptors.insert(m_objectDescriptors.begin(),
				newDescriptors.begin(),newDescriptors.end());
		m_objectFeaturePoints.insert(m_objectFeaturePoints.begin(),
				newFeaturePoints.begin(),newFeaturePoints.end());
		m_objectFeatureNormals.insert(m_objectFeatureNormals.begin(),
				newFeatureNormals.begin(),newFeatureNormals.end());
	}


	std::cout<<"Added "<<newKeypoints.size()<<" keypoints to collection"<<std::endl;
	std::cout<<"Collection now has "<<m_objectKeypoints.size()<<" keypoints"<<std::endl;
}

}
