/*
 * kalman_node.cpp
 *
 *  Created on: Aug 26, 2009
 *      Author: mkrainin
 */

#include <ros/node_handle.h>
#include <ros/publisher.h>
#include <ros/subscriber.h>
#include <topic_synchronizer2/topic_synchronizer.h>
#include <point_cloud_mapping/cloud_io.h>
#include <sensor_msgs/PointCloud.h>
#include <sensor_msgs/Image.h>
#include <visualization_msgs/Marker.h>
#include <pr_msgs/WAMState.h>
#include <pr_msgs/WAMJointState.h>
#include <pr_msgs/BHState.h>
#include <point_cloud_icp/registration/JointAngleKalmanFilter.h>
#include <point_cloud_icp/registration/PointCloudSegmenter.h>
#include <point_cloud_icp/openrave_interface.h>
#include <point_cloud_icp/registration/icp_utility.h>
#include "rgbd_util/eigen/Core"

#include <string>
#include <sstream>
#include <iomanip>

using namespace std;

namespace registration{

class KalmanNode{

public:
	KalmanNode(ros::NodeHandle& node)
	: m_node (node), m_tf_frame("base_link"), m_filter(&m_inter), m_sync(&registration::KalmanNode::sync_cb, this)
	{

		//load the robot
		std::string dataPath,file;
		m_node.param("openrave_data_path", dataPath, OpenRAVEInterface::readOpenRAVEDataPath());
		m_node.param("robot_file", file, (string)"/robots/barrettwam.robot.xml");
		m_node.param("robot_rotate_joint7_90", m_rotate90, true);
		bool loaded = m_inter.loadRobot(dataPath,file);

		assert(loaded);

		std::cout<<"Robot loaded"<<std::endl;

		double termTime;
		m_node.param("termination_seconds", termTime, 0.0);
		m_terminationTime = termTime;

		//set the camera params
		float pKK[4];
		double pKK0,pKK1,pKK2,pKK3;
		int xres,yres;
		m_node.param("virtual_camera_x_res", xres, 1000);
		m_node.param("virtual_camera_y_res", yres, 800);
		m_node.param("virtual_camera_intrinsic_0", pKK0, 800.0);
		m_node.param("virtual_camera_intrinsic_1", pKK1, 800.0);
		m_node.param("virtual_camera_intrinsic_2", pKK2, xres/2.0);
		m_node.param("virtual_camera_intrinsic_3", pKK3, yres/2.0);
		pKK[0] = pKK0;
		pKK[1] = pKK1;
		pKK[2] = pKK2;
		pKK[3] = pKK3;
		m_inter.setCameraParams(xres,yres,pKK);

		m_node.param("use_camera_images", m_useCameraImages, true);

		//set the camera transform
		double xloc,yloc,zloc;
		m_node.param("camera_loc_x", xloc, -0.065543);
		m_node.param("camera_loc_y", yloc, 0.552191);
		m_node.param("camera_loc_z", zloc, 0.186802);
		rgbd::eigen::Vector3f translation(xloc,yloc,zloc);

		bool readQuaternion,calibFromRave;
		m_node.param("camera_read_quaternion",readQuaternion,false);
		m_node.param("calib_from_rave",calibFromRave,false);
		rgbd::eigen::Transform3f camTransform;
		//read the calibration
		if(readQuaternion){
			double qw,qx,qy,qz;
			m_node.param("camera_qw", qw, 1.0);
			m_node.param("camera_qx", qx, 0.0);
			m_node.param("camera_qy", qy, 0.0);
			m_node.param("camera_qz", qz, 0.0);
			rgbd::eigen::Quaternionf q(qw,qx,qy,qz);
			camTransform = rgbd::eigen::Transform3f(q);
			camTransform.pretranslate(translation);

		}
		else{
			double axisx,axisy,axisz,angle;
			m_node.param("camera_axis_x", axisx, 1.0);
			m_node.param("camera_axis_y", axisy, 0.0);
			m_node.param("camera_axis_z", axisz, 0.0);
			m_node.param("camera_angle", angle, 0.0);
			rgbd::eigen::AngleAxisf angleAxis(angle,rgbd::eigen::Vector3f(axisx,axisy,axisz));
			camTransform = rgbd::eigen::Transform3f(angleAxis);
			camTransform.pretranslate(translation);

		}
		//set the calibration
		if(!calibFromRave){
			//directly computed calibration as opposed to the screwed up
			//ones given by openrave, so use the "rotation adjusted" variant
			m_inter.setRotationAdjustedCameraTranform(camTransform);
		}
		else{
			//calibration from openrave. use the non "rotation adjusted" variant
			m_inter.setCameraTransform(camTransform);
		}


//		m_filter = JointAngleKalmanFilter(&m_inter);
		KalmanParams params;

		//uncertainties
		float degToRad = M_PI/180;
		double initJointDegs,initCamTrans,initCamQ,initObjectTrans,initObjectQ;
		double minMotionDegs,motionRatio,outlierStDevs;
		double armDegs,wristDegs,fingerDegs,icpCamTrans,icpCamQ,icpObjectTrans,icpObjectQ;
		m_node.param("icp_arm_uncertainty_degrees", armDegs, 5.0);
		m_node.param("icp_wrist_uncertainty_degrees", wristDegs, 10.0);
		m_node.param("icp_finger_uncertainty_degrees", fingerDegs, 10.0);
		m_node.param("icp_camera_trans_uncertainty", icpCamTrans, .05);
		m_node.param("icp_camera_quaternion_uncertainty", icpCamQ, .05);
		m_node.param("icp_object_trans_uncertainty", icpObjectTrans, .02);
		m_node.param("icp_object_quaternion_uncertainty", icpObjectQ, .02);
		params.icp_arm_uncertainty = armDegs*degToRad;
		params.icp_wrist_uncertainty = wristDegs*degToRad;
		params.icp_finger_uncertainty = fingerDegs*degToRad;
		params.icp_camera_trans_uncertainty = icpCamTrans;
		params.icp_camera_quaternion_uncertainty = icpCamQ;
		params.icp_object_trans_uncertainty = icpObjectTrans;
		params.icp_object_quaternion_uncertainty = icpObjectQ;

		m_node.param("min_motion_uncertainty_degrees", minMotionDegs, 3.0);
		m_node.param("motion_uncertainty_ratio", motionRatio, 0.1);
		m_node.param("outlier_standard_deviations", outlierStDevs, 1.5);
		params.min_motion_uncertainty = minMotionDegs*degToRad;
		params.motion_uncertainty_ratio = motionRatio;
		params.outlier_standard_deviations = outlierStDevs;

		m_node.param("init_joint_uncertainty", initJointDegs, 5.0);
		m_node.param("init_camera_trans_uncertainty", initCamTrans, .05);
		m_node.param("init_camera_quaternion_uncertainty", initCamQ, .05);
		m_node.param("init_object_trans_uncertainty", initObjectTrans, .02);
		m_node.param("init_object_quaternion_uncertainty", initObjectQ, .02);
		params.init_joint_uncertainty = initJointDegs*degToRad;
		params.init_camera_trans_uncertainty = initCamTrans;
		params.init_camera_quaternion_uncertainty = initCamQ;
		params.init_object_trans_uncertainty = initObjectTrans;
		params.init_object_quaternion_uncertainty = initObjectQ;

		double maxRadius,targetDownsample;
		m_node.param("radius_downsample_radius",maxRadius,1.0);
		m_node.param("target_downsample_rate",targetDownsample,.2);
		params.radius_downsample_radius = maxRadius;
		params.target_downsample_rate = targetDownsample;

		//ray tracing
		double maxDiffDegs;
		m_node.param("icp_ray_tracing_pixel_increment", params.ray_tracing_pixel_increment, 2);
		m_node.param("icp_ray_tracing_max_degree_diff", maxDiffDegs, 10.0);
//		m_node.param("display_ray_tracing_pixel_increment", m_displayPixelIncrement, 4);
		params.ray_tracing_max_angle_diff = maxDiffDegs*degToRad;
		params.icp_params.ray_tracing_pixel_increment = params.ray_tracing_pixel_increment;

		//what's visible
		m_node.param("first_link_in_camera", params.first_link_in_camera, 4);

		//icp params
		double maxDist,interpolation,upperWeight,lowerWeight,handWeight,fixedWeight,
			minAngle,minErrorFrac,minFingerRatio,maxFingerDist,priorStrength;
		m_node.param("icp_max_correspondence_dist", maxDist, -1.0);
		m_node.param("icp_max_rounds", params.icp_params.max_rounds, 3);
		m_node.param("icp_min_error_diff_fraction", minErrorFrac, 0.0001);
		m_node.param("icp_min_angle_diff_degrees", minAngle, 0.01);
		m_node.param("icp_interpolation_rate", interpolation, 0.4);
		m_node.param("icp_use_numeric_gradient", params.icp_params.numeric_gradient, false);
		m_node.param("icp_max_optimizer_iterations",
				params.icp_params.max_optimizer_iterations, 0);
		m_node.param("icp_use_joint_hierarchy", params.icp_params.use_joint_hierarchy, true);
		m_node.param("icp_joint_hierarchy_steps", params.icp_params.joint_hierarchy_steps, 5);
		m_node.param("icp_upper_arm_weight", upperWeight, 1.0);
		m_node.param("icp_lower_arm_weight", lowerWeight, 1.0);
		m_node.param("icp_hand_weight", handWeight, 1.0);
		m_node.param("icp_fixed_corr_weight", fixedWeight, 1.0);
		m_node.param("icp_min_finger_point_ratio", minFingerRatio, .8);
		m_node.param("icp_max_finger_point_dist", maxFingerDist, .005);
		m_node.param("icp_normals_k", params.icp_params.normals_k, 40);
		m_node.param("icp_prior_strength", priorStrength, .05);
		params.icp_params.max_distance = maxDist;
		params.icp_params.interpolation_rate = interpolation;
		params.icp_params.min_error_diff_fraction = minErrorFrac;
		params.icp_params.min_angle_diff = minAngle*degToRad;
		params.icp_params.upper_arm_weight = upperWeight;
		params.icp_params.lower_arm_weight = lowerWeight;
		params.icp_params.hand_weight = handWeight;
		params.icp_params.fixed_corr_weight = fixedWeight;
		params.icp_params.min_finger_point_ratio = minFingerRatio;
		params.icp_params.max_finger_point_dist = maxFingerDist;
		params.icp_prior_strength = priorStrength;


		//parameters for detecting objects in hand
		double maxEdgeDist,minHandDist, minWristDist,objectDownsample, objectDensityRadius, proximity, sleep;
		m_node.param("detect_object_in_hand", params.detect_object_in_hand, false);
		m_node.param("allow_calibration_adjustment", params.allow_calibration_adjustment, false);
		m_node.param("allow_object_adjustment", params.allow_object_adjustment, true);
		m_node.param("no_detection_sleep", sleep, 0.0);
		m_node.param("object_segmentation_max_edge_dist", maxEdgeDist, .005);
		m_node.param("object_segmentation_min_hand_dist", minHandDist, .02);
		m_node.param("object_segmentation_min_points", params.object_segmentation_min_points, 1000);
		m_node.param("object_segmentation_proximity", proximity, .1);
		m_node.param("object_segmentation_min_wrist_dist", minWristDist, .2);
		m_node.param("object_downsample_rate", objectDownsample, 0.2);
		m_node.param("object_density_downsample_radius", objectDensityRadius, 0.005);
		m_node.param("object_segmentation_grid_increment",params.object_segmentation_grid_increment,2);
		params.no_detection_sleep = sleep;
		params.object_segmentation_max_edge_dist = maxEdgeDist;
		params.object_segmentation_min_hand_dist = minHandDist;
		params.object_segmentation_min_wrist_dist = minWristDist;
		params.object_segmentation_proximity = proximity;
		params.object_downsample_rate = objectDownsample;
		params.object_density_downsample_radius = objectDensityRadius;


		//set the parameters in the filter
		m_filter.setParams(params);


		double noiseLevel;
    	m_node.param("simulated_noise_max_degrees", noiseLevel, 0.0);
    	m_noiseLevel = noiseLevel*degToRad;

		//read in topics
		m_node.param("real_cloud_topic", m_realCloudTopic, (string)"/stereo_cloud");
		m_node.param("ray_traced_cloud_topic", m_simulatedCloudTopic, (string)"/ray_traced_cloud");
		m_node.param("icp_cloud_topic", m_icpCloudTopic, (string)"/icp_cloud");
		m_node.param("kalman_cloud_topic", m_kalmanCloudTopic, (string)"/kalman_cloud");

		m_node.param("use_joint_state", m_useJointState, false);
		m_node.param("hand_state_topic", m_handStateTopic, (string)"/handstate");
		m_node.param("wam_state_topic", m_wamStateTopic, (string)"/wamstate");
		m_node.param("joint_state_topic", m_jointStateTopic, (string)"/owd/jointstate");
		m_node.param("stereo_cloud_topic", m_stereoCloudTopic, (string)"/primesensor/cloud");
		m_node.param("camera_image_topic", m_cameraImageTopic, (string)"/primesensor/image");
	}

	int start()
	{
		m_reportedStateHistory.clear();
		m_reportedStateHistory.push_front(std::vector<float>(m_inter.getNumDOF()));

		m_stateTimestamps.clear();
		m_stateTimestamps.push_front(ros::Time());

		m_noise = std::vector<float>(m_inter.getNumDOF(),0);

		m_handStateReady = false;
		m_wamStateReady = false;
		m_initialStateSet = false;

		m_cloudCount = 0;
		m_processedTime = 0;
		m_processedClouds = 0;

		m_realCloudPublisher = m_node.advertise<sensor_msgs::PointCloud>(m_realCloudTopic, 1);
		m_targetCloudPublisher = m_node.advertise<sensor_msgs::PointCloud>("/target_cloud", 1);
		m_simulatedCloudPublisher = m_node.advertise<sensor_msgs::PointCloud>(m_simulatedCloudTopic, 1);
		m_icpCloudPublisher = m_node.advertise<sensor_msgs::PointCloud>(m_icpCloudTopic, 1);
		m_kalmanCloudPublisher = m_node.advertise<sensor_msgs::PointCloud>(m_kalmanCloudTopic, 1);
		m_colorizedCloudPublisher = m_node.advertise<sensor_msgs::PointCloud>("/colorized_cloud", 1);
		m_segmentPublisher = m_node.advertise<sensor_msgs::PointCloud>("/segment_cloud", 1);
		m_visualPointPublisher = m_node.advertise<sensor_msgs::PointCloud>("/visual_point", 1);
		m_markerPublisher = m_node.advertise<visualization_msgs::Marker>("correspondence_marker", 1);
		m_normalsPublisher = m_node.advertise<visualization_msgs::Marker>("normals_marker", 1);

		//hand angles
		ros::Subscriber handSubscriber = m_node.subscribe<pr_msgs::BHState>(m_handStateTopic,0,&registration::KalmanNode::processHandState,this);
		//arm angles
		ros::Subscriber wamSubscriber;
		if(!m_useJointState){
			wamSubscriber = m_node.subscribe<pr_msgs::WAMState>(m_wamStateTopic,0,&registration::KalmanNode::processWAMState,this);
		}
		else{
			wamSubscriber = m_node.subscribe<pr_msgs::WAMJointState>(m_jointStateTopic,0,&registration::KalmanNode::processJointState,this);
		}

		//clouds
		ros::Subscriber cloudSubscriber,imageSubscriber;
		unsigned int queueSize=1;
		if(!m_useCameraImages){
			cloudSubscriber = m_node.subscribe<sensor_msgs::PointCloud>(
					m_stereoCloudTopic,queueSize,&registration::KalmanNode::processCloud,this);
		}
		else{
	    	cloudSubscriber = m_node.subscribe(m_stereoCloudTopic, queueSize, m_sync.synchronize(&registration::KalmanNode::cloud_cb, this));
	    	imageSubscriber = m_node.subscribe(m_cameraImageTopic, queueSize, m_sync.synchronize(&registration::KalmanNode::image_cb, this));
		}

		ros::spin();

		return 0;
	}

private:
	ros::NodeHandle& m_node;

//	rgbd::eigen::Transform3f m_icpCalibrationCorrection;

	//publishers
	ros::Publisher m_realCloudPublisher;
	ros::Publisher m_targetCloudPublisher;
	ros::Publisher m_simulatedCloudPublisher;
	ros::Publisher m_icpCloudPublisher;
	ros::Publisher m_kalmanCloudPublisher;
	ros::Publisher m_colorizedCloudPublisher;
	ros::Publisher m_visualPointPublisher;
	ros::Publisher m_markerPublisher;
	ros::Publisher m_normalsPublisher;
	ros::Publisher m_segmentPublisher;

	//topics to publish
	string m_realCloudTopic;
	string m_simulatedCloudTopic;
	string m_icpCloudTopic;
	string m_kalmanCloudTopic;

	//topics to listen to
	bool m_useJointState;
	string m_handStateTopic;
	string m_wamStateTopic;
	string m_jointStateTopic;
	string m_stereoCloudTopic;
	string m_cameraImageTopic;

	//point cloud frame
	string m_tf_frame;

	JointAngleKalmanFilter m_filter;
	OpenRAVEInterface m_inter;

	//flags to tell what's been done
	std::deque<std::vector<float> > m_reportedStateHistory;
	std::deque<ros::Time> m_stateTimestamps;
	bool m_handStateReady;
	bool m_wamStateReady;
	bool m_initialStateSet;

	//noise to add into the reported angles
	float m_noiseLevel;
	std::vector<float> m_noise;

	int m_cloudCount;
	float m_processedTime;
	int m_processedClouds;

	ros::Time m_firstStamp;
	float m_terminationTime;

	bool m_rotate90;

	//synchronization stuff
	TopicSynchronizer m_sync;
	boost::mutex m_data_lock;
	bool m_useCameraImages;
	sensor_msgs::PointCloudConstPtr m_currentCloudPtr;
	sensor_msgs::ImageConstPtr m_currentImagePtr;

	void processHandState(const pr_msgs::BHState::ConstPtr &handState)
	{
		//need there to be a valid timestamp in place already
		//since handstate doesn't have a timestamp
		if(!m_wamStateReady)
			return;

		std::cout<<"Updating hand state"<<std::endl;

		for(unsigned int i=0; i<4; i++){
			m_reportedStateHistory.front()[i+7] = handState.get()->positions[i];
		}

		m_handStateReady = true;

		if(m_wamStateReady){
			m_reportedStateHistory.push_front(std::vector<float>(m_reportedStateHistory.front()));
			m_stateTimestamps.push_front(m_stateTimestamps.front());

//			if(m_reportedStateHistory.size() % 5 == 0){
//				m_inter.setJointAngles(m_reportedStateHistory.front());
//				m_inter.runViewer();
//			}
		}
	}

	void processWAMState(const pr_msgs::WAMState::ConstPtr &wamState)
	{
		std::cout<<"Updating wam state"<<std::endl;

		//WAMState doesn't have timestamps. if you need timestamps,
		//make sure to use jointstate instead
		ros::Time stamp = ros::Time::now();

		for(unsigned int i=0; i<7; i++){
			m_reportedStateHistory.front()[i] = wamState.get()->positions[i];
		}
		if(m_rotate90){
			m_reportedStateHistory.front()[6] -= M_PI_2;
		}
		m_stateTimestamps.front() = stamp;

		m_wamStateReady = true;

		if(m_handStateReady){
			m_reportedStateHistory.push_front(std::vector<float>(m_reportedStateHistory.front()));
			m_stateTimestamps.push_front(m_stateTimestamps.front());
		}
	}

	void processJointState(const pr_msgs::WAMJointState::ConstPtr &wamState)
	{
		std::cout<<"Updating wam state"<<std::endl;

		ros::Time stamp = wamState.get()->header.stamp;

		for(unsigned int i=0; i<7; i++){
			m_reportedStateHistory.front()[i] = wamState.get()->positions[i];
		}
		if(m_rotate90){
			m_reportedStateHistory.front()[6] -= M_PI_2;
		}
		m_stateTimestamps.front() = stamp;

		m_wamStateReady = true;

		if(m_handStateReady){
			m_reportedStateHistory.push_front(std::vector<float>(m_reportedStateHistory.front()));
			m_stateTimestamps.push_front(m_stateTimestamps.front());
		}
	}


	bool getStateNum(ros::Time const& stamp,unsigned int &stateNum)
	{
		//find the joint angles from when the stereo images were captured
		stateNum = 1;
		double secToAddToJoints;
		bool increaseFound = false;
		m_node.param("add_to_joint_timestamp",secToAddToJoints,0.0);
//		std::cout<<"Adding "<<secToAddToJoints<<" to joint timestamps"<<std::endl;

		ros::Duration gapDuration = stamp - m_stateTimestamps[stateNum];
		double shortestGap = gapDuration.toSec() - secToAddToJoints;
		if(shortestGap < 0)
			shortestGap*=-1;
//			std::cout<<"Time difference between current cloud and last received joint "<<
//				"angles is "<<shortestGap<<" seconds"<<std::endl;
		//move back to older messages until timestamps get farter apart
		while(stateNum+1 < m_reportedStateHistory.size()){
			gapDuration = stamp - m_stateTimestamps[stateNum+1];
			double gap = gapDuration.toSec() - secToAddToJoints;
			if(gap < 0)
				gap*=-1;

//				std::cout<<"Next gap is "<<gap<<std::endl;

			if(gap > shortestGap){
				increaseFound = true;
				break;
			}

			shortestGap = gap;
			stateNum++;
		}

		if(!increaseFound){
			std::cout<<"Did not find a point in timestamp history where timestamp difference increased"<<std::endl;
			std::cout<<"Waiting for joint angle history to be populated further"<<std::endl;
			return false;
		}

		if(stateNum == 1){
			std::cout<<"Using last angles"<<std::endl;
		}
		else{
			std::cout<<"Skipping back "<<(stateNum-1)<<" angles"<<std::endl;
		}
//			std::cout<<"Shortest gap was "<<shortestGap<<" seconds"<<std::endl;

		return true;
	}

    void cloud_cb(const sensor_msgs::PointCloudConstPtr& point_cloud)
    {
    	boost::unique_lock<boost::mutex> lock(m_data_lock);
    	ROS_INFO("--Cloud callback:%f", point_cloud->header.stamp.toSec());
    	m_currentCloudPtr = point_cloud;
    	//TODO: remove
    	this->processCloud(m_currentCloudPtr);
    }

    void image_cb(const sensor_msgs::ImageConstPtr& image_pointer)
    {
    	boost::unique_lock<boost::mutex> lock(m_data_lock);
    	ROS_INFO ("--Image callback:%f", image_pointer->header.stamp.toSec());
    	m_currentImagePtr = image_pointer;
    }

    void sync_cb()
    {
    	boost::unique_lock<boost::mutex> lock(m_data_lock);
    	ROS_INFO ("--Sync callback");
    	this->processCloud(m_currentCloudPtr);
    }

	void processCloud(const sensor_msgs::PointCloud::ConstPtr &cloud)
	{
		std::cout<<"Incorporating new cloud"<<std::endl;
		bool globalCoords = true;
		bool publishClouds = true;

		//joint angle output. TODO: path parameter
		bool writeJointAngles = true;
		std::string jointAnglesFile = "joints.txt";

		unsigned int skipMod = 1;

		//noise level parameters
		bool addNoise = (m_noiseLevel > 0);
		float maxNoisePerFrame = m_noiseLevel;

		//whether to try to compensate for delays in stereo processing using timestamps
		bool compareTimeStamps = m_useJointState;

		//maximum duration to go for (un-scaled time)
		float maxLength = m_terminationTime;

		//update cloud counters and such
		if(m_cloudCount == 0)
			m_firstStamp = cloud.get()->header.stamp;
		m_cloudCount++;
		ros::Duration seqDur = cloud.get()->header.stamp - m_firstStamp;
		std::cout<<"Gone for "<<seqDur.toSec()<<" seconds so far "<<std::endl;

		//stop if we've gone as far as we want
		if(seqDur.toSec() >= maxLength && maxLength > 0){
			std::cout<<"Max cloud count reached. Exiting"<<std::endl;
			ros::shutdown();
			return;
		}

		//may want to skip every other since we have to have a message queue of at least 1
		//also make sure that there is a state to read
		if(m_cloudCount % skipMod == 1 || !m_handStateReady || !m_wamStateReady)
			return;


		ros::Time startTime = ros::Time::now();

		unsigned int stateNum;
		if(compareTimeStamps){
			bool anglesFound = getStateNum(cloud.get()->header.stamp,stateNum);
			if(!anglesFound)
				return;
		}
		else{
			stateNum = 1;
		}
		std::vector<float> reported = m_reportedStateHistory[stateNum];
		std::vector<float> actualReported = reported;

		//add in noise artificially
		if(addNoise){
			//add some more noise into the accumulated angle drift
			//and add the noise into the reported state
			for(unsigned int j=0; j<m_noise.size(); j++){
				//TODO: normally distributed
				int rand100 = random() % 100;
				float noiseAmt = (rand100 - 50)/50;
				float angleError =  maxNoisePerFrame * noiseAmt;
				m_noise[j] += angleError ;
				reported[j] += m_noise[j];
			}
		}

		if(!m_initialStateSet){
			std::cout<<"First frame"<<std::endl;
			rgbd::eigen::MatrixXf initCovariance = m_filter.getInitialCovariance();
			m_filter.setInitialState(reported,initCovariance);
			m_initialStateSet = true;
		}

		sensor_msgs::PointCloud realCloud = m_inter.convertCameraToGlobalCoords(*cloud.get());
		realCloud.header.stamp = ros::Time::now();
		realCloud.header.frame_id = m_tf_frame;

		bool doUpdate = true;
		std::vector<float> icpResult;
		if(doUpdate){
			if(!m_useCameraImages)
				m_filter.performUpdate(reported,realCloud,globalCoords);
			else
				m_filter.performUpdate(reported,realCloud,globalCoords,m_currentImagePtr);
			icpResult = m_filter.getLastICPResult();
		}
		else{
			icpResult=reported;
		}

		std::vector<float> mean;
		rgbd::eigen::MatrixXf cov;
		m_filter.getState(mean,cov);

		std::vector<float> meanAngles;
		rgbd::eigen::Matrix<float,7,1> calibAdj,objectAdj;
		separateOutStateToVectors(mean,meanAngles,calibAdj,objectAdj);

//		std::cout<<"Reported, Recovered"<<std::endl;
//		for(unsigned int j=0; j<reported.size(); j++){
//			std::cout<<reported[j]<<", "<<mean[j]<<std::endl;
//		}

		ros::Time endTime = ros::Time::now();

		if(publishClouds){
			this->publishClouds(realCloud,reported,icpResult,meanAngles);
			m_inter.setJointAngles(reported);
//			m_inter.runViewer();
		}

		if(writeJointAngles){
			this->writeJointAngles(jointAnglesFile,actualReported,reported,icpResult,meanAngles);
		}

		ros::Duration dur=endTime-startTime;
		std::cout<<"Total update time, excluding publishing clouds is "<<(dur.toSec())<<" seconds"<<std::endl;

		m_processedTime += dur.toSec();
		m_processedClouds++;
		std::cout<<"Average processing time per frame so far: "<<m_processedTime/m_processedClouds<<std::endl;
	}

	void publishClouds(
			sensor_msgs::PointCloud const& realCloud,
			std::vector<float> const& reported,
			std::vector<float> const& icpResult,
			std::vector<float> const& meanAngles)
	{
		bool globalCoords = true;

		std::cout<<"Publishing clouds "<<std::endl;
		sensor_msgs::PointCloud simulatedCloud,ICPCloud,recoveredCloud,segmentCloud;

		std::vector<rgbd::eigen::Vector3f> toRegister;
		std::vector<rgbd::eigen::Vector3f> newPoints,newNormals;
		std::vector<OpenRAVE::KinBody::LinkPtr > links;
		std::vector<rgbd::eigen::Vector3f> normals;
		std::vector<rgbd::eigen::Vector3f> colors;
		std::vector<float> acquisitionAngles;
		m_filter.getLastPointsToRegister(toRegister,links,normals,acquisitionAngles);

		//get the simulated cloud
		colors = std::vector<rgbd::eigen::Vector3f>(toRegister.size(),rgbd::eigen::Vector3f(1.0,1.0,1.0));
		m_inter.getNewPointLocations(toRegister,links,acquisitionAngles,reported,newPoints,globalCoords,globalCoords);
		m_inter.getNewNormals(normals,links,acquisitionAngles,reported,newNormals,globalCoords,globalCoords);
		m_inter.generatePointCloud(simulatedCloud,newPoints,colors,newNormals);

		//get the ICP cloud
		colors = std::vector<rgbd::eigen::Vector3f>(toRegister.size(),rgbd::eigen::Vector3f(1.0,0.0,0.0));
		m_inter.getNewPointLocations(toRegister,links,acquisitionAngles,icpResult,newPoints,globalCoords,globalCoords);
		m_inter.getNewNormals(normals,links,acquisitionAngles,icpResult,newNormals,globalCoords,globalCoords);
		m_inter.generatePointCloud(ICPCloud,newPoints,colors,newNormals);

		//get the Kalman cloud
		colors = std::vector<rgbd::eigen::Vector3f>(toRegister.size(),rgbd::eigen::Vector3f(0.0,0.0,1.0));
		m_inter.getNewPointLocations(toRegister,links,acquisitionAngles,meanAngles,newPoints,globalCoords,globalCoords);
		m_inter.getNewNormals(normals,links,acquisitionAngles,meanAngles,newNormals,globalCoords,globalCoords);
		m_inter.generatePointCloud(recoveredCloud,newPoints,colors,newNormals);


		//get the cloud with JUST the object (in wrist coordinates)
		segmentCloud = m_filter.getDownsampledObjectCloud();
		segmentCloud.header.frame_id = m_tf_frame;

		sensor_msgs::PointCloud targetCloud = m_filter.getLastTargetCloud();
		targetCloud.header.frame_id = m_tf_frame;

		sensor_msgs::PointCloud colorizedCloud = m_filter.getColorizedCloud();
		colorizedCloud.header.frame_id = m_tf_frame;

		publishNormalLines(targetCloud,m_normalsPublisher,m_tf_frame,.01,.0001);
		publishCorrespondenceLines(ICPCloud,0.0001);

		sensor_msgs::PointCloud visMarker;
		visMarker.set_points_size(1);
		visMarker.set_channels_size(3);
		int markerLink = 14; //THUMB
		rgbd::eigen::Vector3f locInLink(0.03708,0.00205,-0.00972);
		rgbd::eigen::Transform3f markerTransform = m_inter.getLinkTransform(reported,markerLink);
		rgbd::eigen::Vector3f globalPoint = markerTransform * locInLink;
		visMarker.points[0].x = globalPoint.x();
		visMarker.points[0].y = globalPoint.y();
		visMarker.points[0].z = globalPoint.z();
		visMarker.channels[0].name = "r";
		visMarker.channels[0].set_values_size(1);
		visMarker.channels[0].values[0] = 0;
		visMarker.channels[1].name = "g";
		visMarker.channels[1].set_values_size(1);
		visMarker.channels[1].values[0] = 1.0;
		visMarker.channels[2].name = "b";
		visMarker.channels[2].set_values_size(1);
		visMarker.channels[2].values[0] = 0;
		visMarker.header.frame_id = m_tf_frame;
		std::cout<<"publishing visual marker"<<std::endl;
		m_visualPointPublisher.publish(visMarker);
		std::cout<<std::endl;


		double maxRadius;
		m_node.param("radius_downsample_radius",maxRadius,1.0);
		sensor_msgs::PointCloud radiusRemovedCloud;
		radiusRemovedCloud.header.stamp = ros::Time::now();
		radiusRemovedCloud.header.frame_id = m_tf_frame;
		rgbd::eigen::Vector3f center = rgbd::eigen::Vector3f::Zero();
		std::deque<unsigned int> indices =
				getRadiusDownsamplingIndices(realCloud,center,maxRadius,true);
		downsampleFromIndices(realCloud,radiusRemovedCloud,indices);

		std::cout<<"publishing simulated cloud with "<<simulatedCloud.points.size()<<" points"<<std::endl;
		m_simulatedCloudPublisher.publish(simulatedCloud);
		std::cout<<"publishing real (radius removed) cloud with "<<radiusRemovedCloud.points.size()<<" points"<<std::endl;
		m_realCloudPublisher.publish(radiusRemovedCloud);
		std::cout<<"publishing target cloud with "<<targetCloud.points.size()<<" points"<<std::endl;
		m_targetCloudPublisher.publish(targetCloud);
		std::cout<<"publishing icp cloud with "<<ICPCloud.points.size()<<" points"<<std::endl;
		m_icpCloudPublisher.publish(ICPCloud);
		std::cout<<"publishing recovered cloud with "<<recoveredCloud.points.size()<<" points"<<std::endl;
		m_kalmanCloudPublisher.publish(recoveredCloud);
		std::cout<<"publishing segment cloud with "<<segmentCloud.points.size()<<" points"<<std::endl;
		m_segmentPublisher.publish(segmentCloud);
		std::cout<<"publishing colorized cloud with "<<colorizedCloud.points.size()<<" points"<<std::endl;
		m_colorizedCloudPublisher.publish(colorizedCloud);
	}

	void writeJointAngles(
			std::string jointAnglesFile,
			std::vector<float> const& actualReported,
			std::vector<float> const& reported,
			std::vector<float> const& icpResult,
			std::vector<float> const& meanAngles
			)
	{
		ofstream anglesOutput;
		anglesOutput.open(jointAnglesFile.c_str(),ios_base::app);

		anglesOutput<<"Angles for cloud "<<m_cloudCount<<std::endl;

		anglesOutput<<"Real: ";
		for(unsigned int i=0; i<actualReported.size(); i++){
			anglesOutput<<actualReported[i];
			if(i < (actualReported.size() -1))
					anglesOutput<<", ";
		}
		anglesOutput<<std::endl;

		anglesOutput<<"With Noise: ";
		for(unsigned int i=0; i<reported.size(); i++){
			anglesOutput<<reported[i];
			if(i < (reported.size() -1))
					anglesOutput<<", ";
		}
		anglesOutput<<std::endl;

		anglesOutput<<"ICP Result: ";
		for(unsigned int i=0; i<icpResult.size(); i++){
			anglesOutput<<icpResult[i];
			if(i < (icpResult.size() -1))
					anglesOutput<<", ";
		}
		anglesOutput<<std::endl;

		anglesOutput<<"Kalman Mean: ";
		for(unsigned int i=0; i<meanAngles.size(); i++){
			anglesOutput<<meanAngles[i];
			if(i < (meanAngles.size() -1))
					anglesOutput<<", ";
		}
		anglesOutput<<std::endl;

		anglesOutput<<"End effector positions for "<<m_cloudCount<<std::endl;

		anglesOutput<<"Real: ";
		rgbd::eigen::Vector3f actualPos = m_inter.getEndEffectorLocation(actualReported);
		for(int i=0; i<actualPos.size(); i++){
			anglesOutput<<actualPos(i);
			if(i < (actualPos.size() -1))
					anglesOutput<<", ";
		}
		anglesOutput<<std::endl;

		anglesOutput<<"With Noise: ";
		rgbd::eigen::Vector3f noisePos = m_inter.getEndEffectorLocation(reported);
		for(int i=0; i<noisePos.size(); i++){
			anglesOutput<<noisePos(i);
			if(i < (noisePos.size() -1))
					anglesOutput<<", ";
		}
		anglesOutput<<std::endl;

		anglesOutput<<"ICP Result: ";
		rgbd::eigen::Vector3f icpPos = m_inter.getEndEffectorLocation(icpResult);
		for(int i=0; i<icpPos.size(); i++){
			anglesOutput<<icpPos(i);
			if(i < (icpPos.size() -1))
					anglesOutput<<", ";
		}
		anglesOutput<<std::endl;

		anglesOutput<<"Kalman Mean: ";
		rgbd::eigen::Vector3f kalmanPos = m_inter.getEndEffectorLocation(meanAngles);
		for(int i=0; i<kalmanPos.size(); i++){
			anglesOutput<<kalmanPos(i);
			if(i < (kalmanPos.size() -1))
					anglesOutput<<", ";
		}
		anglesOutput<<std::endl;

		anglesOutput.flush();
		anglesOutput.close();
	}

	void publishCorrespondenceLines(sensor_msgs::PointCloud &source,float width)
	{
		bool fixedCorrsOnly = false;

		std::vector<unsigned int> correspondenceIndices;
		std::vector<bool> useCorrespondence;
		std::vector<float> correspondenceWeights;
		m_filter.getLastICPCorrespondences(correspondenceIndices,useCorrespondence,correspondenceWeights);
		std::vector<rgbd::eigen::Vector3f> target = m_filter.getLastTargetPoints();

	      visualization_msgs::Marker marker;
	      marker.header.frame_id = m_tf_frame;
	      marker.header.stamp = ros::Time();
	      marker.ns = "correspondence_lines_ns";
	      marker.id = 0;
	      marker.type = visualization_msgs::Marker::LINE_LIST;
	      marker.action = visualization_msgs::Marker::ADD;
	      marker.pose.position.x = 0;
	      marker.pose.position.y = 0;
	      marker.pose.position.z = 0;
	      marker.pose.orientation.x = 0.0;
	      marker.pose.orientation.y = 0.0;
	      marker.pose.orientation.z = 0.0;
	      marker.pose.orientation.w = 1.0;
	      marker.scale.x = width;
	      marker.scale.y = 1;
	      marker.scale.z = 1;
	      marker.color.a = 1.0;
	      marker.color.r = 0.0;
	      marker.color.g = 1.0;
	      marker.color.b = 0.0;

	      unsigned int start = 0;
	      unsigned int end = source.points.size();
	      if(fixedCorrsOnly){
	    	  m_filter.getLastFixedPointRange(start,end);
	      }

	      std::deque<std::pair<geometry_msgs::Point32,geometry_msgs::Point32> > pointPairs;
	      for(unsigned int i=start; i<end; i++){
	    	  if(useCorrespondence[i]){
	    		  geometry_msgs::Point32 pt;
	    		  pt.x = target[correspondenceIndices[i]].x();
	    		  pt.y = target[correspondenceIndices[i]].y();
	    		  pt.z = target[correspondenceIndices[i]].z();
	    		  pointPairs.push_back(std::pair<geometry_msgs::Point32,geometry_msgs::Point32>(
	    				  source.points[i],pt));
	    	  }
	      }

	      int nr_points = pointPairs.size();
	      marker.points.resize (2 * nr_points);
	      for (int i = 0; i < nr_points; i++)
	      {
	          marker.points[2*i].x = pointPairs.front().first.x;
	          marker.points[2*i].y = pointPairs.front().first.y;
	          marker.points[2*i].z = pointPairs.front().first.z;
	          marker.points[2*i+1].x = pointPairs.front().second.x;
	          marker.points[2*i+1].y = pointPairs.front().second.y;
	          marker.points[2*i+1].z = pointPairs.front().second.z;
	          pointPairs.pop_front();
	      }

	      m_markerPublisher.publish (marker);
	      ROS_INFO ("Published %d correspondence lines", nr_points);
	}


};
}


int main(int argc, char** argv)
{

	ros::init (argc, argv,"kalman_node");
	ros::NodeHandle ros_node("~");
	ROS_INFO ("Starting main...");

	registration::KalmanNode node(ros_node);
	return (node.start());
}

