/*
 * icp_combined_test.cpp
 *
 *  Created on: Feb 16, 2010
 *      Author: peter
 */

#include <iostream>
#include <boost/make_shared.hpp>
#include "xforms/xforms.h"
#include "pcl_rgbd/cloudUtils.h" //transform_point_cloud()
#include "point_cloud_icp/registration/icp_combined.h"
using namespace registration;

int main (int argc, char** argv)
{
	pcl::PointCloud<rgbd::pt> random_cloud;
	int max_coordinate_value = 10;
	int point_count = 10;
	random_cloud.points.resize(point_count);
	for (int i = 0; i < point_count; i++) {
		random_cloud.points[i].x = rand() % max_coordinate_value;
		random_cloud.points[i].y = rand() % max_coordinate_value;
		random_cloud.points[i].z = rand() % max_coordinate_value;
	}

	// one way to initialize a transform
	// (rotation:) w x y z (translation:) x y z
	// converter normalizes quaternion
	std::vector<float> transform_as_vector(7, 0.0f);
	// rotation part:
	transform_as_vector[0] = 1.0; // w
	transform_as_vector[1] = 0.0; // x
	transform_as_vector[2] = 0.0; // y
	transform_as_vector[3] = 0.0; // z
	// translation part
	transform_as_vector[4] = 2.0;
	transform_as_vector[5] = 5.0;
	transform_as_vector[6] = 0.0;

	rgbd::eigen::Affine3f transform;
	xf::convertSTDVectorToTransform(transform_as_vector, transform);

	// now apply this transform to the random cloud
	pcl::PointCloud<rgbd::pt> source = random_cloud, target;
	rgbd::transform_point_cloud(transform, source, target, true);

	// debug:
//	std::cout << "Source cloud:" << std::endl;
//	for (unsigned int i = 0; i < source.get_points_size(); i++) {
//		std::cout << "(" << source.points[i].x << "," << source.points[i].y << "," << source.points[i].z << ")" << std::endl;
//	}
//	std::cout << "Target cloud:" << std::endl;
//	for (unsigned int i = 0; i < target.get_points_size(); i++) {
//		std::cout << "(" << target.points[i].x << "," << target.points[i].y << "," << target.points[i].z << ")" << std::endl;
//	}

	// Now initialize ICP:
	registration::ICPCombinedParams global_params;
	// these are reasonable values:
	global_params.max_lm_rounds = 50;
	global_params.max_icp_rounds = 1000; // will terminate before this due to error converging
	global_params.min_error_frac_to_continue = 0.001;

	ICPCombined icp_combined;
	icp_combined.setParams(global_params);

	// add this cloud pair to ICP Combined
	ICPCloudPairParams pair_params;
	pair_params.errType = ICP_ERR_POINT_TO_POINT; // Can also do point to plane error, but requires the target cloud to have normals in "nx", "ny", "nz", which our random cloud doesn't
	pair_params.corrType = ICP_CORRS_SINGLE_TREE;
	pair_params.wtType = ICP_WTS_SCALAR;
	pair_params.fixed_correspondence = false;
	pair_params.max_distance = -1;

	const boost::shared_ptr<ICPCloudPair> cloudPair (new ICPCloudPair(pair_params, source, target));
	cloudPair->setScalarWeights();
	icp_combined.addCloudPair(cloudPair);

	std::cout << "Starting ICP..." << std::endl;

	//icp_combined.setInitialTransform(whatever)
	rgbd::eigen::Affine3f icp_transform;
	bool icp_success = icp_combined.runICP(icp_transform);

	std::cout << "ICP Success:" << icp_success << std::endl;
	std::cout << "Desired Transform:\n" << xf::getTransformString(transform) << std::endl;
	std::cout << "ICP Transform:\n" << xf::getTransformString(icp_transform) << std::endl;

	// apply the transform to a point
	rgbd::eigen::Vector3f test_point(0,0,0);
	rgbd::eigen::Vector3f test_transformed = icp_transform * test_point;
	return 0;
}
