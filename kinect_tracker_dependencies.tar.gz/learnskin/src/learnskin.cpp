#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>
#include <math.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <cmath>
#include <queue>

#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <cv_bridge/CvBridge.h>
#include <image_transport/image_transport.h>

#include <ros/ros.h>
#include <ros/subscriber.h>
#include <rgbd_util/ros_utility.h>
#include <sensor_msgs/Image.h>
#include <rgbd_msgs/DepthMap.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>

#include <pcl/point_cloud.h>
#include <pcl/features/integral_image_normal.h>
#include <pcl/features/normal_3d.h>
#include <pcl/io/pcd_io.h>
#include <pcl/ros/conversions.h>
#include <pcl_ros/publisher.h>

#include "pcl_rgbd/depth_to_cloud_lib.h"
#include "pcl_rgbd/cloudUtils.h"
#include "pcl_rgbd/cloudTofroPLY.h"
#include "pcl_rgbd/cloudGeometry.h"
#include "pcl_rgbd/pointTypes.h"

#include <GL/glut.h>    // Header File For The GLUT Library
#include <GL/gl.h>	// Header File For The OpenGL32 Library
#include <GL/glu.h>	// Header File For The GLu32 Library
#include <GL/glext.h>

#define GLH_EXT_SINGLE_FILE
#include <glh/glh_extensions.h>
#include <glh/glh_obs.h>
#include <glh/glh_glut.h>
#include <glh/glh_glut_text.h>
#include <glh/glh_genext.h>
#include <glh/glh_convenience.h>
#include <glh/glh_text.h>
#include <glh/glh_linear.h>

#include "svm.h"

#define PI 3.14159265

using namespace std;
using namespace glh;

#define ESCAPE 27

#define	SKIN	0
#define	NOTSKIN	1
#define	CLEAR	2
#define	LEARN	3
#define	NOP		4
#define	SET_RGB	5
#define	SET_HSV	6
#define	WRITE	7

vector<float> skin;
vector<float> notskin;

struct svm_problem data;
struct svm_model *model;

int window;
int               rc;
struct timespec   ts;
struct timeval    tp;

#define	NUMBINS	64

int colors[NUMBINS][NUMBINS][NUMBINS];
int skins, notskins;

#define	RGB	10
#define	HSV	11

pthread_mutex_t mutex;
typedef rgbd::pt PointT;

int mode;
int featuretype;
int _width, _height;

std::string files_path_global;

void rgb2hsv(double r, double g, double b, double &h, double &s, double &v)
{
	h = 0;	s = 0;	v = 0;
	double M = max(r, max(g, b));
	v = M;
	double alpha = (2*r-g-b)/2;
	double beta = sqrt(3)*(g-b)/2;
	h = atan2(beta, alpha);
	if(h<0)
		h += M_PI;
	h /= 2*M_PI;
	double c = sqrt(alpha*alpha + beta*beta);
	if(abs(v)>0.00001)
		s = c/v;
	else
		s = 0;
}

void color2feature(double r, double g, double b, vector<double> &feature)
{
	double h, s, v;
	feature.clear();
	switch(featuretype){
	case RGB:
		feature.push_back(r);
		feature.push_back(b);
		feature.push_back(b);
		break;
	case HSV:
		rgb2hsv(r, g, b, h, s, v);
		feature.push_back(h);
		feature.push_back(s);
		feature.push_back(v);
		break;
	default:
		feature.push_back(0);
		feature.push_back(0);
		feature.push_back(0);
		break;
	};
}

void saveColorPalletes()
{
	IplImage* skinimg = cvCreateImage(cvSize(2000,2000), IPL_DEPTH_8U, 3);
	IplImage* notskinimg = cvCreateImage(cvSize(2000,2000), IPL_DEPTH_8U, 3);

	for(int y=0;y<2000;y++)
		for(int x=0;x<2000;x++)
		{
			skinimg->imageData[y*skinimg->widthStep + x*skinimg->nChannels + 0] = (char)(0);
			skinimg->imageData[y*skinimg->widthStep + x*skinimg->nChannels + 1] = (char)(0);
			skinimg->imageData[y*skinimg->widthStep + x*skinimg->nChannels + 2] = (char)(0);
			notskinimg->imageData[y*notskinimg->widthStep + x*notskinimg->nChannels + 0] = (char)(0);
			notskinimg->imageData[y*notskinimg->widthStep + x*notskinimg->nChannels + 1] = (char)(0);
			notskinimg->imageData[y*notskinimg->widthStep + x*notskinimg->nChannels + 2] = (char)(0);
		}

	skins = 0;
	notskins = 0;
	for(int r=0;r<NUMBINS;r++)
		for(int g=0;g<NUMBINS;g++)
			for(int b=0;b<NUMBINS;b++)
			{
				if(colors[r][g][b]==1)
					skins ++;
				else
					notskins++;
			}

	ROS_INFO_STREAM("Skins: "<<skins);
	ROS_INFO_STREAM("Not-skins: "<<notskins);

	int stepsk = (int)(2000.0f/sqrt(skins));
	int stepns = (int)(2000.0f/sqrt(notskins));

	ROS_INFO_STREAM("Skin step: "<<stepsk);
	ROS_INFO_STREAM("Not-skin step: "<<stepns);

	int skx=0, sky=0, nsx=0, nsy=0;
	for(int r=0;r<NUMBINS;r++)
		for(int g=0;g<NUMBINS;g++)
			for(int b=0;b<NUMBINS;b++)
			{
				if(colors[r][g][b]==1)
				{
					skins ++;
					// update skin image
					for(int x=0;x<stepsk;x++)
						for(int y=0;y<stepsk;y++)
						{
							// set (skx+x, sky+y) pixel to the color
							if(skx+x < 0 || skx+x>=2000 || sky+y < 0 || sky+y>=2000)
								continue;
							skinimg->imageData[(sky+y)*skinimg->widthStep + (skx+x)*skinimg->nChannels + 0] = (char)(255*b/NUMBINS);
							skinimg->imageData[(sky+y)*skinimg->widthStep + (skx+x)*skinimg->nChannels + 1] = (char)(255*g/NUMBINS);
							skinimg->imageData[(sky+y)*skinimg->widthStep + (skx+x)*skinimg->nChannels + 2] = (char)(255*r/NUMBINS);
						}
					skx+=stepsk;
					if(skx>=2000)
					{
						skx = 0;
						sky += stepsk;
					}
				}
				else
				{
					notskins++;
					// update notskin image
					for(int x=0;x<stepns;x++)
						for(int y=0;y<stepns;y++)
						{
							// set (nsx+x, nsy+y) pixel to the color
							if(nsx+x < 0 || nsx+x>=2000 || nsy+y < 0 || nsy+y>=2000)
								continue;
							notskinimg->imageData[(nsy+y)*notskinimg->widthStep + (nsx+x)*notskinimg->nChannels + 0] = (char)(255*b/NUMBINS);
							notskinimg->imageData[(nsy+y)*notskinimg->widthStep + (nsx+x)*notskinimg->nChannels + 1] = (char)(255*g/NUMBINS);
							notskinimg->imageData[(nsy+y)*notskinimg->widthStep + (nsx+x)*notskinimg->nChannels + 2] = (char)(255*r/NUMBINS);
						}
					nsx+=stepns;
					if(nsx>=2000)
					{
						nsx = 0;
						nsy += stepns;
					}
				}
			}


	std::string skin_name = files_path_global;
	skin_name.append("data/skin.png");
//	cvSaveImage("/home/ankit/data/skin.png", skinimg);
	cvSaveImage(skin_name.c_str(), skinimg);

	std::string no_skin_name = files_path_global;
	no_skin_name.append("data/notskin.png");
	cvSaveImage(no_skin_name.c_str(), notskinimg);
//	cvSaveImage("/home/ankit/data/notskin.png", notskinimg);

	cvReleaseImage(&skinimg);
	cvReleaseImage(&notskinimg);
}

void clearModel()
{
	for(int r=0;r<NUMBINS;r++)
		for(int g=0;g<NUMBINS;g++)
			for(int b=0;b<NUMBINS;b++)
				colors[r][g][b] = 0;
}

void learnColorModel()
{
	int numskin = skin.size();
	int rbin, gbin, bbin;

	ROS_INFO_STREAM("Learning skin color from "<<numskin<<" points");

	for(int i=0;i<numskin;i++)
	{
		float rgb = skin[i];
		boost::array<float, 3> fcolor = rgbd::unpackRGB<float>(rgb);
		rbin = (int)max(0.0f, min(1.0f*NUMBINS-1, fcolor[0]*NUMBINS));
		gbin = (int)max(0.0f, min(1.0f*NUMBINS-1, fcolor[1]*NUMBINS));
		bbin = (int)max(0.0f, min(1.0f*NUMBINS-1, fcolor[2]*NUMBINS));

		int inc = 1;

		for(int rr=rbin-inc;rr<=rbin+inc;rr++)
			for(int gg=gbin-inc;gg<=gbin+inc;gg++)
				for(int bb=bbin-inc;bb<=bbin+inc;bb++)
					if(rr>=0 && rr<NUMBINS && gg>=0 && gg<NUMBINS && bb>=0 && bb<NUMBINS)
						colors[rr][gg][bb] = 1;
	}

	/*
	if(
		!(true
						|| (fcolor[0]>fcolor[2] && fcolor[1]>fcolor[2] && fcolor[2]>0.6)
						|| (fcolor[0]>0.4 && fcolor[1]>0.4 && fcolor[2]>0.4 && sat<0.1)
						|| sat>0.5
				)
		)
		*/

	// know about the blocks
	for(int r=0;r<NUMBINS;r++)
		for(int g=0;g<NUMBINS;g++)
			for(int b=0;b<NUMBINS;b++)
			{
				float sat = max(1.0f*r, max(1.0f*g, 1.0f*b)) - min(1.0f*r, max(1.0f*g, 1.0f*b));
				if(g>r || b>r || (r>NUMBINS-5 && g>NUMBINS-5 && b>NUMBINS-5) || sat>0.5*NUMBINS)
					colors[r][g][b] = 0;
			}

	saveColorPalletes();

	ROS_INFO_STREAM("Learned the model");
}

void learnSVM()
{
	// clear svm_problem first
	ROS_INFO_STREAM("Clearing previous instance of SVM problem");
	clearModel();

	// put the training data into the svm_problem structure
	ROS_INFO_STREAM("Putting the skin data in problem");
	data.l = skin.size() + notskin.size();
	data.y = new double[data.l];
	data.x = new svm_node*[data.l];
	for(int i=0;i<data.l;i++)
		data.x[i] = new svm_node[4];

	int count = 0;
	for(int i=0;i<(int)skin.size();i++)
	{
		float rgb = skin[i];
		boost::array<float, 3> col = rgbd::unpackRGB<float>(rgb);
		vector<double> feature;
		color2feature(col[0], col[1], col[2], feature);
		data.y[count] = 1;
		for(int j=0;j<3;j++)
		{
			data.x[count][j].index = j+1;
			data.x[count][j].value = feature[j];
		}
		data.x[count][3].index = -1;
		data.x[count][3].value = 0;
		count++;
	}

	ROS_INFO_STREAM("Putting the not-skin data in problem");
	for(int i=0;i<(int)notskin.size();i++)
	{
		float rgb = notskin[i];
		boost::array<float, 3> col = rgbd::unpackRGB<float>(rgb);
		vector<double> feature;
		color2feature(col[0], col[1], col[2], feature);
		data.y[count] = 2;
		for(int j=0;j<3;j++)
		{
			data.x[count][j].index = j+1;
			data.x[count][j].value = feature[j];
		}
		data.x[count][3].index = -1;
		data.x[count][3].value = 0;
		count++;
	}

	ROS_INFO_STREAM("Skin size: " << skin.size());
	ROS_INFO_STREAM("Not-skin size: " << notskin.size());

	struct svm_parameter params;
	params.svm_type = NU_SVC;
	//params.svm_type = ONE_CLASS;
	params.kernel_type = RBF;
	params.nu = 0.1;
	params.cache_size = 100;
	params.eps = 0.00001;
	params.gamma = 0.25;

	// train the SVM model
	ROS_INFO_STREAM("Training the color model");
	model = svm_train(&data, &params);

	// classify the colors now
	ROS_INFO_STREAM("Classifying the color bins");
	svm_node* test = new svm_node[4];
	skins = 0;
	notskins = 0;
	for(int r=0;r<NUMBINS;r++)
		for(int g=0;g<NUMBINS;g++)
			for(int b=0;b<NUMBINS;b++)
			{
				double col[3];
				col[0] = (1.0f*r)/NUMBINS;
				col[1] = (1.0f*g)/NUMBINS;
				col[2] = (1.0f*b)/NUMBINS;
				vector<double> feature;
				color2feature(col[0], col[1], col[2], feature);
				for(int i=0;i<3;i++)
				{
					test[i].index = i+1;
					test[i].value = feature[i];
				}
				test[3].index = -1;	test[3].value = 0;

				int label = (int)svm_predict(model, test);
				if(g>r)
					label = 2;
				else if(b>r)
					label = 2;
				colors[r][g][b] = label;

				if(label==1)
					skins++;
				else
					notskins++;
			}
//	delete(test);

	ROS_INFO_STREAM("Saving the color palletes, skins = "<<skins<<", not-skins = "<<notskins);
	saveColorPalletes();
}

class GLManager
{
public:
	static void InitGL(int Width, int Height);
	static void ReSizeGLScene(int Width, int Height);
	static void keyPressed(unsigned char key,int x,int y);
	static void DrawGLScene();
	void cleanup();
	void start();
	static void removeOccludedPoints();
	static void empty()
	{
	}
};

void GLManager::InitGL(int Width, int Height)	        // We call this right after our OpenGL window is created.
{
	glClearDepth(1.0);				// Enables Clearing Of The Depth Buffer
	glDepthFunc(GL_LESS);			        // The Type Of Depth Test To Do
	glEnable(GL_BLEND);
	glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}

void GLManager::keyPressed(unsigned char key,int x,int y)
{
	ROS_INFO_STREAM("Key pressed: "<<key<<", x: "<<x<<", y: "<<y);
	switch(key){
	case 's':
		pthread_mutex_lock(&mutex);
		mode = SKIN;
		pthread_mutex_unlock(&mutex);
		break;
	case 'n':
		pthread_mutex_lock(&mutex);
		mode = NOTSKIN;
		pthread_mutex_unlock(&mutex);
		break;
	case 'c':
		pthread_mutex_lock(&mutex);
		mode = CLEAR;
		pthread_mutex_unlock(&mutex);
		break;
	case 'l':
		pthread_mutex_lock(&mutex);
		mode = LEARN;
		pthread_mutex_unlock(&mutex);
		break;
	case 'r':
		pthread_mutex_lock(&mutex);
		mode = SET_RGB;
		pthread_mutex_unlock(&mutex);
		break;
	case 'h':
		pthread_mutex_lock(&mutex);
		mode = SET_HSV;
		pthread_mutex_unlock(&mutex);
		break;
	case 'w':
		pthread_mutex_lock(&mutex);
		mode = WRITE;
		pthread_mutex_unlock(&mutex);
		break;
	default:
		pthread_mutex_lock(&mutex);
		mode = NOP;
		pthread_mutex_unlock(&mutex);
		break;
	}
}

void GLManager::ReSizeGLScene(int Width, int Height)
{
	if (Height==0)				// Prevent A Divide By Zero If The Window Is Too Small
		Height=1;

	_width = Width;
	_height = Height;
	glViewport(0, 0, _width, _height);		// Reset The Current Viewport And Perspective Transformation
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();				// Reset The Projection Matrix

	gluPerspective(55.0f,(GLfloat)_width/(GLfloat)_height,0.0001f,200.0f);

	glMatrixMode (GL_MODELVIEW);
}

void GLManager::DrawGLScene()
{

	glViewport(0, 0, _width, _height);		// Reset The Current Viewport And Perspective Transformation

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();				// Reset The Projection Matrix

	gluPerspective(55.0f,(GLfloat)_width/(GLfloat)_height,0.0001f,200.0f);

	glMatrixMode (GL_MODELVIEW);

	glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);	// Clear The Screen And The Depth Buffer
	glLoadIdentity();

	gluLookAt(0,0,0,0,0,1,0,-1,0);

	GLfloat mat_specular[] = { 1, 1, 1, 1.0 };
	GLfloat mat_shininess[] = { 50 };
	GLfloat light_position0[] = { -1.0, 1.0, -1.0, 1.0 };
	GLfloat light_position1[] = { 1.0, 1.0, -1.0, 1.0 };
	GLfloat light_position2[] = { -1.0, 1.0, 1.0, 1.0 };
	GLfloat light_position3[] = { 1.0, 1.0, 1.0, 1.0 };
	GLfloat light_diffuse[] = { 0.5, 0.5, 0.5, 1.0 };

	glShadeModel (GL_SMOOTH);

	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
	glLightfv(GL_LIGHT0, GL_POSITION, light_position0);
	glLightfv(GL_LIGHT1, GL_POSITION, light_position1);
	glLightfv(GL_LIGHT2, GL_POSITION, light_position2);
	glLightfv(GL_LIGHT3, GL_POSITION, light_position3);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, light_diffuse);
	glLightfv(GL_LIGHT2, GL_DIFFUSE, light_diffuse);
	glLightfv(GL_LIGHT3, GL_DIFFUSE, light_diffuse);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);
	glEnable(GL_LIGHT2);
	glEnable(GL_LIGHT3);
	glEnable(GL_DEPTH_TEST);

	// swap the buffers to display, since double buffering is used.
	glutSwapBuffers();
}

void GLManager::cleanup()
{
}

void GLManager::start()
{
	_width = 640;
	_height = 480;

	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_ALPHA | GLUT_DEPTH);

	glutInitWindowSize(_width, _height);

	glutInitWindowPosition(0, 0);

	window = glutCreateWindow("Skin Learner");

	glutDisplayFunc(&DrawGLScene);

	glutIdleFunc(empty);

	glutReshapeFunc(&ReSizeGLScene);

	glutKeyboardFunc(&keyPressed);

	InitGL(_width, _height);

	glutMainLoop();

	cleanup();
}

class BlockTracker {
public:
	BlockTracker();
	~BlockTracker();

	void start();
	void cloudCallback(sensor_msgs::PointCloud2ConstPtr cloud_ptr);

protected:
	// functions
	void load_ros_params();


	// members
	ros::NodeHandle nh_global;
	ros::NodeHandle nh_local;

	int processed_frame;
	int subscription_buffer_size;
	std::string model_name;
	std::string files_path;

	static const int max_out_of_order = 100;
	ros::Subscriber cloud_subscription;
	pcl_ros::Publisher<PointT> cloud_pub;
};

BlockTracker::BlockTracker()
: nh_global(),
  nh_local("~")
{
	processed_frame = 0;

	load_ros_params();

	cloud_pub.advertise(nh_global, "outcloud", 1);
}

BlockTracker::~BlockTracker()
{
}

void
BlockTracker::load_ros_params()
{
    nh_local.param("subscription_buffer_size", subscription_buffer_size, 1);
    nh_local.param("model_name", model_name, std::string(""));
    nh_local.param("files_path", files_path, std::string(""));
    files_path_global = files_path;
}

void writeColorModel()
{
	fstream f;
	std::string model_name = files_path_global;
	model_name.append("data/colormodel.txt");
//	f.open("/home/ankit/data/colormodel.txt", ios::out);
	f.open(model_name.c_str(), ios::out);
	f<<NUMBINS<<"\t"<<NUMBINS<<"\t"<<NUMBINS<<"\n";
	for(int r=0;r<NUMBINS;r++)
		for(int g=0;g<NUMBINS;g++)
			for(int b=0;b<NUMBINS;b++)
			{
				if(colors[r][g][b]==1)
					f<<"1\t";
				else
					f<<"0\t";
			}
	f.close();
}

void
BlockTracker::cloudCallback(sensor_msgs::PointCloud2ConstPtr cloud_ptr)
{

	cout << "Got points." << endl;

	ros::Time current_frame_timestamp = cloud_ptr->header.stamp;
	pcl::PointCloud<PointT> kcloud;
	pcl::fromROSMsg(*cloud_ptr, kcloud);
	int num_points = kcloud.points.size();

	pthread_mutex_lock(&mutex);


	switch(mode){
	case SKIN:
		for(int i=0;i<num_points;i+=3)
			skin.push_back(kcloud.points[i].rgb);
		ROS_INFO_STREAM("Added data for skin");
		mode = NOP;
		break;
	case NOTSKIN:
		for(int i=0;i<num_points;i+=3)
			notskin.push_back(kcloud.points[i].rgb);
		ROS_INFO_STREAM("Added data for not-skin");
		mode = NOP;
		break;
	case CLEAR:
		ROS_INFO_STREAM("Cleared the learning data");
		clearModel();
		skin.clear();
		notskin.clear();
		mode = NOP;
		break;
	case LEARN:
//		learnSVM();
		ROS_INFO_STREAM("Learning model");
		learnColorModel();
		writeColorModel();
		mode = NOP;
		break;
	case SET_RGB:
		ROS_INFO_STREAM("Feature type set to RGB");
		featuretype = RGB;
		mode = NOP;
		break;
	case SET_HSV:
		ROS_INFO_STREAM("Feature type set to HSV");
		featuretype = HSV;
		mode = NOP;
		break;
	case WRITE:
		ROS_INFO_STREAM("Saving model");
		writeColorModel();
		mode = NOP;
		break;
	default:
		break;
	};
	pthread_mutex_unlock(&mutex);

	if(num_points>50)
	{
		// Convert the kcloud into the cloud as required by point_cloud_icp

		pcl::PointCloud<PointT> pubcloud = kcloud;
		pubcloud.points.clear();
		for(int i=0;i<(int)kcloud.points.size();i++)
		{
			float rgb = kcloud.points[i].rgb;
			boost::array<float, 3> fcolor = rgbd::unpackRGB<float>(rgb);
			int rbin, gbin, bbin;
			rbin = (int)max(0.0f, min(1.0f*NUMBINS-1, fcolor[0]*NUMBINS));
			gbin = (int)max(0.0f, min(1.0f*NUMBINS-1, fcolor[1]*NUMBINS));
			bbin = (int)max(0.0f, min(1.0f*NUMBINS-1, fcolor[2]*NUMBINS));
			if(colors[rbin][gbin][bbin]!=1)
				pubcloud.push_back(kcloud.points[i]);
		}
		pubcloud.height = 1;
		pubcloud.width = pubcloud.points.size();
		cloud_pub.publish(pubcloud);
	}
	processed_frame++;
}

void
BlockTracker::start()
{
	int queue_size = 3; // 0 means unlimited queue...
	cloud_subscription = nh_global.subscribe<sensor_msgs::PointCloud2>("incloud", queue_size, boost::bind(&BlockTracker::cloudCallback, this, _1));

	ros::spin();
}

void *NodeThread(void*)
{
	BlockTracker node;
	node.start();
}

void *RenderThread(void*)
{
	GLManager render;
	render.start();
}

int main (int argc, char** argv)
{
	pthread_mutex_init(&mutex, NULL);
	mode = NOP;
	featuretype = HSV;
	clearModel();
	skin.clear();
	notskin.clear();
	data.l = 0;
	data.x = NULL;
	data.y = NULL;

	ros::init (argc, argv, "SkinLearner");
	glutInit(&argc, argv);

	int rc1, rc2;
	pthread_t thread1, thread2;

	/* Create independent threads each of which will execute functionC */

	if( (rc1=pthread_create( &thread1, NULL, &NodeThread, NULL)) )
	{
		printf("Thread creation failed: %d\n", rc1);
	}

	if( (rc2=pthread_create( &thread2, NULL, &RenderThread, NULL)) )
	{
		printf("Thread creation failed: %d\n", rc2);
	}

	/* Wait till threads are complete before main continues. Unless we  */
	/* wait we run the risk of executing an exit which will terminate   */
	/* the process and all threads before the threads have completed.   */

	pthread_join( thread1, NULL);
	pthread_join( thread2, NULL);
	return 0;
}
